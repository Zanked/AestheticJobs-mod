package dev.aestheticjobs.client;

import dev.aestheticjobs.network.OpenOrderPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

/** Client-only helpers called from common code behind an isClientSide check. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openOrder(OpenOrderPayload payload) {
        Minecraft.getInstance().setScreen(new OrderScreen(payload));
    }

    /** The resume form (hand: 0 main, 1 off hand). */
    public static void openResume(int hand, net.minecraft.world.item.ItemStack stack) {
        Minecraft.getInstance().setScreen(new ResumeScreen(hand, stack));
    }

    /** The interview: a new state from the server updates the open window, or opens it; "close" closes it. */
    public static void openInterview(dev.aestheticjobs.network.InterviewStatePayload payload) {
        Minecraft mc = Minecraft.getInstance();
        if (payload.phase() == dev.aestheticjobs.network.InterviewStatePayload.CLOSE) {
            if (mc.screen instanceof InterviewScreen) mc.setScreen(null);
            return;
        }
        if (mc.screen instanceof InterviewScreen screen && screen.manager() == payload.manager()) {
            screen.update(payload);
        } else {
            mc.setScreen(new InterviewScreen(payload));
        }
    }

    public static void openCoffeeMachine(BlockPos pos) {
        Minecraft.getInstance().setScreen(new CoffeeMachineScreen(pos));
    }
}
