package dev.aestheticjobs.client.barista;

import net.minecraft.core.BlockPos;

/**
 * What the barista's own mini-game wants the REAL machine in the world to show (client only). The server-synced
 * phase of the machine runs on a fixed timer; while the barista plays, the machine shows the true state instead:
 * the stream that appears when the pump is held, the tamper that tilts and presses, the pitcher that hangs on the
 * mouse. The renderer asks for the state of its block; null = nothing is played here, draw the default animation.
 */
public final class LiveMachine {
    /** Where the tip of the steam wand is, in machine pixels (x, y up, z away from the barista). Calibrate to the model. */
    public static final double WAND_X = 15.3, WAND_Y = 2.6, WAND_Z = 5.5;

    /** The middle of the cup's surface, in machine pixels (the liquid is the box IN_X0..IN_X1 x IN_Z0..IN_Z1 in the renderer). */
    public static final double CUP_X = 8.0, CUP_Z = 2.575;

    /** The grinder, to the left of the group head (machine pixels). The face with the controls looks toward the barista (z = GRIND_FACE_Z). */
    public static final double GRIND_FACE_Z = 1.4, CRANK_X = 1.9, CRANK_Y = 8.0, CRANK_R = 1.4;
    /** Dial of the fineness and the three buttons beside it (+, -, test shot), all on the face. */
    public static final double[] DIAL = {4.1, 9.0}, BTN_PLUS = {4.1, 10.0}, BTN_MINUS = {4.1, 7.9}, BTN_TEST = {4.1, 6.7};

    /** The shot (see PullStage). */
    public static final class Live {
        public boolean pumping;
        /** 0..1 of the shot (1 = the cup holds the full espresso). */
        public double level;
        public double jitter, channeling;
        public int stream = 0xFF8A5A30, liquid = 0xFF52332A, surface = 0xFFE0AA78;
    }

    /** The puck and the tamper (see TampStage). Lengths in machine pixels, angles in degrees. */
    public static final class Tamp {
        /** 0..1: how packed the grounds are, and how polished. */
        public double comp, polish;
        /** Gap between the tamper and the grounds; the tamper is drawn only while it is in the picture. */
        public double lift;
        public boolean tamper = true;
        public double offX, offZ, rotX, rotZ;
    }

    /** The milk pitcher (see SteamStage): the centre of its rim, the tilt, what is in it. */
    public static final class Steam {
        public boolean active, valve, inAir, scalded;
        public double x, y, z, tilt, slosh, depth, foam, burn;
    }

    /** The latte art (see PourArtStage): the milk grid is the one of the brew, drawn on the real cup; the pitcher at the pour point. */
    public static final class Pour {
        public float[] milk;
        /** The height of the milk surface in machine pixels, written by the renderer, read by the stage to keep the mouse on it. */
        public double surfaceY = 3.0;
        public int base;
        public double fill, tilt, x, z;
        public boolean pouring, picking, done;
        /** Which way the body of the pitcher leans: +1 / -1 along machine x (always toward the right of the screen). */
        public int dir = 1;
    }

    /** The grinder (see GrindStage): the crank and the dial turn with the barista's hand, the portafilter fills. */
    public static final class Grind {
        /** 0..1.4 of the dose; angles in degrees in the plane of the face, from machine +x. */
        public double dose01, crankDeg, dialDeg;
        public boolean grinding;
    }

    private static final Grind GRIND = new Grind();
    private static BlockPos grindPos;
    private static final Live LIVE = new Live();
    private static final Pour POUR = new Pour();
    private static BlockPos pourPos;
    private static final Tamp TAMP = new Tamp();
    private static final Steam STEAM = new Steam();
    private static BlockPos pos, tampPos, steamPos;

    private LiveMachine() {}

    public static Live claim(BlockPos p) {
        if (!p.equals(pos)) {
            pos = p;
            LIVE.pumping = false;
            LIVE.level = 0.0;
        }
        return LIVE;
    }

    public static Live get(BlockPos p) {
        return p.equals(pos) ? LIVE : null;
    }

    public static Tamp claimTamp(BlockPos p) {
        tampPos = p;
        return TAMP;
    }

    public static Tamp tamp(BlockPos p) {
        return p.equals(tampPos) ? TAMP : null;
    }

    public static Steam claimSteam(BlockPos p) {
        steamPos = p;
        return STEAM;
    }

    public static Steam steam(BlockPos p) {
        return p.equals(steamPos) ? STEAM : null;
    }

    public static Pour claimPour(BlockPos p) {
        pourPos = p;
        return POUR;
    }

    public static Pour pour(BlockPos p) {
        return p.equals(pourPos) ? POUR : null;
    }

    public static Grind claimGrind(BlockPos p) {
        grindPos = p;
        return GRIND;
    }

    public static Grind grind(BlockPos p) {
        return p.equals(grindPos) ? GRIND : null;
    }

    public static void clear() {
        grindPos = null;
        pourPos = null;
        pos = null;
        tampPos = null;
        steamPos = null;
    }
}
