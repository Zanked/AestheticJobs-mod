#!/usr/bin/env python3
"""
Synthesizes the sounds of the cafe customers into assets/aestheticjobs/sounds/cafe/*.ogg
(mono, 44.1 kHz, Vorbis, like the terminal sounds).

Voices are "babble": short vowel blips (a saw wave through two formant filters). Every customer has the same
files; the game plays them with a per-customer pitch (see CafeCustomerEntity#getVoicePitch).

Run:  python3 tools/gen_cafe_sounds.py      (needs numpy, scipy and ffmpeg with libvorbis)
"""
import os
import subprocess
import tempfile

import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt

SR = 44100
OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources",
                       "assets", "aestheticjobs", "sounds", "cafe")
rng = np.random.default_rng(7)

VOWELS = {            # first two formants (Hz)
    "a": (800, 1250), "e": (520, 1900), "i": (320, 2300), "o": (500, 900), "u": (350, 700),
}


def t_axis(dur):
    return np.arange(int(SR * dur)) / SR


def adsr(n, a=0.006, d=0.05, s=0.6, r=0.04):
    a, d, r = int(a * SR), int(d * SR), int(r * SR)
    e = np.ones(n) * s
    a = min(a, n)
    e[:a] = np.linspace(0, 1, a, endpoint=False)
    d2 = min(d, max(0, n - a))
    e[a:a + d2] = np.linspace(1, s, d2, endpoint=False)
    r = min(r, n)
    e[n - r:] *= np.linspace(1, 0, r)
    return e


def bandpass(x, f, q=5.0):
    lo, hi = f * (1 - 1 / (2 * q)), f * (1 + 1 / (2 * q))
    sos = butter(2, [max(20, lo), min(SR / 2 - 100, hi)], btype="band", fs=SR, output="sos")
    return sosfilt(sos, x)


def lowpass(x, f, order=2):
    return sosfilt(butter(order, f, btype="low", fs=SR, output="sos"), x)


def highpass(x, f, order=2):
    return sosfilt(butter(order, f, btype="high", fs=SR, output="sos"), x)


def blip(f0, dur, vowel="a", glide=0.0, vibrato=0.0):
    """One vowel-like syllable. glide: relative pitch change over the blip (0.2 = +20 %)."""
    n = int(SR * dur)
    t = np.arange(n) / SR
    f = f0 * (1 + glide * t / dur) * (1 + vibrato * np.sin(2 * np.pi * 6 * t))
    phase = 2 * np.pi * np.cumsum(f) / SR
    src = 2 * ((phase / (2 * np.pi)) % 1.0) - 1          # saw
    f1, f2 = VOWELS[vowel]
    y = bandpass(src, f1, 4.0) * 1.0 + bandpass(src, f2, 6.0) * 0.6
    y += 0.12 * lowpass(src, 900)
    return y * adsr(n, 0.008, dur * 0.4, 0.55, dur * 0.35)


def seq(parts, gap=0.02):
    out = []
    for p in parts:
        out.append(p)
        out.append(np.zeros(int(SR * gap)))
    return np.concatenate(out)


def semitone(base, k):
    return base * 2 ** (k / 12)


def mix(*parts):
    n = max(len(p) for p in parts)
    out = np.zeros(n)
    for p in parts:
        out[:len(p)] += p
    return out


def delayed(x, sec):
    return np.concatenate([np.zeros(int(SR * sec)), x])


def noise(dur):
    return rng.standard_normal(int(SR * dur))


def bell(f, dur, amp=1.0):
    t = t_axis(dur)
    y = np.zeros_like(t)
    for ratio, a, dec in ((1.0, 1.0, 5.0), (2.76, 0.35, 9.0), (5.4, 0.12, 14.0)):
        y += a * np.sin(2 * np.pi * f * ratio * t) * np.exp(-dec * t)
    return amp * y * adsr(len(t), 0.001, 0.0, 1.0, 0.02)


# ---------------------------------------------------------------- sounds

def voice(i):
    """A short babble: 3..5 syllables, a different tune per file."""
    base = 250.0
    k = [0, 2, 4, 5, 7, -2, -5][i % 7]
    n = 3 + i % 3
    vs = ["a", "e", "o", "i", "u"]
    parts = []
    cur = 0
    for _ in range(n):
        cur = int(np.clip(cur + rng.integers(-3, 4), -5, 7))
        parts.append(blip(semitone(base, k + cur), rng.uniform(0.06, 0.1),
                          vs[rng.integers(0, 5)], glide=rng.uniform(-0.08, 0.12)))
    return seq(parts, 0.02)


def happy():
    base = 260.0
    y = seq([blip(semitone(base, 0), 0.09, "a", 0.05),
             blip(semitone(base, 4), 0.09, "e", 0.05),
             blip(semitone(base, 9), 0.2, "a", 0.12, vibrato=0.02)], 0.03)
    sparkle = mix(*[delayed(bell(f, 0.3, 0.12), d) for f, d in ((3136, 0.2), (3951, 0.27), (4699, 0.34))])
    return mix(y, sparkle)


def ok():
    base = 230.0
    return seq([blip(base, 0.11, "o", -0.04), blip(semitone(base, 2), 0.16, "u", 0.04)], 0.05)


def grumble():
    base = 150.0
    y = seq([blip(base, 0.16, "o", -0.15, 0.03), blip(base * 0.9, 0.28, "u", -0.25, 0.04)], 0.04)
    return y


def impatient():
    air = bandpass(noise(0.5), 1800, 0.9) * adsr(int(SR * 0.5), 0.12, 0.1, 0.5, 0.25) * 0.5
    low = blip(170, 0.22, "o", -0.2)
    return mix(air, delayed(low, 0.18))


def step(i):
    n = 0.07
    t = t_axis(n)
    thump = np.sin(2 * np.pi * (140 - 40 * t / n) * t) * np.exp(-45 * t)
    tap = lowpass(noise(n), 1500 + 700 * i) * np.exp(-60 * t)
    return (thump * 0.8 + tap * 0.6) * adsr(len(t), 0.001, 0.0, 1.0, 0.01)


def sip():
    d = 0.55
    n = int(SR * d)
    t = np.arange(n) / SR
    sweep = 500 + 1300 * np.sin(np.pi * t / d)
    nz = noise(d)
    # time-varying bandpass by blending a few fixed bands
    y = sum(bandpass(nz, f, 3.0) * np.clip(1 - abs(sweep - f) / 500, 0, 1) for f in (500, 800, 1200, 1700))
    y *= (0.6 + 0.4 * np.sin(2 * np.pi * 14 * t)) * adsr(n, 0.04, 0.1, 0.8, 0.12)
    gt = t_axis(0.12)
    gulp = np.sin(2 * np.pi * np.cumsum(220 - 110 * gt / 0.12) / SR) * np.exp(-18 * gt) * 0.9
    return mix(y * 0.35, delayed(gulp, 0.45))


def cup_take():
    t = t_axis(0.35)
    y = sum(a * np.sin(2 * np.pi * f * t) * np.exp(-d * t)
            for f, a, d in ((2350, 1.0, 22), (3720, 0.6, 30), (5110, 0.3, 40)))
    click = highpass(noise(0.01), 3000) * np.exp(-300 * t_axis(0.01))
    return mix(y * 0.5, click * 0.6)


def arrive():
    return mix(bell(1318.5, 0.9, 0.7), delayed(bell(1760, 1.0, 0.7), 0.16))


def leave():
    return mix(bell(1760, 0.6, 0.45), delayed(bell(1318.5, 0.8, 0.45), 0.12))


def reveal():
    notes = (1046.5, 1318.5, 1568, 2093)
    y = np.zeros(int(SR * 1.2))
    for i, f in enumerate(notes):
        b = bell(f, 0.7, 0.5)
        o = int(SR * 0.07 * i)
        y[o:o + len(b)] += b[:len(y) - o]
    return y


def burst():
    d = 0.9
    n = int(SR * d)
    y = np.zeros(n)
    for _ in range(46):                                  # pixels popping
        f = rng.uniform(1800, 6500)
        at = rng.uniform(0, 0.55) ** 1.2
        t = t_axis(0.12)
        ping = np.sin(2 * np.pi * f * t) * np.exp(-40 * t) * rng.uniform(0.05, 0.16)
        o = int(at * SR)
        y[o:o + len(ping)] += ping[:n - o]
    whoosh = highpass(noise(d), 2500) * adsr(n, 0.25, 0.2, 0.4, 0.35) * 0.06
    t = t_axis(0.18)
    pop = np.sin(2 * np.pi * (420 - 220 * t / 0.18) * t) * np.exp(-22 * t) * 0.6
    return mix(y, whoosh, pop)


SOUNDS = {
    "voice_1": voice(0), "voice_2": voice(1), "voice_3": voice(2),
    "happy": happy(), "ok": ok(), "grumble": grumble(), "impatient": impatient(),
    "step_1": step(0), "step_2": step(1),
    "sip": sip(), "cup_take": cup_take(),
    "arrive": arrive(), "leave": leave(), "reveal": reveal(), "burst": burst(),
}


def save(name, y):
    y = np.asarray(y, dtype=np.float64)
    fade = min(len(y) // 10, int(SR * 0.01))
    y[:fade] *= np.linspace(0, 1, fade)
    y[-fade:] *= np.linspace(1, 0, fade)
    peak = np.max(np.abs(y)) or 1.0
    y = y / peak * 0.8
    pcm = (y * 32767).astype(np.int16)
    os.makedirs(OUT_DIR, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        wav = os.path.join(tmp, name + ".wav")
        wavfile.write(wav, SR, pcm)
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-ac", "1", "-ar", str(SR),
                        "-c:a", "libvorbis", "-q:a", "4", os.path.join(OUT_DIR, name + ".ogg")], check=True)
    return len(y) / SR


if __name__ == "__main__":
    for name, y in SOUNDS.items():
        print(f"{name:10s} {save(name, y):.2f}s")
    print("->", os.path.abspath(OUT_DIR))
