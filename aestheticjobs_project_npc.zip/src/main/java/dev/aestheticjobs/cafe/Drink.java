package dev.aestheticjobs.cafe;

import dev.aestheticjobs.AestheticJobs;
import net.minecraft.network.chat.Component;

/**
 * The latte-art patterns of the cafe. Every drink has a 16x16 template of foam cells.
 * The same class is used by the client (live accuracy) and by the server (the real score).
 */
public enum Drink {
    HEART("heart", 450, new String[]{
            "................", "................", "................", "...###....###...",
            "..#####..#####..", ".##############.", ".##############.", ".##############.",
            "..############..", "...##########...", "....########....", ".....######.....",
            "......####......", ".......##.......", "................", "................"}),
    STAR("star", 500, new String[]{
            "................", "................", ".......##.......", ".......##.......",
            "......####......", "......####......", "..############..", "...##########...",
            "....########....", "....########....", "...####..####...", "...###....###...",
            "..###......###..", "................", "................", "................"}),
    CAT("cat", 550, new String[]{
            "................", "................", "................", "...##......##...",
            "...###....###...", "..############..", ".##############.", ".##..######..##.",
            ".##..######..##.", ".##############.", "..############..", "...##########...",
            "....########....", ".....######.....", "................", "................"}),
    SMILE("smile", 400, new String[]{
            "................", "................", "....########....", "..############..",
            ".##############.", ".##############.", ".###..####..###.", ".###..####..###.",
            ".##############.", ".##..######..##.", ".###........###.", "..############..",
            "..############..", "....########....", "................", "................"});

    public static final int SIZE = 16;
    public static final int CELLS = SIZE * SIZE;

    private final String id;
    private final long priceCents;
    private final boolean[] mask = new boolean[CELLS];
    private final boolean[] near = new boolean[CELLS];

    Drink(String id, long priceCents, String[] rows) {
        this.id = id;
        this.priceCents = priceCents;
        for (int y = 0; y < SIZE; y++) {
            for (int x = 0; x < SIZE; x++) {
                mask[y * SIZE + x] = rows[y].charAt(x) == '#';
            }
        }
        for (int y = 0; y < SIZE; y++) {
            for (int x = 0; x < SIZE; x++) {
                boolean n = false;
                for (int dy = -1; dy <= 1 && !n; dy++) {
                    for (int dx = -1; dx <= 1 && !n; dx++) {
                        int nx = x + dx, ny = y + dy;
                        if (nx >= 0 && ny >= 0 && nx < SIZE && ny < SIZE && mask[ny * SIZE + nx]) n = true;
                    }
                }
                near[y * SIZE + x] = n;
            }
        }
    }

    public String id() {
        return id;
    }

    public long priceCents() {
        return priceCents;
    }

    public Component displayName() {
        return Component.translatable("drink." + AestheticJobs.MODID + "." + id);
    }

    public boolean inTemplate(int x, int y) {
        return x >= 0 && y >= 0 && x < SIZE && y < SIZE && mask[y * SIZE + x];
    }

    /** The template as an art string ('1' = foam), used for the order ticket tooltip. */
    public String templateArt() {
        StringBuilder sb = new StringBuilder(CELLS);
        for (boolean b : mask) sb.append(b ? '1' : '0');
        return sb.toString();
    }

    /** The cup is round: only cells inside the circle can be drawn on. */
    public static boolean inCup(int x, int y) {
        double dx = x - 7.5, dy = y - 7.5;
        return dx * dx + dy * dy <= 57.8;
    }

    /** Keeps only valid art: exactly 256 chars of 0/1/2, nothing outside the cup. Returns null if broken. */
    public static String sanitize(String art) {
        if (art == null || art.length() != CELLS) return null;
        StringBuilder sb = new StringBuilder(CELLS);
        for (int i = 0; i < CELLS; i++) {
            char c = art.charAt(i);
            if (c != '0' && c != '1' && c != '2') return null;
            sb.append(inCup(i % SIZE, i / SIZE) ? c : '0');
        }
        return sb.toString();
    }

    /** 0..100: how close the drawing is to the template. Spreading foam everywhere gets a low score. */
    public int score(String art) {
        int template = 0, inter = 0, extra = 0, border = 0;
        for (int i = 0; i < CELLS; i++) {
            boolean drawn = art.charAt(i) != '0';
            if (mask[i]) {
                template++;
                if (drawn) inter++;
            } else if (drawn) {
                if (near[i]) border++; else extra++;
            }
        }
        if (inter == 0) return 0;
        double raw = inter / (template + extra + 0.5 * border);
        return (int) Math.round(100.0 * Math.pow(Math.min(1.0, raw), 1.5));
    }

    public static Drink byIndex(int i) {
        Drink[] all = values();
        return i >= 0 && i < all.length ? all[i] : null;
    }
}
