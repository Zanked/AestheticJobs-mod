package dev.aestheticjobs.cafe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

/** A finished cup: the drawing on the foam (256 chars: 0 empty, 1 milk, 2 cocoa), the pattern and the quality 0..100. */
public record CupData(String art, int drink, int quality) {
    public static final Codec<CupData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.STRING.fieldOf("art").forGetter(CupData::art),
            Codec.INT.fieldOf("drink").forGetter(CupData::drink),
            Codec.INT.fieldOf("quality").forGetter(CupData::quality)
    ).apply(instance, CupData::new));

    public static final StreamCodec<ByteBuf, CupData> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.STRING_UTF8, CupData::art,
            ByteBufCodecs.VAR_INT, CupData::drink,
            ByteBufCodecs.VAR_INT, CupData::quality,
            CupData::new);

    public int stars() {
        if (quality >= 90) return 5;
        if (quality >= 75) return 4;
        if (quality >= 60) return 3;
        if (quality >= 40) return 2;
        return 1;
    }

    public static String starText(int stars) {
        return "\u2605".repeat(stars) + "\u2606".repeat(5 - stars);
    }
}
