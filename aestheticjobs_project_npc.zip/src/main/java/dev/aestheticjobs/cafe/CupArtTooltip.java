package dev.aestheticjobs.cafe;

import net.minecraft.world.inventory.tooltip.TooltipComponent;

/** Picture shown in an item tooltip: the latte art of a cup, or the template on an order ticket. */
public record CupArtTooltip(String art) implements TooltipComponent {
}
