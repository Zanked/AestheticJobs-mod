package dev.aestheticjobs.cafe;

import dev.aestheticjobs.economy.Bank;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.economy.Transaction;
import dev.aestheticjobs.entity.CafeCustomerEntity;
import dev.aestheticjobs.job.Jobs;
import dev.aestheticjobs.job.Profession;
import dev.aestheticjobs.job.Shift;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.registry.ModItems;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class CafeLogic {
    public static final String CAFE_JOB = "cafe_worker";

    private CafeLogic() {}

    public static int count(Player player, Item item) {
        int n = 0;
        for (ItemStack s : player.getInventory().items) {
            if (s.is(item)) n += s.getCount();
        }
        return n;
    }

    public static boolean takeOne(Player player, Item item) {
        for (ItemStack s : player.getInventory().items) {
            if (s.is(item)) {
                s.shrink(1);
                return true;
            }
        }
        return false;
    }

    public static ItemStack findTicket(Player player) {
        for (ItemStack s : player.getInventory().items) {
            if (s.get(ModComponents.ORDER.get()) != null) return s;
        }
        return ItemStack.EMPTY;
    }

    /** Removes the ticket of an order that was never served (the customer lost patience). */
    public static void voidTicket(ServerPlayer player, long created) {
        for (ItemStack s : player.getInventory().items) {
            Order o = s.get(ModComponents.ORDER.get());
            if (o != null && o.created() == created) {
                s.shrink(1);
                return;
            }
        }
    }

    /** Quality 0..100 from the art score and the espresso shot. */
    public static int quality(int artScore, int extraction) {
        return (int) Math.round(0.7 * artScore + 0.3 * extraction);
    }

    public static boolean isCafeWorker(ServerPlayer player) {
        Optional<Profession> job = Jobs.currentProfession(player.server, player.getUUID());
        return job.isPresent() && job.get().id().getPath().equals(CAFE_JOB);
    }

    /**
     * A barista takes an order. From the register a customer NPC is spawned (if there is room) and walks up;
     * from a spawn-egg customer (npc != null) that very customer orders. Without room the order is just a ticket.
     */
    public static void issueOrder(ServerPlayer player, ServerLevel level, BlockPos soundPos,
                                  @Nullable BlockPos registerPos, @Nullable Direction registerFacing,
                                  @Nullable CafeCustomerEntity npc) {
        if (!isCafeWorker(player)) {
            player.displayClientMessage(Component.translatable("cafe.register.need_job"), true);
            return;
        }
        if (Jobs.REQUIRE_SHIFT_FOR_WORK && !Shift.isOnShift(player.server, player.getUUID())) {
            player.displayClientMessage(Component.translatable("cafe.register.need_shift"), true);
            return;
        }
        if (!findTicket(player).isEmpty()) {
            player.displayClientMessage(Component.translatable("cafe.register.have_ticket"), true);
            return;
        }
        Shift.touch(player);
        Drink drink = Drink.values()[level.random.nextInt(Drink.values().length)];
        int customer = npc != null ? Math.floorMod(npc.getVariant(), Order.CUSTOMERS) : level.random.nextInt(Order.CUSTOMERS);
        long now = level.getGameTime();

        if (npc != null) {
            npc.beginOrder(player.getUUID(), drink.ordinal(), now, null, null, false);
        } else if (registerPos != null && registerFacing != null) {
            CafeCustomerEntity.spawnFor(level, registerPos, registerFacing, player.getUUID(), customer, drink.ordinal(), now);
        }

        ItemStack ticket = new ItemStack(ModItems.ORDER_TICKET.get());
        ticket.set(ModComponents.ORDER.get(), new Order(drink.ordinal(), customer, now));
        player.getInventory().placeItemBackInInventory(ticket);
        level.playSound(null, soundPos, SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.BLOCKS, 1.0F, 1.2F);
        player.sendSystemMessage(Component.translatable("cafe.register.new_order",
                Component.translatable("customer.aestheticjobs." + customer), drink.displayName()));
    }

    /**
     * Hands a finished cup over: checks the ticket, pays (commission + tips), gives xp.
     * If the customer NPC is there, it takes the cup and shows the drawing (see CafeCustomerEntity).
     */
    public static void serve(ServerPlayer player, ServerLevel level, BlockPos pos, ItemStack cupStack, CupData cup,
                             @Nullable CafeCustomerEntity npc) {
        Shift.touch(player);
        ItemStack ticket = findTicket(player);
        if (ticket.isEmpty()) {
            player.displayClientMessage(Component.translatable("cafe.register.no_order"), true);
            return;
        }
        Order order = ticket.get(ModComponents.ORDER.get());
        Drink wanted = Drink.byIndex(order.drink());
        if (wanted == null || order.drink() != cup.drink()) {
            Component name = wanted == null ? Component.empty() : wanted.displayName();
            player.displayClientMessage(Component.translatable("cafe.register.wrong", name), true);
            return;
        }

        long elapsed = level.getGameTime() - order.created();
        double speed = elapsed <= wanted.fastTicks() ? 0.30 : elapsed <= wanted.okTicks() ? 0.10 : 0.0;
        int stars = cup.stars();
        long price = wanted.priceCents();
        long base = Math.round(price * 0.6);
        long tip = Math.round(price * (stars * 0.08 + speed));
        long total = base + tip;

        Bank.Result paid = Bank.deposit(player.server, player.getUUID(), total, Transaction.Type.WAGE, "cafe");
        if (paid != Bank.Result.OK) {
            player.displayClientMessage(Component.translatable("cafe.register.bank_full"), true);
            return;
        }
        cupStack.shrink(1);
        ticket.shrink(1);

        Jobs.XpResult xp = Jobs.addXp(player.server, player.getUUID(), 4L + stars * 2L);
        if (npc != null) {
            npc.receiveCup(player, cup, stars);
        } else {
            level.playSound(null, pos, SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.BLOCKS, 0.9F, 1.3F);
            level.sendParticles(ParticleTypes.HEART, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 4, 0.25, 0.1, 0.25, 0.0);
        }
        player.sendSystemMessage(Component.translatable("cafe.register.paid",
                Component.translatable("customer.aestheticjobs." + Math.floorMod(order.customer(), Order.CUSTOMERS)),
                CupData.starText(stars), Money.format(total), Money.format(tip)));
        if (xp.employed() && xp.newRank() > xp.oldRank() && xp.profession() != null) {
            player.sendSystemMessage(Component.translatable("cafe.rank_up", xp.profession().rankName(xp.newRank())));
        }
    }
}
