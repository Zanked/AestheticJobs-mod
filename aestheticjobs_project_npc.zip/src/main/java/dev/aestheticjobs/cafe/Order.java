package dev.aestheticjobs.cafe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

/** An order ticket: which pattern the customer wants, who the customer is, and when the order was taken (game ticks). */
public record Order(int drink, int customer, long created) {
    public static final int CUSTOMERS = 8;

    public static final Codec<Order> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.INT.fieldOf("drink").forGetter(Order::drink),
            Codec.INT.fieldOf("customer").forGetter(Order::customer),
            Codec.LONG.fieldOf("created").forGetter(Order::created)
    ).apply(instance, Order::new));

    public static final StreamCodec<ByteBuf, Order> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, Order::drink,
            ByteBufCodecs.VAR_INT, Order::customer,
            ByteBufCodecs.VAR_LONG, Order::created,
            Order::new);
}
