package dev.aestheticjobs.item;

import dev.aestheticjobs.cafe.CupArtTooltip;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.Order;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.registry.ModComponents;
import java.util.List;
import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

/** A paper slip from the till: who ordered what. The tooltip shows the pattern to draw. */
public class OrderTicketItem extends Item {
    public OrderTicketItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public Optional<TooltipComponent> getTooltipImage(ItemStack stack) {
        Order order = stack.get(ModComponents.ORDER.get());
        Drink drink = order == null ? null : Drink.byIndex(order.drink());
        return drink == null ? Optional.empty() : Optional.of(new CupArtTooltip(drink.templateArt()));
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        Order order = stack.get(ModComponents.ORDER.get());
        if (order == null) return;
        Drink drink = Drink.byIndex(order.drink());
        tooltip.add(Component.translatable("item.aestheticjobs.order_ticket.customer",
                Component.translatable("customer.aestheticjobs." + Math.floorMod(order.customer(), Order.CUSTOMERS))).withStyle(ChatFormatting.GRAY));
        if (drink != null) {
            tooltip.add(Component.translatable("item.aestheticjobs.order_ticket.drink", drink.displayName(), Money.format(drink.priceCents()))
                    .withStyle(ChatFormatting.GRAY));
        }
        tooltip.add(Component.translatable("item.aestheticjobs.order_ticket.hint").withStyle(ChatFormatting.DARK_GRAY));
    }
}
