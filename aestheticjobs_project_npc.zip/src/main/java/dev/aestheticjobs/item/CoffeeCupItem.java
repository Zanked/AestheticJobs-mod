package dev.aestheticjobs.item;

import dev.aestheticjobs.cafe.CupArtTooltip;
import dev.aestheticjobs.cafe.CupData;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.registry.ModComponents;
import java.util.List;
import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

/** A latte with a drawing on the foam. The drawing is shown as a picture in the tooltip. */
public class CoffeeCupItem extends Item {
    public CoffeeCupItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public Optional<TooltipComponent> getTooltipImage(ItemStack stack) {
        CupData data = stack.get(ModComponents.CUP.get());
        return data == null ? Optional.empty() : Optional.of(new CupArtTooltip(data.art()));
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        CupData data = stack.get(ModComponents.CUP.get());
        if (data == null) return;
        Drink drink = Drink.byIndex(data.drink());
        if (drink != null) {
            tooltip.add(Component.translatable("item.aestheticjobs.coffee_cup.drink", drink.displayName()).withStyle(ChatFormatting.GRAY));
        }
        tooltip.add(Component.literal(CupData.starText(data.stars())).withStyle(ChatFormatting.GOLD)
                .append(Component.literal("  " + data.quality() + "%").withStyle(ChatFormatting.DARK_GRAY)));
    }
}
