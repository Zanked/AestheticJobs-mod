package dev.aestheticjobs.registry;

import dev.aestheticjobs.AestheticJobs;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** The terminal's own sounds (assets/aestheticjobs/sounds/atm/*.ogg, listed in sounds.json). */
public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, AestheticJobs.MODID);

    public static final DeferredHolder<SoundEvent, SoundEvent> KEY = register("atm.key");
    public static final DeferredHolder<SoundEvent, SoundEvent> PIN_OK = register("atm.pin_ok");
    public static final DeferredHolder<SoundEvent, SoundEvent> PIN_FAIL = register("atm.pin_fail");
    public static final DeferredHolder<SoundEvent, SoundEvent> CARD_INSERT = register("atm.card_insert");
    public static final DeferredHolder<SoundEvent, SoundEvent> CARD_EJECT = register("atm.card_eject");
    public static final DeferredHolder<SoundEvent, SoundEvent> BILL_FEED = register("atm.bill_feed");
    public static final DeferredHolder<SoundEvent, SoundEvent> DISPENSE = register("atm.dispense");
    public static final DeferredHolder<SoundEvent, SoundEvent> SUCCESS = register("atm.success");
    public static final DeferredHolder<SoundEvent, SoundEvent> ERROR = register("atm.error");

    // cafe customers (assets/aestheticjobs/sounds/cafe/*.ogg)
    public static final DeferredHolder<SoundEvent, SoundEvent> CUSTOMER_VOICE = register("customer.voice");
    public static final DeferredHolder<SoundEvent, SoundEvent> CUSTOMER_HAPPY = register("customer.happy");
    public static final DeferredHolder<SoundEvent, SoundEvent> CUSTOMER_OK = register("customer.ok");
    public static final DeferredHolder<SoundEvent, SoundEvent> CUSTOMER_GRUMBLE = register("customer.grumble");
    public static final DeferredHolder<SoundEvent, SoundEvent> CUSTOMER_IMPATIENT = register("customer.impatient");
    public static final DeferredHolder<SoundEvent, SoundEvent> CUSTOMER_STEP = register("customer.step");
    public static final DeferredHolder<SoundEvent, SoundEvent> CUSTOMER_SIP = register("customer.sip");
    public static final DeferredHolder<SoundEvent, SoundEvent> CUSTOMER_CUP_TAKE = register("customer.cup_take");
    public static final DeferredHolder<SoundEvent, SoundEvent> CUSTOMER_ARRIVE = register("customer.arrive");
    public static final DeferredHolder<SoundEvent, SoundEvent> CUSTOMER_LEAVE = register("customer.leave");
    public static final DeferredHolder<SoundEvent, SoundEvent> CUSTOMER_REVEAL = register("customer.reveal");
    public static final DeferredHolder<SoundEvent, SoundEvent> CUSTOMER_BURST = register("customer.burst");

    private static DeferredHolder<SoundEvent, SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, name)));
    }

    private ModSounds() {}
}
