package dev.aestheticjobs.registry;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.economy.Denomination;
import dev.aestheticjobs.item.BankCardItem;
import dev.aestheticjobs.item.CoffeeCupItem;
import dev.aestheticjobs.item.OrderTicketItem;
import dev.aestheticjobs.item.WorkBadgeItem;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(AestheticJobs.MODID);

    public static final DeferredItem<BlockItem> ATM = ITEMS.registerSimpleBlockItem("atm", ModBlocks.ATM);
    public static final DeferredItem<BankCardItem> BANK_CARD = ITEMS.registerItem("bank_card", BankCardItem::new, new Item.Properties().stacksTo(1));

    /** Right-click: start / end the shift. Glows green while on shift (custom_model_data 1). */
    public static final DeferredItem<WorkBadgeItem> WORK_BADGE = ITEMS.registerItem("work_badge", WorkBadgeItem::new, new Item.Properties().stacksTo(1));

    public static final DeferredItem<BlockItem> COFFEE_MACHINE = ITEMS.registerSimpleBlockItem("coffee_machine", ModBlocks.COFFEE_MACHINE);
    public static final DeferredItem<BlockItem> CAFE_REGISTER = ITEMS.registerSimpleBlockItem("cafe_register", ModBlocks.CAFE_REGISTER);
    public static final DeferredItem<Item> EMPTY_CUP = ITEMS.registerSimpleItem("empty_cup", new Item.Properties().stacksTo(16));
    public static final DeferredItem<Item> COFFEE_BEANS = ITEMS.registerSimpleItem("coffee_beans", new Item.Properties());
    public static final DeferredItem<CoffeeCupItem> COFFEE_CUP = ITEMS.registerItem("coffee_cup", CoffeeCupItem::new, new Item.Properties().stacksTo(1));
    public static final DeferredItem<OrderTicketItem> ORDER_TICKET = ITEMS.registerItem("order_ticket", OrderTicketItem::new, new Item.Properties().stacksTo(1));

    /** Spawn egg of the cafe customer (cream and coffee colours, like the mod). */
    public static final DeferredItem<DeferredSpawnEggItem> CAFE_CUSTOMER_SPAWN_EGG = ITEMS.register("cafe_customer_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.CAFE_CUSTOMER, 0xE9D9B0, 0x7A5238, new Item.Properties()));

    /** Coins and bills, one item per denomination (ids: coin_penny ... bill_100). */
    public static final Map<Denomination, DeferredItem<Item>> MONEY = new EnumMap<>(Denomination.class);

    static {
        for (Denomination d : Denomination.values()) {
            MONEY.put(d, ITEMS.registerSimpleItem(d.id(), new Item.Properties()));
        }
    }

    private ModItems() {}
}
