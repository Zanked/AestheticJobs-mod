package dev.aestheticjobs.network;

import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.CupData;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.registry.ModBlocks;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class ModNetwork {
    private ModNetwork() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToServer(BrewPayload.TYPE, BrewPayload.STREAM_CODEC, ModNetwork::handleBrew);
    }

    private static void handleBrew(BrewPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        ServerLevel level = player.serverLevel();
        BlockPos pos = payload.pos();
        if (player.distanceToSqr(Vec3.atCenterOf(pos)) > 64.0) return;
        if (!level.isLoaded(pos) || !level.getBlockState(pos).is(ModBlocks.COFFEE_MACHINE.get())) return;

        dev.aestheticjobs.job.Shift.touch(player);
        Drink drink = Drink.byIndex(payload.drink());
        String art = Drink.sanitize(payload.art());
        if (drink == null || art == null) return;
        int filled = 0;
        for (int i = 0; i < art.length(); i++) if (art.charAt(i) != '0') filled++;
        if (filled < 4) return;

        if (CafeLogic.count(player, ModItems.EMPTY_CUP.get()) < 1 || CafeLogic.count(player, ModItems.COFFEE_BEANS.get()) < 1) {
            player.displayClientMessage(Component.translatable("cafe.machine.missing"), true);
            return;
        }
        CafeLogic.takeOne(player, ModItems.EMPTY_CUP.get());
        CafeLogic.takeOne(player, ModItems.COFFEE_BEANS.get());

        int extraction = Math.max(0, Math.min(100, payload.extraction()));
        int quality = CafeLogic.quality(drink.score(art), extraction);
        ItemStack cup = new ItemStack(ModItems.COFFEE_CUP.get());
        CupData data = new CupData(art, drink.ordinal(), quality);
        cup.set(ModComponents.CUP.get(), data);
        player.getInventory().placeItemBackInInventory(cup);

        level.playSound(null, pos, SoundEvents.BREWING_STAND_BREW, SoundSource.BLOCKS, 1.0F, 1.1F);
        level.sendParticles(ParticleTypes.CLOUD, pos.getX() + 0.5, pos.getY() + 1.05, pos.getZ() + 0.5, 8, 0.15, 0.05, 0.15, 0.01);
        player.displayClientMessage(Component.translatable("cafe.machine.done",
                drink.displayName(), CupData.starText(data.stars())), true);
    }
}
