package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import net.minecraft.core.BlockPos;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client -> server: the player finished a drink at a coffee machine. The server recomputes the score itself. */
public record BrewPayload(BlockPos pos, int drink, int extraction, String art) implements CustomPacketPayload {
    public static final Type<BrewPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "brew"));

    public static final StreamCodec<net.minecraft.network.RegistryFriendlyByteBuf, BrewPayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, BrewPayload::pos,
            ByteBufCodecs.VAR_INT, BrewPayload::drink,
            ByteBufCodecs.VAR_INT, BrewPayload::extraction,
            ByteBufCodecs.stringUtf8(300), BrewPayload::art,
            BrewPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
