package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModSounds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/**
 * Grind: dial in the fineness with the mouse wheel (espresso wants it fine, about 7) and crank the handle by
 * moving the mouse in circles while holding the left button. One turn grinds 2.4 g, the dose is 18 g.
 * The fineness stays: a coarse grind makes the shot run fast, a fine one slow.
 */
public class GrindStage extends Stage {
    private static final double TARGET_DOSE = 18.0, TURN_G = 2.4;
    private static final int TARGET_FINE = 7;
    private static final ResourceLocation BEANS = ResourceLocation.fromNamespaceAndPath("aestheticjobs", "textures/item/coffee_beans.png");

    private double dose, fineness = 5, rotation, lastAngle, soundAcc;
    private boolean hasLast;
    private final List<float[]> beans = new ArrayList<>();   // x, y, vy
    private float beanTimer;

    public GrindStage(Brew brew, Step step) {
        super(brew, step);
    }

    private int cx() { return rx + rw / 2 - 40; }
    private int cy() { return ry + rh / 2 + 4; }

    @Override
    public void update(float dt, int mx, int my) {
        if (done) return;
        double dx = mx - cx(), dy = my - cy();
        double dist = Math.sqrt(dx * dx + dy * dy);
        if (Ui.lmb() && dist > 10 && dist < 70) {
            double a = Math.atan2(dy, dx);
            if (hasLast) {
                double d = a - lastAngle;
                while (d > Math.PI) d -= 2 * Math.PI;
                while (d < -Math.PI) d += 2 * Math.PI;
                if (d > 0 && d < 1.2) {                         // clockwise on screen
                    rotation += d;
                    dose = Math.min(32.0, dose + d / (2 * Math.PI) * TURN_G);
                    soundAcc += d;
                    beanTimer += d;
                }
            }
            lastAngle = a;
            hasLast = true;
        } else {
            hasLast = false;
        }
        if (soundAcc > 0.8) {
            soundAcc = 0;
            Ui.sound(ModSounds.BARISTA_GRIND.get(), 0.85F + (float) (fineness * 0.04), 0.55F);
        }
        while (beanTimer > 0.5) {                               // a bean falls into the portafilter
            beanTimer -= 0.5;
            beans.add(new float[]{cx() + 58 + (float) (Math.random() * 6 - 3), cy() - 22, 0});
        }
        for (int i = beans.size() - 1; i >= 0; i--) {
            float[] b = beans.get(i);
            b[2] += 260 * dt;
            b[1] += b[2] * dt;
            if (b[1] > cy() + 46) beans.remove(i);
        }
    }

    @Override
    public void scroll(double amount) {
        if (done) return;
        fineness = Math.max(1, Math.min(10, fineness + (amount > 0 ? 1 : -1)));
        Ui.sound(ModSounds.BARISTA_GRIND.get(), 1.4F, 0.4F);
    }

    @Override
    public boolean click(double mx, double my, int button) {
        if (done) return false;
        int bx = rx + rw - 74;
        if (Ui.in(mx, my, bx, ry + 22, 16, 14)) { scroll(-1); return true; }
        if (Ui.in(mx, my, bx + 36, ry + 22, 16, 14)) { scroll(1); return true; }
        return false;
    }

    @Override
    public boolean canFinish() {
        return !done && dose >= 4;
    }

    @Override
    public Component finishLabel() {
        return Component.translatable("step.aestheticjobs.grind.stop");
    }

    @Override
    public void finish() {
        brew.fineness = fineness;
        done = true;
    }

    @Override
    public int score() {
        double diff = Math.abs(dose - TARGET_DOSE);
        double ds = diff <= 0.6 ? 100 : Math.max(0, 100 - (diff - 0.6) * 22);
        double fs = Math.max(0, 100 - Math.abs(fineness - TARGET_FINE) * 20);
        return (int) Math.round(0.6 * ds + 0.4 * fs);
    }

    @Override
    public Component status() {
        if (dose < 4) return step.hint();
        return Component.translatable("step.aestheticjobs.grind.dose", String.format("%.1f", dose), (int) TARGET_DOSE);
    }

    @Override
    public void render(GuiGraphics g, Font font, int mx, int my) {
        int cx = cx(), cy = cy();
        // grinder body
        Ui.box(g, cx + 30, cy - 62, 56, 96, Ui.STEEL_D, Ui.STEEL);
        g.fill(cx + 34, cy - 58, cx + 38, cy + 28, 0xFFEAEFF1);                  // highlight
        Ui.box(g, cx + 36, cy - 84, 44, 24, 0xFFC9B88E, 0xFFE9D9B0);              // hopper
        Ui.icon(g, BEANS, cx + 42, cy - 84, 32);
        g.fill(cx + 50, cy + 34, cx + 66, cy + 40, Ui.STEEL_D);                    // chute
        // the portafilter below
        Ui.box(g, cx + 36, cy + 40, 44, 14, 0xFF6A4A3A, 0xFF8A6A58);
        Ui.box(g, cx + 44, cy + 36, 28, 6, 0xFF4A3228, 0xFF3A2A24);
        int level = (int) Math.min(18, dose / TARGET_DOSE * 12);
        g.fill(cx + 46, cy + 40 - level / 2, cx + 70, cy + 42, 0xFF6A4435);       // grounds heap
        // handle: a crank on the left
        Ui.ring(g, cx, cy, 46, 2, 0xFFC9B88E);
        g.fill(cx - 2, cy - 2, cx + 3, cy + 3, Ui.STEEL_D);
        double kx = cx + Math.cos(rotation) * 38, ky = cy + Math.sin(rotation) * 38;
        Ui.line(g, cx, cy, kx, ky, 3, Ui.STEEL_D);
        Ui.disc(g, (int) kx, (int) ky, 6, 0xFFE3A08C);
        Ui.disc(g, (int) kx - 1, (int) ky - 1, 2, 0xFFF7CDBB);
        Ui.line(g, cx + 46, cy, cx + 30, cy, 3, Ui.STEEL_D);
        for (float[] b : beans) g.fill((int) b[0], (int) b[1], (int) b[0] + 3, (int) b[1] + 3, 0xFF6A4435);

        // dose meter
        int mxp = rx + rw - 30, myp = ry + 12, mh = rh - 40;
        Ui.text(g, font, Component.translatable("step.aestheticjobs.grind.g"), mxp - 4, myp - 10, Ui.LABEL);
        g.fill(mxp - 1, myp - 1, mxp + 15, myp + mh + 1, Ui.KHAKI);
        g.fill(mxp, myp, mxp + 14, myp + mh, Ui.TAN);
        double scale = mh / 30.0;
        int fillH = (int) (dose * scale);
        g.fill(mxp, myp + mh - fillH, mxp + 14, myp + mh, diffColor());
        int t0 = myp + mh - (int) ((TARGET_DOSE + 0.6) * scale), t1 = myp + mh - (int) ((TARGET_DOSE - 0.6) * scale);
        g.fill(mxp - 3, t0, mxp + 17, t0 + 1, Ui.GOOD_D);
        g.fill(mxp - 3, t1, mxp + 17, t1 + 1, Ui.GOOD_D);
        Ui.text(g, font, Component.literal(String.format("%.1f", dose)), mxp - 2, myp + mh + 4, Ui.INK);

        // fineness dial
        int bx = rx + rw - 74;
        Ui.text(g, font, Component.translatable("step.aestheticjobs.grind.fineness"), bx - 6, ry + 8, Ui.LABEL);
        Ui.button(g, font, bx, ry + 22, 16, 14, Component.literal("-"), Ui.in(mx, my, bx, ry + 22, 16, 14), !done, 0);
        Ui.centered(g, font, Component.literal(String.valueOf((int) fineness)), bx + 26, ry + 25, Ui.INK);
        Ui.button(g, font, bx + 36, ry + 22, 16, 14, Component.literal("+"), Ui.in(mx, my, bx + 36, ry + 22, 16, 14), !done, 0);
        for (int i = 1; i <= 10; i++) {                                         // little scale, the espresso zone is green
            int x = bx - 2 + (i - 1) * 6;
            g.fill(x, ry + 42, x + 4, ry + 48, (i >= 6 && i <= 8) ? Ui.GOOD : Ui.TAN);
            if (i == (int) fineness) g.fill(x, ry + 50, x + 4, ry + 53, Ui.INK);
        }
        Ui.text(g, font, Component.translatable("step.aestheticjobs.grind.coarse"), bx - 4, ry + 56, Ui.LABEL);
        Ui.text(g, font, Component.translatable("step.aestheticjobs.grind.fine"), bx + 28, ry + 56, Ui.LABEL);
    }

    private int diffColor() {
        double diff = Math.abs(dose - TARGET_DOSE);
        return diff <= 0.6 ? Ui.GOOD : diff <= 2.5 ? Ui.WARN : Ui.BAD;
    }
}
