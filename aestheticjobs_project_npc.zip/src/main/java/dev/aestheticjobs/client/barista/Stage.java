package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.cafe.Step;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** One mini-game of a recipe. The screen gives it a rectangle, calls update every frame and render after it. */
public abstract class Stage {
    protected final Brew brew;
    public final Step step;
    protected boolean done;
    protected int rx, ry, rw, rh;

    protected Stage(Brew brew, Step step) {
        this.brew = brew;
        this.step = step;
    }

    public final void layout(int x, int y, int w, int h) {
        rx = x;
        ry = y;
        rw = w;
        rh = h;
    }

    public boolean isDone() { return done; }

    /** 0..100, valid once the stage is done. */
    public abstract int score();

    public abstract void update(float dt, int mx, int my);

    public abstract void render(GuiGraphics g, Font font, int mx, int my);

    /** A line under the play area that changes with what is going on. */
    public Component status() { return step.hint(); }

    /** The main button of the stage (grind: "stop", steam: "done" ...). */
    public boolean canFinish() { return false; }

    public Component finishLabel() { return Component.translatable("gui.aestheticjobs.cafe.done"); }

    public void finish() { }

    public boolean click(double mx, double my, int button) { return false; }

    public void scroll(double amount) { }
}
