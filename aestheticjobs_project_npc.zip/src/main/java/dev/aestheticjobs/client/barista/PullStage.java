package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModSounds;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Pull the shot: hold the left button (or Space) to run the pump, let go at the right moment. Read the stream:
 * dark at the start, golden honey in the sweet spot, pale and watery when it is over-extracted.
 * The grind sets the speed (a coarse grind runs fast), a crooked tamp makes the stream sputter.
 */
public class PullStage extends Stage {
    private final double target;
    private double t;                       // shot time in "shot seconds"
    private boolean started, pumping;
    private float soundTimer;
    private double jitter;

    public PullStage(Brew brew, Step step) {
        super(brew, step);
        this.target = step.p1();
    }

    private double max() { return target * 2.2; }

    private double streamU() { return t / target; }

    @Override
    public void update(float dt, int mx, int my) {
        if (done) return;
        boolean hold = Ui.lmb() || Ui.space();
        if (hold && !(started && !pumping)) {
            started = true;
            pumping = true;
            double flow = Math.max(0.5, 1.0 + (brew.fineness - 7) * 0.10);
            t += dt * flow;
            soundTimer += dt;
            if (soundTimer > 0.3) {
                soundTimer = 0;
                Ui.sound(ModSounds.BARISTA_PUMP.get(), 0.9F + (float) streamU() * 0.2F, 0.5F);
            }
            jitter = (Math.random() - 0.5) * 2 * brew.channeling * 5;
        } else if (started) {
            pumping = false;
            finishShot();
        }
        if (started && t >= max()) finishShot();
    }

    private void finishShot() {
        if (done) return;
        done = true;
        brew.shotQuality = score();
        brew.cremaKept = Math.max(0.2, Math.min(1.0, brew.shotQuality / 100.0 + 0.25));
        Ui.sound(ModSounds.BARISTA_DING.get(), 1.2F, 0.5F);
    }

    @Override
    public int score() {
        double d = Math.abs(t - target);
        double s = d <= 0.7 ? 100 : Math.max(0, 100 - (d - 0.7) * 30);
        s *= (1.0 - 0.35 * brew.channeling);
        return started ? (int) Math.round(s) : 0;
    }

    private int streamColor() {
        double u = streamU();
        if (u < 0.55) return Ui.lerp(0xFF3B241B, 0xFF7A4A28, u / 0.55);
        if (u < 1.15) return Ui.lerp(0xFFB87838, 0xFFD9A850, (u - 0.55) / 0.6);
        return Ui.lerp(0xFFE8C98A, 0xFFF4E4BC, Math.min(1.0, (u - 1.15) / 0.8));
    }

    @Override
    public Component status() {
        if (!started) return step.hint();
        double u = streamU();
        if (done) return Component.translatable("step.aestheticjobs.pull.time", String.format("%.1f", t));
        return Component.translatable(u < 0.55 ? "step.aestheticjobs.pull.dark" : u < 1.15 ? "step.aestheticjobs.pull.golden" : "step.aestheticjobs.pull.pale");
    }

    @Override
    public void render(GuiGraphics g, Font font, int mx, int my) {
        int cx = rx + rw / 2 - 20, top = ry + 6;
        // group head
        Ui.box(g, cx - 40, top, 80, 22, Ui.STEEL_D, Ui.STEEL);
        g.fill(cx - 36, top + 3, cx - 30, top + 18, 0xFFEAEFF1);
        Ui.box(g, cx - 28, top + 22, 56, 10, 0xFF6A4A3A, 0xFF8A6A58);
        g.fill(cx - 22, top + 32, cx - 16, top + 38, 0xFF6A4A3A);
        g.fill(cx + 16, top + 32, cx + 22, top + 38, 0xFF6A4A3A);
        // the glass
        int gx = cx - 30, gy = top + 76, gw = 60, gh = 60;
        double level = Math.min(1.0, t / (target * 1.5));
        int liquidH = (int) (gh * level);
        Ui.box(g, gx - 2, gy - 2, gw + 4, gh + 4, 0xFFBDD7DC, 0xFFE6F2F4);
        if (liquidH > 0) {
            g.fill(gx, gy + gh - liquidH, gx + gw, gy + gh, 0xFF52332A);
            int cremaH = Math.min(liquidH, 2 + (int) (6 * Math.min(1.0, streamU()) * (1.0 - 0.6 * Math.max(0, streamU() - 1.0))));
            g.fill(gx, gy + gh - liquidH, gx + gw, gy + gh - liquidH + cremaH, streamU() > 1.2 ? 0xFFE8C98A : Ui.GOLDEN);
        }
        g.fill(gx + 3, gy + 2, gx + 6, gy + gh - 2, 0x66FFFFFF);
        // the streams from the two spouts
        if (pumping) {
            int c = streamColor();
            int surfaceY = gy + gh - liquidH;
            for (int s = -1; s <= 1; s += 2) {
                int x = cx + s * 19 + (int) jitter;
                g.fill(x, top + 38, x + 3, Math.max(top + 40, surfaceY), c);
                if (brew.channeling > 0.35 && Math.random() < 0.5) {            // a sputtering jet
                    g.fill(x + (int) ((Math.random() - 0.5) * 16), top + 40, x + 2, surfaceY - 4, c);
                }
            }
        }
        // timeline with the golden window
        int bx = rx + 14, by = ry + rh - 22, bw = rw - 28;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 9, Ui.KHAKI);
        g.fill(bx, by, bx + bw, by + 8, Ui.TAN);
        int w0 = bx + (int) (bw * (target - 0.7) / max()), w1 = bx + (int) (bw * (target + 0.7) / max());
        g.fill(w0, by, w1, by + 8, Ui.GOOD);
        int nx = bx + (int) (bw * Math.min(1.0, t / max()));
        g.fill(nx - 1, by - 3, nx + 2, by + 11, Ui.INK);
        Ui.text(g, font, Component.literal(String.format("%.1f c", t)), bx, by - 12, Ui.LABEL);
    }
}
