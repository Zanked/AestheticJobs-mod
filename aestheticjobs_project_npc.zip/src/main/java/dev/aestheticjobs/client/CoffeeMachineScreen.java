package dev.aestheticjobs.client;

import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.CupData;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.client.barista.Brew;
import dev.aestheticjobs.client.barista.DecorStage;
import dev.aestheticjobs.client.barista.GrindStage;
import dev.aestheticjobs.client.barista.LayerStage;
import dev.aestheticjobs.client.barista.PourArtStage;
import dev.aestheticjobs.client.barista.PullStage;
import dev.aestheticjobs.client.barista.Stage;
import dev.aestheticjobs.client.barista.SteamStage;
import dev.aestheticjobs.client.barista.StirStage;
import dev.aestheticjobs.client.barista.TampStage;
import dev.aestheticjobs.client.barista.Ui;
import dev.aestheticjobs.client.barista.WaterStage;
import dev.aestheticjobs.network.BrewPayload;
import dev.aestheticjobs.registry.ModItems;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The barista table. MENU: pick a drink (each one is a different recipe). BREW: one mini-game per step of the
 * recipe (grind, tamp, pull the shot, steam the milk, pour the art ...). SUMMARY: how every step went; serve the cup.
 */
public class CoffeeMachineScreen extends Screen {
    private static final int W = 300, H = 214;
    private enum Mode { MENU, BREW, SUMMARY }

    private static int lastDrink = Drink.LATTE.ordinal();

    private final BlockPos pos;
    private Mode mode = Mode.MENU;
    private Drink selected = Drink.byIndex(lastDrink) == null ? Drink.LATTE : Drink.byIndex(lastDrink);
    private Brew brew;
    private int stepIndex;
    private Stage stage;
    private long lastNanos = Util.getNanos();
    private double doneTimer = -1;
    private int left, top;

    public CoffeeMachineScreen(BlockPos pos) {
        super(Component.translatable("block.aestheticjobs.coffee_machine"));
        this.pos = pos;
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ------------------------------------------------------------------ helpers
    private static ResourceLocation itemIcon(Item item) {
        ResourceLocation key = BuiltInRegistries.ITEM.getKey(item);
        return ResourceLocation.fromNamespaceAndPath(key.getNamespace(), "textures/item/" + key.getPath() + ".png");
    }

    private static int have(Item item) {
        var player = Minecraft.getInstance().player;
        return player == null ? 0 : CafeLogic.count(player, item);
    }

    private boolean hasSupplies(Drink d) {
        if (have(ModItems.EMPTY_CUP.get()) < 1) return false;
        for (Drink.Supply s : d.supplies()) if (have(s.item()) < 1) return false;
        return true;
    }

    private Stage create(Step s) {
        return switch (s.kind()) {
            case GRIND -> new GrindStage(brew, s);
            case TAMP -> new TampStage(brew, s);
            case PULL -> new PullStage(brew, s);
            case WATER -> new WaterStage(brew, s);
            case LAYER -> new LayerStage(brew, s);
            case STIR -> new StirStage(brew, s);
            case STEAM -> new SteamStage(brew, s);
            case POUR -> new PourArtStage(brew, s);
            case COCOA, WHIP, CARAMEL -> new DecorStage(brew, s);
        };
    }

    private void start() {
        if (!hasSupplies(selected)) return;
        lastDrink = selected.ordinal();
        brew = new Brew(selected, pos);
        stepIndex = 0;
        stage = create(selected.steps()[0]);
        doneTimer = -1;
        mode = Mode.BREW;
    }

    private int stageX() { return left + 8; }
    private int stageY() { return top + 32; }
    private int stageW() { return W - 16; }
    private int stageH() { return 138; }

    private static Component grade(int score) {
        int g = score >= 90 ? 5 : score >= 75 ? 4 : score >= 60 ? 3 : score >= 40 ? 2 : 1;
        return Component.translatable("gui.aestheticjobs.cafe.grade." + g);
    }

    private static int gradeColor(int score) {
        return score >= 75 ? Ui.GOOD_D : score >= 50 ? Ui.WARN_D : Ui.BAD_D;
    }

    private void advance() {
        brew.scores.add(stage.score());
        stepIndex++;
        if (stepIndex >= brew.drink.steps().length) {
            mode = Mode.SUMMARY;
        } else {
            stage = create(brew.drink.steps()[stepIndex]);
        }
        doneTimer = -1;
    }

    private void serve() {
        PacketDistributor.sendToServer(new BrewPayload(pos, brew.drink.ordinal(), java.util.List.copyOf(brew.scores), brew.art()));
        onClose();
    }

    // ------------------------------------------------------------------ input
    private int cardX(int i) { return left + 12 + (i % 4) * 71; }
    private int cardY(int i) { return top + 32 + (i / 4) * 58; }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (mode == Mode.MENU) {
            for (int i = 0; i < Drink.values().length; i++) {
                if (Ui.in(mx, my, cardX(i), cardY(i), 68, 54)) {
                    selected = Drink.values()[i];
                    Ui.sound(net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK.value(), 1.0F, 0.6F);
                    return true;
                }
            }
            if (Ui.in(mx, my, left + W - 100, top + 170, 88, 22)) {
                start();
                return true;
            }
        } else if (mode == Mode.BREW) {
            if (Ui.in(mx, my, left + 12, top + H - 26, 70, 18)) {
                onClose();
                return true;
            }
            if (stage != null && !stage.isDone() && stage.canFinish() && Ui.in(mx, my, left + W - 112, top + H - 26, 100, 18)) {
                stage.finish();
                return true;
            }
            if (stage != null && stage.click(mx, my, button)) return true;
        } else {
            if (Ui.in(mx, my, left + W - 124, top + H - 28, 112, 20)) {
                serve();
                return true;
            }
            if (Ui.in(mx, my, left + 12, top + H - 28, 70, 20)) {
                onClose();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        if (mode == Mode.BREW && stage != null) {
            stage.scroll(scrollY);
            return true;
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }

    // ------------------------------------------------------------------ drawing
    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        long now = Util.getNanos();
        float dt = Math.min(0.05F, (now - lastNanos) / 1.0E9F);
        lastNanos = now;

        renderBackground(g, mx, my, partial);
        Ui.box(g, left - 3, top - 3, W + 6, H + 6, Ui.BORDER, Ui.BORDER);
        Ui.box(g, left, top, W, H, Ui.KHAKI, Ui.BG);
        g.renderOutline(left + 3, top + 3, W - 6, H - 6, 0x66FFFFFF);

        if (mode == Mode.MENU) renderMenu(g, mx, my);
        else if (mode == Mode.BREW) renderBrew(g, mx, my, dt);
        else renderSummary(g, mx, my);
    }

    private void renderMenu(GuiGraphics g, int mx, int my) {
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.cafe.menu"), left + 12, top + 10, Ui.INK);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.cafe.menu.hint"), left + 12, top + 21, Ui.LABEL);
        for (int i = 0; i < Drink.values().length; i++) {
            Drink d = Drink.values()[i];
            int x = cardX(i), y = cardY(i);
            boolean sel = d == selected, hov = Ui.in(mx, my, x, y, 68, 54);
            Ui.box(g, x, y, 68, 54, sel ? Ui.BAD_D : Ui.KHAKI, sel ? 0xFFFBE3D8 : hov ? 0xFFFFFBEE : Ui.INNER);
            Ui.icon(g, d.iconTexture(), x + 18, y + 3, 32);
            Ui.centered(g, font, d.displayName(), x + 34, y + 37, Ui.INK);
            Ui.centered(g, font, Component.literal(dev.aestheticjobs.economy.Money.format(d.priceCents())), x + 34, y + 46 - 1, Ui.LABEL);
        }
        // the selected recipe
        int y0 = top + 150;
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.cafe.needs"), left + 12, y0, Ui.LABEL);
        int ix = left + 12;
        ix = supplyIcon(g, ModItems.EMPTY_CUP.get(), ix, y0 + 11);
        for (Drink.Supply s : selected.supplies()) ix = supplyIcon(g, s.item(), ix, y0 + 11);
        boolean ok = hasSupplies(selected);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.cafe.steps", selected.steps().length), left + 12, y0 + 32, Ui.LABEL);
        Ui.button(g, font, left + W - 100, top + 170, 88, 22, Component.translatable("gui.aestheticjobs.cafe.start"),
                Ui.in(mx, my, left + W - 100, top + 170, 88, 22), ok, 1);
        if (!ok) Ui.centered(g, font, Component.translatable("gui.aestheticjobs.cafe.supplies_missing"), left + W - 56, top + 195, Ui.BAD_D);
    }

    private int supplyIcon(GuiGraphics g, Item item, int x, int y) {
        boolean ok = have(item) > 0;
        Ui.box(g, x, y, 20, 20, ok ? Ui.GOOD_D : Ui.BAD_D, ok ? 0xFFF2F8EC : 0xFFFBE3D8);
        Ui.icon(g, itemIcon(item), x + 2, y + 2, 16);
        return x + 23;
    }

    private void renderBrew(GuiGraphics g, int mx, int my, float dt) {
        Step[] steps = brew.drink.steps();
        // header: the drink, the steps as dots
        Ui.icon(g, brew.drink.iconTexture(), left + 8, top + 4, 24);
        Ui.text(g, font, stage.step.title(), left + 36, top + 8, Ui.INK);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.cafe.of", stepIndex + 1, steps.length), left + 36, top + 19, Ui.LABEL);
        int dotsX = left + W - 12 - steps.length * 14;
        for (int i = 0; i < steps.length; i++) {
            int c = i < stepIndex ? gradeColorFor(i) : i == stepIndex ? Ui.BAD_D : Ui.TAN;
            Ui.disc(g, dotsX + i * 14 + 5, top + 14, i == stepIndex ? 5 : 4, c);
        }

        Stage s = stage;
        s.layout(stageX(), stageY(), stageW(), stageH());
        Ui.box(g, stageX() - 1, stageY() - 1, stageW() + 2, stageH() + 2, Ui.KHAKI, Ui.INNER);
        if (!s.isDone()) s.update(dt, mx, my);
        s.render(g, font, mx, my);

        // finished: show the grade for a moment, then go on
        if (s.isDone()) {
            if (doneTimer < 0) doneTimer = 0;
            doneTimer += dt;
            int sc = s.score();
            int bw = 150, bh = 34, bx = stageX() + stageW() / 2 - bw / 2, by = stageY() + stageH() / 2 - bh / 2;
            Ui.box(g, bx, by, bw, bh, gradeColor(sc), 0xEEFFF6E2);
            Ui.centered(g, font, grade(sc), bx + bw / 2, by + 7, gradeColor(sc));
            Ui.centered(g, font, Component.literal(sc + "%"), bx + bw / 2, by + 19, Ui.INK);
            if (doneTimer > 1.1) advance();
        }

        Ui.centered(g, font, s.status(), left + W / 2, top + 175, Ui.LABEL);
        Ui.button(g, font, left + 12, top + H - 26, 70, 18, Component.translatable("gui.aestheticjobs.cafe.cancel"),
                Ui.in(mx, my, left + 12, top + H - 26, 70, 18), true, 0);
        boolean can = !s.isDone() && s.canFinish();
        Ui.button(g, font, left + W - 112, top + H - 26, 100, 18, s.finishLabel(),
                Ui.in(mx, my, left + W - 112, top + H - 26, 100, 18), can, 1);
    }

    private int gradeColorFor(int i) {
        return i < brew.scores.size() ? (brew.scores.get(i) >= 75 ? Ui.GOOD_D : brew.scores.get(i) >= 50 ? Ui.WARN_D : Ui.BAD_D) : Ui.TAN;
    }

    private void renderSummary(GuiGraphics g, int mx, int my) {
        Step[] steps = brew.drink.steps();
        int q = brew.estimate();
        int stars = brew.stars(q);
        Ui.icon(g, brew.drink.iconTexture(), left + 8, top + 4, 24);
        Ui.text(g, font, brew.drink.displayName(), left + 36, top + 8, Ui.INK);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.cafe.ready"), left + 36, top + 19, Ui.LABEL);

        // the cup from above
        int cell = 7, cx = left + 14, cy = top + 40;
        Ui.disc(g, cx + 8 * cell, cy + 8 * cell, 8 * cell + 9, 0xFFE6D9BA);
        Ui.disc(g, cx + 8 * cell, cy + 8 * cell, 8 * cell + 5, 0xFFFFF6E2);
        CupRenderer.draw(g, cx, cy, cell, brew.art(), brew.drink);
        Ui.ring(g, cx + 8 * cell, cy + 8 * cell, 8 * cell + 1, 2, 0xFFD9CBA8);

        // the result
        int rx = left + 150;
        Ui.text(g, font, Component.literal(CupData.starText(stars)), rx, top + 36, 0xFFD9A850);
        Ui.text(g, font, Component.literal(q + "%"), rx + 62, top + 36, Ui.INK);
        for (int i = 0; i < steps.length && i < brew.scores.size(); i++) {
            int y = top + 54 + i * 15, sc = brew.scores.get(i);
            Ui.text(g, font, steps[i].title(), rx, y, Ui.LABEL);
            Ui.bar(g, rx + 78, y + 1, 52, 6, sc / 100.0, sc >= 75 ? Ui.GOOD : sc >= 50 ? Ui.WARN : Ui.BAD);
            Ui.text(g, font, Component.literal(String.valueOf(sc)), rx + 134, y, Ui.INK);
        }
        Ui.button(g, font, left + 12, top + H - 28, 70, 20, Component.translatable("gui.aestheticjobs.cafe.cancel"),
                Ui.in(mx, my, left + 12, top + H - 28, 70, 20), true, 0);
        Ui.button(g, font, left + W - 124, top + H - 28, 112, 20, Component.translatable("gui.aestheticjobs.cafe.serve"),
                Ui.in(mx, my, left + W - 124, top + H - 28, 112, 20), true, 1);
    }
}
