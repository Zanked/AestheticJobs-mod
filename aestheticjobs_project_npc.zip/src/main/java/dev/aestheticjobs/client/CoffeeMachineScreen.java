package dev.aestheticjobs.client;

import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.network.BrewPayload;
import dev.aestheticjobs.registry.ModItems;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

/**
 * Two steps: 1) pull the espresso shot (stop the needle in the green zone), 2) draw the latte art on the foam.
 * Everything is drawn with plain fills in the mod's warm palette, no texture needed.
 */
public class CoffeeMachineScreen extends Screen {
    private static final int W = 252, H = 176;
    private static final int CELL = 8;

    private static final int BG = 0xFFEFE0BC, BORDER = 0xFF5C4234, INNER = 0xFFFCF0D6;
    private static final int TEXT = 0xFF5C4234, LABEL = 0xFF7A5C48, ERROR = 0xFFB0604A;

    private final BlockPos pos;
    private Drink drink = Drink.HEART;
    private boolean artPhase = false;

    // shot
    private long meterStart = Util.getMillis();
    private boolean stopped = false;
    private long stoppedAt;
    private int extraction;

    // art
    private final char[] art = new char[Drink.CELLS];
    private char brush = '1';
    private int lastCell = -1;
    private long flashUntil;

    private int left, top;

    public CoffeeMachineScreen(BlockPos pos) {
        super(Component.translatable("block.aestheticjobs.coffee_machine"));
        this.pos = pos;
        java.util.Arrays.fill(art, '0');
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ------------------------------------------------------------------ helpers
    private boolean hasSupplies() {
        var player = Minecraft.getInstance().player;
        return player != null
                && CafeLogic.count(player, ModItems.EMPTY_CUP.get()) > 0
                && CafeLogic.count(player, ModItems.COFFEE_BEANS.get()) > 0;
    }

    private double meterPos() {
        double ph = ((Util.getMillis() - meterStart) % 1400L) / 1400.0;
        return ph < 0.5 ? ph * 2 : 2 - ph * 2;
    }

    private static int extractionScore(double p) {
        double dist = Math.abs(p - 0.5) * 2;
        if (dist <= 0.2) return 100;
        return (int) Math.round(100 * Math.pow(Math.max(0, 1 - (dist - 0.2) / 0.8), 1.5));
    }

    private void click() {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private String artString() {
        return new String(art);
    }

    private int filled() {
        int n = 0;
        for (char c : art) if (c != '0') n++;
        return n;
    }

    // ------------------------------------------------------------------ layout
    private int chipX(int i) { return left + 8 + i * 61; }
    private int chipY() { return top + 24; }
    private int shotBtnX() { return left + W / 2 - 55; }
    private int shotBtnY() { return top + 118; }
    private int canvasX() { return left + 12; }
    private int canvasY() { return top + 30; }

    // ------------------------------------------------------------------ logic
    @Override
    public void tick() {
        if (!artPhase && stopped && Util.getMillis() - stoppedAt > 800) {
            artPhase = true;
        }
    }

    private void stopMeter() {
        if (stopped || !hasSupplies()) return;
        stopPos = meterPos();
        extraction = extractionScore(stopPos);
        stopped = true;
        stoppedAt = Util.getMillis();
        click();
    }

    private void finish() {
        if (filled() < 6) {
            flashUntil = Util.getMillis() + 1500;
            return;
        }
        PacketDistributor.sendToServer(new BrewPayload(pos, drink.ordinal(), extraction, artString()));
        onClose();
    }

    private void paintCell(double mx, double my, int button) {
        int cx = (int) Math.floor((mx - canvasX()) / CELL);
        int cy = (int) Math.floor((my - canvasY()) / CELL);
        if (cx < 0 || cy < 0 || cx >= Drink.SIZE || cy >= Drink.SIZE) { lastCell = -1; return; }
        int idx = cy * Drink.SIZE + cx;
        // fill the gap between two drag events so quick strokes stay solid
        if (lastCell >= 0) {
            int lx = lastCell % Drink.SIZE, ly = lastCell / Drink.SIZE;
            int steps = Math.max(Math.abs(cx - lx), Math.abs(cy - ly));
            for (int s = 1; s < steps; s++) {
                setCell(lx + Math.round((float) (cx - lx) * s / steps), ly + Math.round((float) (cy - ly) * s / steps), button);
            }
        }
        setCell(cx, cy, button);
        lastCell = idx;
    }

    private void setCell(int x, int y, int button) {
        if (!Drink.inCup(x, y)) return;
        art[y * Drink.SIZE + x] = button == 1 ? '0' : brush;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (!artPhase) {
            for (int i = 0; i < Drink.values().length; i++) {
                if (in(mx, my, chipX(i), chipY(), 56, 14) && !stopped) {
                    drink = Drink.values()[i];
                    click();
                    return true;
                }
            }
            if (in(mx, my, shotBtnX(), shotBtnY(), 110, 18)) {
                stopMeter();
                return true;
            }
        } else {
            int rx = left + 152;
            if (in(mx, my, rx, top + 46, 88, 13)) { brush = '1'; click(); return true; }
            if (in(mx, my, rx, top + 62, 88, 13)) { brush = '2'; click(); return true; }
            if (in(mx, my, rx, top + 120, 88, 14)) { java.util.Arrays.fill(art, '0'); click(); return true; }
            if (in(mx, my, rx, top + 138, 88, 18)) { finish(); return true; }
            lastCell = -1;
            paintCell(mx, my, button);
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (artPhase) {
            paintCell(mx, my, button);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        lastCell = -1;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (!artPhase && key == GLFW.GLFW_KEY_SPACE) {
            stopMeter();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    // ------------------------------------------------------------------ drawing
    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        renderBackground(g, mx, my, partial);
        g.fill(left - 2, top - 2, left + W + 2, top + H + 2, BORDER);
        g.fill(left, top, left + W, top + H, BG);
        g.renderOutline(left + 2, top + 2, W - 4, H - 4, INNER);

        if (!artPhase) renderShot(g, mx, my); else renderArt(g, mx, my);
    }

    private void text(GuiGraphics g, Component c, int x, int y, int color) {
        g.drawString(font, c, x, y, color, false);
    }

    private void centered(GuiGraphics g, Component c, int cx, int y, int color) {
        g.drawString(font, c, cx - font.width(c) / 2, y, color, false);
    }

    private void button(GuiGraphics g, int x, int y, int w, int h, Component label, boolean hover, boolean enabled, int kind) {
        int border, base;
        if (!enabled) { border = 0xFFBFAE90; base = 0xFFDDD3BC; }
        else if (kind == 1) { border = 0xFF7C9E6C; base = hover ? 0xFFC4DAB2 : 0xFFAAC496; }   // main action
        else if (kind == 2) { border = 0xFFC98468; base = hover ? 0xFFF2C4AE : 0xFFE8B096; }   // selected
        else { border = 0xFFA8946C; base = hover ? 0xFFF6EAC8 : 0xFFE9D9B0; }
        g.fill(x, y, x + w, y + h, border);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, base);
        g.drawString(font, label, x + w / 2 - font.width(label) / 2, y + (h - 8) / 2 + 1, enabled ? TEXT : 0xFF9A8A70, false);
    }

    private void renderShot(GuiGraphics g, int mx, int my) {
        text(g, Component.translatable("gui.aestheticjobs.cafe.title"), left + 10, top + 9, TEXT);
        for (int i = 0; i < Drink.values().length; i++) {
            Drink d = Drink.values()[i];
            button(g, chipX(i), chipY(), 56, 14, d.displayName(), in(mx, my, chipX(i), chipY(), 56, 14) && !stopped, !stopped,
                    d == drink ? 2 : 0);
        }
        centered(g, Component.translatable("gui.aestheticjobs.cafe.pick"), left + W / 2, top + 44, LABEL);

        // pressure meter
        int bx = left + 24, by = top + 70, bw = 204, bh = 16;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + bh + 1, 0xFFA8946C);
        g.fill(bx, by, bx + bw, by + bh, 0xFFD7C9A5);
        int zx = bx + (int) (bw * 0.4), zw = (int) (bw * 0.2);
        g.fill(zx, by, zx + zw, by + bh, 0xFFAAC496);
        g.renderOutline(zx, by, zw, bh, 0xFF7C9E6C);
        double p = stopped ? stopPos : meterPos();
        int nx = bx + (int) (bw * p);
        g.fill(nx - 1, by - 3, nx + 2, by + bh + 3, 0xFF402C24);
        centered(g, Component.translatable("gui.aestheticjobs.cafe.hint"), left + W / 2, top + 92, LABEL);

        if (stopped) {
            centered(g, Component.translatable("gui.aestheticjobs.cafe.shot", extraction), left + W / 2, top + 104, TEXT);
        }
        boolean supplies = hasSupplies();
        button(g, shotBtnX(), shotBtnY(), 110, 18, Component.translatable("gui.aestheticjobs.cafe.pull"),
                in(mx, my, shotBtnX(), shotBtnY(), 110, 18), supplies && !stopped, 1);
        centered(g, Component.translatable(supplies ? "gui.aestheticjobs.cafe.supplies_ok" : "gui.aestheticjobs.cafe.supplies_missing"),
                left + W / 2, top + 148, supplies ? LABEL : ERROR);
    }

    private double stopPos = 0.5;

    private void renderArt(GuiGraphics g, int mx, int my) {
        text(g, Component.translatable("gui.aestheticjobs.cafe.art_title"), left + 10, top + 9, TEXT);
        int cx = canvasX(), cy = canvasY();
        g.fill(cx - 5, cy - 5, cx + Drink.SIZE * CELL + 5, cy + Drink.SIZE * CELL + 5, 0xFFC9B88E);
        g.fill(cx - 4, cy - 4, cx + Drink.SIZE * CELL + 4, cy + Drink.SIZE * CELL + 4, 0xFFE9D9B0);
        CupRenderer.draw(g, cx, cy, CELL, artString(), drink);

        int rx = left + 152;
        text(g, drink.displayName(), rx, top + 30, TEXT);
        button(g, rx, top + 46, 88, 13, Component.translatable("gui.aestheticjobs.cafe.milk"), in(mx, my, rx, top + 46, 88, 13), true, brush == '1' ? 2 : 0);
        g.fill(rx + 3, top + 49, rx + 9, top + 55, CupRenderer.MILK);
        g.renderOutline(rx + 3, top + 49, 6, 6, 0xFFA8946C);
        button(g, rx, top + 62, 88, 13, Component.translatable("gui.aestheticjobs.cafe.cocoa"), in(mx, my, rx, top + 62, 88, 13), true, brush == '2' ? 2 : 0);
        g.fill(rx + 3, top + 65, rx + 9, top + 71, CupRenderer.COCOA);

        int accuracy = filled() == 0 ? 0 : drink.score(artString());
        text(g, Component.translatable("gui.aestheticjobs.cafe.accuracy", accuracy), rx, top + 84, TEXT);
        text(g, Component.translatable("gui.aestheticjobs.cafe.shot", extraction), rx, top + 96, LABEL);
        text(g, Component.translatable("gui.aestheticjobs.cafe.erase"), rx, top + 108, LABEL);

        button(g, rx, top + 120, 88, 14, Component.translatable("gui.aestheticjobs.cafe.reset"), in(mx, my, rx, top + 120, 88, 14), true, 0);
        button(g, rx, top + 138, 88, 18, Component.translatable("gui.aestheticjobs.cafe.done"), in(mx, my, rx, top + 138, 88, 18), true, 1);
        if (Util.getMillis() < flashUntil) {
            centered(g, Component.translatable("gui.aestheticjobs.cafe.draw_more"), left + W / 2, top + H - 14, ERROR);
        }
    }
}
