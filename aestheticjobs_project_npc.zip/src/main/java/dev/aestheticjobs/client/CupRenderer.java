package dev.aestheticjobs.client;

import dev.aestheticjobs.cafe.Drink;
import net.minecraft.client.gui.GuiGraphics;

/** Draws the round cup top with the latte art. Used by the brewing screen and by item tooltips. */
public final class CupRenderer {
    public static final int COFFEE = 0xFF7A5238;
    public static final int MILK = 0xFFFCF0D6;
    public static final int COCOA = 0xFF402C24;
    public static final int GUIDE = 0xFFA27A58;

    private CupRenderer() {}

    /** guide != null: faint dots show where the pattern goes (only for big cells). */
    public static void draw(GuiGraphics g, int x, int y, int cell, String art, Drink guide) {
        for (int cy = 0; cy < Drink.SIZE; cy++) {
            for (int cx = 0; cx < Drink.SIZE; cx++) {
                if (!Drink.inCup(cx, cy)) continue;
                char c = art.charAt(cy * Drink.SIZE + cx);
                int color = c == '1' ? MILK : c == '2' ? COCOA : COFFEE;
                int x0 = x + cx * cell, y0 = y + cy * cell;
                g.fill(x0, y0, x0 + cell, y0 + cell, color);
                if (guide != null && c == '0' && cell >= 6 && guide.inTemplate(cx, cy)) {
                    int m = cell / 2 - 1;
                    g.fill(x0 + m, y0 + m, x0 + m + 2, y0 + m + 2, GUIDE);
                }
            }
        }
    }
}
