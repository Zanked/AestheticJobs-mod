package dev.aestheticjobs.block;

import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModBlockEntities;
import dev.aestheticjobs.registry.ModSounds;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * What the espresso machine is doing right now, so that EVERYBODY near it sees the barista work (the brewing
 * screen itself is client-side only). The barista's screen reports the phase of the recipe it is in; the
 * server stores it, syncs it to the clients, and the renderer animates the machine from it
 * (see client/CoffeeMachineRenderer). The state is only trusted while the screen keeps pinging it.
 */
public class CoffeeMachineBlockEntity extends BlockEntity {
    public static final int IDLE = 0, GRIND = 1, TAMP = 2, PULL = 3, WATER = 4, STEAM = 5, STIR = 6, LAYER = 7,
            POUR = 8, FINISH = 9, DONE = 10;
    /** The screen pings every 2 s; with no ping for 6 s the machine falls back to idle (screen closed, player left). */
    public static final long TIMEOUT_TICKS = 120L;

    private int phase = IDLE;
    private int drink;
    private long phaseStart;
    private String art = "";
    // server only
    private long lastPing;
    @Nullable private UUID operator;

    public CoffeeMachineBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.COFFEE_MACHINE.get(), pos, state);
    }

    public int getPhase() { return phase; }
    public int getDrinkIndex() { return drink; }
    public long getPhaseStart() { return phaseStart; }
    public String getArt() { return art; }

    /** Which phase of the machine a recipe step belongs to. */
    public static int phaseOf(Step.Kind kind) {
        return switch (kind) {
            case GRIND -> GRIND;
            case TAMP -> TAMP;
            case PULL -> PULL;
            case WATER -> WATER;
            case STEAM -> STEAM;
            case STIR -> STIR;
            case LAYER -> LAYER;
            case POUR -> POUR;
            case COCOA, WHIP, CARAMEL -> FINISH;
        };
    }

    // ------------------------------------------------------------------ server side

    /**
     * Called for a report of the barista's screen. Returns false if another barista is busy at this machine.
     * The same phase again is just a heartbeat.
     */
    public boolean setState(ServerLevel level, ServerPlayer player, int newPhase, int newDrink, String newArt) {
        long now = level.getGameTime();
        boolean busy = phase != IDLE && operator != null && !operator.equals(player.getUUID()) && now - lastPing <= TIMEOUT_TICKS;
        if (busy) return false;
        if (newPhase < IDLE || newPhase > DONE) return false;
        if (newPhase == IDLE) {
            if (phase != IDLE && (operator == null || operator.equals(player.getUUID()))) reset(level);
            return true;
        }
        if (Drink.byIndex(newDrink) == null) return false;
        String cleanArt = "";
        if (newPhase == DONE) {
            String s = Drink.sanitize(newArt);
            cleanArt = s == null ? "" : s;
        }

        lastPing = now;
        operator = player.getUUID();
        if (newPhase == phase && newDrink == drink && cleanArt.equals(art)) return true;   // heartbeat

        boolean wasActive = phase != IDLE;
        phase = newPhase;
        drink = newDrink;
        art = cleanArt;
        phaseStart = now;
        sync(level, wasActive);
        SoundEvent sound = soundOf(newPhase);
        if (sound != null) level.playSound(player, worldPosition, sound, SoundSource.BLOCKS, 0.7F, 1.0F);   // the barista hears the screen's own sound
        return true;
    }

    @Nullable
    private static SoundEvent soundOf(int phase) {
        return switch (phase) {
            case GRIND -> ModSounds.BARISTA_GRIND.get();
            case TAMP -> ModSounds.BARISTA_TAMP.get();
            case PULL -> ModSounds.BARISTA_PUMP.get();
            case STEAM -> ModSounds.BARISTA_STEAM.get();
            case POUR -> ModSounds.BARISTA_POUR.get();
            case FINISH -> ModSounds.BARISTA_SPRINKLE.get();
            default -> null;
        };
    }

    public void reset(ServerLevel level) {
        boolean wasActive = phase != IDLE;
        phase = IDLE;
        art = "";
        operator = null;
        sync(level, wasActive);
    }

    /** Syncs to the clients; the BREWING block state switches the model with the built-in cup to the one without it. */
    private void sync(ServerLevel level, boolean wasActive) {
        setChanged();
        BlockState state = level.getBlockState(worldPosition);
        if (!state.hasProperty(CoffeeMachineBlock.BREWING)) return;
        boolean active = phase != IDLE;
        if (state.getValue(CoffeeMachineBlock.BREWING) != active) {
            level.setBlock(worldPosition, state.setValue(CoffeeMachineBlock.BREWING, active), 3);
        } else {
            level.sendBlockUpdated(worldPosition, state, state, 3);
        }
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, CoffeeMachineBlockEntity be) {
        if (be.phase != IDLE && level instanceof ServerLevel sl && level.getGameTime() - be.lastPing > TIMEOUT_TICKS) {
            be.reset(sl);
        }
    }

    // ------------------------------------------------------------------ client side: particles

    /** A point of the machine (block-local pixels, machine facing north) in the world. */
    private static Vec3 world(BlockPos pos, Direction facing, double x, double y, double z) {
        double cx = x - 8.0, cz = z - 8.0, rx, rz;
        switch (facing) {
            case EAST -> { rx = -cz; rz = cx; }
            case SOUTH -> { rx = -cx; rz = -cz; }
            case WEST -> { rx = cz; rz = -cx; }
            default -> { rx = cx; rz = cz; }
        }
        return new Vec3(pos.getX() + (rx + 8.0) / 16.0, pos.getY() + y / 16.0, pos.getZ() + (rz + 8.0) / 16.0);
    }

    private static final DustParticleOptions GROUNDS = new DustParticleOptions(new Vector3f(0.33F, 0.20F, 0.12F), 0.7F);

    public static void clientTick(Level level, BlockPos pos, BlockState state, CoffeeMachineBlockEntity be) {
        if (be.phase == IDLE) return;
        RandomSource r = level.random;
        Direction f = state.hasProperty(CoffeeMachineBlock.FACING) ? state.getValue(CoffeeMachineBlock.FACING) : Direction.NORTH;
        switch (be.phase) {
            case GRIND -> {
                if (r.nextInt(2) == 0) {
                    Vec3 p = world(pos, f, 8.0 + (r.nextDouble() - 0.5) * 1.2, 4.6, 3.2);
                    level.addParticle(GROUNDS, p.x, p.y, p.z, 0.0, -0.02, 0.0);
                }
            }
            case PULL, WATER -> {
                if (r.nextInt(5) == 0) {
                    Vec3 p = world(pos, f, 8.0 + (r.nextDouble() - 0.5) * 2.0, 3.8, 2.9);
                    level.addParticle(ParticleTypes.CLOUD, p.x, p.y, p.z, 0.0, 0.01, 0.0);
                }
            }
            case STEAM -> {
                for (int i = 0; i < 2; i++) {
                    Vec3 p = world(pos, f, 15.3 + (r.nextDouble() - 0.5) * 0.8, 4.2, 5.5 + (r.nextDouble() - 0.5) * 0.8);
                    level.addParticle(ParticleTypes.CLOUD, p.x, p.y, p.z, (r.nextDouble() - 0.5) * 0.01, 0.04, (r.nextDouble() - 0.5) * 0.01);
                }
            }
            case DONE -> {
                if (r.nextInt(6) == 0) {
                    Vec3 p = world(pos, f, 8.0 + (r.nextDouble() - 0.5), 4.2, 2.6 + (r.nextDouble() - 0.5));
                    level.addParticle(ParticleTypes.CLOUD, p.x, p.y, p.z, 0.0, 0.015, 0.0);
                }
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------ saving and syncing

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("phase", phase);
        tag.putInt("drink", drink);
        tag.putLong("start", phaseStart);
        tag.putString("art", art);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        phase = tag.getInt("phase");
        drink = tag.getInt("drink");
        phaseStart = tag.getLong("start");
        art = tag.getString("art");
        // lastPing stays 0 after loading: the server tick sees a stale state and resets the machine to idle
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
