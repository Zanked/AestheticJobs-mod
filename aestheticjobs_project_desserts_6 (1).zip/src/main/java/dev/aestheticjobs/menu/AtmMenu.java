package dev.aestheticjobs.menu;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.economy.Bank;
import dev.aestheticjobs.economy.Denomination;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.economy.Transaction;
import dev.aestheticjobs.item.CardOwner;
import dev.aestheticjobs.registry.ModBlocks;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.registry.ModItems;
import dev.aestheticjobs.registry.ModMenus;
import dev.aestheticjobs.registry.ModSounds;
import java.util.Arrays;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * Cash terminal menu with two modes, built to feel like a real machine.
 *
 * Card: put it in the reader slot, or right-click the terminal holding it (it slides in by itself).
 *       It comes back when the screen is closed.
 * PIN: the account of a card is protected by a 4-digit PIN. The first PIN is set by the card's owner
 *       at the terminal. Withdrawing and seeing the balance need the PIN; paying cash IN does not.
 *       Three wrong tries block the card for a while. Anyone who has the card AND the PIN may withdraw.
 * DEPOSIT: bills in the feeder slot are pulled in ONE BY ONE with a click for every bill; the counter
 *       on the display runs up. "Confirm" credits the counted sum to the card's account.
 * WITHDRAW: the player builds a sum by clicking denominations. "Confirm" debits the account and the
 *       machine pushes the bills out ONE BY ONE into the tray (the same slot). Take them from the tray.
 *
 * All logic runs on the server; the client only receives numbers (never the PIN of a card).
 */
public class AtmMenu extends AbstractContainerMenu {
    public static final int CARD_SLOT = 0;
    public static final int BILL_SLOT = 1;
    public static final int MAX_BILLS = 40;

    /** Ticks between two bills pulled in / pushed out. */
    private static final int FEED_INTERVAL = 3;
    private static final int DISPENSE_INTERVAL = 4;

    public static final int MODE_DEPOSIT = 0;
    public static final int MODE_WITHDRAW = 1;

    // button ids (sent from the client)
    public static final int BUTTON_CANCEL = 0;
    public static final int BUTTON_CONFIRM = 1;
    public static final int BUTTON_MODE_DEPOSIT = 2;
    public static final int BUTTON_MODE_WITHDRAW = 3;
    public static final int BUTTON_ADD_BASE = 10;      // + bill index: add one bill
    public static final int BUTTON_REMOVE_BASE = 20;   // + bill index: remove one bill
    public static final int BUTTON_ADD5_BASE = 30;     // + bill index: add five bills
    public static final int BUTTON_PIN_ENTER_BASE = 1000;   // + the 4-digit PIN as a number (0..9999)
    public static final int BUTTON_PIN_SET_BASE = 20000;    // + the new 4-digit PIN as a number

    public static final int STATUS_NO_CARD = 0;
    public static final int STATUS_CARD = 1;           // a card bound to an account
    public static final int STATUS_BLANK_CARD = 2;     // not activated yet

    public static final int ACCESS_NONE = 0;           // no usable card
    public static final int ACCESS_SET_PIN = 1;        // owner's card, no PIN yet: choose one
    public static final int ACCESS_ENTER_PIN = 2;
    public static final int ACCESS_LOCKED = 3;         // too many wrong PINs
    public static final int ACCESS_UNLOCKED = 4;
    public static final int ACCESS_NO_PIN = 5;         // somebody else's card whose owner has not set a PIN

    /** Bills in ascending order: $1 ... $100. The index is the position in the counts array. */
    public static final Denomination[] BILLS = Arrays.stream(Denomination.values())
            .filter(Denomination::isBill).toArray(Denomination[]::new);

    /*
     * Synced numbers. Vanilla sends container data as 16-bit values, so bigger numbers are split:
     * 0-1 pending cents (lo, hi), 2-4 balance cents (3 x 16 bit), 5 status,
     * 6 flags (bit0 = withdraw mode, bit1 = dispensing), 7 access, 8 seconds left of a block,
     * 9.. count per bill.
     */
    private static final int DATA_SIZE = 9 + BILLS.length;

    private final ContainerLevelAccess access;
    private final Player player;
    private final ContainerData data;

    private final SimpleContainer cardContainer = new SimpleContainer(1) {
        @Override
        public void setChanged() {
            super.setChanged();
            AtmMenu.this.slotsChanged(this);
        }
    };
    private final SimpleContainer billContainer = new SimpleContainer(1) {
        @Override
        public void setChanged() {
            super.setChanged();
            AtmMenu.this.slotsChanged(this);
        }
    };

    // server-side state
    private final int[] counts = new int[BILLS.length];
    private int pendingCents;
    private long balanceCache;
    private int status;
    private int accessState;
    private int lockSeconds;
    private boolean unlocked;
    @Nullable private UUID unlockedFor;
    private int mode = MODE_DEPOSIT;
    private boolean dispensing;
    private boolean cardPresent;
    private boolean limitWarned;
    private long lastTick = -1;
    private int tickCount;

    /** Client side. */
    public AtmMenu(int containerId, Inventory inventory) {
        this(containerId, inventory, ContainerLevelAccess.NULL, new SimpleContainerData(DATA_SIZE));
    }

    /** Server side. */
    public AtmMenu(int containerId, Inventory inventory, ContainerLevelAccess access) {
        this(containerId, inventory, access, null);
    }

    private AtmMenu(int containerId, Inventory inventory, ContainerLevelAccess access, @Nullable ContainerData clientData) {
        super(ModMenus.ATM.get(), containerId);
        this.player = inventory.player;
        this.access = access;
        this.data = clientData != null ? clientData : new ServerData();

        addSlot(new Slot(cardContainer, 0, 19, 39) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return stack.is(ModItems.BANK_CARD.get());
            }

            @Override
            public int getMaxStackSize() {
                return 1;
            }
        });
        // feeder in DEPOSIT mode, dispenser tray in WITHDRAW mode
        addSlot(new Slot(billContainer, 0, 141, 39) {
            @Override
            public boolean mayPlace(ItemStack stack) {
                return getMode() == MODE_DEPOSIT && billIndex(stack) >= 0;
            }
        });
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, 9 + row * 9 + col, 8 + col * 18, 124 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, 8 + col * 18, 182));
        }
        addDataSlots(this.data);
    }

    /** Server side: the card the player was holding when clicking the terminal. */
    public void preloadCard(ItemStack card) {
        cardContainer.setItem(0, card);
    }

    // ---------------- helpers ----------------

    public static int billIndex(ItemStack stack) {
        if (stack.isEmpty()) return -1;
        for (int i = 0; i < BILLS.length; i++) {
            if (stack.is(ModItems.MONEY.get(BILLS[i]).get())) return i;
        }
        return -1;
    }

    private int totalBills() {
        int sum = 0;
        for (int c : counts) sum += c;
        return sum;
    }

    @Nullable
    private CardOwner cardOwner() {
        ItemStack card = cardContainer.getItem(0);
        return card.isEmpty() ? null : card.get(ModComponents.CARD_OWNER.get());
    }

    private void message(Player target, String key, Object... args) {
        target.displayClientMessage(Component.translatable(key, args), true);
    }

    private void sound(SoundEvent event, float pitch) {
        access.execute((level, pos) -> level.playSound(null, pos, event, SoundSource.BLOCKS, 0.8F, pitch));
    }

    /** Like vanilla crafting grids: a disconnected or dead player's items are dropped instead of lost. */
    private void giveBack(Player target, ItemStack stack) {
        boolean gone = !target.isAlive() || (target instanceof ServerPlayer sp && sp.hasDisconnected());
        if (gone) {
            target.drop(stack, false);
        } else {
            target.getInventory().placeItemBackInInventory(stack);
        }
    }

    // ---------------- server tick ----------------

    @Override
    public void broadcastChanges() {
        if (!player.level().isClientSide) {
            refreshState();
            tick();
        }
        super.broadcastChanges();
    }

    /** Runs at most once per game tick, however often vanilla calls broadcastChanges. */
    private void tick() {
        long now = player.level().getGameTime();
        if (now == lastTick) return;
        lastTick = now;
        tickCount++;
        if (mode == MODE_DEPOSIT) {
            if (tickCount % FEED_INTERVAL == 0) feedBill();
        } else if (dispensing) {
            if (tickCount % DISPENSE_INTERVAL == 0) dispenseBill();
        }
    }

    /** Pull ONE bill from the feeder into the counter. */
    private void feedBill() {
        ItemStack stack = billContainer.getItem(0);
        int idx = billIndex(stack);
        if (idx < 0) {
            limitWarned = false;
            return;
        }
        if (totalBills() >= MAX_BILLS) {
            if (!limitWarned) {
                message(player, "gui.aestheticjobs.atm.limit", MAX_BILLS);
                limitWarned = true;
            }
            return;
        }
        counts[idx]++;
        pendingCents += (int) BILLS[idx].cents();
        stack.shrink(1);
        if (stack.isEmpty()) {
            billContainer.setItem(0, ItemStack.EMPTY);
        } else {
            billContainer.setChanged();
        }
        // the pitch rises while counting
        sound(ModSounds.BILL_FEED.get(), 1.0F + Math.min(0.5F, totalBills() * 0.012F));
    }

    /** Push ONE bill (largest first) out into the tray. */
    private void dispenseBill() {
        int idx = -1;
        for (int i = BILLS.length - 1; i >= 0; i--) {
            if (counts[i] > 0) {
                idx = i;
                break;
            }
        }
        if (idx < 0) {
            finishDispensing();
            return;
        }
        Item item = ModItems.MONEY.get(BILLS[idx]).get();
        ItemStack tray = billContainer.getItem(0);
        if (tray.isEmpty()) {
            billContainer.setItem(0, new ItemStack(item, 1));
        } else if (tray.is(item) && tray.getCount() < tray.getMaxStackSize()) {
            tray.grow(1);
            billContainer.setChanged();
        } else {
            return;     // the tray holds another denomination: wait until the player takes it
        }
        counts[idx]--;
        pendingCents -= (int) BILLS[idx].cents();
        sound(ModSounds.DISPENSE.get(), 1.0F);
        if (totalBills() == 0) finishDispensing();
    }

    private void finishDispensing() {
        dispensing = false;
        pendingCents = 0;
        Arrays.fill(counts, 0);
        message(player, "gui.aestheticjobs.atm.take_cash");
        sound(ModSounds.SUCCESS.get(), 1.0F);
    }

    private void refreshState() {
        ItemStack card = cardContainer.getItem(0);
        CardOwner owner = card.isEmpty() ? null : card.get(ModComponents.CARD_OWNER.get());
        UUID ownerId = owner == null ? null : owner.id();
        if (card.isEmpty()) {
            status = STATUS_NO_CARD;
        } else if (owner == null) {
            status = STATUS_BLANK_CARD;
        } else {
            status = STATUS_CARD;
        }
        // the PIN session belongs to one card: another card or no card closes it
        if (unlocked && (ownerId == null || !ownerId.equals(unlockedFor))) {
            unlocked = false;
            unlockedFor = null;
        }
        boolean present = !card.isEmpty();
        if (present != cardPresent) {
            cardPresent = present;
            sound(present ? ModSounds.CARD_INSERT.get() : ModSounds.CARD_EJECT.get(), 1.0F);
        }

        MinecraftServer server = player.getServer();
        lockSeconds = 0;
        if (ownerId == null || server == null) {
            accessState = ACCESS_NONE;
        } else if (unlocked) {
            accessState = ACCESS_UNLOCKED;
        } else {
            long lock = Bank.lockSecondsLeft(server, ownerId);
            if (lock > 0) {
                accessState = ACCESS_LOCKED;
                lockSeconds = (int) Math.min(lock, 65535);
            } else if (!Bank.hasPin(server, ownerId)) {
                accessState = ownerId.equals(player.getUUID()) ? ACCESS_SET_PIN : ACCESS_NO_PIN;
            } else {
                accessState = ACCESS_ENTER_PIN;
            }
        }
        // the balance is only sent after the PIN has been entered
        balanceCache = (accessState == ACCESS_UNLOCKED) ? Bank.balance(server, ownerId) : 0L;
    }

    // ---------------- buttons ----------------

    @Override
    public boolean clickMenuButton(Player clicker, int id) {
        if (clicker.level().isClientSide) return false;
        if (dispensing) return false;                 // the machine is busy pushing cash out
        if (id >= BUTTON_PIN_ENTER_BASE && id < BUTTON_PIN_ENTER_BASE + 10000) {
            enterPin(clicker, id - BUTTON_PIN_ENTER_BASE);
            return true;
        }
        if (id >= BUTTON_PIN_SET_BASE && id < BUTTON_PIN_SET_BASE + 10000) {
            setPin(clicker, id - BUTTON_PIN_SET_BASE);
            return true;
        }
        if (id == BUTTON_CANCEL) {
            if (mode == MODE_DEPOSIT) returnBills(clicker); else clearSelection();
            return true;
        }
        if (id == BUTTON_CONFIRM) {
            if (mode == MODE_DEPOSIT) deposit(clicker); else withdraw(clicker);
            return true;
        }
        if (id == BUTTON_MODE_DEPOSIT) {
            setMode(clicker, MODE_DEPOSIT);
            return true;
        }
        if (id == BUTTON_MODE_WITHDRAW) {
            setMode(clicker, MODE_WITHDRAW);
            return true;
        }
        if (id >= BUTTON_ADD_BASE && id < BUTTON_ADD_BASE + BILLS.length) {
            adjust(clicker, id - BUTTON_ADD_BASE, 1);
            return true;
        }
        if (id >= BUTTON_REMOVE_BASE && id < BUTTON_REMOVE_BASE + BILLS.length) {
            adjust(clicker, id - BUTTON_REMOVE_BASE, -1);
            return true;
        }
        if (id >= BUTTON_ADD5_BASE && id < BUTTON_ADD5_BASE + BILLS.length) {
            adjust(clicker, id - BUTTON_ADD5_BASE, 5);
            return true;
        }
        return false;
    }

    private void enterPin(Player entering, int value) {
        CardOwner owner = cardOwner();
        MinecraftServer server = entering.getServer();
        if (owner == null || server == null || accessState != ACCESS_ENTER_PIN) return;
        Bank.PinOutcome outcome = Bank.verifyPin(server, owner.id(), String.format("%04d", value));
        switch (outcome.result()) {
            case OK -> {
                unlocked = true;
                unlockedFor = owner.id();
                message(entering, "gui.aestheticjobs.atm.pin.ok");
                sound(ModSounds.PIN_OK.get(), 1.0F);
            }
            case WRONG -> {
                message(entering, "gui.aestheticjobs.atm.pin.wrong", outcome.attemptsLeft());
                sound(ModSounds.PIN_FAIL.get(), 1.0F);
            }
            case LOCKED -> {
                message(entering, "gui.aestheticjobs.atm.pin.blocked", (outcome.lockSecondsLeft() + 59) / 60);
                sound(ModSounds.PIN_FAIL.get(), 0.8F);
            }
            default -> sound(ModSounds.ERROR.get(), 1.0F);
        }
    }

    private void setPin(Player entering, int value) {
        CardOwner owner = cardOwner();
        MinecraftServer server = entering.getServer();
        if (owner == null || server == null || accessState != ACCESS_SET_PIN) return;
        if (!owner.id().equals(entering.getUUID())) return;      // only the owner chooses the first PIN
        if (Bank.setPin(server, owner.id(), String.format("%04d", value))) {
            unlocked = true;
            unlockedFor = owner.id();
            message(entering, "gui.aestheticjobs.atm.pin.set_done");
            sound(ModSounds.PIN_OK.get(), 1.0F);
        }
    }

    private void setMode(Player clicker, int newMode) {
        if (newMode == mode) return;
        if (mode == MODE_DEPOSIT) {
            returnBills(clicker);       // bills already counted go back to the player
        } else {
            clearSelection();
        }
        mode = newMode;
    }

    private void clearSelection() {
        Arrays.fill(counts, 0);
        pendingCents = 0;
    }

    /** WITHDRAW mode: change the number of bills of one denomination in the selection. */
    private void adjust(Player clicker, int index, int delta) {
        if (mode != MODE_WITHDRAW) return;
        int cents = (int) BILLS[index].cents();
        if (delta < 0) {
            if (counts[index] > 0) {
                counts[index]--;
                pendingCents -= cents;
            }
            return;
        }
        for (int n = 0; n < delta; n++) {
            if (accessState != ACCESS_UNLOCKED) {
                message(clicker, "gui.aestheticjobs.atm.pin_required");
                sound(ModSounds.ERROR.get(), 1.0F);
                return;
            }
            if (totalBills() >= MAX_BILLS) {
                message(clicker, "gui.aestheticjobs.atm.limit", MAX_BILLS);
                return;
            }
            if (pendingCents + cents > balanceCache) {
                message(clicker, "gui.aestheticjobs.atm.not_enough");
                sound(ModSounds.ERROR.get(), 1.0F);
                return;
            }
            counts[index]++;
            pendingCents += cents;
        }
        sound(ModSounds.KEY.get(), 1.1F);
    }

    /** Gives the counted / selected bills to the player (deposit cancelled, or machine closed mid-way). */
    private void returnBills(Player target) {
        boolean any = false;
        for (int i = 0; i < BILLS.length; i++) {
            if (counts[i] > 0) {
                giveBack(target, new ItemStack(ModItems.MONEY.get(BILLS[i]).get(), counts[i]));
                counts[i] = 0;
                any = true;
            }
        }
        pendingCents = 0;
        if (any) sound(ModSounds.BILL_FEED.get(), 0.8F);
    }

    private void deposit(Player depositor) {
        if (pendingCents <= 0) return;
        CardOwner owner = cardOwner();
        MinecraftServer server = depositor.getServer();
        if (owner == null || server == null) {
            message(depositor, "gui.aestheticjobs.atm.no_card");
            sound(ModSounds.ERROR.get(), 1.0F);
            return;
        }
        boolean own = owner.id().equals(depositor.getUUID());
        Bank.Result result = Bank.deposit(server, owner.id(), pendingCents, Transaction.Type.DEPOSIT, "terminal",
                own ? null : depositor.getUUID());
        if (result == Bank.Result.OK) {
            AestheticJobs.LOGGER.info("[bank] {} deposited {} to account {} via terminal",
                    depositor.getGameProfile().getName(), Money.format(pendingCents), owner.id());
            message(depositor, "gui.aestheticjobs.atm.done", Money.format(pendingCents));
            sound(ModSounds.SUCCESS.get(), 1.0F);
            clearSelection();
        } else {
            message(depositor, "gui.aestheticjobs.atm.balance_limit");
            sound(ModSounds.ERROR.get(), 1.0F);
        }
    }

    private void withdraw(Player taker) {
        if (pendingCents <= 0) return;
        CardOwner owner = cardOwner();
        MinecraftServer server = taker.getServer();
        if (owner == null || server == null || accessState != ACCESS_UNLOCKED) {
            message(taker, "gui.aestheticjobs.atm.pin_required");
            sound(ModSounds.ERROR.get(), 1.0F);
            return;
        }
        Bank.Result result = Bank.withdraw(server, owner.id(), pendingCents, Transaction.Type.WITHDRAW,
                owner.id().equals(taker.getUUID()) ? "terminal" : "terminal:" + taker.getGameProfile().getName());
        if (result == Bank.Result.OK) {
            AestheticJobs.LOGGER.info("[bank] {} withdrew {} from account {} via terminal",
                    taker.getGameProfile().getName(), Money.format(pendingCents), owner.id());
            message(taker, "gui.aestheticjobs.atm.withdrawn", Money.format(pendingCents));
            dispensing = true;          // the bills now come out one by one, see dispenseBill()
        } else {
            message(taker, "gui.aestheticjobs.atm.not_enough");
            sound(ModSounds.ERROR.get(), 1.0F);
        }
    }

    @Override
    public void removed(Player closing) {
        super.removed(closing);
        if (!closing.level().isClientSide) {
            if (cardPresent) sound(ModSounds.CARD_EJECT.get(), 1.0F);
            // already paid but not yet dispensed bills are handed over, nothing is lost
            if (mode == MODE_DEPOSIT || dispensing) returnBills(closing); else clearSelection();
            dispensing = false;
            unlocked = false;
            unlockedFor = null;
            clearContainer(closing, billContainer);
            clearContainer(closing, cardContainer);
        }
    }

    @Override
    public boolean stillValid(Player user) {
        return stillValid(access, user, ModBlocks.ATM.get());
    }

    @Override
    public ItemStack quickMoveStack(Player user, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            if (index <= BILL_SLOT) {
                if (!moveItemStackTo(stack, BILL_SLOT + 1, slots.size(), true)) return ItemStack.EMPTY;
            } else if (stack.is(ModItems.BANK_CARD.get())) {
                if (!moveItemStackTo(stack, CARD_SLOT, CARD_SLOT + 1, false)) return ItemStack.EMPTY;
            } else if (billIndex(stack) >= 0) {
                if (!moveItemStackTo(stack, BILL_SLOT, BILL_SLOT + 1, false)) return ItemStack.EMPTY;
            } else {
                return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) {
                slot.setByPlayer(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
            if (stack.getCount() == result.getCount()) return ItemStack.EMPTY;
            slot.onTake(user, stack);
        }
        return result;
    }

    // ---------------- getters (work on both sides through synced data) ----------------

    public int getPending() {
        return (data.get(0) & 0xFFFF) | ((data.get(1) & 0xFFFF) << 16);
    }

    public long getBalance() {
        return (data.get(2) & 0xFFFFL) | ((data.get(3) & 0xFFFFL) << 16) | ((data.get(4) & 0xFFFFL) << 32);
    }

    public int getStatus() {
        return data.get(5);
    }

    public int getMode() {
        return data.get(6) & 1;
    }

    public boolean isDispensing() {
        return (data.get(6) & 2) != 0;
    }

    public int getAccess() {
        return data.get(7);
    }

    public int getLockSeconds() {
        return data.get(8) & 0xFFFF;
    }

    public int getBillCount(int index) {
        return data.get(9 + index) & 0xFFFF;
    }

    public boolean isCardReady() {
        return getStatus() == STATUS_CARD;
    }

    /** Server-side values exposed to vanilla's data-slot sync. */
    private final class ServerData implements ContainerData {
        @Override
        public int get(int index) {
            return switch (index) {
                case 0 -> pendingCents & 0xFFFF;
                case 1 -> (pendingCents >>> 16) & 0xFFFF;
                case 2 -> (int) (balanceCache & 0xFFFFL);
                case 3 -> (int) ((balanceCache >>> 16) & 0xFFFFL);
                case 4 -> (int) ((balanceCache >>> 32) & 0xFFFFL);
                case 5 -> status;
                case 6 -> mode | (dispensing ? 2 : 0);
                case 7 -> accessState;
                case 8 -> lockSeconds;
                default -> (index >= 9 && index - 9 < counts.length) ? counts[index - 9] : 0;
            };
        }

        @Override
        public void set(int index, int value) {
            // read-only on the server
        }

        @Override
        public int getCount() {
            return DATA_SIZE;
        }
    }
}
