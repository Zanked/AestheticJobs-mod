package dev.aestheticjobs.registry;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.cafe.CupData;
import dev.aestheticjobs.cafe.Order;
import dev.aestheticjobs.item.CardOwner;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModComponents {
    public static final DeferredRegister.DataComponents COMPONENTS =
            DeferredRegister.createDataComponents(Registries.DATA_COMPONENT_TYPE, AestheticJobs.MODID);

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<CardOwner>> CARD_OWNER =
            COMPONENTS.registerComponentType("card_owner",
                    builder -> builder.persistent(CardOwner.CODEC).networkSynchronized(CardOwner.STREAM_CODEC));

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<CupData>> CUP =
            COMPONENTS.registerComponentType("cup",
                    builder -> builder.persistent(CupData.CODEC).networkSynchronized(CupData.STREAM_CODEC));

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Order>> ORDER =
            COMPONENTS.registerComponentType("order",
                    builder -> builder.persistent(Order.CODEC).networkSynchronized(Order.STREAM_CODEC));

    private ModComponents() {}
}
