package dev.aestheticjobs.registry;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.entity.CafeCustomerEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, AestheticJobs.MODID);

    /** The cafe customer: a small NPC with a thought bubble over the head. */
    public static final DeferredHolder<EntityType<?>, EntityType<CafeCustomerEntity>> CAFE_CUSTOMER =
            ENTITIES.register("cafe_customer", () -> EntityType.Builder
                    .of(CafeCustomerEntity::new, MobCategory.MISC)
                    .sized(0.5F, 1.4F)
                    .clientTrackingRange(10)
                    .build("cafe_customer"));

    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(CAFE_CUSTOMER.get(), CafeCustomerEntity.createAttributes().build());
    }

    private ModEntities() {}
}
