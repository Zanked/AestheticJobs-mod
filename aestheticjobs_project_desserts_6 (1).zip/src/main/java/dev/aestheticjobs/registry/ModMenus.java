package dev.aestheticjobs.registry;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.menu.AtmMenu;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.inventory.MenuType;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModMenus {
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(Registries.MENU, AestheticJobs.MODID);

    public static final DeferredHolder<MenuType<?>, MenuType<AtmMenu>> ATM =
            MENUS.register("atm", () -> IMenuTypeExtension.create((windowId, inventory, buf) -> new AtmMenu(windowId, inventory)));

    private ModMenus() {}
}
