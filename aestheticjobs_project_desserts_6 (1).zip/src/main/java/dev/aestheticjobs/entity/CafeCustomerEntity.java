package dev.aestheticjobs.entity;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.cafe.Art;
import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.CupData;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.cafe.Order;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.registry.ModEntities;
import dev.aestheticjobs.registry.ModItems;
import dev.aestheticjobs.registry.ModSounds;
import dev.aestheticjobs.cafe.DeliveryService;
import dev.aestheticjobs.item.DeliveryBoxItem;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.ai.util.LandRandomPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * A cafe customer. It walks to the register, waits there with a thought bubble over its head
 * (the exact foam pattern it wants + a patience bar), takes the cup from the barista and then
 * "drinks the picture": the barista's real drawing floats up out of the cup and bursts into pixels.
 *
 * Server: all logic (states, patience, burst). Client: only reads the synced data and animates.
 */
public class CafeCustomerEntity extends PathfinderMob {
    /** Skin / variant of the supplier courier (the customers are 0..Order.CUSTOMERS-1). */
    public static final int COURIER_VARIANT = 8;

    public static final int STATE_IDLE = 0;      // spawn-egg customer without an order
    public static final int STATE_WALKING = 1;   // on its way to the register
    public static final int STATE_WAITING = 2;   // order bubble over the head
    public static final int STATE_DRINKING = 3;  // got the cup: sip, art reveal, pixel burst
    public static final int STATE_LEAVING = 4;   // walks away and disappears

    /** Ticks after the cup is handed over: the drawing appears over the head / bursts into pixels / the show is over. */
    public static final int REVEAL_TICK = 30;
    public static final int BURST_TICK = 72;
    public static final int DRINK_TOTAL = 92;

    /** World size of one foam cell in the pixel burst. */
    private static final double CELL = 0.085D;

    private static final EntityDataAccessor<Integer> DATA_VARIANT =
            SynchedEntityData.defineId(CafeCustomerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_DRINK =
            SynchedEntityData.defineId(CafeCustomerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_DESSERT =
            SynchedEntityData.defineId(CafeCustomerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_STATE =
            SynchedEntityData.defineId(CafeCustomerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_PATIENCE =
            SynchedEntityData.defineId(CafeCustomerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_STARS =
            SynchedEntityData.defineId(CafeCustomerEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<String> DATA_ART =
            SynchedEntityData.defineId(CafeCustomerEntity.class, EntityDataSerializers.STRING);

    // ---- server side only ----
    @Nullable private UUID worker;
    private long orderTime;
    @Nullable private BlockPos standPos;
    @Nullable private BlockPos registerPos;
    private int stateTicks;
    /** true: came to a register and disappears afterwards; false: spawn-egg customer that stays. */
    private boolean ephemeral;
    private Vec3 servedDir = new Vec3(0.0D, 0.0D, 1.0D);
    /** A supplier courier: walks to the terminal (registerPos), leaves the box with the cargo and goes away. */
    private boolean courier;
    private final List<ItemStack> cargo = new ArrayList<>();

    // ---- client side only ----
    private int clientStateStart;

    public CafeCustomerEntity(EntityType<? extends CafeCustomerEntity> type, Level level) {
        super(type, level);
        setInvulnerable(true);
        if (getNavigation() instanceof GroundPathNavigation nav) {
            nav.setCanOpenDoors(true);
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_VARIANT, 0);
        builder.define(DATA_DRINK, -1);
        builder.define(DATA_DESSERT, -1);
        builder.define(DATA_STATE, STATE_IDLE);
        builder.define(DATA_PATIENCE, 100);
        builder.define(DATA_STARS, 0);
        builder.define(DATA_ART, "");
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new OpenDoorGoal(this, true));
        goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.7D) {
            @Override
            public boolean canUse() {
                return getState() == STATE_IDLE && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                return getState() == STATE_IDLE && super.canContinueToUse();
            }
        });
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6.0F) {
            @Override
            public boolean canUse() {
                int s = getState();
                return (s == STATE_IDLE || s == STATE_WAITING || s == STATE_DRINKING) && super.canUse();
            }

            @Override
            public boolean canContinueToUse() {
                int s = getState();
                return (s == STATE_IDLE || s == STATE_WAITING || s == STATE_DRINKING) && super.canContinueToUse();
            }
        });
        goalSelector.addGoal(7, new RandomLookAroundGoal(this) {
            @Override
            public boolean canUse() {
                return (getState() == STATE_IDLE || getState() == STATE_WAITING) && super.canUse();
            }
        });
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    // ------------------------------------------------------------------ getters (synced)

    public int getVariant() {
        return entityData.get(DATA_VARIANT);
    }

    public void setVariant(int variant) {
        int v = variant == COURIER_VARIANT ? COURIER_VARIANT : Math.floorMod(variant, Order.CUSTOMERS);
        entityData.set(DATA_VARIANT, v);
        setCustomName(Component.translatable("customer." + AestheticJobs.MODID + "." + v));
    }

    /** Index in item/Dessert of the dessert ordered with the drink, -1 = none. */
    public int getDessert() {
        return entityData.get(DATA_DESSERT);
    }

    public int getState() {
        return entityData.get(DATA_STATE);
    }

    public int getDrink() {
        return entityData.get(DATA_DRINK);
    }

    /** 0..100: how much patience is left (100 = just ordered). */
    public int getPatience() {
        return entityData.get(DATA_PATIENCE);
    }

    public int getStars() {
        return entityData.get(DATA_STARS);
    }

    /** The drawing the customer is drinking right now (256 chars), empty otherwise. */
    public String getArt() {
        return entityData.get(DATA_ART);
    }

    @Nullable
    public UUID getWorker() {
        return worker;
    }

    /** Client: tick (entity age) at which the current state started. */
    public int getClientStateStart() {
        return clientStateStart;
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (DATA_STATE.equals(key) && level().isClientSide) {
            clientStateStart = tickCount;
        }
    }

    private void setState(int state) {
        entityData.set(DATA_STATE, state);
        stateTicks = 0;
    }

    // ------------------------------------------------------------------ orders

    /**
     * The barista took an order from this customer. With a register position the customer walks
     * to the stand spot first; without one (direct order from a spawn-egg customer) it waits right here.
     */
    public void beginOrder(UUID worker, int drink, int dessert, long orderTime, @Nullable BlockPos stand,
                           @Nullable BlockPos register, boolean ephemeral) {
        this.worker = worker;
        this.orderTime = orderTime;
        this.standPos = stand;
        this.registerPos = register;
        this.ephemeral = ephemeral;
        entityData.set(DATA_DRINK, drink);
        entityData.set(DATA_DESSERT, dessert);
        entityData.set(DATA_PATIENCE, 100);
        entityData.set(DATA_ART, "");
        entityData.set(DATA_STARS, 0);
        getNavigation().stop();
        setState(stand == null ? STATE_WAITING : STATE_WALKING);
    }

    /** Where the barista's customer stands: 2 blocks from the register, preferably on the far side of the counter. */
    @Nullable
    public static BlockPos findStandSpot(ServerLevel level, BlockPos register, Direction facing) {
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist < 1.5D || dist > 3.5D) continue;
                for (int dy = -2; dy <= 1; dy++) {
                    BlockPos p = register.offset(dx, dy, dz);
                    if (!isStandable(level, p)) continue;
                    if (!level.getEntitiesOfClass(CafeCustomerEntity.class, new AABB(p).inflate(0.4D)).isEmpty()) continue;
                    int dot = dx * facing.getStepX() + dz * facing.getStepZ();
                    double score = Math.abs(dist - 2.0D) + (dot > 0 ? 4.0D : 0.0D) + Math.abs(dy) * 0.5D;
                    if (score < bestScore) {
                        bestScore = score;
                        best = p;
                    }
                }
            }
        }
        return best;
    }

    /** A spot 5..9 blocks away where the customer "comes from". */
    @Nullable
    public static BlockPos findArrivalSpot(ServerLevel level, BlockPos stand) {
        for (int i = 0; i < 40; i++) {
            int dx = level.random.nextInt(19) - 9;
            int dz = level.random.nextInt(19) - 9;
            int d2 = dx * dx + dz * dz;
            if (d2 < 25 || d2 > 81) continue;
            for (int dy = 2; dy >= -2; dy--) {
                BlockPos p = stand.offset(dx, dy, dz);
                if (isStandable(level, p)) return p;
            }
        }
        return null;
    }

    private static boolean isStandable(ServerLevel level, BlockPos p) {
        BlockPos below = p.below();
        BlockState floor = level.getBlockState(below);
        return floor.isFaceSturdy(level, below, Direction.UP)
                && level.getBlockState(p).getCollisionShape(level, p).isEmpty()
                && level.getBlockState(p.above()).getCollisionShape(level, p.above()).isEmpty()
                && level.getFluidState(p).isEmpty();
    }

    /** Spawns a customer for the register. Returns null if there is no room (the order then stays a plain ticket). */
    @Nullable
    public static CafeCustomerEntity spawnFor(ServerLevel level, BlockPos register, Direction facing,
                                              UUID worker, int variant, int drink, int dessert, long orderTime) {
        BlockPos stand = findStandSpot(level, register, facing);
        if (stand == null) return null;
        BlockPos from = findArrivalSpot(level, stand);
        BlockPos start = from != null ? from : stand;

        CafeCustomerEntity npc = ModEntities.CAFE_CUSTOMER.get().create(level);
        if (npc == null) return null;
        npc.moveTo(start.getX() + 0.5D, start.getY(), start.getZ() + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
        npc.setVariant(variant);
        npc.beginOrder(worker, drink, dessert, orderTime, stand, register, true);
        level.addFreshEntity(npc);
        level.playSound(null, register, ModSounds.CUSTOMER_ARRIVE.get(), SoundSource.BLOCKS, 0.8F, 1.0F);
        level.sendParticles(ParticleTypes.POOF, npc.getX(), npc.getY() + 0.7D, npc.getZ(), 8, 0.2D, 0.4D, 0.2D, 0.02D);
        return npc;
    }

    /**
     * Spawns the supplier courier: it comes from a few blocks away with the box in its hand, puts the box on the
     * terminal and leaves. Returns false if there is no room (the caller then just drops the box).
     */
    public static boolean spawnCourier(ServerLevel level, BlockPos terminal, Direction facing, UUID owner, List<ItemStack> cargo) {
        BlockPos stand = findStandSpot(level, terminal, facing);
        if (stand == null) return false;
        BlockPos from = findArrivalSpot(level, stand);
        BlockPos start = from != null ? from : stand;

        CafeCustomerEntity npc = ModEntities.CAFE_CUSTOMER.get().create(level);
        if (npc == null) return false;
        npc.moveTo(start.getX() + 0.5D, start.getY(), start.getZ() + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
        npc.setVariant(COURIER_VARIANT);
        npc.courier = true;
        for (ItemStack s : cargo) npc.cargo.add(s.copy());
        npc.beginOrder(owner, -1, -1, level.getGameTime(), stand, terminal, true);
        npc.setItemSlot(EquipmentSlot.MAINHAND, DeliveryBoxItem.pack(cargo));
        npc.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        level.addFreshEntity(npc);
        level.playSound(null, terminal, ModSounds.CUSTOMER_ARRIVE.get(), SoundSource.BLOCKS, 0.8F, 1.2F);
        level.sendParticles(ParticleTypes.POOF, npc.getX(), npc.getY() + 0.7D, npc.getZ(), 8, 0.2D, 0.4D, 0.2D, 0.02D);
        return true;
    }

    /** The courier reached the terminal: the box goes on top of it, the owner gets a message, the courier leaves. */
    private void deliver() {
        ServerLevel sl = (ServerLevel) level();
        if (registerPos != null) {
            DeliveryService.dropBox(sl, registerPos, cargo);
            sl.playSound(null, registerPos, SoundEvents.NOTE_BLOCK_CHIME.value(), SoundSource.BLOCKS, 1.0F, 1.3F);
            sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, registerPos.getX() + 0.5D, registerPos.getY() + 1.2D,
                    registerPos.getZ() + 0.5D, 6, 0.3D, 0.2D, 0.3D, 0.0D);
        }
        ServerPlayer p = worker == null ? null : sl.getServer().getPlayerList().getPlayer(worker);
        if (p != null) {
            p.sendSystemMessage(Component.translatable("cafe.supplier.delivered"));
        }
        cargo.clear();
        courier = false;
        worker = null;
        finishVisit();
    }

    /** The nearest customer of this barista that is waiting for a cup near the given point. */
    @Nullable
    public static CafeCustomerEntity findWaitingFor(ServerLevel level, Vec3 at, UUID worker, double radius) {
        List<CafeCustomerEntity> list = level.getEntitiesOfClass(CafeCustomerEntity.class,
                new AABB(at, at).inflate(radius),
                e -> e.getState() == STATE_WAITING && worker.equals(e.worker));
        return list.stream().min(Comparator.comparingDouble(e -> e.distanceToSqr(at))).orElse(null);
    }

    /** The barista hands over the cup. Called by the serve logic after the payment went through. */
    public void receiveCup(ServerPlayer player, CupData cup, int stars) {
        String art = Drink.sanitize(cup.art());
        entityData.set(DATA_ART, art == null ? "" : art);
        entityData.set(DATA_STARS, stars);
        entityData.set(DATA_DRINK, cup.drink());                    // the show shows this drink's colours
        worker = player.getUUID();

        Vec3 toPlayer = new Vec3(player.getX() - getX(), 0.0D, player.getZ() - getZ());
        servedDir = toPlayer.lengthSqr() < 1.0E-4D ? new Vec3(0.0D, 0.0D, 1.0D) : toPlayer.normalize();
        float yaw = (float) (Mth.atan2(servedDir.z, servedDir.x) * (180.0D / Math.PI)) - 90.0F;
        setYRot(yaw);
        yBodyRot = yaw;
        yHeadRot = yaw;

        getNavigation().stop();
        ItemStack held = new ItemStack(ModItems.COFFEE_CUP.get());
        held.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(cup.drink() + 1));   // he holds the real drink
        setItemSlot(EquipmentSlot.MAINHAND, held);
        setDropChance(EquipmentSlot.MAINHAND, 0.0F);
        setState(STATE_DRINKING);
    }

    // ------------------------------------------------------------------ interaction

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        ItemStack stack = player.getItemInHand(hand);
        CupData cupData = stack.get(ModComponents.CUP.get());
        boolean cup = cupData != null;
        int state = getState();

        if (cup) {
            if (!level().isClientSide && player instanceof ServerPlayer sp) {
                if (state == STATE_WAITING && sp.getUUID().equals(worker)) {
                    CafeLogic.serve(sp, (ServerLevel) level(), blockPosition(), stack, cupData, this);
                } else {
                    sp.displayClientMessage(Component.translatable("cafe.customer.not_yours"), true);
                }
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }

        if (stack.isEmpty()) {
            if (!level().isClientSide && player instanceof ServerPlayer sp) {
                if (state == STATE_IDLE) {
                    CafeLogic.issueOrder(sp, (ServerLevel) level(), blockPosition(), null, null, this);
                } else if (state == STATE_WAITING && sp.getUUID().equals(worker)) {
                    Drink d = Drink.byIndex(getDrink());
                    if (d != null) {
                        Dessert extra = Dessert.byIndex(getDessert());
                        Component wanted = extra == null ? d.displayName()
                                : Component.empty().append(d.displayName()).append(" + ").append(extra.displayName());
                        sp.displayClientMessage(Component.translatable("cafe.customer.waiting",
                                getDisplayName(), wanted), true);
                    }
                }
            }
            if (state == STATE_IDLE || state == STATE_WAITING) {
                return InteractionResult.sidedSuccess(level().isClientSide);
            }
        }
        return InteractionResult.PASS;
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide) {
            serverTick();
        }
    }

    private void serverTick() {
        stateTicks++;
        switch (getState()) {
            case STATE_WALKING -> tickWalking();
            case STATE_WAITING -> tickWaiting();
            case STATE_DRINKING -> tickDrinking();
            case STATE_LEAVING -> tickLeaving();
            default -> { }
        }
    }

    private void tickWalking() {
        if (standPos == null) {
            setState(STATE_WAITING);
            return;
        }
        double tx = standPos.getX() + 0.5D, ty = standPos.getY(), tz = standPos.getZ() + 0.5D;
        double dx = tx - getX(), dz = tz - getZ();
        if (dx * dx + dz * dz < 0.36D && Math.abs(ty - getY()) < 1.5D) {
            getNavigation().stop();
            if (courier) {
                deliver();
                return;
            }
            setState(STATE_WAITING);
            playSound(ModSounds.CUSTOMER_VOICE.get(), 1.0F, getVoicePitch());      // "hello!"
            return;
        }
        if (stateTicks > 240) {                       // stuck behind something: just appear at the counter
            moveTo(tx, ty, tz, getYRot(), 0.0F);
            getNavigation().stop();
            if (courier) {
                deliver();
                return;
            }
            setState(STATE_WAITING);
            return;
        }
        if (stateTicks % 10 == 1) {
            getNavigation().moveTo(tx, ty, tz, 1.0D);
        }
    }

    private void tickWaiting() {
        getNavigation().stop();
        if (registerPos != null) {
            double dx = registerPos.getX() + 0.5D - getX();
            double dz = registerPos.getZ() + 0.5D - getZ();
            float yaw = (float) (Mth.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
            setYRot(yaw);
            yBodyRot = yaw;
        }
        if (stateTicks % 10 != 0) return;

        long elapsed = level().getGameTime() - orderTime;
        Drink wanted = Drink.byIndex(getDrink());
        long total = wanted != null ? CafeLogic.okTicks(wanted, getDessert()) : 6000L;      // as long as the "ok" tip window of the drink
        int pct = (int) Mth.clamp(100L - elapsed * 100L / total, 0L, 100L);
        if (pct != getPatience()) {
            entityData.set(DATA_PATIENCE, pct);
        }
        if (pct <= 0) {
            loseTemper();
        } else if (pct < 25 && stateTicks % 60 == 0) {
            playSound(ModSounds.CUSTOMER_IMPATIENT.get(), 0.9F, getVoicePitch());
            ((ServerLevel) level()).sendParticles(ParticleTypes.ANGRY_VILLAGER,
                    getX(), getY() + 1.55D, getZ(), 1, 0.15D, 0.05D, 0.15D, 0.0D);
        }
    }

    private void loseTemper() {
        ServerLevel sl = (ServerLevel) level();
        ServerPlayer p = worker == null ? null : sl.getServer().getPlayerList().getPlayer(worker);
        if (p != null) {
            CafeLogic.voidTicket(p, orderTime);
            p.sendSystemMessage(Component.translatable("cafe.customer.left", getDisplayName()));
        }
        sl.sendParticles(ParticleTypes.ANGRY_VILLAGER, getX(), getY() + 1.6D, getZ(), 5, 0.3D, 0.2D, 0.3D, 0.0D);
        sl.playSound(null, getX(), getY(), getZ(), ModSounds.CUSTOMER_GRUMBLE.get(), SoundSource.NEUTRAL, 1.0F, getVoicePitch());
        worker = null;
        entityData.set(DATA_DRINK, -1);
        entityData.set(DATA_DESSERT, -1);
        finishVisit();
    }

    private void tickDrinking() {
        ServerLevel sl = (ServerLevel) level();
        int t = stateTicks;
        int stars = getStars();

        if (t == 2) {
            sl.playSound(null, getX(), getY(), getZ(), ModSounds.CUSTOMER_CUP_TAKE.get(), SoundSource.NEUTRAL, 0.8F, 1.0F);
        } else if (t == 14) {
            sl.playSound(null, getX(), getY(), getZ(), ModSounds.CUSTOMER_SIP.get(), SoundSource.NEUTRAL, 0.8F, 1.0F);
        } else if (t == REVEAL_TICK) {
            sl.playSound(null, getX(), getY(), getZ(), ModSounds.CUSTOMER_REVEAL.get(), SoundSource.NEUTRAL, 0.9F, 1.0F);
            sl.sendParticles(ParticleTypes.ENCHANT, getX(), getY() + 1.8D, getZ(), 18, 0.4D, 0.3D, 0.4D, 0.3D);
            ServerPlayer p = worker == null ? null : sl.getServer().getPlayerList().getPlayer(worker);
            if (p != null) {
                p.sendSystemMessage(Component.translatable("cafe.customer.says", getDisplayName(),
                        Component.translatable("customer.line." + Mth.clamp(stars, 1, 5))));
            }
        } else if (t == BURST_TICK) {
            setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            burst(sl, stars);
        }

        if ((t == BURST_TICK || t == BURST_TICK + 8) && stars >= 4 && onGround()) {
            jumpFromGround();                         // a happy hop
        }
        if (t >= DRINK_TOTAL) {
            entityData.set(DATA_ART, "");
            worker = null;
            finishVisit();
        }
    }

    /** The drawing explodes into pixels: every foam cell becomes a dust particle in the real colour, in a plane facing the barista. */
    private void burst(ServerLevel sl, int stars) {
        String art = getArt();
        Vec3 right = new Vec3(servedDir.z, 0.0D, -servedDir.x);   // the barista's right while looking at us
        Vec3 center = position().add(0.0D, 2.05D, 0.0D);
        if (art.length() == Drink.CELLS) {
            Drink shown = Drink.byIndex(getDrink());
            for (int cy = 0; cy < Drink.SIZE; cy++) {
                for (int cx = 0; cx < Drink.SIZE; cx++) {
                    char c = art.charAt(cy * Drink.SIZE + cx);
                    if (c == '0') continue;
                    Vec3 p = center.add(right.scale((cx - 7.5D) * CELL)).add(0.0D, (7.5D - cy) * CELL, 0.0D);
                    int argb = Art.rgb(c, shown);
                    Vector3f color = new Vector3f((argb >> 16 & 255) / 255.0F, (argb >> 8 & 255) / 255.0F, (argb & 255) / 255.0F);
                    sl.sendParticles(new DustParticleOptions(color, 0.8F),
                            p.x, p.y, p.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
                }
            }
        }
        float pitch = 0.8F + stars * 0.1F;
        sl.playSound(null, getX(), getY(), getZ(), ModSounds.CUSTOMER_BURST.get(), SoundSource.NEUTRAL, 1.0F, pitch);
        if (stars >= 4) {
            sl.playSound(null, getX(), getY(), getZ(), ModSounds.CUSTOMER_HAPPY.get(), SoundSource.NEUTRAL, 1.0F, getVoicePitch());
            sl.sendParticles(ParticleTypes.HEART, getX(), getY() + 1.6D, getZ(), stars == 5 ? 10 : 5, 0.4D, 0.3D, 0.4D, 0.0D);
            if (stars == 5) {
                sl.sendParticles(ParticleTypes.END_ROD, center.x, center.y, center.z, 24, 0.7D, 0.5D, 0.1D, 0.03D);
            }
        } else if (stars <= 2) {
            sl.playSound(null, getX(), getY(), getZ(), ModSounds.CUSTOMER_GRUMBLE.get(), SoundSource.NEUTRAL, 1.0F, getVoicePitch());
            sl.sendParticles(ParticleTypes.ANGRY_VILLAGER, getX(), getY() + 1.6D, getZ(), 3, 0.3D, 0.2D, 0.3D, 0.0D);
        } else {
            sl.playSound(null, getX(), getY(), getZ(), ModSounds.CUSTOMER_OK.get(), SoundSource.NEUTRAL, 1.0F, getVoicePitch());
        }
    }

    /** The visit is over: register customers walk away and vanish, spawn-egg customers stay. */
    private void finishVisit() {
        entityData.set(DATA_DRINK, -1);
        entityData.set(DATA_DESSERT, -1);
        entityData.set(DATA_PATIENCE, 100);
        setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        if (!ephemeral) {
            standPos = null;
            registerPos = null;
            setState(STATE_IDLE);
            return;
        }
        setState(STATE_LEAVING);
        Vec3 from = registerPos != null ? Vec3.atCenterOf(registerPos) : position();
        Vec3 away = LandRandomPos.getPosAway(this, 12, 5, from);
        if (away != null) {
            getNavigation().moveTo(away.x, away.y, away.z, 0.9D);
        }
    }

    private void tickLeaving() {
        if (stateTicks % 20 == 1 && getNavigation().isDone()) {
            Vec3 away = LandRandomPos.getPosAway(this, 12, 5, position());
            if (away != null) {
                getNavigation().moveTo(away.x, away.y, away.z, 0.9D);
            }
        }
        if (stateTicks > 120) {
            playSound(ModSounds.CUSTOMER_LEAVE.get(), 0.6F, 1.0F);
            ((ServerLevel) level()).sendParticles(ParticleTypes.POOF, getX(), getY() + 0.7D, getZ(), 8, 0.2D, 0.4D, 0.2D, 0.02D);
            discard();
        }
    }

    // ------------------------------------------------------------------ sounds

    /** Every customer talks in its own pitch (by skin number: Emma lowest, Max highest); the sound files are the same. */
    @Override
    public float getVoicePitch() {
        return 0.8F + Math.floorMod(getVariant(), Order.CUSTOMERS) * 0.08F + (random.nextFloat() - 0.5F) * 0.06F;
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        int s = getState();
        return s == STATE_IDLE || s == STATE_WAITING ? ModSounds.CUSTOMER_VOICE.get() : null;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        playSound(ModSounds.CUSTOMER_STEP.get(), 0.4F, 0.9F + random.nextFloat() * 0.25F);
    }

    // ------------------------------------------------------------------ save / load

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", getVariant());
        tag.putInt("Drink", getDrink());
        tag.putInt("Dessert", getDessert());
        tag.putBoolean("Courier", courier);
        if (!cargo.isEmpty()) {
            ListTag list = new ListTag();
            for (ItemStack s : cargo) {
                CompoundTag t = new CompoundTag();
                t.putString("id", BuiltInRegistries.ITEM.getKey(s.getItem()).toString());
                t.putInt("n", s.getCount());
                list.add(t);
            }
            tag.put("Cargo", list);
        }
        tag.putInt("State", getState());
        tag.putLong("OrderTime", orderTime);
        tag.putBoolean("Ephemeral", ephemeral);
        if (worker != null) tag.putUUID("Worker", worker);
        if (standPos != null) tag.putLong("Stand", standPos.asLong());
        if (registerPos != null) tag.putLong("Register", registerPos.asLong());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setVariant(tag.getInt("Variant"));
        entityData.set(DATA_DRINK, tag.contains("Drink") ? tag.getInt("Drink") : -1);
        entityData.set(DATA_DESSERT, tag.contains("Dessert") ? tag.getInt("Dessert") : -1);
        courier = tag.getBoolean("Courier");
        cargo.clear();
        ListTag cargoTag = tag.getList("Cargo", Tag.TAG_COMPOUND);
        for (int i = 0; i < cargoTag.size(); i++) {
            CompoundTag t = cargoTag.getCompound(i);
            cargo.add(new ItemStack(BuiltInRegistries.ITEM.get(ResourceLocation.parse(t.getString("id"))), t.getInt("n")));
        }
        orderTime = tag.getLong("OrderTime");
        ephemeral = tag.getBoolean("Ephemeral");
        worker = tag.hasUUID("Worker") ? tag.getUUID("Worker") : null;
        standPos = tag.contains("Stand") ? BlockPos.of(tag.getLong("Stand")) : null;
        registerPos = tag.contains("Register") ? BlockPos.of(tag.getLong("Register")) : null;
        int state = tag.getInt("State");
        if (state == STATE_DRINKING) {
            state = ephemeral ? STATE_LEAVING : STATE_IDLE;   // the show is not resumed after a reload
        }
        entityData.set(DATA_STATE, state);
        stateTicks = 0;
    }
}
