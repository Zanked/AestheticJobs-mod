package dev.aestheticjobs.job;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import dev.aestheticjobs.AestheticJobs;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.neoforged.neoforge.event.AddReloadListenerEvent;

/** Loads every profession file on world load and on /reload, so wages can be tuned without restarting. */
public final class ProfessionManager extends SimpleJsonResourceReloadListener {
    private static final Gson GSON = new GsonBuilder().create();
    public static final ProfessionManager INSTANCE = new ProfessionManager();

    private volatile Map<ResourceLocation, Profession> professions = Map.of();

    private ProfessionManager() {
        super(GSON, "profession");
    }

    public static void onAddReloadListeners(AddReloadListenerEvent event) {
        event.addListener(INSTANCE);
    }

    @Override
    protected void apply(Map<ResourceLocation, JsonElement> files, ResourceManager manager, ProfilerFiller profiler) {
        Map<ResourceLocation, Profession> loaded = new TreeMap<>();
        files.forEach((id, json) -> Profession.parse(id, json,
                        message -> AestheticJobs.LOGGER.error("[jobs] profession {} skipped: {}", id, message))
                .ifPresent(profession -> loaded.put(id, profession)));
        professions = Collections.unmodifiableMap(loaded);
        AestheticJobs.LOGGER.info("[jobs] loaded {} professions", loaded.size());
    }

    public static Optional<Profession> get(ResourceLocation id) {
        return Optional.ofNullable(INSTANCE.professions.get(id));
    }

    public static Collection<Profession> all() {
        return INSTANCE.professions.values();
    }

    public static Collection<ResourceLocation> ids() {
        return INSTANCE.professions.keySet();
    }
}
