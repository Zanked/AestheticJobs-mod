package dev.aestheticjobs.job;

import dev.aestheticjobs.economy.Bank;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.economy.Transaction;
import dev.aestheticjobs.job.JobData.PlayerJob;
import dev.aestheticjobs.job.JobData.Progress;
import dev.aestheticjobs.registry.ModItems;
import dev.aestheticjobs.registry.ModSounds;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomModelData;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;

/**
 * Shifts and wages. Call only on the server thread.
 *
 * A shift is started and ended with the work badge (or /shift). While it runs, every ACTIVE second earns the
 * hourly wage of the current rank (rank changes are picked up immediately). Standing still for AFK_SECONDS stops
 * the pay until the player does something again. The wage is paid to the bank account when the shift ends:
 * by the badge, on quitting the job, on logout, or at the shift limit.
 *
 * Only pay_source "server" exists so far; "employer" is paid by the server as well until player-run businesses exist.
 */
public final class Shift {
    /** Without moving, turning the camera or having a menu open for this long the player counts as idle. */
    public static final int AFK_SECONDS = 180;
    /** A shift is closed (and paid) automatically after this long. */
    public static final long MAX_SECONDS = 4 * 3600L;
    /** The player gets a short earnings report on the action bar this often. */
    public static final int REPORT_EVERY_SECONDS = 300;

    public enum StartResult { OK, NOT_EMPLOYED, ALREADY }

    public record Payout(long seconds, long cents, Bank.Result paid) {}

    private static final class Activity {
        double x, y, z;
        float yaw, pitch;
        int lastActiveTick;
        boolean warned;

        Activity(ServerPlayer p) {
            remember(p);
            lastActiveTick = p.tickCount;
        }

        void remember(ServerPlayer p) {
            x = p.getX();
            y = p.getY();
            z = p.getZ();
            yaw = p.getYRot();
            pitch = p.getXRot();
        }

        /** Called once a second. */
        void update(ServerPlayer p) {
            boolean moved = Math.abs(p.getX() - x) > 0.05 || Math.abs(p.getY() - y) > 0.05 || Math.abs(p.getZ() - z) > 0.05
                    || Math.abs(Mth.wrapDegrees(p.getYRot() - yaw)) > 1.0F || Math.abs(p.getXRot() - pitch) > 1.0F;
            if (moved || p.containerMenu != p.inventoryMenu) lastActiveTick = p.tickCount;
            remember(p);
        }
    }

    private static final Map<UUID, Activity> ACTIVITY = new HashMap<>();

    private Shift() {}

    public static boolean isOnShift(MinecraftServer server, UUID id) {
        return JobData.get(server).player(id).onShift;
    }

    /** Workplaces call this when the player does something useful (brewing, serving), so the pay does not stop. */
    public static void touch(ServerPlayer player) {
        Activity a = ACTIVITY.get(player.getUUID());
        if (a != null) {
            a.lastActiveTick = player.tickCount;
            a.warned = false;
        }
    }

    // ------------------------------------------------------------------ start / end

    public static StartResult start(ServerPlayer player) {
        MinecraftServer server = player.server;
        JobData data = JobData.get(server);
        PlayerJob job = data.player(player.getUUID());
        if (job.current == null || ProfessionManager.get(job.current).isEmpty()) return StartResult.NOT_EMPLOYED;
        if (job.onShift) return StartResult.ALREADY;
        job.onShift = true;
        job.shiftUnits = 0;
        job.shiftSeconds = 0;
        data.setDirty();
        ACTIVITY.put(player.getUUID(), new Activity(player));
        syncBadges(player, true);
        return StartResult.OK;
    }

    /**
     * Ends the shift of a player (online or not) and pays it. Returns null if there was no shift.
     * notify: tell the player (if online) what they earned.
     */
    @Nullable
    public static Payout end(MinecraftServer server, UUID id, boolean notify) {
        JobData data = JobData.get(server);
        PlayerJob job = data.player(id);
        if (!job.onShift) return null;

        long seconds = job.shiftSeconds;
        long cents = Math.round(job.shiftUnits / 3600.0);
        Bank.Result paid = Bank.Result.INVALID_AMOUNT;
        if (cents > 0) paid = Bank.deposit(server, id, cents, Transaction.Type.WAGE, "shift");
        if (job.current != null) {
            job.progress.computeIfAbsent(job.current, k -> new Progress()).workedSeconds += seconds;
        }
        job.onShift = false;
        job.shiftUnits = 0;
        job.shiftSeconds = 0;
        data.setDirty();
        ACTIVITY.remove(id);

        ServerPlayer p = server.getPlayerList().getPlayer(id);
        if (p != null) {
            syncBadges(p, false);
            if (notify) {
                Component msg;
                if (cents <= 0) {
                    msg = Component.translatable("shift.end_unpaid", duration(seconds));
                } else if (paid != Bank.Result.OK) {
                    msg = Component.translatable("shift.end_bank_full", duration(seconds), Money.format(cents));
                } else {
                    msg = Component.translatable("shift.end", duration(seconds), Money.format(cents));
                }
                p.sendSystemMessage(msg);
            }
        }
        return new Payout(seconds, cents, paid);
    }

    /** What the badge does: starts the shift, or ends it and pays. */
    public static void toggle(ServerPlayer player) {
        if (isOnShift(player.server, player.getUUID())) {
            end(player.server, player.getUUID(), true);
            player.level().playSound(null, player.blockPosition(), ModSounds.SUCCESS.get(), SoundSource.PLAYERS, 0.7F, 1.0F);
            return;
        }
        switch (start(player)) {
            case OK -> {
                Optional<Jobs.Status> st = Jobs.status(player.server, player.getUUID());
                if (st.isPresent()) {
                    player.displayClientMessage(Component.translatable("shift.start",
                            st.get().profession().displayName(), Money.format(st.get().wageCentsPerHour())), true);
                }
                player.level().playSound(null, player.blockPosition(), ModSounds.CARD_INSERT.get(), SoundSource.PLAYERS, 0.8F, 1.2F);
            }
            case NOT_EMPLOYED -> {
                player.displayClientMessage(Component.translatable("shift.error.no_job"), true);
                player.level().playSound(null, player.blockPosition(), ModSounds.ERROR.get(), SoundSource.PLAYERS, 0.6F, 1.0F);
            }
            case ALREADY -> player.displayClientMessage(Component.translatable("shift.already"), true);
        }
    }

    // ------------------------------------------------------------------ the clock

    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer p)) return;
        if (p.tickCount % 20 != 0) return;
        MinecraftServer server = p.server;
        JobData data = JobData.get(server);
        PlayerJob job = data.player(p.getUUID());
        if (!job.onShift) return;

        Optional<Jobs.Status> st = Jobs.status(server, p.getUUID());
        if (st.isEmpty()) {                                   // the profession file disappeared
            end(server, p.getUUID(), true);
            return;
        }
        Activity a = ACTIVITY.computeIfAbsent(p.getUUID(), k -> new Activity(p));
        a.update(p);
        if (p.tickCount - a.lastActiveTick > AFK_SECONDS * 20) {
            if (!a.warned) {
                a.warned = true;
                p.displayClientMessage(Component.translatable("shift.afk"), true);
            }
            return;
        }
        if (job.shiftSeconds >= MAX_SECONDS) {
            end(server, p.getUUID(), true);
            p.sendSystemMessage(Component.translatable("shift.limit", MAX_SECONDS / 3600));
            return;
        }
        job.shiftSeconds++;
        job.shiftUnits += st.get().wageCentsPerHour();
        if (job.shiftSeconds % 60 == 0) data.setDirty();
        if (job.shiftSeconds % REPORT_EVERY_SECONDS == 0) {
            p.displayClientMessage(Component.translatable("shift.report", duration(job.shiftSeconds),
                    Money.format(Math.round(job.shiftUnits / 3600.0))), true);
        }
    }

    /** A shift never survives a logout: it is closed and paid. (After a crash the leftover is paid on the next login.) */
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            end(p.server, p.getUUID(), false);
        }
    }

    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            if (isOnShift(p.server, p.getUUID())) {
                end(p.server, p.getUUID(), true);
            } else {
                syncBadges(p, false);
            }
        }
    }

    // ------------------------------------------------------------------ status, badge

    /** Seconds on the current shift, or -1 if the player is off shift. */
    public static long shiftSeconds(MinecraftServer server, UUID id) {
        PlayerJob job = JobData.get(server).player(id);
        return job.onShift ? job.shiftSeconds : -1;
    }

    /** Cents earned so far on the current shift (not paid yet). */
    public static long earnedCents(MinecraftServer server, UUID id) {
        PlayerJob job = JobData.get(server).player(id);
        return job.onShift ? Math.round(job.shiftUnits / 3600.0) : 0;
    }

    /** Lights the badges of the player green while on shift (custom_model_data 1 selects the "on" model). */
    public static void syncBadges(ServerPlayer p, boolean on) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!s.is(ModItems.WORK_BADGE.get())) continue;
            if (on) {
                s.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(1));
            } else {
                s.remove(DataComponents.CUSTOM_MODEL_DATA);
            }
        }
    }

    /** Gives the badge unless the player already carries one. Returns true if a new one was given. */
    public static boolean giveBadgeIfMissing(ServerPlayer p) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).is(ModItems.WORK_BADGE.get())) return false;
        }
        ItemStack badge = new ItemStack(ModItems.WORK_BADGE.get());
        if (isOnShift(p.server, p.getUUID())) badge.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(1));
        p.getInventory().placeItemBackInInventory(badge);
        return true;
    }

    public static String duration(long seconds) {
        return String.format("%d:%02d:%02d", seconds / 3600, seconds / 60 % 60, seconds % 60);
    }
}
