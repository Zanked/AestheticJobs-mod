package dev.aestheticjobs.job;

import dev.aestheticjobs.job.JobData.PlayerJob;
import dev.aestheticjobs.job.JobData.Progress;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;

/**
 * Public jobs API. Call only on the server thread.
 * The employment center, the shift clock and the workplaces all go through these methods.
 */
public final class Jobs {
    /** How long a player has to wait after quitting before taking a new job (will move to a config). */
    public static final long QUIT_COOLDOWN_MINUTES = 10;

    /** Workplaces (cafe register ...) only work for players who are on a shift. */
    public static final boolean REQUIRE_SHIFT_FOR_WORK = true;

    public enum Result { OK, UNKNOWN_PROFESSION, ALREADY_EMPLOYED, NOT_EMPLOYED, COOLDOWN, REQUIREMENTS_NOT_MET }

    /** nextRankXp is -1 at the top rank. */
    public record Status(Profession profession, int rank, long xp, long nextRankXp, long wageCentsPerHour) {}

    public record XpResult(boolean employed, int oldRank, int newRank, Profession profession) {}

    private Jobs() {}

    public static Optional<Profession> currentProfession(MinecraftServer server, UUID player) {
        PlayerJob job = JobData.get(server).player(player);
        return job.current == null ? Optional.empty() : ProfessionManager.get(job.current);
    }

    public static Optional<Status> status(MinecraftServer server, UUID player) {
        PlayerJob job = JobData.get(server).player(player);
        if (job.current == null) return Optional.empty();
        Optional<Profession> found = ProfessionManager.get(job.current);
        if (found.isEmpty()) return Optional.empty();
        Profession p = found.get();
        Progress progress = job.progress.get(job.current);
        long xp = progress == null ? 0 : progress.xp;
        int rank = p.rankIndex(xp);
        return Optional.of(new Status(p, rank, xp, p.nextRankXp(rank), p.wageCents(rank)));
    }

    public static boolean isOnShift(MinecraftServer server, UUID player) {
        return JobData.get(server).player(player).onShift;
    }

    /** Highest rank the player reached in a profession, or -1 if the player never worked there. */
    public static int bestRank(MinecraftServer server, UUID player, ResourceLocation professionId) {
        PlayerJob job = JobData.get(server).player(player);
        Progress progress = job.progress.get(professionId);
        Optional<Profession> p = ProfessionManager.get(professionId);
        if (progress == null || p.isEmpty()) return -1;
        return p.get().rankIndex(progress.xp);
    }

    /** force = skip every check (cooldown, requirements, already employed). Used by admin commands. */
    public static Result hire(MinecraftServer server, UUID player, ResourceLocation professionId, boolean force) {
        Optional<Profession> found = ProfessionManager.get(professionId);
        if (found.isEmpty()) return Result.UNKNOWN_PROFESSION;
        JobData data = JobData.get(server);
        PlayerJob job = data.player(player);
        long now = System.currentTimeMillis();
        if (!force) {
            if (job.current != null) return Result.ALREADY_EMPLOYED;
            if (job.lastQuit > 0 && now - job.lastQuit < QUIT_COOLDOWN_MINUTES * 60_000L) return Result.COOLDOWN;
            for (Profession.Requirement r : found.get().requirements()) {
                if (bestRank(server, player, r.profession()) < r.minRank()) return Result.REQUIREMENTS_NOT_MET;
            }
        }
        if (job.onShift) Shift.end(server, player, true);     // changing the job closes the shift and pays it
        job.current = professionId;
        job.hiredAt = now;
        job.progress.computeIfAbsent(professionId, k -> new Progress());
        data.setDirty();
        return Result.OK;
    }

    /** force = no cooldown afterwards. */
    public static Result quit(MinecraftServer server, UUID player, boolean force) {
        JobData data = JobData.get(server);
        PlayerJob job = data.player(player);
        if (job.current == null) return Result.NOT_EMPLOYED;
        if (job.onShift) Shift.end(server, player, true);
        job.current = null;
        if (!force) job.lastQuit = System.currentTimeMillis();
        data.setDirty();
        return Result.OK;
    }

    /** Adds experience to the current profession. */
    public static XpResult addXp(MinecraftServer server, UUID player, long amount) {
        JobData data = JobData.get(server);
        PlayerJob job = data.player(player);
        Optional<Profession> found = job.current == null ? Optional.empty() : ProfessionManager.get(job.current);
        if (found.isEmpty()) return new XpResult(false, 0, 0, null);
        Profession p = found.get();
        Progress progress = job.progress.computeIfAbsent(job.current, k -> new Progress());
        int oldRank = p.rankIndex(progress.xp);
        progress.xp = Math.min(progress.xp + amount, 1_000_000_000L);
        int newRank = p.rankIndex(progress.xp);
        data.setDirty();
        return new XpResult(true, oldRank, newRank, p);
    }
}
