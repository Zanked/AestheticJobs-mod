package dev.aestheticjobs.job;

import com.google.gson.JsonElement;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.aestheticjobs.economy.Money;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.StringRepresentable;

/**
 * One profession, loaded from data/<namespace>/profession/<name>.json.
 * Display names come from the lang file: profession.<namespace>.<name> and
 * profession.<namespace>.<name>.rank.<rank id>.
 */
public record Profession(ResourceLocation id, ResourceLocation icon, double hourlyWage, PaySource paySource,
                         List<Rank> ranks, List<Requirement> requirements) {

    /** Who pays the wage: the server itself, or the employer's account (a player-owned business). */
    public enum PaySource implements StringRepresentable {
        SERVER, EMPLOYER;

        public static final Codec<PaySource> CODEC = StringRepresentable.fromEnum(PaySource::values);

        @Override
        public String getSerializedName() {
            return name().toLowerCase();
        }
    }

    public record Rank(String id, long xp, double wageMultiplier) {
        public static final Codec<Rank> CODEC = RecordCodecBuilder.create(i -> i.group(
                Codec.STRING.fieldOf("id").forGetter(Rank::id),
                Codec.LONG.optionalFieldOf("xp", 0L).forGetter(Rank::xp),
                Codec.DOUBLE.optionalFieldOf("wage_multiplier", 1.0).forGetter(Rank::wageMultiplier)
        ).apply(i, Rank::new));
    }

    /** The player must have worked in this profession and reached at least this rank (0 = any). */
    public record Requirement(ResourceLocation profession, int minRank) {
        public static final Codec<Requirement> CODEC = RecordCodecBuilder.create(i -> i.group(
                ResourceLocation.CODEC.fieldOf("profession").forGetter(Requirement::profession),
                Codec.INT.optionalFieldOf("min_rank", 0).forGetter(Requirement::minRank)
        ).apply(i, Requirement::new));
    }

    private record Body(ResourceLocation icon, double hourlyWage, PaySource paySource,
                        List<Rank> ranks, List<Requirement> requirements) {
        static final Codec<Body> CODEC = RecordCodecBuilder.create(i -> i.group(
                ResourceLocation.CODEC.optionalFieldOf("icon", ResourceLocation.parse("minecraft:paper")).forGetter(Body::icon),
                Codec.doubleRange(0.0, 100000.0).fieldOf("hourly_wage").forGetter(Body::hourlyWage),
                PaySource.CODEC.optionalFieldOf("pay_source", PaySource.SERVER).forGetter(Body::paySource),
                Rank.CODEC.listOf().fieldOf("ranks").forGetter(Body::ranks),
                Requirement.CODEC.listOf().optionalFieldOf("requirements", List.of()).forGetter(Body::requirements)
        ).apply(i, Body::new));
    }

    /** Parses and validates one file. Returns empty (after reporting the reason) when it is broken. */
    public static Optional<Profession> parse(ResourceLocation id, JsonElement json, Consumer<String> error) {
        Optional<Body> parsed = Body.CODEC.parse(JsonOps.INSTANCE, json).resultOrPartial(error);
        if (parsed.isEmpty()) return Optional.empty();
        Body b = parsed.get();
        if (b.ranks().isEmpty()) {
            error.accept("needs at least one rank");
            return Optional.empty();
        }
        long previous = -1;
        for (Rank r : b.ranks()) {
            if (r.xp() <= previous) {
                error.accept("rank xp must increase from rank to rank, and the first rank must have xp 0");
                return Optional.empty();
            }
            previous = r.xp();
        }
        if (b.ranks().get(0).xp() != 0) {
            error.accept("the first rank must have xp 0");
            return Optional.empty();
        }
        return Optional.of(new Profession(id, b.icon(), b.hourlyWage(), b.paySource(), List.copyOf(b.ranks()), List.copyOf(b.requirements())));
    }

    /** Index of the highest rank whose xp threshold is reached. */
    public int rankIndex(long xp) {
        int index = 0;
        for (int i = 0; i < ranks.size(); i++) {
            if (xp >= ranks.get(i).xp()) index = i;
        }
        return index;
    }

    /** Wage per hour at the given rank, in cents. */
    public long wageCents(int rankIndex) {
        return BigDecimal.valueOf(hourlyWage)
                .multiply(BigDecimal.valueOf(ranks.get(rankIndex).wageMultiplier()))
                .movePointRight(2).setScale(0, RoundingMode.HALF_UP).longValue();
    }

    public long baseWageCents() {
        return wageCents(0);
    }

    /** XP needed for the next rank, or -1 when the player is at the top rank. */
    public long nextRankXp(int rankIndex) {
        return rankIndex + 1 < ranks.size() ? ranks.get(rankIndex + 1).xp() : -1;
    }

    public Component displayName() {
        return Component.translatable("profession." + id.getNamespace() + "." + id.getPath());
    }

    public Component rankName(int rankIndex) {
        return Component.translatable("profession." + id.getNamespace() + "." + id.getPath()
                + ".rank." + ranks.get(rankIndex).id());
    }

    public String wageText(int rankIndex) {
        return Money.format(wageCents(rankIndex));
    }
}
