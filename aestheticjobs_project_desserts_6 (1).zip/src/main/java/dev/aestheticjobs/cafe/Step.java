package dev.aestheticjobs.cafe;

import dev.aestheticjobs.AestheticJobs;
import net.minecraft.network.chat.Component;

/**
 * One step of a recipe. Every step is its own mini-game on the barista screen (see client/barista).
 * p1 / p2 are the parameters of the mini-game (see the comment at each constant), weight is how much the
 * step counts for the quality of the cup.
 */
public enum Step {
    /** Dial in the grind (scroll) and crank the grinder to a 18 g dose. */
    GRIND(Kind.GRIND, 0, 0, 1.0),
    /** Keep the tamper level while pressing the puck. */
    TAMP(Kind.TAMP, 0, 0, 1.0),
    /** p1 = target shot time in seconds. A ristretto is a short shot, an espresso a normal one. */
    PULL_ESPRESSO(Kind.PULL, 8.0, 0, 1.8),
    PULL_RISTRETTO(Kind.PULL, 5.5, 0, 1.8),
    /** Americano: pour hot water down the wall of the cup, p1 = the fill line. */
    WATER(Kind.WATER, 0.66, 0, 1.2),
    /** Macchiato: pour the espresso over a spoon onto the milk. */
    LAYER(Kind.LAYER, 0, 0, 1.4),
    /** Stir the syrup / chocolate into the base. p1 = 0 vanilla cream, 1 chocolate. */
    STIR_CREAM(Kind.STIR, 0, 0, 0.9),
    STIR_CHOC(Kind.STIR, 1, 0, 0.9),
    /** Steam the milk. p1 = foam share of the volume (0..1), p2 = target temperature in degrees C. */
    STEAM_LATTE(Kind.STEAM, 0.18, 62, 1.8),
    STEAM_CAPPUCCINO(Kind.STEAM, 0.45, 62, 1.8),
    STEAM_FLAT(Kind.STEAM, 0.10, 60, 1.8),
    STEAM_RAF(Kind.STEAM, 0.25, 58, 1.5),
    STEAM_MOCHA(Kind.STEAM, 0.15, 62, 1.5),
    STEAM_MACCHIATO(Kind.STEAM, 0.50, 62, 1.4),
    /** The latte art: pour (LMB), pull through with the pick (RMB). Scored by the server from the picture itself. */
    POUR(Kind.POUR, 0, 0, 3.0),
    /** Finishing touches. */
    COCOA(Kind.COCOA, 0, 0, 1.0),
    WHIP(Kind.WHIP, 0, 0, 1.0),
    CARAMEL(Kind.CARAMEL, 0, 0, 1.0);

    public enum Kind { GRIND, TAMP, PULL, WATER, LAYER, STIR, STEAM, POUR, COCOA, WHIP, CARAMEL }

    private final Kind kind;
    private final double p1, p2, weight;

    Step(Kind kind, double p1, double p2, double weight) {
        this.kind = kind;
        this.p1 = p1;
        this.p2 = p2;
        this.weight = weight;
    }

    public Kind kind() { return kind; }
    public double p1() { return p1; }
    public double p2() { return p2; }
    public double weight() { return weight; }

    public String id() {
        return name().toLowerCase();
    }

    public Component title() {
        return Component.translatable("step." + AestheticJobs.MODID + "." + id());
    }

    public Component hint() {
        return Component.translatable("step." + AestheticJobs.MODID + "." + id() + ".hint");
    }
}
