package dev.aestheticjobs.cafe;

import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.registry.ModItems;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.Item;

/**
 * What the supplier terminal sells: the supplies of the coffee recipes and every dessert, in packs.
 * The order of the list is the order of the packet (client and server build the same list).
 */
public final class SupplyCatalog {
    public enum Category { SUPPLIES, DESSERTS }

    /** One line of the catalog: a pack of {@code packSize} items for {@code packPriceCents}. */
    public record Product(Item item, int packSize, long packPriceCents, Category category) {
        public Component name() {
            return item.getDescription();
        }

        /** The 32x32 item picture (same path scheme as the drinks). */
        public ResourceLocation icon() {
            ResourceLocation key = BuiltInRegistries.ITEM.getKey(item);
            return ResourceLocation.fromNamespaceAndPath(key.getNamespace(), "textures/item/" + key.getPath() + ".png");
        }
    }

    /** Wholesale price of a dessert = this share of what the customer pays for it. */
    public static final double DESSERT_WHOLESALE = 0.40;
    public static final int SUPPLY_PACK = 8;
    public static final int DESSERT_PACK = 4;

    private static List<Product> cache;

    private SupplyCatalog() {}

    public static synchronized List<Product> products() {
        if (cache == null) {
            List<Product> list = new ArrayList<>();
            // per piece: cheap enough that a drink still earns well (see CafeLogic.serve)
            list.add(new Product(ModItems.COFFEE_BEANS.get(), SUPPLY_PACK, 20L * SUPPLY_PACK, Category.SUPPLIES));
            list.add(new Product(ModItems.MILK_CARTON.get(), SUPPLY_PACK, 30L * SUPPLY_PACK, Category.SUPPLIES));
            list.add(new Product(ModItems.CREAM_CARTON.get(), SUPPLY_PACK, 30L * SUPPLY_PACK, Category.SUPPLIES));
            list.add(new Product(ModItems.SYRUP_VANILLA.get(), SUPPLY_PACK, 25L * SUPPLY_PACK, Category.SUPPLIES));
            list.add(new Product(ModItems.SYRUP_CARAMEL.get(), SUPPLY_PACK, 25L * SUPPLY_PACK, Category.SUPPLIES));
            list.add(new Product(ModItems.CHOCOLATE.get(), SUPPLY_PACK, 25L * SUPPLY_PACK, Category.SUPPLIES));
            list.add(new Product(ModItems.EMPTY_CUP.get(), 16, 8L * 16, Category.SUPPLIES));
            for (Dessert d : Dessert.values()) {
                long piece = Math.round(d.priceCents() * DESSERT_WHOLESALE);
                list.add(new Product(d.item(), DESSERT_PACK, piece * DESSERT_PACK, Category.DESSERTS));
            }
            cache = List.copyOf(list);
        }
        return cache;
    }
}
