package dev.aestheticjobs.cafe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import java.util.List;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

/**
 * A finished cup: the picture on the surface (256 chars, see Art), the drink (index in Drink), the quality 0..100
 * and the score of every step of the recipe (what exactly went well or badly).
 */
public record CupData(String art, int drink, int quality, List<Integer> scores) {
    public static final Codec<CupData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.STRING.fieldOf("art").forGetter(CupData::art),
            Codec.INT.fieldOf("drink").forGetter(CupData::drink),
            Codec.INT.fieldOf("quality").forGetter(CupData::quality),
            Codec.INT.listOf().optionalFieldOf("scores", List.of()).forGetter(CupData::scores)
    ).apply(instance, CupData::new));

    public static final StreamCodec<ByteBuf, CupData> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.STRING_UTF8, CupData::art,
            ByteBufCodecs.VAR_INT, CupData::drink,
            ByteBufCodecs.VAR_INT, CupData::quality,
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(16)), CupData::scores,
            CupData::new);

    public int stars() {
        if (quality >= 90) return 5;
        if (quality >= 75) return 4;
        if (quality >= 60) return 3;
        if (quality >= 40) return 2;
        return 1;
    }

    public static String starText(int stars) {
        return "\u2605".repeat(stars) + "\u2606".repeat(5 - stars);
    }
}
