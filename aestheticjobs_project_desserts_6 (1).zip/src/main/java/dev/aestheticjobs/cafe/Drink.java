package dev.aestheticjobs.cafe;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.registry.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;

import static dev.aestheticjobs.cafe.Step.*;

/**
 * The menu of the cafe. Every drink is a different recipe: its own list of steps (mini-games), its own supplies.
 * This class also carries the helpers of the 16x16 "art" of a cup (the picture on the surface, see Art).
 */
public enum Drink {
    ESPRESSO("espresso", 350, 40, 0xFF5A3A2A,
            new Supply[]{Supply.BEANS},
            new Step[]{GRIND, TAMP, PULL_ESPRESSO}),
    AMERICANO("americano", 400, 55, 0xFF7A5238,
            new Supply[]{Supply.BEANS},
            new Step[]{GRIND, TAMP, PULL_ESPRESSO, WATER}),
    LATTE("latte", 450, 80, 0xFF8A5E40,
            new Supply[]{Supply.BEANS, Supply.MILK},
            new Step[]{GRIND, TAMP, PULL_ESPRESSO, STEAM_LATTE, POUR}),
    CAPPUCCINO("cappuccino", 450, 95, 0xFF8A5E40,
            new Supply[]{Supply.BEANS, Supply.MILK},
            new Step[]{GRIND, TAMP, PULL_ESPRESSO, STEAM_CAPPUCCINO, POUR, COCOA}),
    FLAT_WHITE("flat_white", 500, 80, 0xFF8A5E40,
            new Supply[]{Supply.BEANS, Supply.MILK},
            new Step[]{GRIND, TAMP, PULL_RISTRETTO, STEAM_FLAT, POUR}),
    RAF("raf", 550, 105, 0xFFD8C08A,
            new Supply[]{Supply.BEANS, Supply.CREAM, Supply.VANILLA},
            new Step[]{GRIND, TAMP, PULL_ESPRESSO, STIR_CREAM, STEAM_RAF, POUR}),
    MOCHA("mocha", 600, 120, 0xFF6E4638,
            new Supply[]{Supply.BEANS, Supply.MILK, Supply.CHOCOLATE},
            new Step[]{GRIND, TAMP, PULL_ESPRESSO, STIR_CHOC, STEAM_MOCHA, POUR, WHIP}),
    MACCHIATO("macchiato", 650, 110, 0xFFE9D9B0,
            new Supply[]{Supply.BEANS, Supply.MILK, Supply.VANILLA, Supply.CARAMEL},
            new Step[]{STEAM_MACCHIATO, GRIND, TAMP, PULL_ESPRESSO, LAYER, CARAMEL});

    /** What a drink uses up (besides the empty cup). */
    public enum Supply {
        BEANS, MILK, CREAM, VANILLA, CARAMEL, CHOCOLATE;

        public Item item() {
            return switch (this) {
                case BEANS -> ModItems.COFFEE_BEANS.get();
                case MILK -> ModItems.MILK_CARTON.get();
                case CREAM -> ModItems.CREAM_CARTON.get();
                case VANILLA -> ModItems.SYRUP_VANILLA.get();
                case CARAMEL -> ModItems.SYRUP_CARAMEL.get();
                case CHOCOLATE -> ModItems.CHOCOLATE.get();
            };
        }
    }

    public static final int SIZE = 16;
    public static final int CELLS = SIZE * SIZE;

    private final String id;
    private final long priceCents;
    private final int baseSeconds;
    private final int baseColor;
    private final Supply[] supplies;
    private final Step[] steps;

    Drink(String id, long priceCents, int baseSeconds, int baseColor, Supply[] supplies, Step[] steps) {
        this.id = id;
        this.priceCents = priceCents;
        this.baseSeconds = baseSeconds;
        this.baseColor = baseColor;
        this.supplies = supplies;
        this.steps = steps;
    }

    public String id() { return id; }
    public long priceCents() { return priceCents; }
    /** The colour of an empty ('0') art cell: the liquid or crema under the foam. */
    public int baseColor() { return baseColor; }
    public Supply[] supplies() { return supplies; }
    public Step[] steps() { return steps; }

    public Component displayName() {
        return Component.translatable("drink." + AestheticJobs.MODID + "." + id);
    }

    /** The detailed 32x32 picture of the drink (item texture), also drawn in the customer's thought bubble. */
    public ResourceLocation iconTexture() {
        return ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "textures/item/cup_" + id + ".png");
    }

    /** custom_model_data of the filled cup: 1..8 selects the model of this drink. */
    public int modelData() {
        return ordinal() + 1;
    }

    public boolean hasArt() {
        for (Step s : steps) if (s == POUR) return true;
        return false;
    }

    /** Service within this time gets the speed bonus (about 1.4x the time an expert needs). */
    public long fastTicks() { return Math.round(baseSeconds * 1.4 * 20); }

    /** The customer waits this long. */
    public long okTicks() { return Math.round(baseSeconds * 3.5 * 20); }

    public static Drink byIndex(int i) {
        Drink[] all = values();
        return i >= 0 && i < all.length ? all[i] : null;
    }

    // ------------------------------------------------------------------ the 16x16 art of the surface

    /** The cup is round: only cells inside the circle exist. */
    public static boolean inCup(int x, int y) {
        double dx = x - 7.5, dy = y - 7.5;
        return dx * dx + dy * dy <= 57.8;
    }

    /** Keeps only valid art: exactly 256 chars of '0'..'6', nothing outside the cup. Returns null if broken. */
    public static String sanitize(String art) {
        if (art == null || art.length() != CELLS) return null;
        StringBuilder sb = new StringBuilder(CELLS);
        for (int i = 0; i < CELLS; i++) {
            char c = art.charAt(i);
            if (c < '0' || c > '6') return null;
            sb.append(inCup(i % SIZE, i / SIZE) ? c : '0');
        }
        return sb.toString();
    }
}
