package dev.aestheticjobs.cafe;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Deliveries that are paid but not yet brought by the courier (world/data/aestheticjobs_deliveries.dat). Server side only. */
public class DeliveryData extends SavedData {
    public static final String NAME = "aestheticjobs_deliveries";

    /** item = registry id, count = number of items (not packs). */
    public record Line(String item, int count) {}

    /** due = game time (overworld) at which the courier sets off; cost is kept for a refund. */
    public record Pending(String dim, BlockPos pos, UUID owner, long due, long cost, List<Line> lines) {}

    private final List<Pending> pending = new ArrayList<>();

    public static DeliveryData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(factory(), NAME);
    }

    public static SavedData.Factory<DeliveryData> factory() {
        return new SavedData.Factory<>(DeliveryData::new, DeliveryData::load, null);
    }

    /** The live list: callers that change it must call setDirty(). */
    public List<Pending> pending() {
        return pending;
    }

    public int countFor(UUID owner) {
        int n = 0;
        for (Pending p : pending) if (p.owner().equals(owner)) n++;
        return n;
    }

    public static DeliveryData load(CompoundTag tag, HolderLookup.Provider registries) {
        DeliveryData data = new DeliveryData();
        ListTag list = tag.getList("pending", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            List<Line> lines = new ArrayList<>();
            ListTag ls = t.getList("lines", Tag.TAG_COMPOUND);
            for (int j = 0; j < ls.size(); j++) {
                CompoundTag l = ls.getCompound(j);
                lines.add(new Line(l.getString("item"), l.getInt("count")));
            }
            data.pending.add(new Pending(t.getString("dim"), BlockPos.of(t.getLong("pos")), t.getUUID("owner"),
                    t.getLong("due"), t.getLong("cost"), lines));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        for (Pending p : pending) {
            CompoundTag t = new CompoundTag();
            t.putString("dim", p.dim());
            t.putLong("pos", p.pos().asLong());
            t.putUUID("owner", p.owner());
            t.putLong("due", p.due());
            t.putLong("cost", p.cost());
            ListTag ls = new ListTag();
            for (Line l : p.lines()) {
                CompoundTag c = new CompoundTag();
                c.putString("item", l.item());
                c.putInt("count", l.count());
                ls.add(c);
            }
            t.put("lines", ls);
            list.add(t);
        }
        tag.put("pending", list);
        return tag;
    }
}
