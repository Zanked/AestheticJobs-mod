package dev.aestheticjobs.cafe;

/**
 * The picture on the surface of a cup: 16x16 cells, one char per cell.
 *   0 the liquid / crema under it   1 milk foam      2 cocoa        3 caramel
 *   4 whipped cream                 5 light crema    6 dark crema
 * The same class scores the art on the server (the client's number is not trusted for the art).
 */
public final class Art {
    private Art() {}

    public static int rgb(char c, Drink drink) {
        return switch (c) {
            case '1' -> 0xFFFCF0D6;
            case '2' -> 0xFF5A382C;
            case '3' -> 0xFFE2A85A;
            case '4' -> 0xFFFFF9EC;
            case '5' -> 0xFFE0AA78;
            case '6' -> 0xFF5A3A2A;
            default -> drink == null ? 0xFF7A5238 : drink.baseColor();
        };
    }

    private static boolean milk(String art, int x, int y) {
        if (x < 0 || y < 0 || x >= Drink.SIZE || y >= Drink.SIZE) return false;
        char c = art.charAt(y * Drink.SIZE + x);
        return c == '1';
    }

    /**
     * 0..100 how pretty the milk drawing is. Rewards: left-right symmetry, a decent share of foam (a quarter to
     * half of the cup), being centred, and DETAIL (a long edge for the amount of foam: a plain blob scores
     * mediocre, a heart or a rosette scores high).
     */
    public static int score(String art) {
        int cupCells = 0, foam = 0, edges = 0, both = 0, either = 0;
        double sx = 0, sy = 0;
        for (int y = 0; y < Drink.SIZE; y++) {
            for (int x = 0; x < Drink.SIZE; x++) {
                if (!Drink.inCup(x, y)) continue;
                cupCells++;
                boolean m = milk(art, x, y);
                boolean mirror = milk(art, Drink.SIZE - 1 - x, y);
                if (m) {
                    foam++;
                    sx += x;
                    sy += y;
                }
                if (m && mirror) both++;
                if (m || mirror) either++;
                if (m != milk(art, x + 1, y) && Drink.inCup(x + 1, y)) edges++;
                if (m != milk(art, x, y + 1) && Drink.inCup(x, y + 1)) edges++;
            }
        }
        if (foam < 6) return 0;
        double sym = either == 0 ? 0 : (double) both / either;
        double cov = (double) foam / cupCells;
        double covScore = cov < 0.22 ? cov / 0.22 : cov > 0.55 ? Math.max(0, 1 - (cov - 0.55) / 0.35) : 1.0;
        double cx = sx / foam - 7.5, cy = sy / foam - 7.5;
        double center = 1.0 - Math.min(1.0, Math.sqrt(cx * cx + cy * cy) / 4.0);
        double ratio = edges / Math.sqrt(foam);
        double detail = Math.max(0, Math.min(1, (ratio - 3.6) / 2.9));
        double s = 0.35 * sym + 0.20 * covScore + 0.10 * center + 0.35 * detail;
        return (int) Math.round(100 * Math.max(0, Math.min(1, s)));
    }

    /** A crema surface for the drinks that have no milk art: rings of light and dark crema, noisier when the shot was worse. */
    public static String crema(int shotQuality, long seed) {
        java.util.Random r = new java.util.Random(seed);
        double noise = 0.5 * (1.0 - shotQuality / 100.0) + 0.06;
        StringBuilder sb = new StringBuilder(Drink.CELLS);
        for (int y = 0; y < Drink.SIZE; y++) {
            for (int x = 0; x < Drink.SIZE; x++) {
                if (!Drink.inCup(x, y)) {
                    sb.append('0');
                    continue;
                }
                double dx = x - 7.5, dy = y - 7.5;
                double rad = Math.sqrt(dx * dx + dy * dy);
                double wave = Math.sin(rad * 1.7 + Math.atan2(dy, dx) * 0.0) + (r.nextDouble() - 0.5) * 2 * noise * 2.2;
                char c = rad < 1.6 ? '6' : wave > 0.45 ? '5' : wave < -0.55 ? '6' : '0';
                if (rad > 6.9) c = '6';
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /** All cells foam: the surface of a milk drink before anything is poured / drawn. */
    public static String foamSurface() {
        StringBuilder sb = new StringBuilder(Drink.CELLS);
        for (int i = 0; i < Drink.CELLS; i++) sb.append(Drink.inCup(i % Drink.SIZE, i / Drink.SIZE) ? '1' : '0');
        return sb.toString();
    }
}
