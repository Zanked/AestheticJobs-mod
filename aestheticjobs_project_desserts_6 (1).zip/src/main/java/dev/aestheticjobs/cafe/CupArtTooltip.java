package dev.aestheticjobs.cafe;

import net.minecraft.world.inventory.tooltip.TooltipComponent;

/** Picture shown in the tooltip of a cup: the art on its surface (drink = index in Drink, for the base colour). */
public record CupArtTooltip(String art, int drink) implements TooltipComponent {
}
