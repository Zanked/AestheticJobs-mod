package dev.aestheticjobs.cafe;

import dev.aestheticjobs.economy.Bank;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.economy.Transaction;
import dev.aestheticjobs.entity.CafeCustomerEntity;
import dev.aestheticjobs.item.DeliveryBoxItem;
import dev.aestheticjobs.registry.ModBlocks;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/**
 * Supplier deliveries: the terminal takes the order and the money, after a delay a courier NPC walks to the
 * terminal and leaves a delivery box. The pending orders live in {@link DeliveryData}, so they survive restarts.
 */
public final class DeliveryService {
    /** From the order to the courier setting off (2 minutes), the walk comes on top. */
    public static final long DELAY_TICKS = 2400L;
    public static final int MAX_PENDING = 3;
    public static final int MAX_PACKS_PER_LINE = 16;
    public static final int MAX_PACKS_TOTAL = 64;

    private DeliveryService() {}

    /** Server: a player pressed "order" in the terminal. packs = number of packs per catalog line. */
    public static void place(ServerPlayer player, ServerLevel level, BlockPos pos, List<Integer> packs) {
        List<SupplyCatalog.Product> products = SupplyCatalog.products();
        if (packs.size() != products.size()) return;

        long total = 0;
        int totalPacks = 0;
        List<DeliveryData.Line> lines = new ArrayList<>();
        for (int i = 0; i < products.size(); i++) {
            int n = packs.get(i);
            if (n < 0 || n > MAX_PACKS_PER_LINE) return;                    // not a valid order
            if (n == 0) continue;
            SupplyCatalog.Product p = products.get(i);
            total += p.packPriceCents() * n;
            totalPacks += n;
            lines.add(new DeliveryData.Line(BuiltInRegistries.ITEM.getKey(p.item()).toString(), p.packSize() * n));
        }
        if (totalPacks > MAX_PACKS_TOTAL) return;
        if (lines.isEmpty()) {
            player.displayClientMessage(Component.translatable("cafe.supplier.empty"), true);
            return;
        }
        MinecraftServer server = level.getServer();
        DeliveryData data = DeliveryData.get(server);
        if (data.countFor(player.getUUID()) >= MAX_PENDING) {
            player.displayClientMessage(Component.translatable("cafe.supplier.too_many", MAX_PENDING), true);
            return;
        }
        Bank.Result paid = Bank.withdraw(server, player.getUUID(), total, Transaction.Type.PURCHASE, "supplier");
        if (paid != Bank.Result.OK) {
            player.displayClientMessage(Component.translatable("cafe.supplier.no_money", Money.format(total)), true);
            return;
        }
        long due = server.overworld().getGameTime() + DELAY_TICKS;
        data.pending().add(new DeliveryData.Pending(level.dimension().location().toString(), pos, player.getUUID(), due, total, lines));
        data.setDirty();
        player.sendSystemMessage(Component.translatable("cafe.supplier.ordered", Money.format(total), DELAY_TICKS / 1200L));
    }

    /** Once a second: send out the couriers of the orders that are due. */
    public static void onServerTick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        if (server.getTickCount() % 20 != 0) return;
        DeliveryData data = DeliveryData.get(server);
        if (data.pending().isEmpty()) return;
        long now = server.overworld().getGameTime();

        Iterator<DeliveryData.Pending> it = data.pending().iterator();
        while (it.hasNext()) {
            DeliveryData.Pending p = it.next();
            if (p.due() > now) continue;
            ServerLevel level = server.getLevel(ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(p.dim())));
            if (level == null || !level.getBlockState(p.pos()).is(ModBlocks.SUPPLIER_TERMINAL.get())) {
                if (level != null && !level.isLoaded(p.pos())) continue;      // wait until the terminal is loaded
                refund(server, p);
                it.remove();
                data.setDirty();
                continue;
            }
            if (!level.isLoaded(p.pos())) continue;
            Direction facing = level.getBlockState(p.pos()).getValue(HorizontalDirectionalBlock.FACING);
            List<ItemStack> cargo = stacks(p.lines());
            if (!CafeCustomerEntity.spawnCourier(level, p.pos(), facing, p.owner(), cargo)) {
                dropBox(level, p.pos(), cargo);                                // no room for the courier: the box just appears
                ServerPlayer owner = server.getPlayerList().getPlayer(p.owner());
                if (owner != null) owner.sendSystemMessage(Component.translatable("cafe.supplier.delivered"));
            }
            it.remove();
            data.setDirty();
        }
    }

    /** Puts a delivery box on top of the terminal. */
    public static void dropBox(ServerLevel level, BlockPos terminal, List<ItemStack> cargo) {
        ItemEntity box = new ItemEntity(level, terminal.getX() + 0.5D, terminal.getY() + 1.0D, terminal.getZ() + 0.5D,
                DeliveryBoxItem.pack(cargo));
        box.setDeltaMovement(0.0D, 0.1D, 0.0D);
        level.addFreshEntity(box);
    }

    private static void refund(MinecraftServer server, DeliveryData.Pending p) {
        Bank.deposit(server, p.owner(), p.cost(), Transaction.Type.DEPOSIT, "supplier refund");
        ServerPlayer owner = server.getPlayerList().getPlayer(p.owner());
        if (owner != null) owner.sendSystemMessage(Component.translatable("cafe.supplier.refund", Money.format(p.cost())));
    }

    /** The items of the lines, split into stacks. */
    public static List<ItemStack> stacks(List<DeliveryData.Line> lines) {
        List<ItemStack> out = new ArrayList<>();
        for (DeliveryData.Line l : lines) {
            Item item = BuiltInRegistries.ITEM.get(ResourceLocation.parse(l.item()));
            int left = l.count();
            while (left > 0) {
                int n = Math.min(left, item.getDefaultMaxStackSize());
                out.add(new ItemStack(item, n));
                left -= n;
            }
        }
        return out;
    }
}
