package dev.aestheticjobs.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.entity.CafeCustomerEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * A small chibi (22 px tall, big head). The whole skin is one 32x32 texture:
 * head (0,0) 8x8x8, body (0,16) 6x8x4, arm (20,16) 2x6x2, leg (20,24) 2x6x2; the left limbs are mirrored copies.
 */
public class CafeCustomerModel extends EntityModel<CafeCustomerEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "cafe_customer"), "main");

    private static final float DEG = (float) (Math.PI / 180.0);

    private final ModelPart root;
    public final ModelPart head;
    public final ModelPart body;
    public final ModelPart rightArm;
    public final ModelPart leftArm;
    public final ModelPart rightLeg;
    public final ModelPart leftLeg;

    public CafeCustomerModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, 10.0F, 0.0F));
        root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 16).addBox(-3.0F, 0.0F, -2.0F, 6.0F, 8.0F, 4.0F),
                PartPose.offset(0.0F, 10.0F, 0.0F));
        root.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(20, 16).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                PartPose.offset(-4.0F, 11.0F, 0.0F));
        root.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(20, 16).mirror().addBox(-1.0F, -1.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                PartPose.offset(4.0F, 11.0F, 0.0F));
        root.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(20, 24).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                PartPose.offset(-1.5F, 18.0F, 0.0F));
        root.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(20, 24).mirror().addBox(-1.0F, 0.0F, -1.0F, 2.0F, 6.0F, 2.0F),
                PartPose.offset(1.5F, 18.0F, 0.0F));

        return LayerDefinition.create(mesh, 32, 32);
    }

    private static float ease(float x) {
        x = Mth.clamp(x, 0.0F, 1.0F);
        return x * x * (3.0F - 2.0F * x);
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    @Override
    public void setupAnim(CafeCustomerEntity e, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        head.xRot = headPitch * DEG;
        head.yRot = netHeadYaw * DEG;
        head.zRot = 0.0F;

        float sw = limbSwing * 0.6662F;
        rightLeg.xRot = Mth.cos(sw) * 1.2F * limbSwingAmount;
        leftLeg.xRot = Mth.cos(sw + (float) Math.PI) * 1.2F * limbSwingAmount;
        rightArm.xRot = Mth.cos(sw + (float) Math.PI) * 0.9F * limbSwingAmount;
        leftArm.xRot = Mth.cos(sw) * 0.9F * limbSwingAmount;
        rightArm.yRot = 0.0F;
        leftArm.yRot = 0.0F;
        float sway = Mth.cos(ageInTicks * 0.09F) * 0.04F;
        rightArm.zRot = 0.06F + sway;
        leftArm.zRot = -0.06F - sway;

        int state = e.getState();
        float t = ageInTicks - e.getClientStateStart();

        if (state == CafeCustomerEntity.STATE_WAITING && e.getPatience() < 25) {
            // impatient: taps a foot
            rightLeg.xRot = -0.35F * Math.abs(Mth.sin(ageInTicks * 0.8F));
        }

        if (state == CafeCustomerEntity.STATE_DRINKING) {
            int stars = e.getStars();
            // right arm: reach for the cup, bring it to the mouth, sip, lower it
            float arm;
            if (t < 10.0F) {
                arm = lerp(0.0F, -1.35F, ease(t / 10.0F));
            } else if (t < 18.0F) {
                arm = lerp(-1.35F, -2.45F, ease((t - 10.0F) / 8.0F));
            } else if (t < 36.0F) {
                arm = -2.45F + Mth.sin((t - 18.0F) * 0.6F) * 0.06F;
            } else {
                arm = lerp(-2.45F, 0.0F, ease((t - 36.0F) / 16.0F));
            }
            rightArm.xRot = arm;
            rightArm.zRot = 0.1F;
            if (t >= 14.0F && t < 34.0F) {
                head.xRot -= 0.22F * ease(Math.min((t - 14.0F) / 4.0F, (34.0F - t) / 4.0F));   // tilts back to drink
            }
            if (t >= CafeCustomerEntity.BURST_TICK) {
                float k = t - CafeCustomerEntity.BURST_TICK;
                if (stars >= 4) {                       // cheers
                    float up = ease(k / 4.0F);
                    rightArm.xRot = lerp(rightArm.xRot, -3.0F, up) + Mth.sin(k * 0.9F) * 0.2F * up;
                    leftArm.xRot = lerp(leftArm.xRot, -3.0F, up) - Mth.sin(k * 0.9F) * 0.2F * up;
                    rightArm.zRot = 0.35F * up;
                    leftArm.zRot = -0.35F * up;
                } else if (stars <= 2) {                // shakes the head
                    head.yRot += Mth.sin(k * 1.3F) * 0.35F;
                }
            }
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
        root.render(poseStack, buffer, packedLight, packedOverlay, color);
    }
}
