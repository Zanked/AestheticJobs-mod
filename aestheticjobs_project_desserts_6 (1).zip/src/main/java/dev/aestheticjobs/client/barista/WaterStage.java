package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModSounds;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Americano: hold the left button to pour hot water into the espresso and let go at the fill line.
 * Pour down the WALL of the cup (mouse near the edge of the glass): in the middle the stream destroys the crema.
 */
public class WaterStage extends Stage {
    private final double line;
    private double level = 0.26, crema, pouredTime;
    private boolean started;
    private float soundTimer;
    private double streamX;

    public WaterStage(Brew brew, Step step) {
        super(brew, step);
        this.line = step.p1();
        this.crema = brew.cremaKept;
    }

    private int gx() { return rx + rw / 2 - 40; }
    private int gy() { return ry + 24; }

    @Override
    public void update(float dt, int mx, int my) {
        if (done) return;
        int gw = 80;
        double edge = Math.abs((mx - (gx() + gw / 2.0)) / (gw / 2.0));          // 0 centre .. 1 wall
        boolean pour = Ui.lmb() || Ui.space();
        if (pour) {
            started = true;
            level = Math.min(1.0, level + 0.2 * dt);
            pouredTime += dt;
            streamX = Math.max(gx() + 6, Math.min(gx() + gw - 6, mx));
            double harm = edge < 0.35 ? 0.34 : edge < 0.6 ? 0.12 : 0.0;
            crema = Math.max(0, crema - harm * dt);
            soundTimer += dt;
            if (soundTimer > 0.28) {
                soundTimer = 0;
                Ui.sound(ModSounds.BARISTA_POUR.get(), 1.0F, 0.5F);
            }
            if (level >= 0.97) finishPour();
        } else if (started) {
            finishPour();
        }
    }

    private void finishPour() {
        if (done) return;
        done = true;
        brew.cremaKept = crema;
        Ui.sound(ModSounds.BARISTA_DING.get(), 1.2F, 0.5F);
    }

    @Override
    public int score() {
        double diff = Math.abs(level - line);
        double ls = diff <= 0.03 ? 100 : Math.max(0, 100 - (diff - 0.03) * 600);
        return (int) Math.round(0.6 * ls + 0.4 * crema * 100);
    }

    @Override
    public Component status() {
        if (done) return Component.translatable("step.aestheticjobs.water.done", (int) Math.round(crema * 100));
        return step.hint();
    }

    @Override
    public void render(GuiGraphics g, Font font, int mx, int my) {
        int gx = gx(), gy = gy(), gw = 80, gh = 100;
        Ui.box(g, gx - 3, gy - 3, gw + 6, gh + 6, 0xFFBDD7DC, 0xFFE6F2F4);
        int h = (int) (gh * level);
        int top = gy + gh - h;
        // espresso at the bottom, the water makes it lighter towards the top
        for (int y = 0; y < h; y++) {
            double k = 1.0 - (double) y / Math.max(1, h);
            g.fill(gx, gy + gh - 1 - y, gx + gw, gy + gh - y, Ui.lerp(0xFF52332A, 0xFFA86E44, Math.max(0, (level - 0.26) * 1.6) * (1 - k * 0.0) * (y / (double) Math.max(1, h))));
        }
        int cremaH = (int) Math.round(8 * crema);
        if (cremaH > 0) g.fill(gx, top, gx + gw, top + cremaH, Ui.CREMA);
        g.fill(gx + 4, gy + 3, gx + 8, gy + gh - 3, 0x66FFFFFF);
        // the fill line
        int ly = gy + gh - (int) (gh * line);
        g.fill(gx - 8, ly, gx + gw + 8, ly + 1, Ui.GOOD_D);
        Ui.text(g, font, Component.translatable("step.aestheticjobs.water.line"), gx + gw + 10, ly - 4, Ui.GOOD_D);
        // the kettle and the stream
        boolean pour = !done && (Ui.lmb() || Ui.space());
        int kx = Math.max(gx + 2, Math.min(gx + gw - 2, mx));
        Ui.box(g, kx - 14, gy - 20, 28, 12, Ui.STEEL_D, Ui.STEEL);
        if (pour) g.fill((int) streamX - 1, gy - 8, (int) streamX + 2, top, 0xCCBFE3F0);
        Ui.text(g, font, Component.translatable("step.aestheticjobs.water.crema", (int) Math.round(crema * 100)), rx + 10, ry + rh - 22, Ui.LABEL);
    }
}
