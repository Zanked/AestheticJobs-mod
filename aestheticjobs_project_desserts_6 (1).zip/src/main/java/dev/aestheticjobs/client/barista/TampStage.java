package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModSounds;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Tamp: the tamper tilts by itself (a drifting bubble level). Move the mouse to counter the tilt and keep the
 * bubble in the middle while you HOLD the left button to press. Pressing crooked makes the shot channel.
 */
public class TampStage extends Stage {
    private static final double TOLERANCE = 0.30;

    private double driftX, driftY, velX, velY;
    private double bx, by;
    private double progress, sumOff, timePressing;
    private float chimeTimer;

    public TampStage(Brew brew, Step step) {
        super(brew, step);
        driftX = (Math.random() - 0.5) * 0.8;
        driftY = (Math.random() - 0.5) * 0.8;
    }

    private int cx() { return rx + rw / 2 - 50; }
    private int cy() { return ry + rh / 2; }

    @Override
    public void update(float dt, int mx, int my) {
        if (done) return;
        velX += (Math.random() - 0.5) * 2.4 * dt;
        velY += (Math.random() - 0.5) * 2.4 * dt;
        velX = Math.max(-0.5, Math.min(0.5, velX * (1 - 0.8 * dt)));
        velY = Math.max(-0.5, Math.min(0.5, velY * (1 - 0.8 * dt)));
        driftX = Math.max(-0.9, Math.min(0.9, driftX + velX * dt));
        driftY = Math.max(-0.9, Math.min(0.9, driftY + velY * dt));
        double relX = Math.max(-1.5, Math.min(1.5, (mx - (rx + rw - 62)) / 42.0));
        double relY = Math.max(-1.5, Math.min(1.5, (my - cy()) / 42.0));
        bx = relX * 0.6 + driftX;
        by = relY * 0.6 + driftY;
        double off = Math.sqrt(bx * bx + by * by);
        if (Ui.lmb()) {
            timePressing += dt;
            sumOff += off * dt;
            if (off < TOLERANCE) {
                progress = Math.min(1.0, progress + dt / 2.4);
                chimeTimer += dt;
                if (chimeTimer > 0.5) {
                    chimeTimer = 0;
                    Ui.sound(ModSounds.BARISTA_TAMP.get(), 1.4F, 0.25F);
                }
            } else {
                progress = Math.max(0, progress - dt * 0.3);
            }
            if (progress >= 1.0) {
                done = true;
                brew.channeling = 1.0 - score() / 100.0;
                Ui.sound(ModSounds.BARISTA_TAMP.get(), 0.8F, 1.0F);
            }
        }
    }

    @Override
    public int score() {
        double avg = timePressing <= 0 ? 0.5 : sumOff / timePressing;
        return (int) Math.max(0, Math.round(100 - Math.min(100, avg * 230)));
    }

    @Override
    public Component status() {
        if (done) return Component.translatable("step.aestheticjobs.tamp.done");
        double off = Math.sqrt(bx * bx + by * by);
        return Component.translatable(off < TOLERANCE ? "step.aestheticjobs.tamp.level" : "step.aestheticjobs.tamp.tilt");
    }

    @Override
    public void render(GuiGraphics g, Font font, int mx, int my) {
        int cx = cx(), cy = cy(), R = 44;
        // portafilter basket seen from above
        Ui.disc(g, cx, cy, R + 6, 0xFF8A6A58);
        Ui.disc(g, cx, cy, R + 3, 0xFFA9B2B6);
        // the coffee puck: cells shaded by the tilt (lighter where it is higher)
        for (int y = -R; y <= R; y += 4) {
            for (int x = -R; x <= R; x += 4) {
                if (x * x + y * y > R * R) continue;
                double k = (x * bx + y * by) / R;
                int c = Ui.lerp(0xFF6A4435, 0xFF9A6E58, 0.5 + k * 0.5 * (1.0 - progress * 0.8));
                g.fill(cx + x, cy + y, cx + x + 4, cy + y + 4, c);
            }
        }
        if (progress > 0) {                                                     // the tamper pressing down
            int tr = (int) (R * (0.55 + 0.45 * progress));
            Ui.ring(g, cx, cy, tr, 3, 0xAAEAEFF1);
        }
        // the level: a round vial on the right
        int lx = rx + rw - 62, ly = cy;
        Ui.disc(g, lx, ly, 46, Ui.KHAKI);
        Ui.disc(g, lx, ly, 44, 0xFFE6F2F4);
        Ui.ring(g, lx, ly, (int) (TOLERANCE * 42), 1, Ui.GOOD_D);
        g.fill(lx - 46, ly, lx + 47, ly + 1, 0xFFBDD7DC);
        g.fill(lx, ly - 46, lx + 1, ly + 47, 0xFFBDD7DC);
        int px = lx + (int) Math.max(-38, Math.min(38, bx * 42)), py = ly + (int) Math.max(-38, Math.min(38, by * 42));
        double off = Math.sqrt(bx * bx + by * by);
        Ui.disc(g, px, py, 7, off < TOLERANCE ? Ui.GOOD : off < 0.6 ? Ui.WARN : Ui.BAD);
        Ui.disc(g, px - 2, py - 2, 2, 0xFFFFFFFF);
        // progress
        Ui.bar(g, rx + 10, ry + rh - 14, rw - 20, 7, progress, Ui.GOOD);
    }
}
