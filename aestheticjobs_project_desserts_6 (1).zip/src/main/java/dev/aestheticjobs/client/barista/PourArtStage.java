package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.cafe.Art;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModSounds;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * The latte art. The cup is seen from above, the mouse is the spout of the pitcher.
 *   LEFT button   pour milk. Hold still: a white disc grows. Move slowly: a fat line. Move fast: a thin line.
 *                 While moving, every "wave" of milk leaves a thin dark crema line behind it (a rosette).
 *   RIGHT button  the pick: drag it through the foam to pull a heart, a leaf or a tulip out of the milk.
 * MOUSE WHEEL tilts the pitcher: tilted far = a strong flow (a fat line or blob, the milk runs out fast),
 *                 barely tilted = a thin precise flow for the details (and the milk lasts).
 * The foam of your steamed milk matters: silky microfoam flows, bubbly milk leaves specks.
 * The picture is scored by the server: symmetry, enough foam, centred, and detail.
 */
public class PourArtStage extends Stage {
    private static final int N = Brew.GRID, CELL = 4;
    private static final double C = (N - 1) / 2.0, RAD = 15.2;
    private static final double STEP = 1.0 / 30.0;

    private final float[] m;
    private final float[] tmp = new float[N * N], tmp2 = new float[N * N];
    private double r, acc, hx, hy, lastX, lastY, volume = 100, stepTimer, endTimer;
    private boolean haveLast, pouringNow, pickingNow;
    private float soundTimer;
    private double tilt = 0.7;                       // 0.35 .. 1.0, the wheel
    private int artScore;
    private final double growMul, radMul;

    public PourArtStage(Brew brew, Step step) {
        super(brew, step);
        this.m = brew.milk;
        java.util.Arrays.fill(m, 0f);
        this.growMul = 0.7 + brew.foam * 1.2;
        this.radMul = Math.max(0.85, Math.min(1.12, 0.85 + brew.foam * 0.6));
    }

    private int ox() { return rx + 12; }
    private int oy() { return ry + (rh - N * CELL) / 2; }

    private static boolean inCup(int x, int y) {
        double dx = x - C, dy = y - C;
        return dx * dx + dy * dy <= RAD * RAD;
    }

    @Override
    public void update(float dt, int mx, int my) {
        if (done) return;
        stepTimer += dt;
        while (stepTimer >= STEP) {
            stepTimer -= STEP;
            sim(mx, my);
        }
        if (volume <= 0 && !pouringNow) {
            endTimer += dt;
            if (endTimer > 0.8) finish();
        }
        if (pouringNow) {
            soundTimer += dt;
            if (soundTimer > 0.28) {
                soundTimer = 0;
                Ui.sound(ModSounds.BARISTA_POUR.get(), 1.1F, 0.4F);
            }
        }
    }

    private void sim(int mx, int my) {
        double px = (mx - ox()) / (double) CELL - 0.5, py = (my - oy()) / (double) CELL - 0.5;
        double dx = px - C, dy = py - C, dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > RAD + 3) {
            px = C + dx / dist * (RAD + 3);
            py = C + dy / dist * (RAD + 3);
        }
        pouringNow = Ui.lmb() && volume > 0;
        pickingNow = Ui.rmb();
        if (!haveLast) {
            lastX = px;
            lastY = py;
            haveLast = true;
        }
        double vx = px - lastX, vy = py - lastY, sp = Math.sqrt(vx * vx + vy * vy);
        lastX = px;
        lastY = py;

        if (pickingNow) {
            pick(px, py, vx, vy, sp);
            acc = 0;
            r = 0;
        } else if (pouringNow) {
            volume -= 0.30 * tilt / 0.7;
            if (sp < 0.18) {                                  // still: the white disc grows
                r = Math.min(r + 0.045 * growMul * tilt / 0.7, 7.5);
                disc(px, py, r);
                acc = 0;
            } else {
                hx = 0.7 * hx + 0.3 * vx / sp;
                hy = 0.7 * hy + 0.3 * vy / sp;
                double n = Math.sqrt(hx * hx + hy * hy);
                if (n < 1e-6) n = 1;
                double ux = hx / n, uy = hy / n;
                acc += sp;
                if (acc >= 2.1) {
                    acc = 0;
                    double rs = Math.max(1.3, Math.min(5.0, 4.6 - 0.9 * sp)) * radMul * (0.75 + 0.25 * tilt / 0.7);
                    rs = Math.min(5.4, rs);
                    disc(px, py, rs);
                    for (int y = 0; y < N; y++) {
                        for (int x = 0; x < N; x++) {
                            double ddx = x - px, ddy = y - py, d = Math.sqrt(ddx * ddx + ddy * ddy);
                            if (d > rs + 0.2 && d <= rs + 1.15 && ddx * ux + ddy * uy < -0.12 * rs && m[y * N + x] > 0.5F) {
                                m[y * N + x] = 0f;            // the thin crema line between two waves of milk
                            }
                        }
                    }
                    r = Math.max(rs - 0.15, 1.4);
                }
            }
        } else {
            r = 0;
            acc = 0;
        }
        mask();
    }

    private void disc(double px, double py, double rad) {
        for (int y = 0; y < N; y++) {
            for (int x = 0; x < N; x++) {
                double d = Math.sqrt((x - px) * (x - px) + (y - py) * (y - py));
                double a = Math.max(0, Math.min(1, rad + 0.5 - d));
                if (a > 0) m[y * N + x] = (float) (m[y * N + x] * (1 - a) + a);
            }
        }
    }

    private void pick(double px, double py, double vx, double vy, double sp) {
        final double R = 3.8;
        if (sp > 1e-6) {
            System.arraycopy(m, 0, tmp, 0, m.length);
            for (int y = 0; y < N; y++) {
                for (int x = 0; x < N; x++) {
                    double d = Math.sqrt((x - px) * (x - px) + (y - py) * (y - py));
                    if (d >= R) continue;
                    double w = 0.5 * (1 + Math.cos(Math.PI * d / R));
                    tmp[y * N + x] = bilinear(m, x - vx * w * 1.25, y - vy * w * 1.25);
                }
            }
            System.arraycopy(tmp, 0, m, 0, m.length);
            System.arraycopy(m, 0, tmp2, 0, m.length);
            for (int y = 1; y < N - 1; y++) {
                for (int x = 1; x < N - 1; x++) {
                    double d = Math.sqrt((x - px) * (x - px) + (y - py) * (y - py));
                    float v = tmp2[y * N + x];
                    if (d < R && v > 0.15F && v < 0.85F) {
                        float avg = (tmp2[y * N + x] + tmp2[y * N + x - 1] + tmp2[y * N + x + 1] + tmp2[(y - 1) * N + x] + tmp2[(y + 1) * N + x]) / 5f;
                        m[y * N + x] = Math.max(0f, Math.min(1f, (avg - 0.5f) * 1.4f + 0.5f));
                    }
                }
            }
        }
    }

    private static float bilinear(float[] a, double sx, double sy) {
        sx = Math.max(0, Math.min(N - 1.001, sx));
        sy = Math.max(0, Math.min(N - 1.001, sy));
        int x0 = (int) sx, y0 = (int) sy;
        double fx = sx - x0, fy = sy - y0;
        return (float) (a[y0 * N + x0] * (1 - fx) * (1 - fy) + a[y0 * N + x0 + 1] * fx * (1 - fy)
                + a[(y0 + 1) * N + x0] * (1 - fx) * fy + a[(y0 + 1) * N + x0 + 1] * fx * fy);
    }

    private void mask() {
        for (int y = 0; y < N; y++) {
            for (int x = 0; x < N; x++) {
                int i = y * N + x;
                m[i] = inCup(x, y) ? Math.max(0f, Math.min(1f, m[i])) : 0f;
            }
        }
    }

    private int coverage() {
        int n = 0;
        for (float v : m) if (v > 0.5f) n++;
        return n;
    }

    @Override
    public void scroll(double amount) {
        if (done) return;
        double v = Math.max(0.35, Math.min(1.0, tilt + (amount > 0 ? 0.1 : -0.1)));
        if (Math.abs(v - tilt) > 1e-9) {
            tilt = v;
            Ui.sound(ModSounds.BARISTA_POUR.get(), 1.5F, 0.25F);
        }
    }

    @Override
    public boolean canFinish() {
        return !done && coverage() > 25;
    }

    @Override
    public void finish() {
        if (done) return;
        if (brew.micro < 0.6) {                                    // bubbly milk leaves dark specks in the white
            java.util.Random rnd = new java.util.Random(brew.pos.asLong());
            int specks = (int) ((0.6 - brew.micro) * 60);
            for (int i = 0; i < specks; i++) {
                int x = rnd.nextInt(N), y = rnd.nextInt(N);
                if (m[y * N + x] > 0.8f) m[y * N + x] = 0.1f;
            }
        }
        done = true;
        artScore = Art.score(brew.art());
        Ui.sound(ModSounds.BARISTA_DING.get(), 1.2F, 0.5F);
    }

    @Override
    public int score() {
        return done ? artScore : Art.score(brew.art());
    }

    @Override
    public Component status() {
        if (volume <= 0) return Component.translatable("step.aestheticjobs.pour.empty");
        return step.hint();
    }

    @Override
    public void render(GuiGraphics g, Font font, int mx, int my) {
        int ox = ox(), oy = oy();
        int ccx = ox + N * CELL / 2, ccy = oy + N * CELL / 2;
        Ui.disc(g, ccx, ccy, N * CELL / 2 + 9, 0xFFE6D9BA);                       // saucer
        Ui.disc(g, ccx, ccy, N * CELL / 2 + 5, 0xFFFFF6E2);
        int base = Art.rgb('0', brew.drink);
        for (int y = 0; y < N; y++) {
            for (int x = 0; x < N; x++) {
                if (!inCup(x, y)) continue;
                g.fill(ox + x * CELL, oy + y * CELL, ox + x * CELL + CELL, oy + y * CELL + CELL, Ui.lerp(base, Ui.MILK, m[y * N + x]));
            }
        }
        Ui.ring(g, ccx, ccy, N * CELL / 2 + 1, 2, 0xFFD9CBA8);

        // the pitcher at the cursor
        if (!done) {
            boolean pour = pouringNow, pick = pickingNow;
            if (pick) {
                Ui.line(g, mx, my, mx + 12, my - 18, 2, 0xFF8A6A58);
                g.fill(mx - 1, my - 1, mx + 2, my + 2, Ui.INK);
            } else {
                int lift = (int) ((1.0 - tilt) * 14);                                   // barely tilted: the pitcher stands up
                Ui.box(g, mx + 3, my - 24 - lift, 24, 20, Ui.STEEL_D, Ui.STEEL);
                g.fill(mx, my - 6, mx + 6, my - 3, Ui.STEEL_D);                    // spout
                if (pour) g.fill(mx - 1, my - 6, mx + 1, my, 0xFFFFFFFF);
            }
        }

        // side panel
        int sx = ox + N * CELL + 16, w = rx + rw - sx - 6;
        Ui.text(g, font, Component.translatable("step.aestheticjobs.pour.milk"), sx, ry + 8, Ui.LABEL);
        Ui.bar(g, sx, ry + 20, w, 7, volume / 100.0, volume > 25 ? Ui.MILK : Ui.BAD);
        int shown = done ? artScore : Art.score(brew.art());
        Ui.text(g, font, Component.translatable("step.aestheticjobs.pour.score", shown), sx, ry + 38, Ui.INK);
        Ui.bar(g, sx, ry + 50, w, 7, shown / 100.0, shown >= 75 ? Ui.GOOD : shown >= 50 ? Ui.WARN : Ui.BAD);
        Ui.text(g, font, Component.translatable("step.aestheticjobs.pour.tip1"), sx, ry + 70, Ui.LABEL);
        Ui.text(g, font, Component.translatable("step.aestheticjobs.pour.tip2"), sx, ry + 82, Ui.LABEL);
        Ui.text(g, font, Component.translatable("step.aestheticjobs.pour.tip3"), sx, ry + 94, Ui.LABEL);
        Ui.text(g, font, Component.translatable("step.aestheticjobs.pour.tip4"), sx, ry + 106, Ui.LABEL);
        Ui.text(g, font, Component.translatable("step.aestheticjobs.pour.tilt"), sx, ry + 119, Ui.LABEL);
        Ui.bar(g, sx + 34, ry + 120, Math.max(10, w - 34), 6, (tilt - 0.3) / 0.7, Ui.WARN);
    }
}
