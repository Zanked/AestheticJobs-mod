package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModSounds;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Stir the syrup / chocolate into the base: hold the left button and move the mouse in circles around the cup.
 * Keep a steady speed: too slow leaves lumps, too fast splashes. The swirl melts into one colour.
 */
public class StirStage extends Stage {
    private static final double LO = 3.4, HI = 7.5;
    private final boolean chocolate;
    private double mix, omega, lastAngle, angleOffset, bandTime, totalTime;
    private boolean hasLast;
    private float soundTimer;

    public StirStage(Brew brew, Step step) {
        super(brew, step);
        this.chocolate = step.p1() >= 1;
    }

    private int cx() { return rx + rw / 2 - 30; }
    private int cy() { return ry + rh / 2 - 4; }

    @Override
    public void update(float dt, int mx, int my) {
        if (done) return;
        double dx = mx - cx(), dy = my - cy(), dist = Math.sqrt(dx * dx + dy * dy);
        double w = 0;
        if (Ui.lmb() && dist > 8 && dist < 74) {
            double a = Math.atan2(dy, dx);
            if (hasLast) {
                double d = a - lastAngle;
                while (d > Math.PI) d -= 2 * Math.PI;
                while (d < -Math.PI) d += 2 * Math.PI;
                w = Math.abs(d) / Math.max(dt, 1e-3);
                angleOffset += d;
            }
            lastAngle = a;
            hasLast = true;
        } else {
            hasLast = false;
        }
        omega += (Math.min(w, 14.0) - omega) * Math.min(1.0, dt * 8);
        if (omega > 0.8) {
            totalTime += dt;
            boolean inBand = omega >= LO && omega <= HI;
            if (inBand) bandTime += dt;
            mix = Math.min(1.0, mix + dt * (inBand ? 0.2 : omega > HI ? 0.07 : 0.09));
            soundTimer += dt;
            if (soundTimer > 0.22) {
                soundTimer = 0;
                Ui.sound(ModSounds.BARISTA_POUR.get(), inBand ? 1.3F : 0.9F, 0.22F);
            }
        }
        if (mix >= 1.0) {
            done = true;
            Ui.sound(ModSounds.BARISTA_DING.get(), 1.2F, 0.5F);
        }
    }

    @Override
    public int score() {
        return totalTime <= 0 ? 0 : (int) Math.round(Math.max(30, Math.min(100, 100 * bandTime / totalTime * 1.05)));
    }

    @Override
    public Component status() {
        if (omega < 0.8) return step.hint();
        return Component.translatable(omega < LO ? "step.aestheticjobs.stir.slow" : omega > HI ? "step.aestheticjobs.stir.fast" : "step.aestheticjobs.stir.good");
    }

    @Override
    public void render(GuiGraphics g, Font font, int mx, int my) {
        int cx = cx(), cy = cy(), R = 52;
        int a = 0xFF52332A;
        int b = chocolate ? 0xFFB98A70 : 0xFFFBECCB;
        Ui.disc(g, cx, cy, R + 5, 0xFFE6D9BA);
        Ui.disc(g, cx, cy, R + 2, 0xFFFFF6E2);
        for (int y = -R; y <= R; y += 3) {
            for (int x = -R; x <= R; x += 3) {
                double r = Math.sqrt(x * x + y * y);
                if (r > R) continue;
                double ang = Math.atan2(y, x);
                double t = 0.5 + 0.5 * Math.sin(ang * 3 + r * 0.16 - angleOffset * 2.2);
                double wgt = t * (1 - mix) + 0.5 * mix;
                int c = Ui.lerp(a, b, wgt);
                if (mix < 0.55 && omega < LO && ((x * 7 + y * 13) % 11 == 0)) c = b;      // lumps when stirred too slowly
                g.fill(cx + x, cy + y, cx + x + 3, cy + y + 3, c);
            }
        }
        if (omega > HI) {
            for (int i = 0; i < 6; i++) {
                double an = Math.random() * Math.PI * 2;
                g.fill(cx + (int) (Math.cos(an) * (R + 4)), cy + (int) (Math.sin(an) * (R + 4)), cx + (int) (Math.cos(an) * (R + 4)) + 2, cy + (int) (Math.sin(an) * (R + 4)) + 2, 0xFFE3A08C);
            }
        }
        // the spoon follows the mouse
        if (Ui.lmb()) Ui.line(g, cx, cy, Math.max(cx - R, Math.min(cx + R, mx)), Math.max(cy - R, Math.min(cy + R, my)), 3, Ui.STEEL_D);
        // speed gauge on the right
        int gx = rx + rw - 40, gy = ry + 14, gh = rh - 40;
        g.fill(gx - 1, gy - 1, gx + 13, gy + gh + 1, Ui.KHAKI);
        g.fill(gx, gy, gx + 12, gy + gh, Ui.TAN);
        int z0 = gy + gh - (int) (gh * HI / 14.0), z1 = gy + gh - (int) (gh * LO / 14.0);
        g.fill(gx, z0, gx + 12, z1, Ui.GOOD);
        int ny = gy + gh - (int) (gh * Math.min(1.0, omega / 14.0));
        g.fill(gx - 3, ny, gx + 15, ny + 2, Ui.INK);
        Ui.bar(g, rx + 10, ry + rh - 14, rw - 20, 7, mix, Ui.GOOD);
    }
}
