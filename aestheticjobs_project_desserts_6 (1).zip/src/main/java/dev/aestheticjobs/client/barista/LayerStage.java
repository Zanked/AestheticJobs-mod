package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModSounds;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Macchiato: pour the espresso OVER A SPOON onto the foam so that it floats as a layer.
 * The spoon swings from side to side: hold the left button and keep the stream on the spoon.
 * Pouring beside it digs into the foam and mixes the layers.
 */
public class LayerStage extends Stage {
    private double progress, mix, time;
    private float soundTimer;

    public LayerStage(Brew brew, Step step) {
        super(brew, step);
    }

    private int gx() { return rx + rw / 2 - 40; }
    private int gy() { return ry + 40; }
    private double spoonX() { return gx() + 40 + Math.sin(time * 1.5) * 24; }

    @Override
    public void update(float dt, int mx, int my) {
        if (done) return;
        time += dt;
        if (Ui.lmb() || Ui.space()) {
            boolean aimed = Math.abs(mx - spoonX()) < 15;
            if (aimed) progress = Math.min(1.0, progress + dt / 3.6);
            else {
                mix += dt * 0.7;
                progress = Math.min(1.0, progress + dt / 7.0);
            }
            soundTimer += dt;
            if (soundTimer > 0.28) {
                soundTimer = 0;
                Ui.sound(ModSounds.BARISTA_POUR.get(), aimed ? 1.15F : 0.8F, 0.5F);
            }
            if (progress >= 1.0) {
                done = true;
                Ui.sound(ModSounds.BARISTA_DING.get(), 1.2F, 0.5F);
            }
        }
    }

    @Override
    public int score() {
        return (int) Math.round(Math.max(20, 100 * (1.0 - Math.min(1.0, mix / 1.6))));
    }

    @Override
    public Component status() {
        return Component.translatable(mix > 0.5 ? "step.aestheticjobs.layer.mixed" : "step.aestheticjobs.layer.hint");
    }

    @Override
    public void render(GuiGraphics g, Font font, int mx, int my) {
        int gx = gx(), gy = gy(), gw = 80, gh = 84;
        Ui.box(g, gx - 3, gy - 3, gw + 6, gh + 6, 0xFFBDD7DC, 0xFFE6F2F4);
        int milkH = (int) (gh * 0.62), foamH = (int) (gh * 0.22);
        g.fill(gx, gy + gh - milkH, gx + gw, gy + gh, 0xFFF4E2B0);                   // vanilla milk
        g.fill(gx, gy + gh - milkH - foamH, gx + gw, gy + gh - milkH, 0xFFFFFAEC);   // foam
        int espH = (int) (foamH * 0.9 * progress);
        int top = gy + gh - milkH - foamH;
        double blur = Math.min(1.0, mix / 1.6);
        for (int y = 0; y < espH; y++) {                                              // the espresso layer, smeared if mixed
            int c = Ui.lerp(0xFF52332A, 0xFFB98A60, blur * (y / (double) Math.max(1, espH)));
            g.fill(gx, top + y, gx + gw, top + y + 1, c);
        }
        if (blur > 0.2) {
            for (int i = 0; i < blur * 40; i++) {
                int x = gx + (int) ((i * 37) % gw), y = top + espH + (int) ((i * 17) % 14);
                g.fill(x, y, x + 3, y + 2, 0x88B98A60);
            }
        }
        g.fill(gx + 4, gy + 3, gx + 8, gy + gh - 3, 0x66FFFFFF);
        // the spoon and the stream
        int sx = (int) spoonX();
        Ui.disc(g, sx, top - 3, 9, Ui.STEEL_D);
        Ui.disc(g, sx, top - 4, 8, Ui.STEEL);
        boolean pour = !done && (Ui.lmb() || Ui.space());
        int jx = Math.max(gx + 4, Math.min(gx + gw - 4, mx));
        Ui.box(g, jx - 10, gy - 30, 20, 12, 0xFF6A4A3A, 0xFF8A6A58);
        if (pour) {
            boolean aimed = Math.abs(mx - spoonX()) < 15;
            g.fill(jx - 1, gy - 18, jx + 2, aimed ? top - 12 : top + espH, 0xFF52332A);
        }
        Ui.bar(g, rx + 10, ry + rh - 14, rw - 20, 7, progress, Ui.GOOD);
    }
}
