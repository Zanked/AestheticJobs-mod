package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModSounds;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/**
 * Grind and DIAL IN. The right fineness is different every day (the beans are damper, the weather changes) and
 * drifts a little from cup to cup: nobody tells you the number. Turn the knob (wheel or the buttons), pull a TEST
 * SHOT and read the taste: sour = grind finer, bitter = grind coarser. Then crank the handle (hold LMB and move
 * the mouse in circles) until the dose is 18 g. The machine remembers the last setting that was right, so a good
 * barista only fine-tunes between cups. The fineness is carried on: it sets how fast the shot runs.
 */
public class GrindStage extends Stage {
    private static final double TARGET_DOSE = 18.0, TURN_G = 2.4, TEST_SECONDS = 1.5;
    private static final ResourceLocation BEANS = ResourceLocation.fromNamespaceAndPath("aestheticjobs", "textures/item/coffee_beans.png");

    /** The setting that was right last time. */
    private static double lastGood = 5.0;

    private double dose, fineness, rotation, lastAngle, soundAcc;
    private final double ideal;
    private boolean hasLast;
    private final List<float[]> beans = new ArrayList<>();   // x, y, vy
    private float beanTimer;
    // tasting
    private int tests;
    private double testT = -1, pending, reading;
    private boolean hasReading, stale;

    public GrindStage(Brew brew, Step step) {
        super(brew, step);
        this.fineness = lastGood;
        this.ideal = idealFor(brew);
    }

    /** Today's right fineness (the same all day) plus a small drift from cup to cup. */
    private static double idealFor(Brew brew) {
        var level = Minecraft.getInstance().level;
        long day = level == null ? 0L : level.getDayTime() / 24000L;
        long hour = level == null ? 0L : level.getGameTime() / 6000L;
        double base = 5.0 + 2.6 * new java.util.Random(day * 7919L + 17L).nextDouble();
        double drift = (new java.util.Random(brew.pos.asLong() * 31L + hour).nextDouble() - 0.5) * 0.7;
        return Math.max(2.0, Math.min(9.0, base + drift));
    }

    private int cx() { return rx + 62; }
    private int cy() { return ry + rh / 2 + 4; }
    private int px() { return rx + 152; }

    // ------------------------------------------------------------------ input

    @Override
    public void update(float dt, int mx, int my) {
        if (done) return;
        if (testT >= 0) {
            testT += dt;
            if (testT >= TEST_SECONDS) {
                testT = -1;
                reading = pending;
                hasReading = true;
                stale = false;
                Ui.sound(ModSounds.BARISTA_DING.get(), 1.3F, 0.5F);
            }
        }
        double dx = mx - cx(), dy = my - cy();
        double dist = Math.sqrt(dx * dx + dy * dy);
        if (Ui.lmb() && dist > 10 && dist < 70) {
            double a = Math.atan2(dy, dx);
            if (hasLast) {
                double d = a - lastAngle;
                while (d > Math.PI) d -= 2 * Math.PI;
                while (d < -Math.PI) d += 2 * Math.PI;
                if (d > 0 && d < 1.2) {                         // clockwise on screen
                    rotation += d;
                    dose = Math.min(32.0, dose + d / (2 * Math.PI) * TURN_G);
                    soundAcc += d;
                    beanTimer += d;
                }
            }
            lastAngle = a;
            hasLast = true;
        } else {
            hasLast = false;
        }
        if (soundAcc > 0.8) {
            soundAcc = 0;
            Ui.sound(ModSounds.BARISTA_GRIND.get(), 0.85F + (float) (fineness * 0.04), 0.55F);
        }
        while (beanTimer > 0.5) {                               // a bean falls into the portafilter
            beanTimer -= 0.5;
            beans.add(new float[]{cx() + 58 + (float) (Math.random() * 6 - 3), cy() - 22, 0});
        }
        for (int i = beans.size() - 1; i >= 0; i--) {
            float[] b = beans.get(i);
            b[2] += 260 * dt;
            b[1] += b[2] * dt;
            if (b[1] > cy() + 46) beans.remove(i);
        }
    }

    private void nudge(int dir) {
        double v = Math.max(1.0, Math.min(10.0, fineness + dir * 0.5));
        if (v != fineness) {
            fineness = v;
            if (hasReading) stale = true;                        // the old taste does not tell anything about the new setting
            Ui.sound(ModSounds.BARISTA_GRIND.get(), 1.4F, 0.4F);
        }
    }

    @Override
    public void scroll(double amount) {
        if (!done) nudge(amount > 0 ? 1 : -1);
    }

    private void startTest() {
        if (testT >= 0 || done) return;
        tests++;
        testT = 0;
        pending = Math.max(-1.0, Math.min(1.0, (fineness - ideal) / 2.2));   // + = finer than right = bitter
        Ui.sound(ModSounds.BARISTA_PUMP.get(), 1.2F, 0.6F);
    }

    @Override
    public boolean click(double mx, double my, int button) {
        if (done) return false;
        int px = px();
        if (Ui.in(mx, my, px, ry + 25, 14, 14)) { nudge(-1); return true; }
        if (Ui.in(mx, my, px + 80, ry + 25, 14, 14)) { nudge(1); return true; }
        if (Ui.in(mx, my, px, ry + 96, 94, 16)) { startTest(); return true; }
        return false;
    }

    @Override
    public boolean canFinish() {
        return !done && dose >= 4;
    }

    @Override
    public Component finishLabel() {
        return Component.translatable("step.aestheticjobs.grind.stop");
    }

    @Override
    public void finish() {
        brew.fineness = fineness;
        brew.idealFineness = ideal;
        if (Math.abs(fineness - ideal) < 0.6) lastGood = fineness;      // the machine remembers a setting that worked
        done = true;
    }

    @Override
    public int score() {
        double diff = Math.abs(dose - TARGET_DOSE);
        double ds = diff <= 0.6 ? 100 : Math.max(0, 100 - (diff - 0.6) * 22);
        double gs = Math.max(0, 100 - Math.abs(fineness - ideal) * 38);
        return (int) Math.round(0.55 * gs + 0.45 * ds);
    }

    @Override
    public Component status() {
        if (hasReading && !stale && testT < 0) {
            double a = Math.abs(reading);
            return Component.translatable(a < 0.14 ? "step.aestheticjobs.grind.balanced"
                    : reading > 0 ? "step.aestheticjobs.grind.bitter" : "step.aestheticjobs.grind.sour");
        }
        if (dose < 4) return step.hint();
        return Component.translatable("step.aestheticjobs.grind.dose", String.format(Locale.ROOT, "%.1f", dose), (int) TARGET_DOSE);
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void render(GuiGraphics g, Font font, int mx, int my) {
        int cx = cx(), cy = cy();
        // grinder body
        Ui.box(g, cx + 30, cy - 62, 56, 96, Ui.STEEL_D, Ui.STEEL);
        g.fill(cx + 34, cy - 58, cx + 38, cy + 28, 0xFFEAEFF1);                  // highlight
        Ui.box(g, cx + 34, cy - 72, 48, 12, 0xFFC9B88E, 0xFFE9D9B0);              // hopper
        Ui.icon(g, BEANS, cx + 46, cy - 66, 24);
        g.fill(cx + 50, cy + 34, cx + 66, cy + 40, Ui.STEEL_D);                    // chute
        // the portafilter below
        Ui.box(g, cx + 36, cy + 40, 44, 14, 0xFF6A4A3A, 0xFF8A6A58);
        Ui.box(g, cx + 44, cy + 36, 28, 6, 0xFF4A3228, 0xFF3A2A24);
        int level = (int) Math.min(18, dose / TARGET_DOSE * 12);
        g.fill(cx + 46, cy + 40 - level / 2, cx + 70, cy + 42, 0xFF6A4435);       // grounds heap
        // handle: a crank on the left
        Ui.ring(g, cx, cy, 46, 2, 0xFFC9B88E);
        g.fill(cx - 2, cy - 2, cx + 3, cy + 3, Ui.STEEL_D);
        double kx = cx + Math.cos(rotation) * 38, ky = cy + Math.sin(rotation) * 38;
        Ui.line(g, cx, cy, kx, ky, 3, Ui.STEEL_D);
        Ui.disc(g, (int) kx, (int) ky, 6, 0xFFE3A08C);
        Ui.disc(g, (int) kx - 1, (int) ky - 1, 2, 0xFFF7CDBB);
        Ui.line(g, cx + 46, cy, cx + 30, cy, 3, Ui.STEEL_D);
        for (float[] b : beans) g.fill((int) b[0], (int) b[1], (int) b[0] + 3, (int) b[1] + 3, 0xFF6A4435);

        // dose meter
        int mxp = rx + rw - 30, myp = ry + 12, mh = rh - 40;
        Ui.text(g, font, Component.translatable("step.aestheticjobs.grind.g"), mxp - 4, myp - 10, Ui.LABEL);
        g.fill(mxp - 1, myp - 1, mxp + 15, myp + mh + 1, Ui.KHAKI);
        g.fill(mxp, myp, mxp + 14, myp + mh, Ui.TAN);
        double scale = mh / 30.0;
        int fillH = (int) (dose * scale);
        g.fill(mxp, myp + mh - fillH, mxp + 14, myp + mh, diffColor());
        int t0 = myp + mh - (int) ((TARGET_DOSE + 0.6) * scale), t1 = myp + mh - (int) ((TARGET_DOSE - 0.6) * scale);
        g.fill(mxp - 3, t0, mxp + 17, t0 + 1, Ui.GOOD_D);
        g.fill(mxp - 3, t1, mxp + 17, t1 + 1, Ui.GOOD_D);
        Ui.text(g, font, Component.literal(String.format(Locale.ROOT, "%.1f", dose)), mxp - 2, myp + mh + 4, Ui.INK);

        renderDial(g, font, mx, my);
    }

    /** The dial-in corner: the knob, the taste gauge and the test shot button. */
    private void renderDial(GuiGraphics g, Font font, int mx, int my) {
        int px = px();
        Ui.text(g, font, Component.translatable("step.aestheticjobs.grind.fineness"), px + 24, ry + 5, Ui.LABEL);
        int kx = px + 47, ky = ry + 32;
        for (int i = 1; i <= 10; i++) {                                           // ticks of the scale, 270 degrees
            double a = Math.toRadians(135 + (i - 1) / 9.0 * 270.0);
            Ui.disc(g, (int) Math.round(kx + Math.cos(a) * 27), (int) Math.round(ky + Math.sin(a) * 27), i == Math.round(fineness) ? 2 : 1, Ui.LABEL);
        }
        Ui.disc(g, kx, ky, 22, Ui.STEEL_D);
        Ui.disc(g, kx, ky, 19, Ui.STEEL);
        Ui.disc(g, kx - 5, ky - 6, 5, 0xFFEAEFF1);
        double fa = Math.toRadians(135 + (fineness - 1) / 9.0 * 270.0);
        Ui.line(g, kx, ky, kx + Math.cos(fa) * 16, ky + Math.sin(fa) * 16, 3, Ui.INK);
        Ui.disc(g, kx, ky, 3, Ui.INK);
        Ui.button(g, font, px, ry + 25, 14, 14, Component.literal("-"), Ui.in(mx, my, px, ry + 25, 14, 14), !done, 0);
        Ui.button(g, font, px + 80, ry + 25, 14, 14, Component.literal("+"), Ui.in(mx, my, px + 80, ry + 25, 14, 14), !done, 0);
        Ui.centered(g, font, Component.literal(String.format(Locale.ROOT, "%.1f", fineness)), kx, ry + 58, Ui.INK);

        // the taste gauge: sour (left) - balanced - bitter (right)
        int gx = px, gy = ry + 72, gw = 94;
        g.fill(gx - 1, gy - 1, gx + gw + 1, gy + 9, Ui.KHAKI);
        g.fill(gx, gy, gx + (int) (gw * 0.36), gy + 8, Ui.WARN);
        g.fill(gx + (int) (gw * 0.36), gy, gx + (int) (gw * 0.64), gy + 8, Ui.GOOD);
        g.fill(gx + (int) (gw * 0.64), gy, gx + gw, gy + 8, 0xFFC9A078);
        double shown = 0.0;
        boolean live = false;
        if (testT >= 0) {                                                          // the needle swings in while the test runs
            double k = Math.min(1.0, testT / TEST_SECONDS);
            shown = pending * (1 - Math.pow(1 - k, 3)) + Math.sin(testT * 16.0) * 0.3 * (1 - k);
            live = true;
        } else if (hasReading) {
            shown = reading;
            live = !stale;
        }
        if (testT >= 0 || hasReading) {
            int nx = gx + gw / 2 + (int) Math.round(Math.max(-1, Math.min(1, shown)) * gw / 2.0);
            g.fill(nx - 1, gy - 3, nx + 2, gy + 11, live ? Ui.INK : 0xFFB5A58A);
        } else {
            Ui.centered(g, font, Component.literal("?"), gx + gw / 2, gy, Ui.LABEL);
        }
        Ui.text(g, font, Component.translatable("step.aestheticjobs.grind.sour_end"), gx, ry + 83, Ui.LABEL);
        Component bitter = Component.translatable("step.aestheticjobs.grind.bitter_end");
        Ui.text(g, font, bitter, gx + gw - font.width(bitter), ry + 83, Ui.LABEL);

        boolean testing = testT >= 0;
        Ui.button(g, font, px, ry + 96, 94, 16, Component.translatable("step.aestheticjobs.grind.test", tests),
                Ui.in(mx, my, px, ry + 96, 94, 16), !done && !testing, 3);
    }

    private int diffColor() {
        double diff = Math.abs(dose - TARGET_DOSE);
        return diff <= 0.6 ? Ui.GOOD : diff <= 2.5 ? Ui.WARN : Ui.BAD;
    }
}
