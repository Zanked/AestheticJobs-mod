package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModSounds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Steam the milk like a real barista. The mouse is the steam wand (position = where the tip is in the pitcher),
 * hold the left button / Space to open the valve.
 *   1. AERATE: keep the tip right under the surface (a soft "tss") and foam builds, but only while the milk is
 *      cold (below ~46 C). Too high and it screams and makes big bubbles.
 *   2. TEXTURE: sink the tip a little and off-centre: the milk starts to whirl, big bubbles are folded in and the
 *      foam becomes silky microfoam.
 * Stop (the Done button) at the right temperature and the right amount of foam. Above 72 C the milk is scalded.
 */
public class SteamStage extends Stage {
    private final double foamTarget, tempTarget;
    private double temp = 5, foam, big, smooth, vortex, time;
    private boolean started, scalded;
    private float soundTimer;
    private final List<float[]> puffs = new ArrayList<>();   // x, y, life

    public SteamStage(Brew brew, Step step) {
        super(brew, step);
        this.foamTarget = step.p1();
        this.tempTarget = step.p2();
    }

    private int pcx() { return rx + rw / 2 - 34; }
    private int pty() { return ry + 26; }
    private static final int PH = 96, HW_TOP = 34, HW_BOTTOM = 26;

    private double depth(int my) { return Math.max(0, Math.min(1, (my - pty()) / (double) PH)); }
    private double surface() { return 0.46 - 0.18 * foam; }

    @Override
    public void update(float dt, int mx, int my) {
        if (done) return;
        time += dt;
        lastMy = my;
        double d = depth(my);
        double rel = d - surface();
        double off = Math.abs(mx - pcx()) / (double) HW_TOP;
        boolean valve = (Ui.lmb() || Ui.space()) && !scalded;

        double vt = rel > 0.05 && rel < 0.42 && off > 0.25 && off < 0.72 ? 1.0 : 0.0;
        vortex += (vt - vortex) * Math.min(1.0, dt * 3);

        if (valve) {
            started = true;
            temp += (rel > 0.42 ? 8.0 : 5.5) * dt;
            if (rel < -0.02) {                                   // in the air: spitting and screaming
                big = Math.min(1, big + 0.3 * dt);
            } else if (rel <= 0.10) {                            // right at the surface: aeration
                if (temp < 50) {
                    foam = Math.min(0.8, foam + 0.09 * dt * (1.15 - temp / 70.0));
                    big = Math.min(1, big + (rel < 0.02 ? 0.22 : 0.03) * dt);
                } else {
                    foam = Math.min(0.8, foam + 0.01 * dt);
                    big = Math.min(1, big + 0.12 * dt);
                }
            }
            if (vortex > 0.5 && foam > 0.02) {                   // whirlpool folds the bubbles in
                smooth = Math.min(1, smooth + 0.3 * dt * vortex);
                big = Math.max(0, big - 0.22 * dt * vortex);
            }
            if (temp >= 72) {
                scalded = true;
                Ui.sound(ModSounds.CUSTOMER_GRUMBLE.get(), 0.6F, 0.6F);
            }
            soundTimer += dt;
            if (soundTimer > 0.3) {
                soundTimer = 0;
                float pitch = rel < -0.02 ? 1.5F : rel <= 0.10 ? 1.1F : 0.8F;
                Ui.sound(ModSounds.BARISTA_STEAM.get(), pitch, 0.5F);
            }
            if (Math.random() < 0.6) puffs.add(new float[]{mx + (float) (Math.random() * 6 - 3), pty() + (float) (d * PH) - 4, 1.0F});
        } else {
            temp = Math.max(5, temp - 0.35 * dt);
        }
        for (int i = puffs.size() - 1; i >= 0; i--) {
            float[] p = puffs.get(i);
            p[1] -= 34 * dt;
            p[0] += (float) (Math.sin(time * 4 + i) * 6 * dt);
            p[2] -= dt * 1.2F;
            if (p[2] <= 0) puffs.remove(i);
        }
    }

    @Override
    public boolean canFinish() {
        return !done && started && temp > 20;
    }

    @Override
    public void finish() {
        done = true;
        brew.foam = foam;
        brew.micro = microScore() / 100.0;
        brew.milkTemp = temp;
        Ui.sound(ModSounds.BARISTA_DING.get(), 1.2F, 0.5F);
    }

    private int microScore() {
        return (int) Math.round(100 * (0.6 * smooth + 0.4 * (1 - big)));
    }

    @Override
    public int score() {
        double fs = Math.max(0, 100 - Math.abs(foam - foamTarget) * 260);
        double ts = Math.max(0, 100 - Math.abs(temp - tempTarget) * 8);
        double total = 0.35 * fs + 0.30 * ts + 0.35 * microScore();
        if (scalded) total = Math.min(total, 25);
        return (int) Math.round(total);
    }

    @Override
    public Component status() {
        if (scalded) return Component.translatable("step.aestheticjobs.steam.scalded");
        if (!started) return step.hint();
        if (!(Ui.lmb() || Ui.space())) return Component.translatable("step.aestheticjobs.steam.paused");
        double rel = depth(lastMy) - surface();
        if (rel < -0.02) return Component.translatable("step.aestheticjobs.steam.air");
        if (rel <= 0.10) return Component.translatable(temp < 50 ? "step.aestheticjobs.steam.aerate" : "step.aestheticjobs.steam.cold_late");
        return Component.translatable(vortex > 0.5 ? "step.aestheticjobs.steam.whirl" : "step.aestheticjobs.steam.offcentre");
    }

    private int lastMy;

    @Override
    public void render(GuiGraphics g, Font font, int mx, int my) {
        lastMy = my;
        int cx = pcx(), top = pty();
        double sf = surface();
        // pitcher
        for (int y = 0; y < PH; y += 1) {
            double k = y / (double) PH;
            int half = (int) Math.round(HW_TOP + (HW_BOTTOM - HW_TOP) * k);
            g.fill(cx - half - 2, top + y, cx - half, top + y + 1, Ui.STEEL_D);
            g.fill(cx + half, top + y, cx + half + 2, top + y + 1, Ui.STEEL_D);
            g.fill(cx - half, top + y, cx + half, top + y + 1, 0xFFF4F7F8);
            if (k >= sf) {
                boolean inFoam = k < sf + foam * 0.34;
                int c = inFoam ? Ui.lerp(0xFFFFFAEC, 0xFFFCF0D6, (k - sf) / Math.max(0.01, foam * 0.34)) : 0xFFF8EBD0;
                g.fill(cx - half, top + y, cx + half, top + y + 1, c);
            }
        }
        g.fill(cx - HW_BOTTOM - 4, top + PH, cx + HW_BOTTOM + 4, top + PH + 3, Ui.STEEL_D);
        g.fill(cx + HW_TOP, top - 4, cx + HW_TOP + 10, top + 4, Ui.STEEL_D);            // spout
        // whirl lines
        if (vortex > 0.2) {
            for (int i = 0; i < 6; i++) {
                double a = time * 3.2 + i * 1.05;
                int x = cx + (int) (Math.sin(a) * 20 * vortex), y = top + (int) ((sf + 0.12 + 0.07 * i) * PH);
                if (y < top + PH - 4) g.fill(x, y, x + 8, y + 1, 0x99FFFFFF);
            }
        }
        // big bubbles on the surface
        int nb = (int) (big * 7);
        for (int i = 0; i < nb; i++) {
            int bx = cx - 26 + (i * 23) % 52, by = top + (int) (sf * PH) - 3 + (i * 5) % 5;
            Ui.ring(g, bx, by, 3, 1, 0xFFFFFAEC);
        }
        // the wand
        int wx = Math.max(cx - HW_TOP + 4, Math.min(cx + HW_TOP - 4, mx));
        int ty = top + (int) (depth(my) * PH);
        g.fill(wx - 1, top - 22, wx + 2, ty, Ui.STEEL_D);
        g.fill(wx - 3, ty - 2, wx + 4, ty + 3, Ui.STEEL);
        if (!done && (Ui.lmb() || Ui.space()) && !scalded) {
            for (int i = 0; i < 4; i++) g.fill(wx - 5 + i * 3, ty + 3 + (i % 2) * 3, wx - 3 + i * 3, ty + 6 + (i % 2) * 3, 0xAAFFFFFF);
        }
        for (float[] p : puffs) {
            int a = (int) (p[2] * 150);
            g.fill((int) p[0], (int) p[1], (int) p[0] + 4, (int) p[1] + 4, a << 24 | 0xFFFFFF);
        }
        // thermometer
        int tx = rx + rw - 46, ty0 = ry + 12, th = rh - 44;
        g.fill(tx - 1, ty0 - 1, tx + 13, ty0 + th + 1, Ui.KHAKI);
        g.fill(tx, ty0, tx + 12, ty0 + th, Ui.TAN);
        int z0 = ty0 + th - (int) (th * (tempTarget + 2) / 80.0), z1 = ty0 + th - (int) (th * (tempTarget - 2) / 80.0);
        g.fill(tx, z0, tx + 12, z1, Ui.GOOD);
        g.fill(tx, ty0, tx + 12, ty0 + th - (int) (th * 72 / 80.0), Ui.BAD);
        int tyn = ty0 + th - (int) (th * Math.min(1.0, temp / 80.0));
        g.fill(tx - 3, tyn, tx + 15, tyn + 2, Ui.INK);
        Ui.text(g, font, Component.literal((int) temp + "\u00B0"), tx - 2, ty0 + th + 4, scalded ? Ui.BAD_D : Ui.INK);
        // foam gauge
        int bx = rx + 12, by = ry + rh - 20, bw = rw - 70;
        Ui.text(g, font, Component.translatable("step.aestheticjobs.steam.foam", (int) Math.round(foam * 100)), bx, by - 11, Ui.LABEL);
        Ui.bar(g, bx, by, bw, 7, foam / 0.8, Ui.WARN);
        int tick = bx + (int) (bw * foamTarget / 0.8);
        g.fill(tick, by - 3, tick + 2, by + 10, Ui.GOOD_D);
        Ui.text(g, font, Component.translatable("step.aestheticjobs.steam.micro", microScore()), bx + bw - 66, by - 11, Ui.LABEL);
    }
}
