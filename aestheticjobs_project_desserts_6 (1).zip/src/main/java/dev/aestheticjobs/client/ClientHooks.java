package dev.aestheticjobs.client;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

/** Client-only helpers called from common code behind an isClientSide check. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openSupplierTerminal(BlockPos pos) {
        Minecraft.getInstance().setScreen(new SupplierScreen(pos));
    }

    public static void openCoffeeMachine(BlockPos pos) {
        Minecraft.getInstance().setScreen(new CoffeeMachineScreen(pos));
    }
}
