package dev.aestheticjobs.client;

import dev.aestheticjobs.cafe.CupArtTooltip;
import dev.aestheticjobs.cafe.Drink;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;

/** The latte art picture in the tooltip of a cup / order ticket. */
public class ClientCupArtTooltip implements ClientTooltipComponent {
    private static final int CELL = 3;
    private final String art;
    private final Drink drink;

    public ClientCupArtTooltip(CupArtTooltip data) {
        this.art = data.art();
        this.drink = Drink.byIndex(data.drink());
    }

    @Override
    public int getHeight() {
        return Drink.SIZE * CELL + 4;
    }

    @Override
    public int getWidth(Font font) {
        return Drink.SIZE * CELL;
    }

    @Override
    public void renderImage(Font font, int x, int y, GuiGraphics graphics) {
        int size = Drink.SIZE * CELL;
        graphics.fill(x - 1, y - 1, x + size + 1, y + size + 1, 0xFFC9B88E);
        graphics.fill(x, y, x + size, y + size, 0xFFE9D9B0);
        CupRenderer.draw(graphics, x, y, CELL, art, drink);
    }
}
