package dev.aestheticjobs.client;

import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.DeliveryService;
import dev.aestheticjobs.cafe.SupplyCatalog;
import dev.aestheticjobs.client.barista.Ui;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.network.DeliveryOrderPayload;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The catalog of the supplier terminal: two tabs (supplies / desserts), left click adds a pack, right click removes one
 * (Shift: five at a time). "Order" sends the list to the server, which takes the money and sends the courier.
 */
public class SupplierScreen extends Screen {
    private static final int W = 300, H = 246;

    private final BlockPos pos;
    private final List<SupplyCatalog.Product> products = SupplyCatalog.products();
    private final int[] qty = new int[products.size()];
    private final List<Integer> supplyIdx = new ArrayList<>();
    private final List<Integer> dessertIdx = new ArrayList<>();
    private int tab;
    private int left, top;

    public SupplierScreen(BlockPos pos) {
        super(Component.translatable("block.aestheticjobs.supplier_terminal"));
        this.pos = pos;
        for (int i = 0; i < products.size(); i++) {
            (products.get(i).category() == SupplyCatalog.Category.SUPPLIES ? supplyIdx : dessertIdx).add(i);
        }
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ------------------------------------------------------------------ layout
    private List<Integer> shown() { return tab == 0 ? supplyIdx : dessertIdx; }
    private int cols() { return tab == 0 ? 4 : 8; }
    private int cardW() { return tab == 0 ? 68 : 33; }
    private int cardH() { return tab == 0 ? 54 : 36; }
    private int cardX(int k) { return left + 12 + (k % cols()) * (tab == 0 ? 71 : 34); }
    private int cardY(int k) { return top + 52 + (k / cols()) * (tab == 0 ? 58 : 38); }
    private int tabX(int t) { return left + 12 + t * 124; }
    private int buyX() { return left + W - 100; }
    private int clearX() { return left + W - 196; }
    private int barY() { return top + H - 34; }

    private long total() {
        long sum = 0;
        for (int i = 0; i < qty.length; i++) sum += qty[i] * products.get(i).packPriceCents();
        return sum;
    }

    private int totalPacks() {
        int n = 0;
        for (int q : qty) n += q;
        return n;
    }

    private static int have(net.minecraft.world.item.Item item) {
        var player = Minecraft.getInstance().player;
        return player == null ? 0 : CafeLogic.count(player, item);
    }

    // ------------------------------------------------------------------ render
    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        renderBackground(g, mx, my, partial);
        Ui.box(g, left - 3, top - 3, W + 6, H + 6, Ui.BORDER, Ui.BORDER);
        Ui.box(g, left, top, W, H, Ui.KHAKI, Ui.BG);
        g.renderOutline(left + 3, top + 3, W - 6, H - 6, 0x66FFFFFF);

        Ui.text(g, font, Component.translatable("gui.aestheticjobs.supplier.title"), left + 12, top + 10, Ui.INK);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.supplier.hint", DeliveryService.DELAY_TICKS / 1200L),
                left + 12, top + 21, Ui.LABEL);
        for (int t = 0; t < 2; t++) {
            Ui.button(g, font, tabX(t), top + 32, 120, 16,
                    Component.translatable(t == 0 ? "gui.aestheticjobs.supplier.supplies" : "gui.aestheticjobs.supplier.desserts"),
                    Ui.in(mx, my, tabX(t), top + 32, 120, 16), true, tab == t ? 2 : 0);
        }

        List<Integer> list = shown();
        List<Component> tip = null;
        for (int k = 0; k < list.size(); k++) {
            int i = list.get(k);
            SupplyCatalog.Product p = products.get(i);
            int x = cardX(k), y = cardY(k), w = cardW(), h = cardH();
            boolean hov = Ui.in(mx, my, x, y, w, h);
            boolean sel = qty[i] > 0;
            Ui.box(g, x, y, w, h, sel ? Ui.GOOD_D : Ui.KHAKI, sel ? 0xFFF2F8EC : hov ? 0xFFFFFBEE : Ui.INNER);
            if (tab == 0) {
                Ui.icon(g, p.icon(), x + 18, y + 3, 32);
                Ui.centered(g, font, p.name(), x + 34, y + 37, Ui.INK);
                Ui.centered(g, font, Component.literal(Money.format(p.packPriceCents()) + " ×" + p.packSize()), x + 34, y + 45, Ui.LABEL);
            } else {
                Ui.icon(g, p.icon(), x + 4, y + 2, 24);
                Ui.centered(g, font, Component.literal(Money.format(p.packPriceCents())), x + w / 2, y + 27, Ui.LABEL);
            }
            if (sel) {
                Ui.box(g, x + w - 14, y + 1, 13, 11, Ui.GOOD_D, Ui.GOOD);
                Ui.centered(g, font, Component.literal(Integer.toString(qty[i])), x + w - 8, y + 3, Ui.INK);
            }
            if (hov) {
                tip = new ArrayList<>();
                tip.add(p.name());
                tip.add(Component.translatable("gui.aestheticjobs.supplier.pack", p.packSize(), Money.format(p.packPriceCents())));
                if (sel) {
                    tip.add(Component.translatable("gui.aestheticjobs.supplier.in_order", qty[i], qty[i] * p.packSize()));
                }
                tip.add(Component.translatable("gui.aestheticjobs.supplier.have", have(p.item())));
            }
        }

        long total = total();
        int by = barY();
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.supplier.total", Money.format(total)), left + 12, by + 3, Ui.INK);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.supplier.packs", totalPacks(), DeliveryService.MAX_PACKS_TOTAL),
                left + 12, by + 14, Ui.LABEL);
        boolean can = total > 0 && totalPacks() <= DeliveryService.MAX_PACKS_TOTAL;
        Ui.button(g, font, clearX(), by, 88, 22, Component.translatable("gui.aestheticjobs.supplier.clear"),
                Ui.in(mx, my, clearX(), by, 88, 22), total > 0, 0);
        Ui.button(g, font, buyX(), by, 88, 22, Component.translatable("gui.aestheticjobs.supplier.order"),
                Ui.in(mx, my, buyX(), by, 88, 22), can, 1);

        if (tip != null) g.renderComponentTooltip(font, tip, mx, my);
    }

    // ------------------------------------------------------------------ input
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (int t = 0; t < 2; t++) {
            if (Ui.in(mx, my, tabX(t), top + 32, 120, 16)) {
                tab = t;
                return true;
            }
        }
        List<Integer> list = shown();
        for (int k = 0; k < list.size(); k++) {
            if (!Ui.in(mx, my, cardX(k), cardY(k), cardW(), cardH())) continue;
            int i = list.get(k);
            int step = hasShiftDown() ? 5 : 1;
            int delta = button == 0 ? step : button == 1 ? -step : 0;
            qty[i] = Math.max(0, Math.min(DeliveryService.MAX_PACKS_PER_LINE, qty[i] + delta));
            return true;
        }
        int by = barY();
        if (Ui.in(mx, my, clearX(), by, 88, 22)) {
            java.util.Arrays.fill(qty, 0);
            return true;
        }
        if (Ui.in(mx, my, buyX(), by, 88, 22) && total() > 0 && totalPacks() <= DeliveryService.MAX_PACKS_TOTAL) {
            List<Integer> packs = new ArrayList<>();
            for (int q : qty) packs.add(q);
            PacketDistributor.sendToServer(new DeliveryOrderPayload(pos, packs));
            onClose();
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }
}
