package dev.aestheticjobs.client;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.menu.AtmMenu;
import dev.aestheticjobs.registry.ModSounds;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.world.entity.player.Inventory;

/**
 * Terminal screen. The texture has 2x density: 1 GUI pixel = 2x2 texture pixels (see docs/gui_layout.md).
 * The PIN keypad is drawn by code on top of the display; the keyboard works too (digits, Backspace, Enter).
 */
public class AtmScreen extends AbstractContainerScreen<AtmMenu> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "textures/gui/atm.png");
    private static final int TEX = 512;

    private static final int COLOR_TEXT = 0xFF5C4234;
    private static final int COLOR_LABEL = 0xFF7A5C48;
    private static final int COLOR_HEADER = 0xFF402C24;
    private static final int COLOR_BUTTON = 0xFF402C24;
    private static final int COLOR_BUTTON_OFF = 0xFF9A8A70;
    private static final int COLOR_CHIP = 0xFFE0A030;

    private static final String[] CHIP_LABELS = {"1", "2", "5", "10", "20", "50", "100"};
    private static final int[] CHIP_X = new int[CHIP_LABELS.length];
    private static final int[] CHIP_W = new int[CHIP_LABELS.length];
    private static final int CHIP_Y = 74;
    private static final int CHIP_H = 9;

    // PIN keypad geometry (GUI pixels, relative to the window)
    private static final int PAD_X = 48, PAD_Y = 31, PAD_W = 80, PAD_H = 53;
    private static final int LCD_X = 52, LCD_Y = 33, LCD_W = 72, LCD_H = 9;
    private static final int KEY_X0 = 59, KEY_Y0 = 44, KEY_W = 18, KEY_H = 9, KEY_DX = 20, KEY_DY = 10;
    private static final String[] KEYS = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "OK"};
    private static final int KEY_CLEAR = 9;
    private static final int KEY_OK = 11;

    static {
        int total = CHIP_LABELS.length - 1;
        for (int i = 0; i < CHIP_LABELS.length; i++) {
            CHIP_W[i] = CHIP_LABELS[i].length() * 4 - 1 + 4;
            total += CHIP_W[i];
        }
        int x = 48 + (80 - total) / 2;
        for (int i = 0; i < CHIP_LABELS.length; i++) {
            CHIP_X[i] = x;
            x += CHIP_W[i] + 1;
        }
    }

    private SpriteButton cancelButton;
    private SpriteButton confirmButton;
    private SpriteTab depositTab;
    private SpriteTab withdrawTab;
    private double shownCents;

    // PIN entry state (client only, the PIN leaves this screen only when OK is pressed)
    private final StringBuilder typed = new StringBuilder();
    private String firstPin;
    private int lastAccess = -1;
    private long mismatchUntil;
    private int pressedKey = -1;
    private long pressedUntil;

    public AtmScreen(AtmMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176;
        this.imageHeight = 206;
    }

    @Override
    protected void init() {
        super.init();
        depositTab = addRenderableWidget(new SpriteTab(leftPos + 58, topPos + 3,
                Component.translatable("gui.aestheticjobs.atm.tab.deposit"), b -> click(AtmMenu.BUTTON_MODE_DEPOSIT)));
        withdrawTab = addRenderableWidget(new SpriteTab(leftPos + 104, topPos + 3,
                Component.translatable("gui.aestheticjobs.atm.tab.withdraw"), b -> click(AtmMenu.BUTTON_MODE_WITHDRAW)));
        cancelButton = addRenderableWidget(new SpriteButton(leftPos + 8, topPos + 89,
                Component.translatable("gui.aestheticjobs.atm.cancel"), b -> click(AtmMenu.BUTTON_CANCEL), 0));
        confirmButton = addRenderableWidget(new SpriteButton(leftPos + 96, topPos + 89,
                Component.translatable("gui.aestheticjobs.atm.deposit"), b -> click(AtmMenu.BUTTON_CONFIRM), 112));
    }

    private void click(int buttonId) {
        if (minecraft != null && minecraft.gameMode != null) {
            minecraft.gameMode.handleInventoryButtonClick(menu.containerId, buttonId);
        }
    }

    private boolean withdrawMode() {
        return menu.getMode() == AtmMenu.MODE_WITHDRAW;
    }

    private boolean padVisible() {
        int a = menu.getAccess();
        return withdrawMode() && (a == AtmMenu.ACCESS_SET_PIN || a == AtmMenu.ACCESS_ENTER_PIN);
    }

    /** The display is covered by the keypad or by a notice (card blocked / owner has no PIN). */
    private boolean coverVisible() {
        int a = menu.getAccess();
        return withdrawMode() && (a == AtmMenu.ACCESS_SET_PIN || a == AtmMenu.ACCESS_ENTER_PIN
                || a == AtmMenu.ACCESS_LOCKED || a == AtmMenu.ACCESS_NO_PIN);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        int access = menu.getAccess();
        if (access != lastAccess || !withdrawMode()) {
            if (access != lastAccess) {
                typed.setLength(0);
                firstPin = null;
            }
            lastAccess = access;
        }
        boolean withdraw = withdrawMode();
        boolean hasSum = menu.getPending() > 0;
        boolean busy = menu.isDispensing();
        cancelButton.active = hasSum && !busy;
        confirmButton.setMessage(Component.translatable(withdraw ? "gui.aestheticjobs.atm.withdraw" : "gui.aestheticjobs.atm.deposit"));
        confirmButton.active = hasSum && !busy && (withdraw ? access == AtmMenu.ACCESS_UNLOCKED : menu.isCardReady());
        depositTab.selected = !withdraw;
        withdrawTab.selected = withdraw;
        depositTab.active = !busy;
        withdrawTab.active = !busy;
        super.render(g, mouseX, mouseY, partialTick);
        renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        g.blit(TEXTURE, leftPos, topPos, imageWidth, imageHeight, 0, 0, imageWidth * 2, imageHeight * 2, TEX, TEX);

        int status = menu.getStatus();
        boolean withdraw = withdrawMode();
        boolean trayHasCash = menu.getSlot(AtmMenu.BILL_SLOT).hasItem();
        if (withdraw) {
            if (status != AtmMenu.STATUS_CARD) pulseGlow(g, 18, 38);                        // hint: put a card here
            if (menu.isDispensing() || trayHasCash) pulseGlow(g, 140, 38);                   // cash is in the tray
        } else {
            if (status == AtmMenu.STATUS_NO_CARD) pulseGlow(g, 18, 38);
            if (menu.isCardReady()) {
                g.blit(TEXTURE, leftPos + 145, topPos + 57, 8, 7, 360, 232, 16, 14, TEX, TEX);   // lit arrow
                g.blit(TEXTURE, leftPos + 160, topPos + 36, 3, 3, 360, 250, 6, 6, TEX, TEX);     // ready light
                pulseGlow(g, 140, 38);                                                           // hint: put bills here
            }
        }
        if (coverVisible()) {
            g.fill(leftPos + PAD_X, topPos + PAD_Y, leftPos + PAD_X + PAD_W, topPos + PAD_Y + PAD_H, 0xFFFCF0D6);
            g.renderOutline(leftPos + PAD_X, topPos + PAD_Y, PAD_W, PAD_H, 0xFFEBDDBA);
            if (padVisible()) drawPad(g, mouseX, mouseY);
        } else {
            for (int i = 0; i < CHIP_LABELS.length; i++) {
                if (menu.getBillCount(i) > 0) {
                    g.renderOutline(leftPos + CHIP_X[i] - 1, topPos + CHIP_Y - 1, CHIP_W[i] + 2, CHIP_H + 2, COLOR_CHIP);
                }
            }
        }
    }

    // ---------------- PIN keypad ----------------

    private int keyAt(double mouseX, double mouseY) {
        double mx = mouseX - leftPos;
        double my = mouseY - topPos;
        for (int i = 0; i < KEYS.length; i++) {
            int x = KEY_X0 + (i % 3) * KEY_DX;
            int y = KEY_Y0 + (i / 3) * KEY_DY;
            if (mx >= x && mx < x + KEY_W && my >= y && my < y + KEY_H) return i;
        }
        return -1;
    }

    private void drawPad(GuiGraphics g, int mouseX, int mouseY) {
        // display with four dots
        int lx = leftPos + LCD_X, ly = topPos + LCD_Y;
        g.fill(lx, ly, lx + LCD_W, ly + LCD_H, 0xFFC9B88E);
        g.fill(lx + 1, ly + 1, lx + LCD_W - 1, ly + LCD_H - 1, 0xFFD7E4CF);
        for (int i = 0; i < 4; i++) {
            int dx = lx + 20 + i * 9;
            int dy = ly + 2;
            if (i < typed.length()) {
                g.fill(dx, dy, dx + 5, dy + 5, 0xFF5C4234);
            } else {
                g.renderOutline(dx, dy, 5, 5, 0xFF9FB09A);
            }
        }
        int hovered = keyAt(mouseX, mouseY);
        long now = System.currentTimeMillis();
        for (int i = 0; i < KEYS.length; i++) {
            int x = leftPos + KEY_X0 + (i % 3) * KEY_DX;
            int y = topPos + KEY_Y0 + (i / 3) * KEY_DY;
            boolean pressed = i == pressedKey && now < pressedUntil;
            boolean hover = i == hovered;
            int border, base;
            if (i == KEY_CLEAR) {
                border = 0xFFC98468;
                base = pressed ? 0xFFD49A80 : hover ? 0xFFF2C4AE : 0xFFE8B096;
            } else if (i == KEY_OK) {
                boolean ready = typed.length() == 4;
                border = ready ? 0xFF7C9E6C : 0xFFBFAE90;
                base = !ready ? 0xFFDDD3BC : pressed ? 0xFF93AE82 : hover ? 0xFFC4DAB2 : 0xFFAAC496;
            } else {
                border = 0xFFA8946C;
                base = pressed ? 0xFFD4C08C : hover ? 0xFFF6EAC8 : 0xFFE9D9B0;
            }
            g.fill(x, y, x + KEY_W, y + KEY_H, border);
            g.fill(x + 1, y + 1, x + KEY_W - 1, y + KEY_H - 1, base);
            g.drawString(font, KEYS[i], x + KEY_W / 2 - font.width(KEYS[i]) / 2, y + 1 + (pressed ? 1 : 0), COLOR_TEXT, false);
        }
    }

    private void padSound(float pitch) {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.KEY.get(), pitch));
    }

    private void typeDigit(int digit) {
        if (typed.length() < 4) {
            typed.append(digit);
            padSound(0.9F + digit * 0.04F);
        }
    }

    private void backspace() {
        if (typed.length() > 0) {
            typed.setLength(typed.length() - 1);
            padSound(0.8F);
        }
    }

    private void submit() {
        if (typed.length() != 4) return;
        int access = menu.getAccess();
        String entry = typed.toString();
        int value = Integer.parseInt(entry);
        padSound(1.3F);
        if (access == AtmMenu.ACCESS_ENTER_PIN) {
            click(AtmMenu.BUTTON_PIN_ENTER_BASE + value);
            typed.setLength(0);
        } else if (access == AtmMenu.ACCESS_SET_PIN) {
            if (firstPin == null) {
                firstPin = entry;                  // first time: remember, ask to repeat
                typed.setLength(0);
            } else if (firstPin.equals(entry)) {
                click(AtmMenu.BUTTON_PIN_SET_BASE + value);
                typed.setLength(0);
                firstPin = null;
            } else {
                firstPin = null;                   // the two entries differ: start over
                typed.setLength(0);
                mismatchUntil = System.currentTimeMillis() + 1500;
            }
        }
    }

    private void pressKey(int i) {
        pressedKey = i;
        pressedUntil = System.currentTimeMillis() + 110;
        if (i == KEY_OK) {
            submit();
        } else if (i == KEY_CLEAR) {
            if (typed.length() > 0) padSound(0.8F);
            typed.setLength(0);
        } else {
            typeDigit(Integer.parseInt(KEYS[i]));
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (padVisible()) {
            if (keyCode >= 48 && keyCode <= 57) {          // 0-9
                typeDigit(keyCode - 48);
                return true;
            }
            if (keyCode >= 320 && keyCode <= 329) {        // numpad 0-9
                typeDigit(keyCode - 320);
                return true;
            }
            if (keyCode == 259) {                          // Backspace
                backspace();
                return true;
            }
            if (keyCode == 257 || keyCode == 335) {        // Enter
                submit();
                return true;
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    // ---------------- drawing helpers ----------------

    private void glow(GuiGraphics g, int x, int y) {
        g.blit(TEXTURE, leftPos + x, topPos + y, 18, 18, 360, 260, 36, 36, TEX, TEX);
    }

    /** A slow pulse, like the lit slot of a real machine. */
    private void pulseGlow(GuiGraphics g, int x, int y) {
        float alpha = 0.55F + 0.45F * (float) Math.sin(System.currentTimeMillis() / 220.0);
        g.setColor(1.0F, 1.0F, 1.0F, alpha);
        glow(g, x, y);
        g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        int status = menu.getStatus();
        int access = menu.getAccess();
        boolean withdraw = withdrawMode();
        text(g, Component.translatable("gui.aestheticjobs.atm.title"), 8, 5, COLOR_TEXT);

        String headerKey;
        if (status == AtmMenu.STATUS_NO_CARD) {
            headerKey = "gui.aestheticjobs.atm.header.insert_card";
        } else if (status == AtmMenu.STATUS_BLANK_CARD) {
            headerKey = "gui.aestheticjobs.atm.header.blank_card";
        } else if (withdraw) {
            if (access == AtmMenu.ACCESS_SET_PIN) {
                if (System.currentTimeMillis() < mismatchUntil) headerKey = "gui.aestheticjobs.atm.pin.mismatch";
                else headerKey = firstPin == null ? "gui.aestheticjobs.atm.pin.set" : "gui.aestheticjobs.atm.pin.repeat";
            } else if (access == AtmMenu.ACCESS_ENTER_PIN) {
                headerKey = "gui.aestheticjobs.atm.pin.enter";
            } else if (access == AtmMenu.ACCESS_LOCKED) {
                headerKey = "gui.aestheticjobs.atm.pin.locked";
            } else if (access == AtmMenu.ACCESS_NO_PIN) {
                headerKey = "gui.aestheticjobs.atm.pin.no_pin_header";
            } else if (menu.isDispensing()) {
                headerKey = "gui.aestheticjobs.atm.header.dispensing";
            } else if (menu.getSlot(AtmMenu.BILL_SLOT).hasItem()) {
                headerKey = "gui.aestheticjobs.atm.header.take_cash";
            } else {
                headerKey = "gui.aestheticjobs.atm.header.withdraw";
            }
        } else if (menu.getSlot(AtmMenu.BILL_SLOT).hasItem()) {
            headerKey = "gui.aestheticjobs.atm.header.counting";
        } else {
            headerKey = "gui.aestheticjobs.atm.header.ready";
        }
        text(g, Component.translatable(headerKey), 19, 20, COLOR_HEADER);

        centered(g, Component.translatable("gui.aestheticjobs.atm.card"), 27, 62, COLOR_LABEL);
        centered(g, Component.translatable("gui.aestheticjobs.atm.bills"), 149, 64, COLOR_LABEL);

        if (coverVisible() && !padVisible()) {
            // notice instead of the keypad
            Component notice = access == AtmMenu.ACCESS_LOCKED
                    ? Component.translatable("gui.aestheticjobs.atm.pin.locked_time", (menu.getLockSeconds() + 59) / 60)
                    : Component.translatable("gui.aestheticjobs.atm.pin.no_pin");
            List<FormattedCharSequence> lines = font.split(notice, PAD_W - 8);
            int y = PAD_Y + 12;
            for (FormattedCharSequence line : lines) {
                g.drawString(font, line, PAD_X + 4, y, COLOR_TEXT, false);
                y += 10;
            }
        }
        if (!coverVisible()) {
            text(g, Component.translatable(withdraw ? "gui.aestheticjobs.atm.to_dispense" : "gui.aestheticjobs.atm.deposited"),
                    52, 36, COLOR_LABEL);
            long target = menu.getPending();
            shownCents += (target - shownCents) * 0.25;
            if (Math.abs(target - shownCents) < 1.0) shownCents = target;
            right(g, Component.literal(Money.format(Math.round(shownCents))), 121, 49, COLOR_TEXT);

            text(g, Component.translatable("gui.aestheticjobs.atm.balance"), 52, 63, COLOR_LABEL);
            String balance;
            if (status == AtmMenu.STATUS_CARD) {
                balance = access == AtmMenu.ACCESS_UNLOCKED ? Money.format(menu.getBalance()) : "$***";
            } else {
                balance = "\u2014";
            }
            right(g, Component.literal(balance), 124, 63, COLOR_TEXT);
        }

        text(g, playerInventoryTitle, 8, 113, COLOR_TEXT);
    }

    private int chipAt(double mouseX, double mouseY) {
        if (coverVisible()) return -1;
        double mx = mouseX - leftPos;
        double my = mouseY - topPos;
        for (int i = 0; i < CHIP_LABELS.length; i++) {
            if (mx >= CHIP_X[i] && mx < CHIP_X[i] + CHIP_W[i] && my >= CHIP_Y && my < CHIP_Y + CHIP_H) return i;
        }
        return -1;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (padVisible() && button == 0) {
            int key = keyAt(mouseX, mouseY);
            if (key >= 0) {
                pressKey(key);
                return true;
            }
        }
        if (withdrawMode() && !menu.isDispensing() && (button == 0 || button == 1)) {
            int chip = chipAt(mouseX, mouseY);
            if (chip >= 0) {
                if (button == 1) {
                    click(AtmMenu.BUTTON_REMOVE_BASE + chip);
                } else {
                    click((hasShiftDown() ? AtmMenu.BUTTON_ADD5_BASE : AtmMenu.BUTTON_ADD_BASE) + chip);
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    protected void renderTooltip(GuiGraphics g, int mouseX, int mouseY) {
        super.renderTooltip(g, mouseX, mouseY);
        if (hoveredSlot != null && hoveredSlot.hasItem()) return;
        int chip = chipAt(mouseX, mouseY);
        if (chip < 0) return;
        Component line = Component.literal("$" + CHIP_LABELS[chip] + " \u00d7 " + menu.getBillCount(chip));
        if (withdrawMode()) {
            g.renderComponentTooltip(font, List.of(line, Component.translatable("gui.aestheticjobs.atm.hint.chip")), mouseX, mouseY);
        } else {
            g.renderTooltip(font, line, mouseX, mouseY);
        }
    }

    private void text(GuiGraphics g, Component c, int x, int y, int color) {
        g.drawString(font, c, x, y, color, false);
    }

    private void centered(GuiGraphics g, Component c, int centerX, int y, int color) {
        g.drawString(font, c, centerX - font.width(c) / 2, y, color, false);
    }

    private void right(GuiGraphics g, Component c, int rightX, int y, int color) {
        g.drawString(font, c, rightX - font.width(c), y, color, false);
    }

    /** Button drawn from the sprite sheet: 4 states (normal, hover, pressed, disabled) per colour. */
    private static class SpriteButton extends Button {
        private final int baseV;
        private long pressedUntil;

        SpriteButton(int x, int y, Component message, OnPress onPress, int baseV) {
            super(x, y, 72, 14, message, onPress, DEFAULT_NARRATION);
            this.baseV = baseV;
        }

        @Override
        public void playDownSound(SoundManager handler) {
            handler.play(SimpleSoundInstance.forUI(ModSounds.KEY.get(), 0.8F));
        }

        @Override
        public void onPress() {
            pressedUntil = System.currentTimeMillis() + 120;
            super.onPress();
        }

        @Override
        public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            int state;
            if (!active) state = 3;
            else if (System.currentTimeMillis() < pressedUntil) state = 2;
            else if (isHoveredOrFocused()) state = 1;
            else state = 0;
            g.blit(TEXTURE, getX(), getY(), 72, 14, 360, baseV + state * 28, 144, 28, TEX, TEX);
            var font = Minecraft.getInstance().font;
            int textX = getX() + (width - font.width(getMessage())) / 2;
            int textY = getY() + 3 + (state == 2 ? 1 : 0);
            g.drawString(font, getMessage(), textX, textY, active ? COLOR_BUTTON : COLOR_BUTTON_OFF, false);
        }
    }

    /** Mode tab in the title row: 3 sprite states (normal, hover, selected). */
    private static class SpriteTab extends Button {
        boolean selected;

        SpriteTab(int x, int y, Component message, OnPress onPress) {
            super(x, y, 44, 11, message, onPress, DEFAULT_NARRATION);
        }

        @Override
        public void playDownSound(SoundManager handler) {
            handler.play(SimpleSoundInstance.forUI(ModSounds.KEY.get(), 0.7F));
        }

        @Override
        public void renderWidget(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
            int state = selected ? 2 : (isHoveredOrFocused() ? 1 : 0);
            g.blit(TEXTURE, getX(), getY(), 44, 11, 360, 300 + state * 24, 88, 22, TEX, TEX);
            var font = Minecraft.getInstance().font;
            int textX = getX() + (width - font.width(getMessage())) / 2;
            g.drawString(font, getMessage(), textX, getY() + 2, selected ? COLOR_BUTTON : COLOR_LABEL, false);
        }
    }
}
