package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Client -> server: the order of the supplier terminal. packs = number of packs per line of the catalog
 * (cafe/SupplyCatalog). The server checks the block, the list, the limits and the account itself.
 */
public record DeliveryOrderPayload(BlockPos pos, List<Integer> packs) implements CustomPacketPayload {
    public static final Type<DeliveryOrderPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "delivery_order"));

    public static final StreamCodec<RegistryFriendlyByteBuf, DeliveryOrderPayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, DeliveryOrderPayload::pos,
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(128)), DeliveryOrderPayload::packs,
            DeliveryOrderPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
