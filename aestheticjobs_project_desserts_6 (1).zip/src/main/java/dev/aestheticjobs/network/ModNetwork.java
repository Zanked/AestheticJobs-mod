package dev.aestheticjobs.network;

import dev.aestheticjobs.block.CoffeeMachineBlockEntity;
import dev.aestheticjobs.cafe.Art;
import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.CupData;
import dev.aestheticjobs.cafe.DeliveryService;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.job.Shift;
import dev.aestheticjobs.registry.ModBlocks;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.registry.ModItems;
import dev.aestheticjobs.registry.ModSounds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class ModNetwork {
    private ModNetwork() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("2");
        registrar.playToServer(BrewPayload.TYPE, BrewPayload.STREAM_CODEC, ModNetwork::handleBrew);
        registrar.playToServer(MachineStatePayload.TYPE, MachineStatePayload.STREAM_CODEC, ModNetwork::handleMachineState);
        registrar.playToServer(DeliveryOrderPayload.TYPE, DeliveryOrderPayload.STREAM_CODEC, ModNetwork::handleDeliveryOrder);
    }

    private static void handleMachineState(MachineStatePayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        ServerLevel level = player.serverLevel();
        BlockPos pos = payload.pos();
        if (player.distanceToSqr(Vec3.atCenterOf(pos)) > 64.0) return;
        if (!level.isLoaded(pos)) return;
        if (level.getBlockEntity(pos) instanceof CoffeeMachineBlockEntity machine) {
            machine.setState(level, player, payload.phase(), payload.drink(), payload.art());
        }
    }

    private static void handleDeliveryOrder(DeliveryOrderPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        ServerLevel level = player.serverLevel();
        BlockPos pos = payload.pos();
        if (player.distanceToSqr(Vec3.atCenterOf(pos)) > 64.0) return;
        if (!level.isLoaded(pos) || !level.getBlockState(pos).is(ModBlocks.SUPPLIER_TERMINAL.get())) return;
        DeliveryService.place(player, level, pos, payload.packs());
    }

    private static void handleBrew(BrewPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        ServerLevel level = player.serverLevel();
        BlockPos pos = payload.pos();
        if (player.distanceToSqr(Vec3.atCenterOf(pos)) > 64.0) return;
        if (!level.isLoaded(pos) || !level.getBlockState(pos).is(ModBlocks.COFFEE_MACHINE.get())) return;

        Shift.touch(player);
        Drink drink = Drink.byIndex(payload.drink());
        String art = Drink.sanitize(payload.art());
        if (drink == null || art == null) return;
        Step[] steps = drink.steps();
        if (payload.scores().size() != steps.length) return;       // not a valid recipe run

        // supplies: an empty cup and everything the recipe needs
        List<Item> needed = new ArrayList<>();
        needed.add(ModItems.EMPTY_CUP.get());
        for (Drink.Supply s : drink.supplies()) needed.add(s.item());
        for (Item item : needed) {
            if (CafeLogic.count(player, item) < 1) {
                player.displayClientMessage(Component.translatable("cafe.machine.missing", item.getDescription()), true);
                return;
            }
        }
        for (Item item : needed) CafeLogic.takeOne(player, item);

        // quality = weighted average of the steps; the art is scored here from the picture itself
        List<Integer> scores = new ArrayList<>();
        double sum = 0, weights = 0;
        for (int i = 0; i < steps.length; i++) {
            int s = Math.max(0, Math.min(100, payload.scores().get(i)));
            if (steps[i] == Step.POUR) s = Art.score(art);
            scores.add(s);
            sum += s * steps[i].weight();
            weights += steps[i].weight();
        }
        int quality = (int) Math.round(sum / weights);

        ItemStack cup = new ItemStack(ModItems.COFFEE_CUP.get());
        CupData data = new CupData(art, drink.ordinal(), quality, scores);
        cup.set(ModComponents.CUP.get(), data);
        cup.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(drink.modelData()));
        player.getInventory().placeItemBackInInventory(cup);

        if (level.getBlockEntity(pos) instanceof CoffeeMachineBlockEntity machine) machine.reset(level);   // the cup leaves the machine
        level.playSound(null, pos, ModSounds.BARISTA_DING.get(), SoundSource.BLOCKS, 1.0F, 1.0F);
        level.sendParticles(ParticleTypes.CLOUD, pos.getX() + 0.5, pos.getY() + 1.05, pos.getZ() + 0.5, 8, 0.15, 0.05, 0.15, 0.01);
        player.displayClientMessage(Component.translatable("cafe.machine.done",
                drink.displayName(), CupData.starText(data.stars())), true);
    }
}
