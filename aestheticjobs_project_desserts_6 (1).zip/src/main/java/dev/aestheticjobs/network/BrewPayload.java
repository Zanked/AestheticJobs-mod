package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Client -> server: the player finished a drink at a coffee machine.
 * scores = the result (0..100) of every step of the recipe, art = the picture on the surface.
 * The server checks the supplies and the length of the list, and scores the art itself.
 */
public record BrewPayload(BlockPos pos, int drink, List<Integer> scores, String art) implements CustomPacketPayload {
    public static final Type<BrewPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "brew"));

    public static final StreamCodec<RegistryFriendlyByteBuf, BrewPayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, BrewPayload::pos,
            ByteBufCodecs.VAR_INT, BrewPayload::drink,
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(16)), BrewPayload::scores,
            ByteBufCodecs.stringUtf8(300), BrewPayload::art,
            BrewPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
