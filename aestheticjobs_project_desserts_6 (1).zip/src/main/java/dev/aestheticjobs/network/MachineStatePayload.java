package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Client -> server: which phase of the recipe the barista is in at a coffee machine (0 = idle, see
 * CoffeeMachineBlockEntity). Sent when the phase changes and every 2 s as a heartbeat.
 * art = the finished picture (only in the last phase, the machine shows it on the cup).
 */
public record MachineStatePayload(BlockPos pos, int phase, int drink, String art) implements CustomPacketPayload {
    public static final Type<MachineStatePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "machine_state"));

    public static final StreamCodec<RegistryFriendlyByteBuf, MachineStatePayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, MachineStatePayload::pos,
            ByteBufCodecs.VAR_INT, MachineStatePayload::phase,
            ByteBufCodecs.VAR_INT, MachineStatePayload::drink,
            ByteBufCodecs.stringUtf8(300), MachineStatePayload::art,
            MachineStatePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
