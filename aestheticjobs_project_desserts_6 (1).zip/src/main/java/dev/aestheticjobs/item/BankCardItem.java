package dev.aestheticjobs.item;

import dev.aestheticjobs.registry.ModComponents;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * A blank card is activated by right-clicking it: it becomes bound to that player's account.
 * The account itself lives in the bank; the card only says whose account it is.
 */
public class BankCardItem extends Item {
    public BankCardItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (stack.get(ModComponents.CARD_OWNER.get()) != null) {
            return InteractionResultHolder.pass(stack);
        }
        if (!level.isClientSide) {
            stack.set(ModComponents.CARD_OWNER.get(), new CardOwner(player.getUUID(), player.getGameProfile().getName()));
            player.displayClientMessage(Component.translatable("item.aestheticjobs.bank_card.bound"), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        CardOwner owner = stack.get(ModComponents.CARD_OWNER.get());
        if (owner == null) {
            tooltip.add(Component.translatable("item.aestheticjobs.bank_card.blank").withStyle(ChatFormatting.GRAY));
        } else {
            tooltip.add(Component.translatable("item.aestheticjobs.bank_card.owner", owner.name()).withStyle(ChatFormatting.GRAY));
            tooltip.add(Component.translatable("item.aestheticjobs.bank_card.number", owner.shortNumber()).withStyle(ChatFormatting.DARK_GRAY));
        }
    }
}
