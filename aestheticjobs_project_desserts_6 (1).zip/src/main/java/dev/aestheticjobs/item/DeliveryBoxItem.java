package dev.aestheticjobs.item;

import dev.aestheticjobs.registry.ModItems;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.ItemContainerContents;
import net.minecraft.world.level.Level;

/** What the courier leaves: a box with the ordered goods. Right-click unpacks everything into the inventory. */
public class DeliveryBoxItem extends Item {
    public DeliveryBoxItem(Item.Properties properties) {
        super(properties);
    }

    public static ItemStack pack(List<ItemStack> contents) {
        ItemStack box = new ItemStack(ModItems.DELIVERY_BOX.get());
        box.set(DataComponents.CONTAINER, ItemContainerContents.fromItems(contents));
        return box;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack box = player.getItemInHand(hand);
        ItemContainerContents contents = box.get(DataComponents.CONTAINER);
        if (contents == null) return InteractionResultHolder.pass(box);
        if (!level.isClientSide) {
            for (ItemStack s : contents.nonEmptyItems()) {
                player.getInventory().placeItemBackInInventory(s.copy());
            }
            box.shrink(1);
            level.playSound(null, player.blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.6F, 0.8F);
        }
        return InteractionResultHolder.sidedSuccess(box, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        ItemContainerContents contents = stack.get(DataComponents.CONTAINER);
        if (contents == null) return;
        Map<Item, Integer> sum = new LinkedHashMap<>();
        for (ItemStack s : contents.nonEmptyItems()) sum.merge(s.getItem(), s.getCount(), Integer::sum);
        int shown = 0;
        for (Map.Entry<Item, Integer> e : sum.entrySet()) {
            if (shown++ >= 12) {
                tooltip.add(Component.literal("  ...").withStyle(ChatFormatting.DARK_GRAY));
                break;
            }
            tooltip.add(Component.literal("  • ").append(e.getKey().getDescription())
                    .append(" ×" + e.getValue()).withStyle(ChatFormatting.GRAY));
        }
        tooltip.add(Component.translatable("cafe.supplier.box_hint").withStyle(ChatFormatting.DARK_GRAY));
    }
}
