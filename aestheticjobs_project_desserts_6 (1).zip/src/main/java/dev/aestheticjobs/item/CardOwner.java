package dev.aestheticjobs.item;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

/** Who a bank card belongs to. Stored on the card as a data component. */
public record CardOwner(UUID id, String name) {
    public static final Codec<CardOwner> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            UUIDUtil.CODEC.fieldOf("id").forGetter(CardOwner::id),
            Codec.STRING.fieldOf("name").forGetter(CardOwner::name)
    ).apply(instance, CardOwner::new));

    public static final StreamCodec<ByteBuf, CardOwner> STREAM_CODEC = StreamCodec.composite(
            UUIDUtil.STREAM_CODEC, CardOwner::id,
            ByteBufCodecs.STRING_UTF8, CardOwner::name,
            CardOwner::new);

    /** Last 4 hex digits of the account id, shown on the card like a card number. */
    public String shortNumber() {
        return String.format("%04X", id.getLeastSignificantBits() & 0xFFFFL);
    }
}
