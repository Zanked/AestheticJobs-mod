package dev.aestheticjobs.economy;

import java.util.Locale;

public final class Money {
    private Money() {}

    /** 123456 -> "$1,234.56" */
    public static String format(long cents) {
        long abs = Math.abs(cents);
        String s = String.format(Locale.US, "$%,d.%02d", abs / 100, abs % 100);
        return cents < 0 ? "-" + s : s;
    }
}
