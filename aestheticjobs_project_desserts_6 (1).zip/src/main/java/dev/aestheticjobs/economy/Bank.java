package dev.aestheticjobs.economy;

import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.server.MinecraftServer;

/**
 * Public bank API. Call only on the server thread. Amounts are cents.
 * Shops, salaries and the terminal menu all go through these methods.
 */
public final class Bank {
    /** $100 billion in cents: keeps every sum far from long overflow. */
    public static final long MAX_BALANCE = 10_000_000_000_000L;

    public static final int PIN_MAX_ATTEMPTS = 3;
    /** The account stays blocked this long after too many wrong PINs. */
    public static final long PIN_LOCK_MS = 10 * 60_000L;

    public enum Result { OK, INVALID_AMOUNT, INSUFFICIENT_FUNDS, LIMIT_EXCEEDED, SAME_ACCOUNT }

    public enum PinResult { OK, WRONG, LOCKED, NO_PIN }

    /** attemptsLeft is meaningful for WRONG, lockSecondsLeft for LOCKED. */
    public record PinOutcome(PinResult result, int attemptsLeft, long lockSecondsLeft) {}

    private Bank() {}

    public static long balance(MinecraftServer server, UUID account) {
        return BankData.get(server).balance(account);
    }

    public static List<Transaction> history(MinecraftServer server, UUID account) {
        return BankData.get(server).history(account);
    }

    public static Result deposit(MinecraftServer server, UUID account, long cents, Transaction.Type type, String reason) {
        return deposit(server, account, cents, type, reason, null);
    }

    /** Same, but records who made the deposit (for example someone paying cash into another player's card). */
    public static Result deposit(MinecraftServer server, UUID account, long cents, Transaction.Type type, String reason,
                                 @Nullable UUID other) {
        if (cents <= 0) return Result.INVALID_AMOUNT;
        BankData data = BankData.get(server);
        if (data.balance(account) > MAX_BALANCE - cents) return Result.LIMIT_EXCEEDED;
        data.change(account, cents, type, reason, other);
        return Result.OK;
    }

    public static Result withdraw(MinecraftServer server, UUID account, long cents, Transaction.Type type, String reason) {
        if (cents <= 0) return Result.INVALID_AMOUNT;
        BankData data = BankData.get(server);
        if (data.balance(account) < cents) return Result.INSUFFICIENT_FUNDS;
        data.change(account, -cents, type, reason, null);
        return Result.OK;
    }

    /** Atomic: either both sides change or nothing does. */
    public static Result transfer(MinecraftServer server, UUID from, UUID to, long cents, String reason) {
        if (cents <= 0) return Result.INVALID_AMOUNT;
        if (from.equals(to)) return Result.SAME_ACCOUNT;
        BankData data = BankData.get(server);
        if (data.balance(from) < cents) return Result.INSUFFICIENT_FUNDS;
        if (data.balance(to) > MAX_BALANCE - cents) return Result.LIMIT_EXCEEDED;
        data.change(from, -cents, Transaction.Type.TRANSFER_OUT, reason, to);
        data.change(to, cents, Transaction.Type.TRANSFER_IN, reason, from);
        return Result.OK;
    }

    // ---------------- PIN ----------------

    public static boolean isValidPin(@Nullable String pin) {
        return pin != null && pin.matches("\\d{4}");
    }

    public static boolean hasPin(MinecraftServer server, UUID account) {
        return BankData.get(server).hasPin(account);
    }

    /** Sets the first PIN of an account. Returns false if the PIN is malformed or one is already set. */
    public static boolean setPin(MinecraftServer server, UUID account, String pin) {
        if (!isValidPin(pin)) return false;
        BankData data = BankData.get(server);
        if (data.hasPin(account)) return false;
        data.setPin(account, pin);
        return true;
    }

    /** Removes the PIN and any block (lost PIN, admin tool). The owner can set a new one at the terminal. */
    public static void resetPin(MinecraftServer server, UUID account) {
        BankData.get(server).clearPin(account);
    }

    /** Counts wrong attempts and blocks the account after PIN_MAX_ATTEMPTS. */
    public static PinOutcome verifyPin(MinecraftServer server, UUID account, String pin) {
        if (!isValidPin(pin)) return new PinOutcome(PinResult.WRONG, 0, 0);
        return BankData.get(server).verifyPin(account, pin, System.currentTimeMillis());
    }

    public static long lockSecondsLeft(MinecraftServer server, UUID account) {
        return BankData.get(server).lockSecondsLeft(account, System.currentTimeMillis());
    }
}
