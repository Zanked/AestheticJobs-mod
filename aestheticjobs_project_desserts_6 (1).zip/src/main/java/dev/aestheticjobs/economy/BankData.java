package dev.aestheticjobs.economy;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Persistent storage of all accounts (world/data/aestheticjobs_bank.dat). Server side only. */
public class BankData extends SavedData {
    public static final String NAME = "aestheticjobs_bank";
    private static final int MAX_HISTORY = 100;

    private static final class Account {
        long balance;
        final List<Transaction> history = new ArrayList<>();
        // PIN: only a salted hash is stored, never the PIN itself
        @Nullable String pinHash;
        @Nullable String pinSalt;
        int pinFailed;
        long pinLockedUntil;
    }

    private final Map<UUID, Account> accounts = new HashMap<>();

    public static BankData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(factory(), NAME);
    }

    public static SavedData.Factory<BankData> factory() {
        return new SavedData.Factory<>(BankData::new, BankData::load, null);
    }

    public long balance(UUID id) {
        Account a = accounts.get(id);
        return a == null ? 0L : a.balance;
    }

    public List<Transaction> history(UUID id) {
        Account a = accounts.get(id);
        return a == null ? List.of() : Collections.unmodifiableList(a.history);
    }

    /** Raw balance change. All validation happens in {@link Bank}. */
    void change(UUID id, long delta, Transaction.Type type, String reason, @Nullable UUID other) {
        Account a = accounts.computeIfAbsent(id, k -> new Account());
        a.balance += delta;
        a.history.add(new Transaction(System.currentTimeMillis(), type, delta, a.balance, reason, other));
        while (a.history.size() > MAX_HISTORY) a.history.remove(0);
        setDirty();
    }

    // ---------------- PIN ----------------

    boolean hasPin(UUID id) {
        Account a = accounts.get(id);
        return a != null && a.pinHash != null;
    }

    void setPin(UUID id, String pin) {
        Account a = accounts.computeIfAbsent(id, k -> new Account());
        a.pinSalt = newSalt();
        a.pinHash = hash(a.pinSalt, id, pin);
        a.pinFailed = 0;
        a.pinLockedUntil = 0;
        setDirty();
    }

    void clearPin(UUID id) {
        Account a = accounts.get(id);
        if (a == null) return;
        a.pinHash = null;
        a.pinSalt = null;
        a.pinFailed = 0;
        a.pinLockedUntil = 0;
        setDirty();
    }

    long lockSecondsLeft(UUID id, long now) {
        Account a = accounts.get(id);
        if (a == null || a.pinLockedUntil <= now) return 0;
        return (a.pinLockedUntil - now + 999) / 1000;
    }

    Bank.PinOutcome verifyPin(UUID id, String pin, long now) {
        Account a = accounts.get(id);
        if (a == null || a.pinHash == null || a.pinSalt == null) {
            return new Bank.PinOutcome(Bank.PinResult.NO_PIN, 0, 0);
        }
        long lock = lockSecondsLeft(id, now);
        if (lock > 0) return new Bank.PinOutcome(Bank.PinResult.LOCKED, 0, lock);

        boolean match = MessageDigest.isEqual(
                hash(a.pinSalt, id, pin).getBytes(StandardCharsets.UTF_8), a.pinHash.getBytes(StandardCharsets.UTF_8));
        if (match) {
            if (a.pinFailed != 0) {
                a.pinFailed = 0;
                setDirty();
            }
            return new Bank.PinOutcome(Bank.PinResult.OK, Bank.PIN_MAX_ATTEMPTS, 0);
        }
        a.pinFailed++;
        setDirty();
        if (a.pinFailed >= Bank.PIN_MAX_ATTEMPTS) {
            a.pinFailed = 0;
            a.pinLockedUntil = now + Bank.PIN_LOCK_MS;
            return new Bank.PinOutcome(Bank.PinResult.LOCKED, 0, lockSecondsLeft(id, now));
        }
        return new Bank.PinOutcome(Bank.PinResult.WRONG, Bank.PIN_MAX_ATTEMPTS - a.pinFailed, 0);
    }

    private static String hash(String salt, UUID id, String pin) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(digest.digest((salt + ":" + id + ":" + pin).getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    private static String newSalt() {
        byte[] bytes = new byte[16];
        new SecureRandom().nextBytes(bytes);
        return HexFormat.of().formatHex(bytes);
    }

    // ---------------- persistence ----------------

    public static BankData load(CompoundTag tag, HolderLookup.Provider registries) {
        BankData data = new BankData();
        ListTag list = tag.getList("accounts", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            Account a = new Account();
            a.balance = t.getLong("balance");
            ListTag hist = t.getList("history", Tag.TAG_COMPOUND);
            for (int j = 0; j < hist.size(); j++) a.history.add(Transaction.fromTag(hist.getCompound(j)));
            if (t.contains("pinHash") && t.contains("pinSalt")) {
                a.pinHash = t.getString("pinHash");
                a.pinSalt = t.getString("pinSalt");
            }
            a.pinFailed = t.getInt("pinFailed");
            a.pinLockedUntil = t.getLong("pinLockedUntil");
            data.accounts.put(t.getUUID("id"), a);
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        for (Map.Entry<UUID, Account> e : accounts.entrySet()) {
            Account a = e.getValue();
            CompoundTag t = new CompoundTag();
            t.putUUID("id", e.getKey());
            t.putLong("balance", a.balance);
            ListTag hist = new ListTag();
            for (Transaction tr : a.history) hist.add(tr.toTag());
            t.put("history", hist);
            if (a.pinHash != null && a.pinSalt != null) {
                t.putString("pinHash", a.pinHash);
                t.putString("pinSalt", a.pinSalt);
            }
            t.putInt("pinFailed", a.pinFailed);
            t.putLong("pinLockedUntil", a.pinLockedUntil);
            list.add(t);
        }
        tag.put("accounts", list);
        return tag;
    }
}
