package dev.aestheticjobs.economy;

import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

/** Every circulating US coin and bill. Values are in cents. */
public enum Denomination {
    PENNY("coin_penny", 1, false),
    NICKEL("coin_nickel", 5, false),
    DIME("coin_dime", 10, false),
    QUARTER("coin_quarter", 25, false),
    HALF_DOLLAR("coin_half_dollar", 50, false),
    DOLLAR_COIN("coin_dollar", 100, false),
    BILL_1("bill_1", 100, true),
    BILL_2("bill_2", 200, true),
    BILL_5("bill_5", 500, true),
    BILL_10("bill_10", 1000, true),
    BILL_20("bill_20", 2000, true),
    BILL_50("bill_50", 5000, true),
    BILL_100("bill_100", 10000, true);

    /** Largest value first; for equal value the bill comes before the coin. */
    private static final List<Denomination> DESCENDING = Stream.of(values())
            .sorted(Comparator.comparingLong(Denomination::cents).reversed()
                    .thenComparing(d -> !d.bill))
            .toList();

    private final String id;
    private final long cents;
    private final boolean bill;

    Denomination(String id, long cents, boolean bill) {
        this.id = id;
        this.cents = cents;
        this.bill = bill;
    }

    public String id() { return id; }
    public long cents() { return cents; }
    public boolean isBill() { return bill; }

    /**
     * Greedy change-making (optimal for the US system). With billsOnly the remainder
     * smaller than the smallest bill is left out, so check sum(result) == cents if it matters.
     */
    public static Map<Denomination, Integer> breakdown(long cents, boolean billsOnly) {
        Map<Denomination, Integer> result = new EnumMap<>(Denomination.class);
        long rest = cents;
        for (Denomination d : DESCENDING) {
            if (billsOnly && !d.bill) continue;
            long n = rest / d.cents;
            if (n > 0) {
                result.put(d, (int) n);
                rest -= n * d.cents;
            }
        }
        return result;
    }
}
