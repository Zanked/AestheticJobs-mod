package dev.aestheticjobs.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import dev.aestheticjobs.economy.Bank;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.economy.Transaction;
import dev.aestheticjobs.item.CardOwner;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.registry.ModItems;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * /bank balance [player]      - show balance (other players: ops only)
 * /bank history               - last transactions
 * /bank card [player]         - ops: give an activated card
 * /bank pin reset <player>    - ops: remove a lost PIN (the owner sets a new one at the terminal)
 * /bank pay <player> <usd>    - transfer to another player
 * /bank give <player> <usd>   - ops: add money
 * /bank take <player> <usd>   - ops: remove money
 */
public final class BankCommands {
    private static final double MAX_ARG = 1_000_000_000.0;

    private BankCommands() {}

    public static void register(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("bank")
                .then(Commands.literal("balance")
                        .executes(c -> balance(c.getSource(), c.getSource().getPlayerOrException()))
                        .then(Commands.argument("player", EntityArgument.player())
                                .requires(s -> s.hasPermission(2))
                                .executes(c -> balance(c.getSource(), EntityArgument.getPlayer(c, "player")))))
                .then(Commands.literal("history")
                        .executes(c -> history(c.getSource())))
                .then(Commands.literal("card")
                        .requires(s -> s.hasPermission(2))
                        .executes(c -> card(c.getSource(), c.getSource().getPlayerOrException()))
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(c -> card(c.getSource(), EntityArgument.getPlayer(c, "player")))))
                .then(Commands.literal("pin")
                        .requires(s -> s.hasPermission(2))
                        .then(Commands.literal("reset")
                                .then(Commands.argument("player", EntityArgument.player())
                                        .executes(c -> pinReset(c.getSource(), EntityArgument.getPlayer(c, "player"))))))
                .then(Commands.literal("pay")
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("amount", DoubleArgumentType.doubleArg(0.01, MAX_ARG))
                                        .executes(c -> pay(c.getSource(), EntityArgument.getPlayer(c, "player"),
                                                toCents(DoubleArgumentType.getDouble(c, "amount")))))))
                .then(Commands.literal("give")
                        .requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("amount", DoubleArgumentType.doubleArg(0.01, MAX_ARG))
                                        .executes(c -> give(c.getSource(), EntityArgument.getPlayer(c, "player"),
                                                toCents(DoubleArgumentType.getDouble(c, "amount")))))))
                .then(Commands.literal("take")
                        .requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("amount", DoubleArgumentType.doubleArg(0.01, MAX_ARG))
                                        .executes(c -> take(c.getSource(), EntityArgument.getPlayer(c, "player"),
                                                toCents(DoubleArgumentType.getDouble(c, "amount"))))))));
    }

    private static long toCents(double dollars) {
        return BigDecimal.valueOf(dollars).movePointRight(2).setScale(0, RoundingMode.HALF_UP).longValue();
    }

    private static int balance(CommandSourceStack src, ServerPlayer target) throws CommandSyntaxException {
        String money = Money.format(Bank.balance(src.getServer(), target.getUUID()));
        if (src.getEntity() == target) {
            src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.balance.self", money), false);
        } else {
            src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.balance.other", target.getDisplayName(), money), false);
        }
        return 1;
    }

    private static int history(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer player = src.getPlayerOrException();
        List<Transaction> list = Bank.history(src.getServer(), player.getUUID());
        if (list.isEmpty()) {
            src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.history.empty"), false);
            return 0;
        }
        src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.history.header"), false);
        int from = Math.max(0, list.size() - 8);
        for (int i = list.size() - 1; i >= from; i--) {
            Transaction t = list.get(i);
            String sign = t.amount() >= 0 ? "+" : "-";
            src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.history.entry",
                    t.type().name().toLowerCase(), sign + Money.format(Math.abs(t.amount())), Money.format(t.balanceAfter())), false);
        }
        return list.size();
    }

    private static int card(CommandSourceStack src, ServerPlayer target) {
        ItemStack stack = new ItemStack(ModItems.BANK_CARD.get());
        stack.set(ModComponents.CARD_OWNER.get(), new CardOwner(target.getUUID(), target.getGameProfile().getName()));
        target.getInventory().placeItemBackInInventory(stack);
        src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.card.given", target.getDisplayName()), true);
        return 1;
    }

    private static int pinReset(CommandSourceStack src, ServerPlayer target) {
        Bank.resetPin(src.getServer(), target.getUUID());
        src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.pin.reset", target.getDisplayName()), true);
        return 1;
    }

    private static int pay(CommandSourceStack src, ServerPlayer to, long cents) throws CommandSyntaxException {
        ServerPlayer from = src.getPlayerOrException();
        Bank.Result r = Bank.transfer(src.getServer(), from.getUUID(), to.getUUID(), cents, "pay");
        switch (r) {
            case OK -> {
                String money = Money.format(cents);
                src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.pay.success", money, to.getDisplayName()), false);
                to.sendSystemMessage(Component.translatable("commands.aestheticjobs.pay.received", money, from.getDisplayName()));
                return 1;
            }
            case INSUFFICIENT_FUNDS -> src.sendFailure(Component.translatable("commands.aestheticjobs.pay.insufficient",
                    Money.format(Bank.balance(src.getServer(), from.getUUID()))));
            case SAME_ACCOUNT -> src.sendFailure(Component.translatable("commands.aestheticjobs.pay.self"));
            default -> src.sendFailure(Component.translatable("commands.aestheticjobs.limit"));
        }
        return 0;
    }

    private static int give(CommandSourceStack src, ServerPlayer target, long cents) {
        Bank.Result r = Bank.deposit(src.getServer(), target.getUUID(), cents, Transaction.Type.ADMIN_GIVE, "admin");
        if (r == Bank.Result.OK) {
            src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.give.success",
                    Money.format(cents), target.getDisplayName()), true);
            return 1;
        }
        src.sendFailure(Component.translatable("commands.aestheticjobs.limit"));
        return 0;
    }

    private static int take(CommandSourceStack src, ServerPlayer target, long cents) {
        Bank.Result r = Bank.withdraw(src.getServer(), target.getUUID(), cents, Transaction.Type.ADMIN_TAKE, "admin");
        if (r == Bank.Result.OK) {
            src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.take.success",
                    Money.format(cents), target.getDisplayName()), true);
            return 1;
        }
        src.sendFailure(Component.translatable("commands.aestheticjobs.take.insufficient",
                target.getDisplayName(), Money.format(Bank.balance(src.getServer(), target.getUUID()))));
        return 0;
    }
}
