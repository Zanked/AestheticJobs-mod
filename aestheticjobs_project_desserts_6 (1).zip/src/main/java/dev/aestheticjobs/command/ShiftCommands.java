package dev.aestheticjobs.command;

import com.mojang.brigadier.CommandDispatcher;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.job.Jobs;
import dev.aestheticjobs.job.Shift;
import java.util.Optional;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * /shift start   - start the shift (same as the badge)
 * /shift end     - end the shift and get paid
 * /shift status  - time on shift and what has been earned so far
 * /shift badge   - get a new work badge (needs a job)
 */
public final class ShiftCommands {
    private ShiftCommands() {}

    public static void register(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("shift")
                .then(Commands.literal("start").executes(c -> toggle(c.getSource().getPlayerOrException(), true)))
                .then(Commands.literal("end").executes(c -> toggle(c.getSource().getPlayerOrException(), false)))
                .then(Commands.literal("status").executes(c -> status(c.getSource(), c.getSource().getPlayerOrException())))
                .then(Commands.literal("badge").executes(c -> badge(c.getSource(), c.getSource().getPlayerOrException()))));
    }

    private static int toggle(ServerPlayer p, boolean start) {
        boolean on = Shift.isOnShift(p.server, p.getUUID());
        if (start == on) {
            p.displayClientMessage(Component.translatable(start ? "shift.already" : "shift.not_on"), true);
            return 0;
        }
        Shift.toggle(p);
        return 1;
    }

    private static int status(CommandSourceStack src, ServerPlayer p) {
        long secs = Shift.shiftSeconds(src.getServer(), p.getUUID());
        if (secs < 0) {
            src.sendSuccess(() -> Component.translatable("shift.not_on"), false);
            return 0;
        }
        Optional<Jobs.Status> st = Jobs.status(src.getServer(), p.getUUID());
        Component job = st.map(s -> s.profession().displayName()).orElse(Component.empty());
        long earned = Shift.earnedCents(src.getServer(), p.getUUID());
        src.sendSuccess(() -> Component.translatable("shift.status", job, Shift.duration(secs), Money.format(earned)), false);
        return 1;
    }

    private static int badge(CommandSourceStack src, ServerPlayer p) {
        if (Jobs.currentProfession(src.getServer(), p.getUUID()).isEmpty()) {
            src.sendFailure(Component.translatable("shift.error.no_job"));
            return 0;
        }
        if (Shift.giveBadgeIfMissing(p)) return 1;
        src.sendFailure(Component.translatable("shift.badge.have"));
        return 0;
    }
}
