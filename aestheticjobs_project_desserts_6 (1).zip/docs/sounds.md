# Звуки терминала

Файлы лежат в `assets/aestheticjobs/sounds/atm/*.ogg` (моно, 44.1 кГц), события описаны в `sounds.json`.
Чтобы заменить звук, подложите свой `.ogg` с тем же именем (ресурспаком или прямо в мод).

| событие             | файл             | когда играет |
|---------------------|------------------|--------------|
| `atm.key`           | key.ogg          | кнопка клавиатуры, вкладка, выбор номинала |
| `atm.pin_ok`        | pin_ok.ogg       | ПИН принят или установлен |
| `atm.pin_fail`      | pin_fail.ogg     | неверный ПИН, блокировка карты |
| `atm.card_insert`   | card_insert.ogg  | карта вставлена |
| `atm.card_eject`    | card_eject.ogg   | карта вернулась |
| `atm.bill_feed`     | bill_feed.ogg    | купюра затянута (тон растёт при счёте) |
| `atm.dispense`      | dispense.ogg     | купюра выдана в лоток |
| `atm.success`       | success.ogg      | операция выполнена |
| `atm.error`         | error.ogg        | ошибка (нет денег, нет ПИН) |

Все звуки синтезированы, скрипт генерации можно переписать под свои тембры.

# Звуки посетителей

Файлы: `assets/aestheticjobs/sounds/cafe/*.ogg` (моно, 44.1 кГц), события `customer.*` в `sounds.json`, субтитры в lang.
Генератор: `python3 tools/gen_cafe_sounds.py` (numpy, scipy, ffmpeg). «Голос» это бормотание из гласных блипов; у всех клиентов
одни и те же файлы, но у каждого свой тон (`getVoicePitch`: Эмма самая низкая, Макс самый высокий).

| событие | файлы | когда играет |
|---|---|---|
| `customer.voice` | voice_1..3 | «здравствуйте» у стойки, иногда сам по себе, пока ждёт |
| `customer.arrive` | arrive | колокольчик, клиент пришёл к кассе |
| `customer.step` | step_1..2 | мягкие шаги |
| `customer.impatient` | impatient | вздох, когда терпение ниже 25% |
| `customer.cup_take` | cup_take | клиент берёт чашку |
| `customer.sip` | sip | глоток |
| `customer.reveal` | reveal | рисунок всплыл над головой |
| `customer.burst` | burst | рисунок рассыпался пикселями (тон растёт со звёздами) |
| `customer.happy` / `ok` / `grumble` | happy, ok, grumble | реакция: 4-5 звёзд / 3 / 1-2 или клиент ушёл обиженным |
| `customer.leave` | leave | клиент уходит |

Ванильных звуков в сущности больше нет.
