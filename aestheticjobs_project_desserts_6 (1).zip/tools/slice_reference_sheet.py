import sys, json
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

SRC = "/mnt/user-data/attachments/debf8771-42e3-5084-b2c8-b81f55e29a6a/197d265e-image.png"
OUT = sys.argv[1]
FIT = 30            # the sprite fits into 30x30 of the 32x32 texture (1px margin)
BG_MIN = 245

NAMES = ["cup_espresso","cup_americano","cup_latte","cup_cappuccino","cup_flat_white","cup_raf","cup_mocha","cup_macchiato",
 "croissant","donut_pink","donut_choc","cupcake_pink","cupcake_choc","muffin_blueberry","cream_puff","eclair",
 "cinnamon_roll","cookie_choc","cookie_heart","gingerbread_man","macaron_pink","macaron_mint","macaron_lemon","cake_pop",
 "cheesecake","cake_strawberry","cake_choc","tiramisu","apple_pie","medovik","brownie","waffle",
 "pancakes","ice_cream_cone","sundae","creme_brulee","panna_cotta","flan","fruit_tart","baklava",
 "empty_cup","coffee_beans","milk_carton","cream_carton","syrup_vanilla","syrup_caramel","chocolate"]

im = Image.open(SRC).convert("RGB")
a = np.asarray(im).astype(np.int32)
fg = a.min(axis=2) < 250
lab, n = ndi.label(ndi.binary_dilation(fg, iterations=6))
objs = ndi.find_objects(lab)
boxes = [(s[0].start, s[1].start, s[0].stop, s[1].stop) for s in objs]
boxes.sort(key=lambda b: (b[0] // 150, b[1]))
assert len(boxes) == len(NAMES) == 47

def sprite(box):
    y0, x0, y1, x1 = box
    p = 6
    crop = a[max(0,y0-p):y1+p, max(0,x0-p):x1+p]
    white = crop.min(axis=2) >= BG_MIN
    lab2, k = ndi.label(white)
    border = set(np.unique(np.concatenate([lab2[0], lab2[-1], lab2[:,0], lab2[:,-1]]))) - {0}
    bg = np.isin(lab2, list(border))
    alpha = (~bg)
    alpha = ndi.binary_opening(alpha, iterations=1) | (alpha & ~ndi.binary_erosion(ndi.binary_dilation(alpha)))
    # keep only the biggest piece plus pieces near it (cake pop stick etc. are connected anyway)
    l3, k3 = ndi.label(ndi.binary_dilation(alpha, iterations=3))
    sizes = ndi.sum(alpha, l3, range(1, k3+1))
    alpha &= (l3 == (1 + int(np.argmax(sizes))))
    ys, xs = np.where(alpha)
    t, b, l, r = ys.min(), ys.max()+1, xs.min(), xs.max()+1
    rgb = crop[t:b, l:r].astype(np.float32)
    al = alpha[t:b, l:r].astype(np.float32)
    return rgb, al

def to32(rgb, al):
    h, w = al.shape
    s = FIT / max(h, w)
    nw, nh = max(1, round(w*s)), max(1, round(h*s))
    # premultiplied box downscale
    pm = np.dstack([rgb * al[..., None], al])
    img = Image.fromarray(np.zeros((1,1,4), np.uint8))  # placeholder
    chans = []
    for c in range(4):
        ch = Image.fromarray(pm[..., c].astype(np.float32), mode="F").resize((nw, nh), Image.BOX)
        chans.append(np.asarray(ch))
    pm2 = np.dstack(chans)
    A = pm2[..., 3]
    col = np.where(A[..., None] > 1e-3, pm2[..., :3] / np.maximum(A[..., None], 1e-3), 0)
    mask = A > 0.5
    out = np.zeros((32, 32, 4), np.uint8)
    ox, oy = (32 - nw) // 2, (32 - nh) // 2 + (1 if nh < 30 else 0)
    oy = min(oy, 32 - nh)
    sub = np.dstack([np.clip(col, 0, 255).astype(np.uint8), (mask * 255).astype(np.uint8)])
    out[oy:oy+nh, ox:ox+nw] = sub
    return finish(Image.fromarray(out, "RGBA"))

from PIL import ImageFilter

def finish(img):
    """Sharper pixel-art look: unsharp mask, a limited palette (no dithering) and a soft dark outline."""
    arr = np.asarray(img).astype(np.float32)
    alpha = arr[..., 3] > 127
    rgb = Image.fromarray(arr[..., :3].astype(np.uint8), "RGB")
    # fill the transparent area with the nearest colour so that the blur does not bleed the black in
    idx = ndi.distance_transform_edt(~alpha, return_distances=False, return_indices=True)
    filled = arr[..., :3][idx[0], idx[1]]
    rgb = Image.fromarray(filled.astype(np.uint8), "RGB").filter(ImageFilter.UnsharpMask(radius=1.0, percent=70, threshold=2))
    q = rgb.quantize(colors=48, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE).convert("RGB")
    col = np.asarray(q).astype(np.float32)
    out = np.zeros((32, 32, 4), np.uint8)
    out[..., :3] = col.astype(np.uint8)
    out[..., 3] = np.where(alpha, 255, 0)
    # outline: transparent pixels next to the sprite get a darkened colour of the neighbour
    grow = ndi.binary_dilation(alpha, structure=np.array([[0,1,0],[1,1,1],[0,1,0]]))
    edge = grow & ~alpha
    for y, x in zip(*np.where(edge)):
        ns = [col[yy, xx] for yy, xx in ((y-1,x),(y+1,x),(y,x-1),(y,x+1)) if 0 <= yy < 32 and 0 <= xx < 32 and alpha[yy, xx]]
        c = np.mean(ns, axis=0) * 0.52
        out[y, x] = [int(c[0]), int(c[1]), int(c[2]), 235]
    return Image.fromarray(out, "RGBA")

import os
os.makedirs(OUT, exist_ok=True)
for name, box in zip(NAMES, boxes):
    rgb, al = sprite(box)
    to32(rgb, al).save(os.path.join(OUT, name + ".png"))
print("done", len(NAMES))
