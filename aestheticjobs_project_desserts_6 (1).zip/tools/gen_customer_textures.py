#!/usr/bin/env python3
"""
Generates the 32x32 textures of the cafe customers (assets/aestheticjobs/textures/entity/).

  customer_0..7.png : skins of the 8 customers (UV layout below)
  bubble.png        : the thought bubble drawn over the head (order / served art)

UV layout of the customer model (32x32):
  head  box 8x8x8  at (0,0)    -> x 0..31, y 0..15
  body  box 6x8x4  at (0,16)   -> x 0..19, y 16..27
  arm   box 2x6x2  at (20,16)  -> x 20..27, y 16..23   (left arm is the mirrored copy)
  leg   box 2x6x2  at (20,24)  -> x 20..27, y 24..31   (left leg is the mirrored copy)

Run:  python3 tools/gen_customer_textures.py   (needs Pillow)
"""
import os
import sys
from PIL import Image

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources",
                       "assets", "aestheticjobs", "textures", "entity")

# ---- pastel palette (matches the pastel item textures) -------------------------
OUT = "#4a3228"
BROWN = "#8a6a58"
COFFEE = "#a47a5e"
CREAM = "#fff6e2"
TAN = "#efe1c2"
KHAKI = "#bfa982"
TERRA = "#e3a08c"
SAGE = "#a9c79a"
GOLD = "#f6d58a"
MUSTARD = "#eec37a"
DUSTY = "#9fbccf"
PLUM = "#b98aa0"


def rgb(h):
    if isinstance(h, tuple):
        return h
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def shade(c, f):
    r, g, b = rgb(c)
    if f >= 1:
        k = f - 1
        r, g, b = (int(v + (255 - v) * k) for v in (r, g, b))
    else:
        r, g, b = (int(v * f) for v in (r, g, b))
    return (max(0, min(255, r)), max(0, min(255, g)), max(0, min(255, b)))


# ---- characters -------------------------------------------------------------
# style: short | long | bob | beanie | beret
CUSTOMERS = [
    dict(name="Emma", skin="#f6d8bc", hair="#c27a56", iris="#7aa07a", style="long", top=TERRA, trim=CREAM,
         bottom="#8a6a58", detail="stripe", dress=False, legs="#8a6a58", sock=None, shoes="#6a4a3a", extra="bow"),
    dict(name="Liam", skin="#eec1a0", hair="#6a4a3a", iris="#6a8fb0", style="short", top=SAGE, trim=TAN,
         bottom="#8a6a58", detail="pocket", dress=False, legs="#8a6a58", sock=None, shoes="#6a4a3a", extra=None),
    dict(name="Sofia", skin="#d9a47e", hair="#4a3830", iris="#5a3a2a", style="long", top=MUSTARD, trim=CREAM,
         bottom=MUSTARD, detail="dress", dress=True, legs="#a8826a", sock=None, shoes="#6a4a3a", extra="earring"),
    dict(name="Noah", skin="#f6d8bc", hair="#f0cd7e", iris="#8fb0c2", style="short", top=DUSTY, trim=CREAM,
         bottom="#7a6a60", detail="hoodie", dress=False, legs="#7a6a60", sock=None, shoes=CREAM, extra="plaster"),
    dict(name="Mia", skin="#fbe3c8", hair="#8e5f45", iris="#8a6a58", style="beret", top=CREAM, trim=TERRA,
         bottom="#8a6a58", detail="buttons", dress=False, legs="#8a6a58", sock=None, shoes="#6a4a3a", extra=None,
         hat=TERRA),
    dict(name="Oliver", skin="#a9714f", hair="#3a2a24", iris="#3a2a24", style="beanie", top=PLUM, trim=TAN,
         bottom="#8a6a58", detail="stripe", dress=False, legs="#8a6a58", sock=None, shoes=CREAM, extra=None,
         hat=MUSTARD),
    dict(name="Lily", skin="#fbe0c6", hair="#e08a4c", iris="#7aa07a", style="bob", top=SAGE, trim=CREAM,
         bottom=SAGE, detail="dress", dress=True, legs="#fbe0c6", sock=CREAM, shoes="#8a6a58", extra="freckles"),
    dict(name="Max", skin="#eec1a0", hair="#5a4a44", iris="#6a4a3a", style="short", top=COFFEE, trim=MUSTARD,
         bottom="#7a6a60", detail="scarf", dress=False, legs="#7a6a60", sock=None, shoes="#4a3228", extra="stubble"),
]


def paint_customer(v):
    im = Image.new("RGBA", (32, 32), (0, 0, 0, 0))

    def put(x, y, c, f=1.0):
        if c is None:
            return
        im.putpixel((x, y), shade(c, f) + (255,))

    def face(x0, y0, w, h, fn, f=1.0):
        for fy in range(h):
            for fx in range(w):
                c = fn(fx, fy)
                if c is not None:
                    put(x0 + fx, y0 + fy, c, f)

    skin = v["skin"]
    hair = v["hair"]
    hat = v.get("hat", hair)
    style = v["style"]

    # ---------------- head ----------------
    def cover_front(fx, fy):
        if style == "short":
            if fy <= 1: return "h"
            if fy == 2 and (fx <= 2 or fx >= 7): return "h"
            if fy == 3 and (fx == 0 or fx == 7): return "h"
        elif style == "long":
            if fy <= 1: return "h"
            if fy == 2 and (fx <= 2 or fx >= 5): return "h"
            if fy >= 3 and (fx == 0 or fx == 7): return "h"
        elif style == "bob":
            if fy <= 1: return "h"
            if fy == 2 and (fx <= 1 or fx >= 6): return "h"
            if 3 <= fy <= 5 and (fx == 0 or fx == 7): return "h"
        elif style == "beanie":
            if fy <= 1: return "a"
            if fy == 2: return "a2"
        elif style == "beret":
            if fy <= 1: return "a"
            if fy == 2 and (fx <= 1 or fx >= 6): return "h"
            if 3 <= fy <= 4 and (fx == 0 or fx == 7): return "h"
        return "s"

    def cover_side(d, fy):
        if style == "short":
            if fy <= 2: return "h"
            if fy <= 4 and d >= 4: return "h"
        elif style == "long":
            return "h"
        elif style == "bob":
            if fy <= 5: return "h"
        elif style == "beanie":
            if fy <= 1: return "a"
            if fy == 2: return "a2"
            if fy <= 4 and d >= 5: return "h"
        elif style == "beret":
            if fy <= 1: return "a"
            if fy <= 3 and d >= 2: return "h"
            if fy <= 5 and d >= 4: return "h"
        return "s"

    def cover_back(fx, fy):
        if style == "short":
            return "h" if fy <= 4 else "s"
        if style == "long":
            return "h"
        if style == "bob":
            return "h" if fy <= 5 else "s"
        if style == "beanie":
            if fy <= 1: return "a"
            if fy == 2: return "a2"
            return "h" if fy <= 4 else "s"
        if style == "beret":
            if fy <= 1: return "a"
            return "h" if fy <= 5 else "s"
        return "s"

    def color_of(code, fx=0, fy=0, face_id=0):
        if code == "h":
            k = (fx * 3 + fy * 5 + face_id * 2) % 7
            if k == 0: return shade(hair, 1.22)             # strand highlight
            if k in (3, 5) and fy >= 3: return shade(hair, 0.84)   # darker strands lower down
            return hair
        if code == "a": return hat
        if code == "a2": return TAN if style == "beanie" else shade(hat, 1.12)
        return skin

    # top (x8..15,y0..7)
    face(8, 0, 8, 8, lambda fx, fy: hat if style in ("beanie", "beret") else hair, 1.0)
    # highlights / parting on the top of the head
    hl = shade(hat if style in ("beanie", "beret") else hair, 1.22)
    for (fx, fy) in ((2, 1), (3, 1), (2, 2), (5, 5)):
        im.putpixel((8 + fx, fy), hl + (255,))
    if style == "beret":                      # the little stalk
        im.putpixel((11, 3), shade(hat, 0.7) + (255,))
        im.putpixel((12, 3), shade(hat, 0.7) + (255,))
    if style == "beanie":                     # knit lines
        for fx in range(0, 8, 2):
            for fy in range(0, 8):
                im.putpixel((8 + fx, fy), shade(hat, 0.9) + (255,))

    # bottom of the head (x16..23,y0..7): neck/chin
    face(16, 0, 8, 8, lambda fx, fy: skin, 0.7)

    # right side (x0..7,y8..15): front edge is on the right (d = 7 - fx)
    face(0, 8, 8, 8, lambda fx, fy: color_of(cover_side(7 - fx, fy), fx, fy, 1), 0.92)
    # left side (x16..23,y8..15): front edge is on the left (d = fx)
    face(16, 8, 8, 8, lambda fx, fy: color_of(cover_side(fx, fy), fx, fy, 2), 0.92)
    # back (x24..31,y8..15)
    face(24, 8, 8, 8, lambda fx, fy: color_of(cover_back(fx, fy), fx, fy, 3), 0.97)
    # hair shine on back/sides
    if style in ("long", "bob", "short"):
        for x in (26, 27):
            im.putpixel((x, 9), shade(hair, 1.18) + (255,))

    # front (x8..15,y8..15)
    face(8, 8, 8, 8, lambda fx, fy: color_of(cover_front(fx, fy), fx, fy, 4), 1.0)
    # beanie band & beret shadow line
    if style == "beanie":
        for fx in range(8):
            im.putpixel((8 + fx, 8 + 2), shade(TAN, 0.95) + (255,))
    # face (only on skin pixels)
    def is_skin(fx, fy):
        return cover_front(fx, fy) == "s"

    eye_c = OUT
    for fx in (2, 5):                                      # eyes: dark lash on top, coloured iris below
        if is_skin(fx, 4): put(8 + fx, 8 + 4, eye_c)
        if is_skin(fx, 5): put(8 + fx, 8 + 5, v["iris"])
    for fx in (2, 5):                                      # brows
        if is_skin(fx, 3): put(8 + fx, 8 + 3, shade(hair, 0.8))
    if is_skin(4, 5): put(8 + 4, 8 + 5, shade(skin, 0.9))   # nose
    for fx in (1, 6):                                      # blush
        if is_skin(fx, 6): put(8 + fx, 8 + 6, "#f2b3a6")
    for fx in (3, 4):                                      # mouth
        put(8 + fx, 8 + 6, "#d98a84")
    put(8 + 3, 8 + 6, "#c4706a")
    if v["extra"] == "plaster":                            # band-aid on the cheek
        put(8 + 5, 8 + 6, "#fff2cf")
        put(8 + 6, 8 + 6, "#efe1c2")
        put(8 + 5, 8 + 7, "#efe1c2")
    if v["extra"] == "bow":                                # a little bow in the hair
        for (fx, fy) in ((5, 1), (6, 1), (6, 0), (7, 1)):
            im.putpixel((8 + fx, 8 + fy), rgb("#f6b8b0") + (255,))
        im.putpixel((8 + 6, 8 + 1), rgb("#fff0ea") + (255,))
    if v["extra"] == "earring":                            # a gold earring on both sides
        im.putpixel((7, 8 + 5), rgb(GOLD) + (255,))
        im.putpixel((16, 8 + 5), rgb(GOLD) + (255,))
    if v["extra"] == "freckles":
        for (fx, fy) in ((1, 5), (2, 6), (5, 6), (6, 5)):
            put(8 + fx, 8 + fy, "#b8663c")
    if v["extra"] == "stubble":
        for (fx, fy) in ((1, 6), (2, 7), (3, 7), (4, 7), (5, 7), (6, 6)):
            put(8 + fx, 8 + fy, "#9c7658")

    # ---------------- body ----------------
    top, trim, bottom = v["top"], v["trim"], v["bottom"]
    dress = v["dress"]
    detail = v["detail"]

    def body_front(fx, fy):
        if fy <= 5:
            if fy == 0 and fx in (2, 3):
                return skin                                   # neck
            if fy == 0 and detail != "scarf":
                return trim                                   # collar
            if detail == "stripe" and fy in (2, 3):
                return trim
            if detail == "pocket" and 3 <= fy <= 5 and 1 <= fx <= 4:
                return shade(top, 0.82)
            if detail == "hoodie":
                if fy in (1, 2) and fx in (2, 3):
                    return CREAM if fy == 2 else top
                if 4 <= fy <= 5 and 1 <= fx <= 4:
                    return shade(top, 0.82)
            if detail == "buttons" and fx == 2 and fy in (2, 4):
                return GOLD
            if detail == "scarf":
                if fy <= 1: return trim
                if fy in (2, 3, 4) and fx in (4, 5): return trim
            if detail == "dress" and fy == 2:
                return trim if fx in (1, 4) else top          # little bow dots
            return top
        if dress:
            return trim if fy == 7 else top
        return bottom

    def body_side(fx, fy):
        if fy <= 5:
            if detail == "scarf" and fy <= 1: return trim
            return top
        if dress:
            return trim if fy == 7 else top
        return bottom

    def body_back(fx, fy):
        if fy <= 5:
            if detail == "hoodie" and fy <= 1: return shade(top, 0.85)   # hood
            if detail == "scarf" and fy <= 1: return trim
            if detail == "stripe" and fy in (2, 3): return trim
            return top
        if dress:
            return trim if fy == 7 else top
        return bottom

    def knit(fn):
        def inner(fx, fy):
            c = fn(fx, fy)
            if c == top and detail != "dress" and (fx + fy) % 2 == 0 and fy > 0:
                return shade(top, 1.07)                         # knit weave
            return c
        return inner
    body_front, body_side, body_back = knit(body_front), knit(body_side), knit(body_back)
    face(4, 16, 6, 4, lambda fx, fy: top, 1.1)                         # top
    face(10, 16, 6, 4, lambda fx, fy: bottom if not dress else top, 0.7)  # bottom
    face(0, 20, 4, 8, body_side, 0.88)                                 # right
    face(4, 20, 6, 8, body_front, 1.0)                                 # front
    face(10, 20, 4, 8, body_side, 0.88)                                # left
    face(14, 20, 6, 8, body_back, 0.95)                                # back

    # ---------------- arms ----------------
    sleeve_rows = 4 if not dress else 2
    cuff = trim if detail in ("stripe", "hoodie") else shade(top, 0.85)

    def arm_fn(fx, fy):
        if fy < sleeve_rows:
            return top
        if fy == sleeve_rows and not dress and sleeve_rows < 5:
            return cuff
        return skin

    face(22, 16, 2, 2, lambda fx, fy: top, 1.1)                        # top
    face(24, 16, 2, 2, lambda fx, fy: skin, 0.7)                       # bottom (hand)
    face(20, 18, 2, 6, arm_fn, 0.88)                                   # right
    face(22, 18, 2, 6, arm_fn, 1.0)                                    # front
    face(24, 18, 2, 6, arm_fn, 0.88)                                   # left
    face(26, 18, 2, 6, arm_fn, 0.95)                                   # back

    # ---------------- legs ----------------
    legs, sock, shoes = v["legs"], v["sock"], v["shoes"]

    def leg_fn(fx, fy):
        if fy == 5: return shoes
        if fy == 4 and sock: return sock
        return legs

    face(22, 24, 2, 2, lambda fx, fy: legs, 1.1)
    face(24, 24, 2, 2, lambda fx, fy: shoes, 0.6)
    face(20, 26, 2, 6, leg_fn, 0.88)
    face(22, 26, 2, 6, leg_fn, 1.0)
    face(24, 26, 2, 6, leg_fn, 0.88)
    face(26, 26, 2, 6, leg_fn, 0.95)
    return im


def paint_bubble():
    im = Image.new("RGBA", (32, 32), (0, 0, 0, 0))

    def put(x, y, c):
        im.putpixel((x, y), rgb(c) + (255,))

    # body of the bubble: x 1..30, y 0..26, rounded corners
    for y in range(0, 27):
        for x in range(1, 31):
            corner = (x in (1, 30) and y in (0, 26))
            if corner:
                continue
            edge = x in (1, 30) or y in (0, 26)
            if edge:
                put(x, y, OUT)
            else:
                put(x, y, CREAM)
    # soften corners: make the pixels next to the cut corners outline as well
    for (x, y) in ((2, 1), (29, 1), (2, 25), (29, 25)):
        put(x, y, OUT)
    # inner shade (bottom + right)
    for x in range(3, 29):
        put(x, 25, TAN)
    for y in range(2, 25):
        put(29, y, TAN)
    # drop shadow row under the bubble
    for x in range(3, 31):
        if im.getpixel((x, 27))[3] == 0:
            im.putpixel((x, 27), rgb(KHAKI) + (255,))
    # saucer behind the cup art (art is drawn at x 8..23, y 3..18)
    cx, cy = 16.0, 11.0
    for y in range(1, 22):
        for x in range(5, 28):
            d = ((x + 0.5 - cx) ** 2 + (y + 0.5 - cy) ** 2) ** 0.5
            if d <= 9.4:
                put(x, y, "#e4d5ae" if d > 8.2 else TAN)
    # track for the patience bar / stars (x 7..24, y 22..24)
    for y in range(22, 25):
        for x in range(7, 25):
            put(x, y, KHAKI)
    # tail: one thought-bubble circle
    for (x, y) in ((15, 28), (16, 28), (14, 29), (17, 29), (14, 30), (17, 30), (15, 31), (16, 31)):
        put(x, y, OUT)
    for (x, y) in ((15, 29), (16, 29), (15, 30), (16, 30)):
        put(x, y, CREAM)
    # the tail circle must not touch the drop-shadow row
    for x in (14, 15, 16, 17):
        im.putpixel((x, 27), (0, 0, 0, 0))
    # pure white pixels used for tinted quads (bar fills). They sit in columns 0 and 31, which the
    # renderer never draws as part of the bubble (the bubble quad covers columns 1..30 only).
    for y in (30, 31):
        for x in (0, 31):
            im.putpixel((x, y), (255, 255, 255, 255))
    return im


def upscale(im, k):
    return im.resize((im.width * k, im.height * k), Image.NEAREST)


def preview(imgs, path):
    """Front and back view of every customer + the bubble, assembled from the UV regions."""
    K = 8
    cell_w, cell_h = 12 * K, 24 * K + 4
    W = cell_w * 8 + 20
    out = Image.new("RGBA", (W, cell_h * 2 + 90 * 1 + 40 + 32 * 4), (58, 52, 48, 255))

    def region(im, box):
        return im.crop(box)

    for i, im in enumerate(imgs):
        for row, (hf, bf, af, lf) in enumerate((
                ((8, 8, 16, 16), (4, 20, 10, 28), (22, 18, 24, 24), (22, 26, 24, 32)),     # front
                ((24, 8, 32, 16), (14, 20, 20, 28), (26, 18, 28, 24), (26, 26, 28, 32)))):  # back
            canvas = Image.new("RGBA", (12, 22), (0, 0, 0, 0))
            canvas.paste(region(im, hf), (2, 0))                 # head 8x8
            canvas.paste(region(im, bf), (3, 8))                 # body 6x8
            arm = region(im, af)
            canvas.paste(arm, (1, 8), arm)                       # right arm (viewer's left on front)
            canvas.paste(arm.transpose(Image.FLIP_LEFT_RIGHT), (9, 8))
            leg = region(im, lf)
            canvas.paste(leg, (3, 16))
            canvas.paste(leg.transpose(Image.FLIP_LEFT_RIGHT), (7, 16))
            out.paste(upscale(canvas, K), (10 + i * cell_w, 10 + row * (22 * K + 14)),
                      upscale(canvas, K))
    b = paint_bubble()
    out.paste(upscale(b, 6), (10, 2 * (22 * K + 14) + 20), upscale(b, 6))
    # all UV sheets, to check the layout
    for i, im in enumerate(imgs[:4]):
        out.paste(upscale(im, 3), (10 + 32 * 6 + 20 + i * (32 * 3 + 8), 2 * (22 * K + 14) + 20),
                  upscale(im, 3))
    out.save(path)


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    imgs = []
    for i, v in enumerate(CUSTOMERS):
        im = paint_customer(v)
        im.save(os.path.join(OUT_DIR, f"customer_{i}.png"))
        imgs.append(im)
    b = paint_bubble()
    b.save(os.path.join(OUT_DIR, "bubble.png"))
    if len(sys.argv) > 1:
        preview(imgs, sys.argv[1])
    print("ok:", len(imgs), "customers + bubble ->", os.path.abspath(OUT_DIR))


if __name__ == "__main__":
    main()
