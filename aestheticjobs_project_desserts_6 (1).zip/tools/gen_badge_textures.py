#!/usr/bin/env python3
"""Work badge item textures (32x32): work_badge.png (off shift) and work_badge_on.png (on shift)."""
import os
from PIL import Image

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources",
                       "assets", "aestheticjobs", "textures", "item")
OUT, CREAM, TAN, KHAKI = "#402c24", "#fcf0d6", "#e9d9b0", "#a8946c"
TERRA, SAGE, SAGE_L, GOLD, GOLD_D = "#c98468", "#7c9e6c", "#b4d59f", "#f1c760", "#a0742c"
SKIN, HAIR, SHADOW = "#ebc9a6", "#5c4234", "#c9bfa8"


def rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) + (255,)


def badge(on):
    im = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    put = lambda x, y, c: im.putpixel((x, y), rgb(c))
    rect = lambda x0, y0, x1, y1, c: [put(x, y, c) for y in range(y0, y1 + 1) for x in range(x0, x1 + 1)]

    X0, X1, Y0, Y1 = 7, 24, 5, 29                       # card outline box
    rect(X0 + 2, Y0 + 2, X1 + 2, Y1 + 1, SHADOW)        # drop shadow
    rect(X0, Y0, X1, Y1, OUT)
    for (x, y) in ((X0, Y0), (X1, Y0), (X0, Y1), (X1, Y1)):
        im.putpixel((x, y), (0, 0, 0, 0))               # rounded corners
    rect(X0 + 1, Y0 + 1, X1 - 1, Y1 - 1, CREAM)
    rect(X0 + 1, Y1 - 1, X1 - 1, Y1 - 1, TAN)           # inner shade
    # clip / lanyard slot
    rect(13, 2, 18, 5, OUT)
    rect(14, 3, 17, 5, GOLD)
    rect(15, 3, 16, 4, GOLD_D)
    rect(15, 6, 16, 6, OUT)
    # photo
    rect(10, 9, 21, 17, OUT)
    rect(11, 10, 20, 16, TERRA if not on else SAGE)
    rect(14, 11, 17, 14, SKIN)                          # face
    rect(14, 11, 17, 11, HAIR)
    rect(13, 12, 13, 13, HAIR); rect(18, 12, 18, 13, HAIR)
    put(14, 13, OUT); put(17, 13, OUT)                  # eyes
    rect(12, 15, 19, 16, CREAM if not on else SAGE_L)   # shoulders
    # text lines
    rect(10, 20, 21, 20, KHAKI)
    rect(10, 22, 17, 22, KHAKI)
    # status band (red-ish/khaki off, green on) with a lamp
    rect(8, 25, 23, 28, OUT)
    rect(9, 26, 22, 27, SAGE if on else KHAKI)
    if on:
        rect(10, 26, 11, 27, SAGE_L)                    # lit lamp
        put(10, 26, CREAM)
        rect(13, 26, 21, 26, SAGE_L)
    else:
        rect(10, 26, 11, 27, TERRA)                     # dim lamp
    return im


if __name__ == "__main__":
    os.makedirs(OUT_DIR, exist_ok=True)
    off, on = badge(False), badge(True)
    off.save(os.path.join(OUT_DIR, "work_badge.png"))
    on.save(os.path.join(OUT_DIR, "work_badge_on.png"))
    bg = Image.new("RGBA", (2 * 264, 264), (58, 52, 48, 255))
    for i, im in enumerate((off, on)):
        u = im.resize((256, 256), Image.NEAREST)
        bg.paste(u, (i * 264 + 4, 4), u)
    bg.save("/home/claude/prev/badges.png")
    print("ok")
