#!/usr/bin/env python3
"""
Pastel 32x32 dessert textures in the style of gen_cafe_items.py -> assets/aestheticjobs/textures/item/

Same recipe as the cafe sprites: dark warm outline, 4-tone ramp per material (shadow / base / light / highlight),
soft drop shadow on the lower right. Reuses Canvas / RAMPS of gen_cafe_items.py.

Run: python3 tools/gen_desserts.py [preview.png]
"""
import math
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from PIL import Image  # noqa: E402
import gen_cafe_items as base  # noqa: E402
from gen_cafe_items import Canvas, RAMPS, INK, rgb  # noqa: E402

RAMPS.update({
    "dough":     ["#c98f55", "#e3ac6e", "#f0c78f", "#f9ddb0"],     # baked pastry
    "golden":    ["#b9763e", "#d89a58", "#ebb978", "#f8d6a2"],     # croissant / crust, a bit darker
    "graham":    ["#b48557", "#cfa575", "#e1c196", "#efd9b6"],
    "ginger":    ["#8a5434", "#a8693f", "#c4864f", "#dba26c"],
    "berry":     ["#c4566a", "#dd7487", "#ef97a5", "#fbc4cc"],     # strawberry / raspberry
    "pink":      ["#e5a0b4", "#f3bccb", "#f9d4de", "#fff0f4"],     # pink glaze
    "mint":      ["#93c4ad", "#b6dcc8", "#d2eee0", "#effaf4"],
    "lemon":     ["#e6c866", "#f4de88", "#faeaa8", "#fff6cf"],
    "blueberry": ["#4e5f8f", "#667aae", "#8497c6", "#a9b8de"],
    "leaf":      ["#6e9560", "#8db77d", "#abd09b", "#cde8bf"],
    "pistachio": ["#8fae5a", "#aecb74", "#c8e096", "#e2f1bd"],
    "apple":     ["#d3a24e", "#e6bd68", "#f1d08c", "#f8e2ae"],
    "sugar":     ["#e9dfd0", "#f8f2e8", "#fffcf6", "#ffffff"],
    "honey":     ["#c98a3e", "#e2a85a", "#f0c27c", "#f9dba3"],
})

DARK_CHOC = ["#3d251d", "#52332a", "#6b4538", "#86594a"]
PLATE = RAMPS["saucer"]
SPRINKLES = ["#f08ba0", "#8fc7e0", "#f4d36a", "#9fd3a2", "#c5a3e0"]


# ----------------------------------------------------------------------------- helpers
def ramp(r):
    return RAMPS[r] if isinstance(r, str) else r


def cells_ell(cx, cy, rx, ry):
    out = []
    for y in range(int(cy - ry - 1), int(cy + ry + 2)):
        for x in range(int(cx - rx - 1), int(cx + rx + 2)):
            if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1.0:
                out.append((x, y))
    return out


def ell(cv, cx, cy, rx, ry, r, rim=True, flat=False):
    """Shaded ellipse, light from the upper left. rim: dark inner edge (separates overlapping parts)."""
    r = ramp(r)
    cs = set(cells_ell(cx, cy, rx, ry))
    for (x, y) in cs:
        edge = any((x + dx, y + dy) not in cs for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)))
        if rim and edge and ((x - cx) / rx * 0.5 + (y - cy) / ry * 0.85) > 0.15:
            cv.px(x, y, r[0])
            continue
        if flat:
            cv.px(x, y, r[1])
            continue
        s = -0.6 * (x - cx) / rx - 0.8 * (y - cy) / ry
        idx = 3 if s > 0.62 else 2 if s > 0.15 else 1 if s > -0.55 else 0
        cv.px(x, y, r[idx])
    return cs


def hbox(cv, x0, y0, x1, y1, r):
    """Box lit from above: light top rows, base, dark bottom row."""
    r = ramp(r)
    cv.rect(x0, y0, x1, y1, r[1])
    cv.rect(x0, y0, x1, y0, r[2])
    cv.rect(x0, y1, x1, y1, r[0])
    cv.rect(x0, y0, x0, y1, r[2])
    cv.rect(x1, y0, x1, y1, r[0])


def poly(cv, pts, color_fn):
    """Fills a polygon, colour from color_fn(x, y)."""
    ys = [p[1] for p in pts]
    n = len(pts)
    for y in range(min(ys), max(ys) + 1):
        xs = []
        for i in range(n):
            (ax, ay), (bx, by) = pts[i], pts[(i + 1) % n]
            if ay == by:
                continue
            if min(ay, by) <= y + 0.5 < max(ay, by):
                xs.append(ax + (y + 0.5 - ay) * (bx - ax) / (by - ay))
        xs.sort()
        for i in range(0, len(xs) - 1, 2):
            for x in range(int(math.floor(xs[i] + 0.5)), int(math.floor(xs[i + 1] - 0.5)) + 1):
                cv.px(x, y, color_fn(x, y))


def pts(cv, coords, c):
    for (x, y) in coords:
        cv.px(x, y, c)


def sprinkle(cv, cs, n, seed, colors=SPRINKLES):
    """Scatter n 2px sprinkles inside the cell set cs (deterministic)."""
    import random
    rnd = random.Random(seed)
    cl = sorted(cs)
    for i in range(n):
        x, y = rnd.choice(cl)
        c = colors[i % len(colors)]
        if (x + 1, y) in cs:
            cv.px(x, y, c); cv.px(x + 1, y, c)
        else:
            cv.px(x, y, c)


def plate(cv, y=27, rx=13, ry=3):
    cv.ellipse(16, y, rx, ry, PLATE[1])
    cv.ellipse(16, y - 0.4, rx - 2, ry - 1, PLATE[2])
    cv.rect(int(16 - rx + 1), y, int(16 + rx - 1), y, PLATE[0])


def cyl(cv, cx, top, rx, ry, h, r, top_r=None, rim=True):
    """Cylinder seen from slightly above: body + a lighter elliptical top. Returns the top cells."""
    r = ramp(r)
    tr = ramp(top_r) if top_r else r
    cs_b = set(cells_ell(cx, top + h, rx, ry))
    for y in range(top, top + h + 1):
        for x in range(int(round(cx - rx)), int(round(cx + rx)) + 1):
            cs_b.add((x, y))
    for (x, y) in cs_b:
        u = (x - (cx - rx)) / max(1.0, 2 * rx)
        c = r[3] if u < 0.1 else r[2] if u < 0.34 else r[1] if u < 0.76 else r[0]
        cv.px(x, y, c)
    cv.rect(int(cx - rx) + 1, top + h + int(ry) - 1, int(cx + rx) - 1, top + h + int(ry) - 1, r[0])
    return ell(cv, cx, top, rx, ry, tr, rim=rim)


def block(cv, x, y, w, h, d, layers, top, side_dark=True):
    """3D slab: front face x..x+w, y..y+h (layers bottom->top as (ramp, rows)), top face and a right face with depth d."""
    # front
    yy = y + h
    for rname, rows in layers:
        r = ramp(rname)
        for i in range(rows):
            yy -= 1
            for xx in range(x, x + w + 1):
                u = (xx - x) / max(1, w)
                cv.px(xx, yy, r[2] if u < 0.2 else r[1] if u < 0.85 else r[0])
        cv.rect(x, yy, x + w, yy, r[2])
    # side (right)
    def side(px, py):
        yy2 = py + d
        # find layer at the row (relative to the front face)
        rel = y + h - py - (px - (x + w))     # row from bottom in the front-face coordinates
        acc = 0
        for rname, rows in layers:
            acc += rows
            if rel < acc:
                return ramp(rname)[0]
        return ramp(layers[-1][0])[0]
    for dx in range(1, d + 1):
        for yy3 in range(y - dx, y + h - dx + 1):
            cv.px(x + w + dx, yy3, side(x + w + dx, yy3))
    # top (parallelogram)
    tr = ramp(top)
    for dy in range(1, d + 1):
        for xx in range(x + dy, x + w + dy + 1):
            u = (xx - (x + dy)) / max(1, w)
            cv.px(xx, y - dy, tr[3] if (dy == 1 and u < 0.5) else tr[2] if u < 0.6 else tr[1])
    return (x, y, w, h, d)


def block_top_cells(x, y, w, d):
    return {(xx, y - dy) for dy in range(1, d + 1) for xx in range(x + dy, x + w + dy + 1)}


def save(cv, name, shadow=True):
    return base.save(cv, name)


# ----------------------------------------------------------------------------- pastry
def croissant():
    cv = Canvas()
    r = RAMPS["golden"]
    # a crescent: segments along an arch, thin at the horns, fat in the middle, drawn tips first
    order = [-1.0, 1.0, -0.82, 0.82, -0.62, 0.62, -0.4, 0.4, -0.2, 0.2, 0.0]
    for t in order:
        cx = 16 + 12.5 * t
        cy = 11 + 11.5 * t * t
        rr = 2.6 + 5.0 * (1 - abs(t) ** 1.5)
        ell(cv, cx, cy, rr * 0.95, rr * 1.05, r)
    # layer creases and glossy egg-wash
    for t in (-0.7, -0.5, -0.3, 0.3, 0.5, 0.7):
        cx = 16 + 12.5 * t
        cy = 11 + 11.5 * t * t
        cv.px(int(cx), int(cy - 2), r[0]); cv.px(int(cx), int(cy - 1), r[0]); cv.px(int(cx), int(cy), r[0])
    pts(cv, [(13, 7), (14, 7), (15, 6), (18, 7), (19, 7), (9, 11), (8, 13), (23, 11), (24, 13)], r[3])
    return save(cv, "croissant")

def donut(name, glaze, with_sprinkles=True):
    cv = Canvas()
    d = RAMPS["dough"]
    ell(cv, 16, 19, 12.5, 8.5, d)                         # dough body (lower)
    gl = ramp(glaze)
    cs = ell(cv, 16, 16, 12.5, 8.2, gl)                    # glaze on top
    for (x, y) in ((6, 22), (9, 23), (13, 24), (19, 24), (23, 22), (26, 20)):                  # drips
        cv.px(x, y, gl[1]); cv.px(x, y - 1, gl[1])
    hole = cells_ell(16, 16, 3.8, 2.6)
    for (x, y) in hole:
        cv.px(x, y, d[0])
    for (x, y) in cells_ell(16, 16.4, 2.6, 1.6):
        cv.px(x, y, "#9a6238")
    if with_sprinkles:
        inner = {c for c in cs if c not in set(hole)}
        sprinkle(cv, {c for c in inner if abs(c[0] - 16) > 5 or abs(c[1] - 16) > 3}, 9, 4)
    return save(cv, name)


def donut_pink():
    return donut("donut_pink", "pink")


def donut_choc():
    return donut("donut_choc", DARK_CHOC)


def cupcake(name, frosting, wrapper, topping):
    cv = Canvas()
    w = ramp(wrapper)
    # wrapper: trapezoid with vertical flutes
    for y in range(17, 29):
        half = 8.5 - (y - 17) * 0.28
        for x in range(int(round(16 - half)), int(round(16 + half)) + 1):
            k = (x - int(round(16 - half))) % 3
            cv.px(x, y, w[2] if k == 0 else w[1] if k == 1 else w[0])
    cv.rect(7, 17, 25, 17, w[2])
    cv.rect(8, 28, 24, 28, w[0])
    f = ramp(frosting)
    ell(cv, 16, 17, 9.4, 3.2, f)
    ell(cv, 16, 13.5, 7.6, 3.2, f)
    ell(cv, 16, 10, 5.4, 2.8, f)
    ell(cv, 16, 7, 2.8, 2.2, f)
    cv.px(15, 4, f[1]); cv.px(16, 4, f[1]); cv.px(16, 3, f[2])
    topping(cv)
    return save(cv, name)


def cupcake_pink():
    def top(cv):
        for (x, y) in ((16, 3), (15, 4), (16, 4), (17, 4)):
            cv.px(x, y, RAMPS["berry"][1])
        cv.px(16, 3, RAMPS["berry"][3])
        pts(cv, [(12, 12), (19, 14), (14, 9), (20, 10)], "#fff7ea")
        pts(cv, [(10, 16), (22, 16), (16, 12)], SPRINKLES[1])
    return cupcake("cupcake_pink", "pink", "mint", top)


def cupcake_choc():
    def top(cv):
        pts(cv, [(15, 4), (16, 4), (16, 3), (15, 3)], RAMPS["berry"][1])
        cv.px(15, 3, RAMPS["berry"][3])
        pts(cv, [(12, 12), (19, 13), (14, 16), (20, 17)], RAMPS["cream"][3])
        pts(cv, [(15, 10), (17, 8)], RAMPS["cream"][2])
    return cupcake("cupcake_choc", DARK_CHOC, "rose", top)


def muffin_blueberry():
    cv = Canvas()
    w = RAMPS["paper"]
    for y in range(19, 29):
        half = 9 - (y - 19) * 0.3
        for x in range(int(round(16 - half)), int(round(16 + half)) + 1):
            k = (x - int(round(16 - half))) % 3
            cv.px(x, y, w[3] if k == 0 else w[2] if k == 1 else w[1])
    cv.rect(7, 19, 25, 19, w[0]); cv.rect(9, 28, 23, 28, w[0])
    ell(cv, 16, 15, 12, 7.5, "dough")                       # the muffin top overhangs the paper
    ell(cv, 16, 10.5, 8, 4.6, "dough", rim=False)
    cs = set(cells_ell(16, 14, 11, 6))
    for (x, y) in ((9, 14), (13, 11), (18, 10), (22, 14), (12, 17), (19, 16), (16, 13), (25, 17), (7, 17)):
        for (dx, dy) in ((0, 0), (1, 0), (0, 1), (1, 1)):
            cv.px(x + dx, y + dy, RAMPS["blueberry"][1])
        cv.px(x, y, RAMPS["blueberry"][3]); cv.px(x + 1, y + 1, RAMPS["blueberry"][0])
    pts(cv, [(11, 8), (12, 8), (14, 7), (21, 9)], RAMPS["dough"][3])
    return save(cv, "muffin_blueberry")


def cream_puff():
    cv = Canvas()
    plate(cv, 27, 13, 2.8)
    balls = [(10.5, 21.5, 6.6, 5.6), (21.5, 21.5, 6.6, 5.6), (16, 13.5, 7, 6)]
    ch = DARK_CHOC
    for (cx, cy, rx, ry) in balls:
        cs = ell(cv, cx, cy, rx, ry, "dough")
        for (x, y) in cs:                                     # chocolate sauce cap with a wavy edge
            if y < cy - 0.5 + 1.8 * math.sin(x * 1.25 + cx):
                u = (x - (cx - rx)) / (2 * rx)
                cv.px(x, y, ch[3] if (u < 0.3 and y < cy - ry * 0.4) else ch[2] if u < 0.45 else ch[1] if u < 0.8 else ch[0])
        for dx in (-3, 0, 3):                                 # drips
            if (cx + dx, int(cy)) in cs:
                cv.px(int(cx + dx), int(cy + 1.2), ch[1])
    pts(cv, [(7, 17), (8, 17), (14, 9), (15, 9), (21, 18), (22, 18)], RAMPS["sugar"][3])
    pts(cv, [(12, 6), (20, 7)], RAMPS["sugar"][2])
    return save(cv, "cream_puff")

def eclair():
    cv = Canvas()
    d, ch = RAMPS["dough"], DARK_CHOC
    # dough: a long rounded body
    for y in range(12, 25):
        t = (y - 12) / 12
        inset = 3 if y in (12, 24) else 2 if y in (13, 23) else 1 if y in (14, 22) else 0
        for x in range(3 + inset, 29 - inset):
            cv.px(x, y, d[3] if t < 0.12 else d[2] if t < 0.32 else d[1] if t < 0.7 else d[0])
    cv.rect(5, 17, 26, 17, d[0])                              # seam where the cream is
    cv.rect(6, 18, 25, 18, RAMPS["cream"][2])
    # chocolate glaze
    for y in range(9, 17):
        inset = 3 if y in (9,) else 2 if y == 10 else 0
        for x in range(4 + inset, 28 - inset):
            t = (y - 9) / 7
            cv.px(x, y, ch[3] if t < 0.1 else ch[2] if t < 0.38 else ch[1] if t < 0.8 else ch[0])
    for (x, y) in ((6, 17), (11, 17), (12, 18), (17, 17), (23, 17), (24, 18)):
        cv.px(x, y, ch[1]); cv.px(x, y - 1, ch[1])
    # white icing zig-zag
    for i, x in enumerate(range(6, 26)):
        cv.px(x, 12 + (1 if (i // 2) % 2 else 0), RAMPS["sugar"][2])
    pts(cv, [(7, 10), (8, 10)], ch[3])
    return save(cv, "eclair")


def cinnamon_roll():
    cv = Canvas()
    d = RAMPS["dough"]
    cs = ell(cv, 16, 17, 13, 11, "dough")
    cx, cy = 16, 17
    for i in range(0, 700):                                      # two-px wide cinnamon spiral
        th = i * 0.04
        rr = 1.2 + th * 0.62
        x = cx + rr * math.cos(th)
        y = cy + rr * math.sin(th) * 0.84
        for (dx, dy) in ((0, 0), (1, 0), (0, 1)):
            xi, yi = int(round(x)) + dx, int(round(y)) + dy
            if ((xi - cx) / 11.6) ** 2 + ((yi - cy) / 9.6) ** 2 <= 1:
                cv.px(xi, yi, RAMPS["ginger"][1] if dx + dy < 2 else RAMPS["ginger"][0])
    # icing: drizzled zig-zag strands, sparse so the spiral stays readable
    ic = RAMPS["sugar"]
    for (x0, y0, x1) in ((7, 10, 25), (6, 17, 26)):
        for i in range(x1 - x0 + 1):
            x = x0 + i
            y = int(round(y0 + math.sin(i * 0.8) * 2.2))
            if ((x - cx) / 12.4) ** 2 + ((y - cy) / 10.2) ** 2 <= 1 and i % 7 != 6:
                cv.px(x, y, ic[2]); cv.px(x, y + 1, ic[1])
    pts(cv, [(9, 8), (13, 9), (20, 11), (9, 14)], d[3])
    return save(cv, "cinnamon_roll")

# ----------------------------------------------------------------------------- cookies & small bites
def cookie_choc():
    cv = Canvas()
    ck = RAMPS["dough"]
    cs = ell(cv, 16, 16, 12.5, 11.5, ["#b8803f", "#d4a05c", "#e6bb7e", "#f3d3a0"])
    for (x, y) in list(cs):
        if (x - 26) ** 2 + (y - 8) ** 2 <= 22:                # a bite
            cv.px(x, y, (0, 0, 0, 0))
    cv.im.putpixel((24, 10), (0, 0, 0, 0))
    ch = RAMPS["choc"]
    for (x, y) in ((10, 8), (16, 7), (7, 14), (14, 13), (21, 14), (10, 19), (17, 20), (23, 20), (13, 25), (20, 24), (5, 20)):
        if cv.get(x, y)[3] and cv.get(x + 1, y + 1)[3]:
            cv.rect(x, y, x + 1, y + 1, ch[1])
            cv.px(x, y, ch[2]); cv.px(x + 1, y + 1, ch[0])
    pts(cv, [(8, 11), (13, 9), (19, 11), (11, 16)], ck[3])
    return save(cv, "cookie_choc")


def cookie_heart():
    cv = Canvas()
    cs = set()
    for y in range(32):
        for x in range(32):
            u, v = (x - 15.5) / 11.6, -(y - 14.5) / 11.0
            if (u * u + v * v - 1) ** 3 - u * u * v ** 3 <= 0:
                cs.add((x, y))
    r = RAMPS["graham"]
    for (x, y) in cs:
        s = -0.04 * (x - 16) - 0.06 * (y - 15)
        cv.px(x, y, r[2] if s > 0.35 else r[1])
    for (x, y) in cs:                                          # shadow side
        if (x + 1, y) not in cs or (x, y + 1) not in cs:
            cv.px(x, y, r[0])
    # icing: smaller heart + piping border
    ic = set()
    for y in range(32):
        for x in range(32):
            u, v = (x - 15.5) / 9.4, -(y - 14.8) / 8.8
            if (u * u + v * v - 1) ** 3 - u * u * v ** 3 <= 0:
                ic.add((x, y))
    p = RAMPS["pink"]
    for (x, y) in ic:
        cv.px(x, y, p[3] if (x + y) < 28 and x < 14 else p[2] if (x + y) < 36 else p[1])
    for (x, y) in ic:
        if (x + 1, y) not in ic or (x, y + 1) not in ic or (x - 1, y) not in ic or (x, y - 1) not in ic:
            cv.px(x, y, RAMPS["sugar"][2] if (x + y) % 2 else RAMPS["sugar"][1])
    sprinkle(cv, {c for c in ic if 12 < c[1] < 21}, 7, 8, [RAMPS["berry"][1], RAMPS["mint"][0], RAMPS["lemon"][0]])
    pts(cv, [(10, 10), (18, 10)], RAMPS["sugar"][3])
    return save(cv, "cookie_heart")


def gingerbread_man():
    cv = Canvas()
    g = RAMPS["ginger"]
    shapes = [("e", 16, 8, 5.6, 5.2), ("e", 16, 17, 6.6, 6.4), ("e", 7.5, 14, 4.2, 2.8), ("e", 24.5, 14, 4.2, 2.8),
              ("e", 12, 25, 3.2, 4.6), ("e", 20, 25, 3.2, 4.6)]
    for (_, cx, cy, rx, ry) in shapes:
        ell(cv, cx, cy, rx, ry, g, rim=False)
    ell(cv, 16, 17, 6.6, 6.4, g, rim=False)
    ell(cv, 16, 8, 5.6, 5.2, g, rim=False)
    ic = RAMPS["sugar"]
    pts(cv, [(14, 7), (18, 7)], INK)                          # eyes
    pts(cv, [(14, 10), (15, 11), (16, 11), (17, 11), (18, 10)], ic[2])
    for i, c in enumerate(("berry", "mint", "lemon")):         # buttons
        cv.rect(15, 14 + i * 3, 16, 15 + i * 3, RAMPS[c][1])
        cv.px(15, 14 + i * 3, RAMPS[c][3])
    for x in range(5, 9):                                      # frosting cuffs
        cv.px(x, 15 if x % 2 else 16, ic[2])
    for x in range(24, 28):
        cv.px(x, 15 if x % 2 else 16, ic[2])
    pts(cv, [(10, 28), (11, 28), (12, 28), (20, 28), (21, 28), (22, 28)], ic[2])
    pts(cv, [(13, 6), (14, 5), (15, 4)], g[3])
    return save(cv, "gingerbread_man")


def macaron(name, shell, filling="cream"):
    cv = Canvas()
    s, f = RAMPS[shell], RAMPS[filling]
    ell(cv, 16, 21, 11, 3.6, s, rim=False)
    cv.rect(6, 21, 26, 22, s[0])
    for x in range(6, 27):                                     # ruffled feet
        cv.px(x, 21, s[1] if x % 2 else s[0])
    cv.rect(6, 17, 26, 20, f[1]); cv.rect(6, 17, 26, 17, f[2]); cv.rect(6, 20, 26, 20, f[0])
    for x in range(7, 26, 3):
        cv.px(x, 18, f[3])
    ell(cv, 16, 14, 11, 5.8, s, rim=False)
    cv.rect(5, 16, 27, 16, s[0])
    for x in range(6, 27):
        cv.px(x, 16, s[1] if x % 2 else s[0])
    pts(cv, [(10, 10), (11, 9), (13, 8), (15, 8)], s[3])
    pts(cv, [(21, 11), (22, 12)], s[0])
    return save(cv, name)


def macaron_pink():
    return macaron("macaron_pink", "pink")


def macaron_mint():
    return macaron("macaron_mint", "mint")


def macaron_lemon():
    return macaron("macaron_lemon", "lemon")


def cake_pop():
    cv = Canvas()
    st = RAMPS["paper"]
    cv.rect(15, 16, 16, 29, st[1]); cv.rect(15, 16, 15, 29, st[3]); cv.rect(16, 16, 16, 29, st[0])
    ell(cv, 16, 11, 9, 8.6, "pink")
    # glossy coating with a drip skirt
    for (x, y) in ((9, 18), (12, 19), (16, 19), (20, 18), (23, 17)):
        cv.px(x, y, RAMPS["pink"][1]); cv.px(x, y - 1, RAMPS["pink"][1])
    cv.px(16, 20, RAMPS["pink"][0])
    sprinkle(cv, set(cells_ell(16, 10, 7, 6)), 10, 11)
    pts(cv, [(11, 6), (12, 5), (14, 4)], RAMPS["pink"][3])
    # little bow on the stick
    pts(cv, [(12, 23), (13, 22), (14, 23), (14, 24), (13, 24), (18, 23), (19, 22), (20, 23), (19, 24), (18, 24)], RAMPS["berry"][1])
    pts(cv, [(15, 23), (16, 23), (15, 24), (16, 24)], RAMPS["berry"][0])
    return save(cv, "cake_pop")


# ----------------------------------------------------------------------------- cake slices
def slice_item(name, layers, top, top_decor, plate_on=True):
    cv = Canvas()
    if plate_on:
        plate(cv, 27, 13, 3)
    x, y, w, h, d = 4, 12, 19, 13, 5
    block(cv, x, y, w, h, d, layers, top)
    top_decor(cv, x, y, w, d)
    return save(cv, name)


def strawberry(cv, cx, cy):
    b = RAMPS["berry"]
    cv.rect(cx - 2, cy - 1, cx + 2, cy + 1, b[1])
    cv.rect(cx - 1, cy + 2, cx + 1, cy + 2, b[1]); cv.px(cx, cy + 3, b[0])
    cv.px(cx - 2, cy - 1, b[2]); cv.px(cx - 1, cy, b[3])
    cv.px(cx + 2, cy + 1, b[0])
    cv.rect(cx - 2, cy - 2, cx + 1, cy - 2, RAMPS["leaf"][1]); cv.px(cx, cy - 3, RAMPS["leaf"][2])
    cv.px(cx + 1, cy, b[0]); cv.px(cx - 1, cy + 1, b[0])


def cheesecake():
    def deco(cv, x, y, w, d):
        for dy in range(1, d + 1):                              # strawberry glaze across the top
            for xx in range(x + dy + 3, x + w + dy + 1):
                cv.px(xx, y - dy, RAMPS["berry"][2] if (xx + dy) % 5 else RAMPS["berry"][3])
        for xx in range(x + 2, x + w - 3, 3):                  # glaze dripping down the front
            cv.px(xx, y, RAMPS["berry"][1]); cv.px(xx, y + 1, RAMPS["berry"][1])
        for xx in range(x, x + w + 1):
            cv.px(xx, y, RAMPS["berry"][1])
        strawberry(cv, 17, 6)
    return slice_item("cheesecake", [("graham", 3), ("vanilla", 9), ("cream", 1)], "cream", deco)


def cake_strawberry():
    def deco(cv, x, y, w, d):
        for dy in range(1, d + 1):
            for xx in range(x + dy, x + w + dy + 1):
                cv.px(xx, y - dy, RAMPS["foam"][2] if (xx + dy) % 3 else RAMPS["foam"][3])
        for xx in range(x + 1, x + w, 3):
            cv.px(xx, y, RAMPS["foam"][2]); cv.px(xx, y - 1, RAMPS["foam"][2])
        strawberry(cv, 17, 7)
        strawberry(cv, 10, 8)
    return slice_item("cake_strawberry", [("vanilla", 3), ("berry", 1), ("vanilla", 3), ("berry", 1), ("vanilla", 3), ("foam", 2)], "foam", deco)


def cake_choc():
    def deco(cv, x, y, w, d):
        ch = DARK_CHOC
        for dy in range(1, d + 1):
            for xx in range(x + dy, x + w + dy + 1):
                cv.px(xx, y - dy, ch[3] if (dy == 1 and xx < x + 10) else ch[2])
        for xx in range(x, x + w + 1, 2):                      # ganache drips
            cv.px(xx, y, ch[1]); cv.px(xx, y + 1, ch[1])
        for xx in range(x + 2, x + w, 4):
            cv.px(xx, y + 2, ch[1])
        # cherry
        pts(cv, [(15, 6), (16, 6), (15, 7), (16, 7), (16, 4), (17, 3)], RAMPS["berry"][1])
        cv.px(15, 6, RAMPS["berry"][3]); cv.px(16, 7, RAMPS["berry"][0])
        cv.px(16, 5, RAMPS["leaf"][1])
    return slice_item("cake_choc", [("choc", 3), ("cream", 1), ("choc", 3), ("cream", 1), ("choc", 3), ("choc", 2)], DARK_CHOC, deco)


def tiramisu():
    def deco(cv, x, y, w, d):
        ck = RAMPS["cocoa"]
        for dy in range(1, d + 1):
            for xx in range(x + dy, x + w + dy + 1):
                cv.px(xx, y - dy, ck[2] if (xx * 7 + dy * 3) % 5 else ck[3])
        for xx in range(x, x + w + 1):
            cv.px(xx, y, ck[1] if xx % 2 else ck[2])
        pts(cv, [(12, 8), (18, 9), (22, 7), (9, 9)], RAMPS["sugar"][2])
    return slice_item("tiramisu", [("cap", 3), ("cream", 2), ("cap", 3), ("cream", 2), ("cocoa", 2)], "cocoa", deco)


def apple_pie():
    def deco(cv, x, y, w, d):
        g = RAMPS["golden"]
        for dy in range(1, d + 1):                              # lattice top
            for xx in range(x + dy, x + w + dy + 1):
                lat = ((xx + dy) % 4 in (0, 1)) != (dy % 2 == 0)
                cv.px(xx, y - dy, g[3] if lat else RAMPS["caramel"][0])
        for xx in range(x + 1, x + w, 1):                       # the crust edge, crimped
            cv.px(xx, y, g[3] if xx % 2 else g[1])
        pts(cv, [(7, 17), (8, 17), (12, 19), (13, 19), (17, 16), (18, 16), (10, 22), (16, 21), (19, 20)], RAMPS["apple"][3])
    return slice_item("apple_pie", [("golden", 3), ("caramel", 8), ("golden", 2)], "golden", deco)


def medovik():
    def deco(cv, x, y, w, d):
        h = RAMPS["honey"]
        for dy in range(1, d + 1):
            for xx in range(x + dy, x + w + dy + 1):
                cv.px(xx, y - dy, h[2])
        import random
        rnd = random.Random(5)                                  # crumb topping
        for i in range(16):
            dy = rnd.randint(1, d)
            xx = rnd.randint(x + dy, x + w + dy)
            cv.px(xx, y - dy, h[0] if i % 2 else h[3])
    layers = []
    for i in range(5):
        layers += [("honey", 2), ("cream", 1)]
    return slice_item("medovik", layers[:-1] + [("honey", 1)], "honey", deco)


def brownie():
    cv = Canvas()
    plate(cv, 27, 12, 2.6)
    ch = RAMPS["choc"]
    block(cv, 5, 13, 17, 12, 6, [("choc", 12)], DARK_CHOC)
    block_cells = block_top_cells(5, 13, 17, 6)
    for (x, y) in block_cells:                                  # cracked crust
        if (x * 3 + y * 5) % 7 == 0:
            cv.px(x, y, RAMPS["sugar"][1])
    sprinkle(cv, {c for c in block_cells if (c[0] + c[1]) % 3}, 6, 3, ["#e1c196", "#cfa575"])
    for yy in (16, 20):
        cv.rect(5, yy, 22, yy, ch[2])
    pts(cv, [(7, 15), (8, 15), (12, 14)], ch[3])
    # walnut
    wn = RAMPS["graham"]
    pts(cv, [(15, 7), (16, 7), (17, 7), (14, 8), (15, 8), (16, 8), (17, 8), (18, 8), (15, 9), (16, 9), (17, 9)], wn[1])
    pts(cv, [(15, 7), (14, 8)], wn[3]); pts(cv, [(17, 9), (18, 8)], wn[0])
    cv.px(16, 8, wn[0])
    return save(cv, "brownie")


def waffle():
    cv = Canvas()
    d = RAMPS["dough"]
    # rounded square
    for y in range(5, 27):
        for x in range(4, 28):
            corner = (x in (4, 27) and y in (5, 26))
            if corner:
                continue
            cv.px(x, y, d[1])
    cv.rect(4, 5, 27, 5, d[2]); cv.rect(4, 26, 27, 26, d[0]); cv.rect(27, 5, 27, 26, d[0]); cv.rect(4, 5, 4, 26, d[2])
    # grid pockets
    for gy in range(0, 4):
        for gx in range(0, 4):
            x0, y0 = 6 + gx * 6, 7 + gy * 5
            cv.rect(x0, y0, x0 + 3, y0 + 2, d[0])
            cv.rect(x0, y0, x0 + 3, y0, d[0])
            cv.rect(x0 + 1, y0 + 1, x0 + 3, y0 + 2, d[2])
            cv.px(x0 + 3, y0 + 2, d[3])
    # butter + syrup
    for (x, y) in cells_ell(15, 15, 6.5, 5.5):
        cv.px(x, y, RAMPS["honey"][1])
    for (x, y) in ((8, 19), (12, 21), (20, 20), (23, 17), (16, 22)):
        cv.px(x, y, RAMPS["honey"][1]); cv.px(x, y + 1, RAMPS["honey"][1])
    pts(cv, [(11, 11), (12, 11), (13, 10)], RAMPS["honey"][3])
    bt = RAMPS["lemon"]
    cv.rect(12, 12, 18, 16, bt[1]); cv.rect(12, 12, 18, 12, bt[2]); cv.rect(12, 16, 18, 16, bt[0]); cv.rect(18, 12, 18, 16, bt[0])
    cv.px(12, 12, bt[3]); cv.px(13, 12, bt[3])
    return save(cv, "waffle")


def pancakes():
    cv = Canvas()
    plate(cv, 27, 13.5, 3)
    ck = ["#c58a4c", "#e2a965", "#efc388", "#f8dbaf"]
    for i, y in enumerate((20, 15, 10)):
        cyl(cv, 16, y, 10.5, 3.2, 4, ck, ck)
        cv.rect(7, y + 3, 25, y + 3, ck[2] if False else "#f4d9a8")   # pale edge line
    # syrup on top pancake, dripping
    hn = RAMPS["honey"]
    for (x, y) in cells_ell(16, 10, 8.4, 2.4):
        cv.px(x, y, hn[1])
    for (x, y, l) in ((9, 11, 5), (13, 12, 8), (19, 12, 4), (22, 11, 9), (16, 13, 3)):
        for k in range(l):
            cv.px(x, y + k, hn[1])
        cv.px(x, y + l, hn[2])
    pts(cv, [(11, 9), (12, 9), (13, 8)], hn[3])
    bt = RAMPS["lemon"]                                              # butter
    cv.rect(14, 5, 19, 8, bt[1]); cv.rect(14, 5, 19, 5, bt[2]); cv.rect(14, 8, 19, 8, bt[0]); cv.rect(19, 5, 19, 8, bt[0])
    cv.px(14, 5, bt[3])
    return save(cv, "pancakes")


# ----------------------------------------------------------------------------- cold & spoon desserts
def ice_cream_cone():
    cv = Canvas()
    c = RAMPS["graham"]
    # waffle cone, pointing down
    for y in range(16, 31):
        half = 8 - (y - 16) * 0.52
        for x in range(int(round(16 - half)), int(round(16 + half)) + 1):
            lat = ((x + y) % 4 == 0) or ((x - y) % 4 == 0)
            u = (x - (16 - half)) / max(1.0, 2 * half)
            base_c = c[2] if u < 0.35 else c[1] if u < 0.78 else c[0]
            cv.px(x, y, c[0] if lat and u < 0.9 else base_c)
    # scoops
    ell(cv, 16, 17, 9.6, 3.2, "pink")
    ell(cv, 16, 11, 8, 6.6, "pink")
    ell(cv, 16, 6.5, 6.4, 5.2, "mint")
    for (x, y) in ((8, 19), (11, 20), (21, 20), (24, 19)):
        cv.px(x, y, RAMPS["pink"][1])
    cv.px(14, 4, RAMPS["mint"][3]); cv.px(13, 5, RAMPS["mint"][3])
    pts(cv, [(11, 9), (12, 8), (11, 12)], RAMPS["pink"][3])
    sprinkle(cv, set(cells_ell(16, 11, 6, 4)), 6, 21)
    # cherry
    pts(cv, [(16, 1), (17, 1), (16, 2), (17, 2)], RAMPS["berry"][1])
    cv.px(16, 1, RAMPS["berry"][3])
    return save(cv, "ice_cream_cone")


def sundae():
    cv = Canvas()
    g = RAMPS["ice"]
    # base + stem
    cv.ellipse(16, 28, 7, 2, g[1]); cv.ellipse(16, 27.6, 5.4, 1.2, g[2]); cv.rect(9, 28, 23, 28, g[0])
    cv.rect(14, 22, 17, 27, g[2]); cv.rect(14, 22, 14, 27, g[3]); cv.rect(17, 22, 17, 27, g[0])
    # bowl
    for y in range(13, 23):
        t = (y - 13) / 9
        half = 10.5 - t * 6.5
        for x in range(int(round(16 - half)), int(round(16 + half)) + 1):
            u = (x - (16 - half)) / max(1.0, 2 * half)
            cv.px(x, y, g[3] if u < 0.1 else g[2] if u < 0.35 else g[1] if u < 0.8 else g[0])
    # layers visible through the glass
    for y in range(15, 22):
        t = (y - 13) / 9
        half = 10.5 - t * 6.5 - 1.4
        colors = ["berry", "berry", "cream", "cream", "choc", "choc", "choc"][y - 15]
        r = RAMPS[colors]
        for x in range(int(round(16 - half)), int(round(16 + half)) + 1):
            u = (x - (16 - half)) / max(1.0, 2 * half)
            cv.px(x, y, r[2] if u < 0.25 else r[1] if u < 0.8 else r[0])
    # scoops
    ell(cv, 10.5, 12, 4.8, 4.4, "pink")
    ell(cv, 21.5, 12, 4.8, 4.4, "choc")
    ell(cv, 16, 10, 5.4, 5, "vanilla")
    # whipped cream and cherry, wafer
    ell(cv, 16, 6, 3.6, 2.4, "foam")
    cv.px(16, 3, RAMPS["foam"][2]); cv.px(16, 4, RAMPS["foam"][2])
    pts(cv, [(15, 1), (16, 1), (15, 2), (16, 2)], RAMPS["berry"][1])
    cv.px(15, 1, RAMPS["berry"][3])
    w = RAMPS["graham"]
    for i in range(9):
        cv.px(22 + i // 3, 7 - i, w[1]); cv.px(23 + i // 3, 7 - i, w[0])
    pts(cv, [(23, 5), (23, 3)], w[3])
    pts(cv, [(9, 10), (10, 9)], RAMPS["pink"][3])
    return save(cv, "sundae")


def creme_brulee():
    cv = Canvas()
    plate(cv, 27, 13, 3)
    cyl(cv, 16, 15, 10.5, 4, 7, "porcelain", "porcelain")
    # fluted ramekin ridges
    for x in range(8, 25, 2):
        cv.px(x, 19, RAMPS["porcelain"][0]); cv.px(x, 20, RAMPS["porcelain"][0])
    cv.rect(6, 15, 26, 15, RAMPS["porcelain"][0]) if False else None
    # caramelised sugar disc
    cs = set(cells_ell(16, 15, 8.8, 3.1))
    for (x, y) in cs:
        cv.px(x, y, RAMPS["caramel"][1] if (x + y) % 6 else RAMPS["caramel"][2])
    for (x, y) in cs:
        if abs(x - 16) < 8 and abs(y - 15) < 3 and (x * 5 + y * 3) % 11 == 0:
            cv.px(x, y, RAMPS["caramel"][0])
    pts(cv, [(11, 14), (12, 14), (13, 13), (19, 14)], RAMPS["caramel"][3])
    # berry + mint
    r = RAMPS["berry"]
    pts(cv, [(15, 10), (16, 10), (17, 10), (14, 11), (15, 11), (16, 11), (17, 11), (18, 11), (15, 12), (16, 12), (17, 12)], r[1])
    pts(cv, [(15, 10), (14, 11)], r[3]); pts(cv, [(17, 12), (18, 11)], r[0]); cv.px(16, 11, r[0])
    pts(cv, [(20, 9), (21, 8), (22, 9), (21, 10), (20, 10)], RAMPS["leaf"][1])
    pts(cv, [(21, 9)], RAMPS["leaf"][3])
    pts(cv, [(19, 11), (20, 11)], RAMPS["leaf"][0])
    return save(cv, "creme_brulee")


def panna_cotta():
    cv = Canvas()
    g = RAMPS["ice"]
    plate(cv, 28, 11, 2.4)
    top, bot = 9, 26
    for y in range(top, bot + 1):
        t = (y - top) / (bot - top)
        half = 9.2 - t * 2.4
        x0, x1 = int(round(16 - half)), int(round(16 + half))
        if y < 15:
            r = RAMPS["berry"]
        else:
            r = RAMPS["foam"]
        for x in range(x0, x1 + 1):
            u = (x - x0) / max(1, x1 - x0)
            cv.px(x, y, r[3] if u < 0.1 else r[2] if u < 0.34 else r[1] if u < 0.8 else r[0])
        cv.px(x0, y, g[2]); cv.px(x1, y, g[0])
        cv.px(x0 + 1, y, g[3] if y % 3 else r[2])
    cv.rect(10, 15, 22, 15, RAMPS["berry"][0]) if False else None
    for x in range(8, 25):                                       # wavy boundary
        cv.px(x, 15 + (1 if (x // 2) % 2 else 0), RAMPS["berry"][2])
    cv.ellipse(16, top, 9.2, 2.3, g[2]); cv.ellipse(16, top + .3, 8, 1.7, RAMPS["berry"][1])
    cv.ellipse(15, top - .2, 4.5, .9, RAMPS["berry"][2])
    # raspberries and mint
    r = RAMPS["berry"]
    for (cx, cy) in ((13, 6), (19, 6)):
        cv.rect(cx - 1, cy - 1, cx + 1, cy + 1, r[1]); cv.px(cx, cy, r[0]); cv.px(cx - 1, cy - 1, r[3]); cv.px(cx + 1, cy + 1, r[0])
    pts(cv, [(15, 4), (16, 3), (17, 4), (16, 5), (16, 4)], RAMPS["leaf"][1])
    pts(cv, [(16, 3)], RAMPS["leaf"][3])
    return save(cv, "panna_cotta")


def flan():
    cv = Canvas()
    plate(cv, 26, 13.5, 4.2)
    cv.ellipse(16, 26, 12, 2.8, RAMPS["caramel"][1])             # caramel pool
    cv.ellipse(15, 25.6, 8, 1.4, RAMPS["caramel"][2])
    v = RAMPS["vanilla"]
    top, bot = 9, 24
    for y in range(top, bot + 1):
        t = (y - top) / (bot - top)
        half = 7.6 + t * 3.4
        x0, x1 = int(round(16 - half)), int(round(16 + half))
        for x in range(x0, x1 + 1):
            u = (x - x0) / max(1, x1 - x0)
            cv.px(x, y, v[3] if u < 0.1 else v[2] if u < 0.34 else v[1] if u < 0.8 else v[0])
    cv.ellipse(16, bot, 11, 2.6, v[1])
    cv.rect(5, bot + 2, 27, bot + 2, v[0]) if False else None
    ell(cv, 16, top, 7.6, 2.6, "caramel", rim=False)             # glaze cap
    c = RAMPS["caramel"]
    for (x, y, l) in ((9, 11, 5), (12, 12, 9), (16, 11, 6), (20, 12, 10), (23, 11, 4)):
        for k in range(l):
            cv.px(x, y + k, c[1] if k < l - 1 else c[0])
    pts(cv, [(12, 8), (13, 8), (14, 7)], c[3])
    pts(cv, [(11, 15), (12, 17)], v[3])
    return save(cv, "flan")


def fruit_tart():
    cv = Canvas()
    d = RAMPS["golden"]
    cyl(cv, 16, 14, 13, 7.5, 6, "golden", "golden")
    for x in range(5, 28, 2):                                    # fluted crust
        cv.px(x, 21, d[0]); cv.px(x, 22, d[0])
    ell(cv, 16, 14, 10.8, 5.6, "cream", rim=True)
    # fruit
    b = RAMPS["blueberry"]
    for (cx, cy) in ((9, 14), (13, 17), (22, 15), (19, 11)):
        cv.rect(cx - 1, cy - 1, cx + 1, cy + 1, b[1]); cv.px(cx - 1, cy - 1, b[3]); cv.px(cx + 1, cy + 1, b[0])
    r = RAMPS["berry"]
    for (cx, cy) in ((15, 12), (12, 11), (20, 17), (24, 13)):
        cv.rect(cx - 1, cy - 1, cx + 1, cy + 1, r[1]); cv.px(cx, cy, r[0]); cv.px(cx - 1, cy - 1, r[3]); cv.px(cx + 1, cy + 1, r[0])
    k = RAMPS["pistachio"]                                       # kiwi slice
    for (x, y) in cells_ell(16, 15, 2.6, 1.8):
        cv.px(x, y, k[1])
    cv.px(16, 15, RAMPS["sugar"][2])
    pts(cv, [(15, 14), (17, 16)], k[3])
    sl = RAMPS["leaf"]
    pts(cv, [(15, 8), (16, 7), (17, 8), (16, 9)], sl[1]); cv.px(16, 8, sl[3])
    pts(cv, [(12, 9), (13, 9), (22, 12)], RAMPS["sugar"][3])
    return save(cv, "fruit_tart")


def baklava():
    cv = Canvas()
    g = RAMPS["golden"]
    top = [(16, 5), (28, 11), (16, 17), (4, 11)]
    left = [(4, 11), (16, 17), (16, 27), (4, 21)]
    right = [(16, 17), (28, 11), (28, 21), (16, 27)]

    def left_c(x, y):
        k = (y - (x - 4) // 2 * 1) % 4          # stripes slanting with the edge
        return g[2] if k in (0, 1) else RAMPS["vanilla"][1] if k == 2 else g[1]

    def right_c(x, y):
        k = (y + (x - 16) // 2 * 1) % 4
        return g[1] if k in (0, 1) else RAMPS["vanilla"][0] if k == 2 else g[0]

    poly(cv, left, left_c)
    poly(cv, right, right_c)
    poly(cv, top, lambda x, y: g[3] if (x - 16) + (y - 11) * 1.5 < -4 else g[2] if (x + y) % 5 else g[1])
    # honey gloss + pistachio
    hn = RAMPS["honey"]
    for (x, y) in ((11, 9), (12, 9), (13, 8), (22, 12), (23, 12), (16, 12)):
        cv.px(x, y, hn[3])
    p = RAMPS["pistachio"]
    for (x, y) in ((14, 10), (15, 10), (17, 11), (18, 11), (16, 9), (16, 13), (15, 13)):
        cv.px(x, y, p[1])
    pts(cv, [(14, 10), (16, 9), (17, 11)], p[3])
    # edge lines
    for (x0, y0, x1, y1) in ((4, 11, 16, 17), (16, 17, 28, 11)):
        n = max(abs(x1 - x0), abs(y1 - y0))
        for i in range(n + 1):
            cv.px(round(x0 + (x1 - x0) * i / n), round(y0 + (y1 - y0) * i / n), g[0])
    cv.rect(16, 18, 16, 27, g[0])
    return save(cv, "baklava")


# ----------------------------------------------------------------------------- build + preview
ALL = [croissant, donut_pink, donut_choc, cupcake_pink, cupcake_choc, muffin_blueberry, cream_puff, eclair,
       cinnamon_roll, cookie_choc, cookie_heart, gingerbread_man, macaron_pink, macaron_mint, macaron_lemon,
       cake_pop, cheesecake, cake_strawberry, cake_choc, tiramisu, apple_pie, medovik, brownie, waffle,
       pancakes, ice_cream_cone, sundae, creme_brulee, panna_cotta, flan, fruit_tart, baklava]


def main():
    os.makedirs(base.OUT_DIR, exist_ok=True)
    imgs = [fn() for fn in ALL]
    if len(sys.argv) > 1:
        k, cols = 6, 8
        rows = (len(imgs) + cols - 1) // cols
        sheet = Image.new("RGBA", (cols * 34 * k, rows * 34 * k), (74, 66, 62, 255))
        for i, im in enumerate(imgs):
            u = im.resize((32 * k, 32 * k), Image.NEAREST)
            sheet.paste(u, ((i % cols) * 34 * k + k, (i // cols) * 34 * k + k), u)
        sheet.save(sys.argv[1])
    print("ok:", len(imgs), "textures")


if __name__ == "__main__":
    main()
