#!/usr/bin/env python3
"""
Detailed pastel 32x32 item textures of the barista system -> assets/aestheticjobs/textures/item/

  ingredients : coffee_beans, empty_cup, milk_carton, cream_carton, syrup_vanilla, syrup_caramel, chocolate
  drinks      : cup_espresso, cup_americano, cup_latte, cup_cappuccino, cup_flat_white, cup_raf, cup_mocha,
                cup_macchiato   (the filled cup item switches to these by custom_model_data 1..8)

Every sprite: a dark warm outline, a 3-4 step colour ramp per material (shadow / base / light / highlight),
a soft drop shadow on the lower right like the bank card. Run: python3 tools/gen_cafe_items.py [preview.png]
"""
import os
import sys
from PIL import Image

OUT_DIR = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources",
                       "assets", "aestheticjobs", "textures", "item")

# ---------- pastel palette (name -> ramp: shadow, base, light, highlight) ----------
INK = "#4a3228"
SHADOW = "#cfc4ad"
RAMPS = {
    "porcelain": ["#d9cdb4", "#f6ecd9", "#fffaf0", "#ffffff"],
    "saucer":    ["#cdbf9f", "#e6d9ba", "#f3ead2", "#fbf5e6"],
    "coffee":    ["#5a3a2a", "#7a5238", "#98694a", "#b58461"],
    "crema":     ["#b98153", "#d49c68", "#e8b988", "#f4d3ab"],
    "espresso":  ["#3b241b", "#52332a", "#6b4538", "#86594a"],
    "milk":      ["#e6d8bd", "#f8efdc", "#fffaf0", "#ffffff"],
    "foam":      ["#ecdcc0", "#fbf3e1", "#fffdf6", "#ffffff"],
    "cocoa":     ["#5a382c", "#7a4e3d", "#966553", "#b07d68"],
    "choc":      ["#4f3228", "#6e4638", "#8a5c4b", "#a67862"],
    "caramel":   ["#c98a3e", "#e2a85a", "#f0c27c", "#f9dba3"],
    "vanilla":   ["#e7cf96", "#f4e2b0", "#fbefc9", "#fff8e0"],
    "bean":      ["#4a2f24", "#6a4435", "#86594a", "#a47563"],
    "cream":     ["#efdcb6", "#fbeccb", "#fff5dd", "#ffffff"],
    "blue":      ["#8fb0c2", "#b4cfdc", "#d3e5ee", "#eef7fb"],
    "rose":      ["#dca698", "#efc2b4", "#f8d9ce", "#fdeee8"],
    "sage":      ["#8fae80", "#b2cba2", "#cfe2c2", "#e8f3e0"],
    "gold":      ["#d9a850", "#f0c76a", "#f8dc92", "#fdefbd"],
    "ice":       ["#9ec3d6", "#c6e0ee", "#e2f2f9", "#ffffff"],
    "paper":     ["#d8c7a0", "#efe2c2", "#faf1d8", "#fffaec"],
    "cap":       ["#b88a5c", "#d3a877", "#e4c297", "#f1d7b5"],
}


def rgb(c):
    if isinstance(c, tuple):
        return c if len(c) == 4 else c + (255,)
    h = c.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) + (255,)


class Canvas:
    def __init__(self):
        self.im = Image.new("RGBA", (32, 32), (0, 0, 0, 0))

    def px(self, x, y, c):
        if 0 <= x < 32 and 0 <= y < 32 and c is not None:
            self.im.putpixel((x, y), rgb(c))

    def rect(self, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                self.px(x, y, c)

    def ellipse(self, cx, cy, rx, ry, c):
        for y in range(int(cy - ry - 1), int(cy + ry + 2)):
            for x in range(int(cx - rx - 1), int(cx + rx + 2)):
                if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1.0:
                    self.px(x, y, c)

    def get(self, x, y):
        return self.im.getpixel((x, y))

    def outline(self, color=INK):
        """1px outline around everything drawn, then a soft drop shadow on the lower right."""
        src = self.im.copy()
        a = src.load()
        for y in range(32):
            for x in range(32):
                if a[x, y][3] == 0:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < 32 and 0 <= ny < 32 and a[nx, ny][3] > 0 and a[nx, ny][:3] != rgb(color)[:3]:
                            self.px(x, y, color)
                            break
        # shadow
        res = self.im.copy()
        r = res.load()
        for y in range(31):
            for x in range(31):
                if a[x, y][3] > 0 and r[x + 1, y + 1][3] == 0 and (x + 1 >= 32 or True):
                    pass
        snapshot = self.im.copy().load()
        for y in range(31):
            for x in range(31):
                if snapshot[x, y][3] > 0 and snapshot[x + 1, y + 1][3] == 0:
                    self.px(x + 1, y + 1, SHADOW)
        return self

    def shade_box(self, x0, y0, x1, y1, ramp, light="left"):
        """Fills a box with a 4-tone ramp: highlight on the left, base in the middle, shadow on the right."""
        ramp = RAMPS[ramp] if isinstance(ramp, str) else ramp
        w = x1 - x0 + 1
        for x in range(x0, x1 + 1):
            t = (x - x0) / max(1, w - 1)
            idx = 3 if x == x0 + 1 and w > 4 else 2 if t < 0.33 else 1 if t < 0.72 else 0
            for y in range(y0, y1 + 1):
                self.px(x, y, ramp[idx])


def save(cv, name):
    cv.outline()
    cv.im.save(os.path.join(OUT_DIR, name + ".png"))
    return cv.im


# =================================================================== ingredients
def coffee_beans():
    cv = Canvas()
    r = RAMPS["bean"]

    def bean(cx, cy, rx, ry, tilt):
        cells = []
        for y in range(cy - ry - 1, cy + ry + 2):
            for x in range(cx - rx - 1, cx + rx + 2):
                if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1.0:
                    cells.append((x, y))
        cs = set(cells)
        for (x, y) in cells:                                   # own dark rim
            if any((x + dx, y + dy) not in cs for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                cv.px(x, y, r[0])
                continue
            shade = (x - cx) * 0.6 + (y - cy) * 0.8 * (1 if tilt else -1)
            idx = 3 if shade < -rx * 0.5 else 2 if shade < 0.5 else 1
            cv.px(x, y, r[idx])
        for i in range(-ry + 1, ry):                           # the centre crease
            o = (i if tilt else -i) // 2
            cv.px(cx + o, cy + i, r[0])
            cv.px(cx + o + 1, cy + i, r[1])
        cv.px(cx - rx + 2, cy - 1, RAMPS["bean"][3])            # shine
    bean(10, 22, 6, 4, True)
    bean(22, 22, 6, 4, False)
    bean(16, 12, 7, 5, True)
    return save(cv, "coffee_beans")


def empty_cup():
    cv = Canvas()
    p, s = RAMPS["porcelain"], RAMPS["saucer"]
    cv.ellipse(16, 25, 12, 3.4, s[1]); cv.ellipse(16, 24.5, 10, 2.4, s[2])
    cv.rect(6, 25, 25, 25, s[0])
    # cup body (trapezoid)
    for y in range(11, 24):
        inset = (y - 11) * 0.18
        for x in range(int(8 + inset), int(24 - inset) + 1):
            t = (x - (8 + inset)) / max(1, (16 - 2 * inset))
            cv.px(x, y, p[3] if t < 0.14 else p[2] if t < 0.4 else p[1] if t < 0.78 else p[0])
    cv.ellipse(16, 11, 8.2, 2.2, p[2]); cv.ellipse(16, 11.4, 6.8, 1.6, p[0])
    # handle
    for (x, y) in ((24, 14), (25, 14), (26, 15), (26, 16), (26, 17), (25, 18), (24, 18)):
        cv.px(x, y, INK)
    for (x, y) in ((24, 15), (25, 15), (25, 16), (25, 17), (24, 17)):
        cv.px(x, y, p[1])
    # a little rose line decoration
    cv.rect(9, 17, 23, 17, RAMPS["rose"][1])
    return save(cv, "empty_cup")


def carton(name, body, band, label_color, drop=True):
    cv = Canvas()
    b = RAMPS[body]
    # gable top
    for (x0, x1, y) in ((11, 20, 4), (9, 22, 5), (8, 23, 6)):
        cv.rect(x0, y, x1, y, b[2])
    cv.rect(13, 3, 18, 3, b[1])
    cv.rect(14, 2, 17, 2, b[0])
    # box
    cv.shade_box(8, 7, 23, 28, b)
    cv.rect(8, 7, 23, 7, b[0])
    # wide colour band + label
    cv.rect(8, 15, 23, 22, RAMPS[band][1]); cv.rect(8, 15, 23, 15, RAMPS[band][2]); cv.rect(8, 22, 23, 22, RAMPS[band][0])
    cv.rect(10, 17, 21, 20, RAMPS["paper"][2])
    return cv, drop


def milk_carton():
    cv, _ = carton("milk", "milk", "blue", None)
    # a little cow-spot drop icon
    for (x, y) in ((15, 17), (16, 17), (14, 18), (15, 18), (16, 18), (17, 18), (15, 19), (16, 19)):
        cv.px(x, y, RAMPS["blue"][0])
    cv.px(15, 18, RAMPS["blue"][3])
    cv.rect(10, 24, 21, 24, RAMPS["blue"][2])
    return save(cv, "milk_carton")


def cream_carton():
    cv, _ = carton("cream", "cream", "rose", None)
    for (x, y) in ((14, 18), (15, 17), (16, 17), (17, 18), (15, 19), (16, 19)):
        cv.px(x, y, RAMPS["rose"][0])
    cv.px(16, 17, RAMPS["rose"][3])
    cv.rect(10, 24, 21, 24, RAMPS["rose"][2])
    return save(cv, "cream_carton")


def syrup(name, liquid, cap, label):
    cv = Canvas()
    g, l = RAMPS["porcelain"], RAMPS[liquid]
    # bottle body
    for y in range(12, 29):
        for x in range(9, 23):
            t = (x - 9) / 13
            cv.px(x, y, l[3] if t < 0.14 else l[2] if t < 0.32 else l[1] if t < 0.74 else l[0])
    cv.rect(9, 12, 22, 12, l[0])
    # shoulders and neck
    for (x0, x1, y) in ((11, 20, 10), (13, 18, 8), (13, 18, 9)):
        cv.rect(x0, y, x1, y, l[1])
    cv.rect(13, 8, 13, 10, l[2])
    # pump / cap
    c = RAMPS[cap]
    cv.rect(12, 5, 19, 7, c[1]); cv.rect(12, 5, 19, 5, c[2]); cv.rect(12, 7, 19, 7, c[0])
    cv.rect(15, 2, 16, 4, c[1]); cv.rect(15, 2, 22, 2, c[1]); cv.rect(22, 2, 22, 3, c[0])
    # label
    lb = RAMPS[label]
    cv.rect(11, 18, 20, 25, RAMPS["paper"][2]); cv.rect(11, 25, 20, 25, RAMPS["paper"][0])
    cv.rect(11, 18, 20, 19, lb[1]); cv.rect(11, 18, 20, 18, lb[2])
    return cv


def syrup_vanilla():
    cv = syrup("v", "vanilla", "cap", "gold")
    # a tiny flower on the label
    for (x, y) in ((15, 21), (16, 21), (14, 22), (17, 22), (15, 23), (16, 23)):
        cv.px(x, y, RAMPS["gold"][0])
    cv.px(15, 22, RAMPS["gold"][2]); cv.px(16, 22, RAMPS["gold"][2])
    return save(cv, "syrup_vanilla")


def syrup_caramel():
    cv = syrup("c", "caramel", "cocoa", "rose")
    for (x, y) in ((14, 21), (15, 21), (16, 21), (17, 21), (14, 22), (17, 22), (15, 23), (16, 23)):
        cv.px(x, y, RAMPS["cocoa"][1])
    cv.px(15, 22, RAMPS["caramel"][3]); cv.px(16, 22, RAMPS["caramel"][2])
    return save(cv, "syrup_caramel")


def chocolate():
    cv = Canvas()
    c = RAMPS["choc"]
    # a tilted bar of squares with a foil corner
    for row in range(4):
        for col in range(3):
            x0, y0 = 8 + col * 6 + row, 7 + row * 5
            cv.rect(x0, y0, x0 + 4, y0 + 3, c[1])
            cv.rect(x0, y0, x0 + 4, y0, c[2])
            cv.rect(x0, y0, x0, y0 + 3, c[2])
            cv.rect(x0 + 4, y0, x0 + 4, y0 + 3, c[0])
            cv.rect(x0, y0 + 3, x0 + 4, y0 + 3, c[0])
            cv.px(x0 + 1, y0 + 1, c[3])
    # wrapper
    cv.rect(8, 24, 25, 28, RAMPS["rose"][1]); cv.rect(8, 24, 25, 24, RAMPS["rose"][2]); cv.rect(8, 28, 25, 28, RAMPS["rose"][0])
    cv.rect(12, 26, 21, 26, RAMPS["gold"][1])
    return save(cv, "chocolate")


# =================================================================== drinks (side view of a cup)
CUP_TOP, CUP_BOTTOM = 10, 24     # rows of the cup body


def cup_base(cv, small=False):
    p, s = RAMPS["porcelain"], RAMPS["saucer"]
    cv.ellipse(16, 27, 12, 3, s[1]); cv.ellipse(16, 26.6, 10, 2.1, s[2]); cv.rect(5, 27, 26, 27, s[0])
    return p


def cup_shape(cv, top, bottom, w_top=8, w_bottom=5.6):
    """Draws the porcelain body, returns a function (x, y) -> inside"""
    p = RAMPS["porcelain"]
    inside = {}
    for y in range(top, bottom + 1):
        t = (y - top) / max(1, bottom - top)
        half = w_top + (w_bottom - w_top) * t
        for x in range(int(round(16 - half)), int(round(16 + half)) + 1):
            u = (x - (16 - half)) / max(1.0, 2 * half)
            cv.px(x, y, p[3] if u < 0.12 else p[2] if u < 0.38 else p[1] if u < 0.78 else p[0])
            inside[(x, y)] = (u, t)
    return inside, w_top


def layered_cup(layers, topping=None, glass=True, handle=True, surface=None, small=False):
    """A glass cup, seen from the side, with the drink's layers visible over the whole height."""
    cv = Canvas()
    cup_base(cv)
    top, bottom = (12, 25) if small else (9, 25)
    wt, wb = (7.0, 5.0) if small else (8.4, 5.8)
    g = RAMPS["ice"]
    # layers fill the whole body, from the bottom up
    total = sum(f for _, f in layers)
    rows = bottom - top
    bounds, acc = [], 0.0
    for ramp, frac in layers:
        acc += frac / total
        bounds.append((ramp, bottom - int(round(rows * acc))))
    for y in range(top, bottom + 1):
        t = (y - top) / max(1, rows)
        half = wt + (wb - wt) * t
        x0, x1 = int(round(16 - half)), int(round(16 + half))
        ramp = bounds[-1][0]
        for rname, ylim in bounds:
            if y >= ylim:
                ramp = rname
                break
        r = RAMPS[ramp]
        for x in range(x0, x1 + 1):
            u = (x - x0) / max(1, x1 - x0)
            cv.px(x, y, r[3] if u < 0.10 else r[2] if u < 0.32 else r[1] if u < 0.78 else r[0])
        cv.px(x0, y, g[2]); cv.px(x1, y, g[0])                 # glass walls
        cv.px(x0 + 1, y, g[3] if y % 3 else r[2])             # glass glint
    # soft blend line between layers
    for (rname, ylim) in bounds[:-1]:
        for x in range(int(round(16 - wb)) + 1, int(round(16 + wb))):
            pass
    # rim and the foam / surface in the opening
    cv.ellipse(16, top, wt, 2.3, g[2]); cv.ellipse(16, top + 0.3, wt - 1.0, 1.7, g[1])
    surf = RAMPS[surface or layers[-1][0]]
    cv.ellipse(16, top + 0.2, wt - 1.6, 1.4, surf[1]); cv.ellipse(15, top - 0.1, wt - 4.5, 0.8, surf[2])
    if topping:
        topping(cv, top)
    if handle:
        for (x, y2) in ((24, 13), (25, 13), (26, 14), (27, 15), (27, 16), (27, 17), (26, 18), (25, 19), (24, 19)):
            cv.px(x, y2, INK)
        for (x, y2) in ((24, 14), (25, 14), (26, 15), (26, 16), (26, 17), (25, 18)):
            cv.px(x, y2, RAMPS["porcelain"][1])
    return cv


def cup_espresso():
    cv = layered_cup([("espresso", 0.75), ("crema", 0.25)], surface="crema", small=True)
    # crema swirl
    for (x, y) in ((13, 9), (14, 9), (15, 8), (17, 8), (18, 9), (19, 9)):
        cv.px(x, y, RAMPS["crema"][3])
    return save(cv, "cup_espresso")


def cup_americano():
    cv = layered_cup([("espresso", 0.18), ("coffee", 0.64), ("crema", 0.18)], surface="crema")
    for (x, y) in ((12, 9), (13, 8), (16, 8), (19, 9), (20, 9)):
        cv.px(x, y, RAMPS["crema"][3])
    return save(cv, "cup_americano")


def latte_art_top(cv, top):
    f = RAMPS["foam"]
    # tiny heart in the opening
    for (x, y) in ((14, top - 1), (15, top - 1), (17, top - 1), (18, top - 1), (14, top), (15, top), (16, top), (17, top), (18, top), (15, top + 1), (16, top + 1), (17, top + 1), (16, top + 2)):
        cv.px(x, y, f[3] if (x + y) % 2 else f[2])


def cup_latte():
    cv = layered_cup([("coffee", 0.25), ("milk", 0.6), ("foam", 0.15)], topping=latte_art_top, surface="coffee")
    return save(cv, "cup_latte")


def cap_top(cv, top):
    f = RAMPS["foam"]
    cv.ellipse(16, top - 0.4, 7.2, 1.5, f[2])
    cv.ellipse(15, top - 0.8, 4, 0.8, f[3])
    c = RAMPS["cocoa"]
    for (x, y) in ((14, top - 1), (16, top - 1), (18, top - 1), (15, top), (17, top), (16, top - 1)):
        cv.px(x, y, c[1])


def cup_cappuccino():
    cv = layered_cup([("coffee", 0.3), ("milk", 0.28), ("foam", 0.42)], topping=cap_top, surface="foam")
    return save(cv, "cup_cappuccino")


def cup_flat_white():
    cv = layered_cup([("coffee", 0.4), ("milk", 0.5), ("foam", 0.1)], topping=latte_art_top, surface="coffee")
    # smaller, tulip-ish: a thin brown ring on the cup
    return save(cv, "cup_flat_white")


def raf_top(cv, top):
    v = RAMPS["vanilla"]
    cv.ellipse(16, top - 0.2, 6.8, 1.4, v[2])
    for (x, y) in ((13, top), (15, top - 1), (17, top), (19, top - 1)):
        cv.px(x, y, v[3])
    for (x, y) in ((14, top - 1), (18, top)):
        cv.px(x, y, RAMPS["gold"][1])


def cup_raf():
    cv = layered_cup([("vanilla", 0.45), ("cream", 0.4), ("foam", 0.15)], topping=raf_top, surface="vanilla")
    return save(cv, "cup_raf")


def mocha_top(cv, top):
    c, f = RAMPS["cream"], RAMPS["foam"]
    # whipped cream swirl, three tiers, a choc drizzle
    cv.ellipse(16, top - 1, 6, 1.6, f[1]); cv.ellipse(16, top - 3, 4.4, 1.5, f[2]); cv.ellipse(16, top - 5, 2.6, 1.3, f[2])
    cv.px(16, top - 7, f[1]); cv.px(16, top - 6, f[3])
    cv.px(14, top - 2, f[3]); cv.px(15, top - 4, f[3])
    for (x, y) in ((13, top - 1), (15, top - 2), (17, top - 2), (19, top - 1), (16, top - 4)):
        cv.px(x, y, RAMPS["choc"][1])


def cup_mocha():
    cv = layered_cup([("choc", 0.35), ("coffee", 0.25), ("milk", 0.3), ("foam", 0.1)], topping=mocha_top, surface="choc")
    return save(cv, "cup_mocha")


def mac_top(cv, top):
    f, c = RAMPS["foam"], RAMPS["caramel"]
    cv.ellipse(16, top - 0.2, 7, 1.5, f[2])
    for i in range(-5, 6, 2):                           # caramel lattice
        cv.px(16 + i, top - 1, c[1]); cv.px(16 + i, top, c[2])
    for (x, y) in ((12, top - 1), (14, top), (18, top), (20, top - 1)):
        cv.px(x, y, c[0])


def cup_macchiato():
    cv = layered_cup([("coffee", 0.34), ("vanilla", 0.2), ("milk", 0.28), ("foam", 0.18)], topping=mac_top, surface="foam")
    # stripes show the layered espresso on the milk
    return save(cv, "cup_macchiato")


# =================================================================== build + preview
ALL = [coffee_beans, empty_cup, milk_carton, cream_carton, syrup_vanilla, syrup_caramel, chocolate,
       cup_espresso, cup_americano, cup_latte, cup_cappuccino, cup_flat_white, cup_raf, cup_mocha, cup_macchiato]


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    imgs = [fn() for fn in ALL]
    if len(sys.argv) > 1:
        k, cols = 6, 5
        rows = (len(imgs) + cols - 1) // cols
        sheet = Image.new("RGBA", (cols * 34 * k, rows * 34 * k), (74, 66, 62, 255))
        for i, im in enumerate(imgs):
            u = im.resize((32 * k, 32 * k), Image.NEAREST)
            sheet.paste(u, ((i % cols) * 34 * k + k, (i // cols) * 34 * k + k), u)
        sheet.save(sys.argv[1])
    print("ok:", len(imgs), "textures")


if __name__ == "__main__":
    main()
