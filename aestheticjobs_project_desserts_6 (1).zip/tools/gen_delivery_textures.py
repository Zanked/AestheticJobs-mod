#!/usr/bin/env python3
"""
Textures + block model of the supplier delivery:

  textures/block/supplier_terminal.png (64x32)  + models/block/supplier_terminal.json
  textures/item/delivery_box.png       (32x32)
  textures/entity/customer_8.png       (32x32)  the courier skin (same UV layout as the customers)

Run: python3 tools/gen_delivery_textures.py [preview.png]
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from PIL import Image, ImageDraw  # noqa: E402
import gen_cafe_items as base  # noqa: E402
import gen_desserts as ds  # noqa: E402
import gen_customer_textures as ct  # noqa: E402
from gen_cafe_items import Canvas, RAMPS, rgb  # noqa: E402

ASSETS = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "aestheticjobs")
INK = "#4a3228"


# ------------------------------------------------------------------ the courier skin
COURIER = dict(name="Courier", skin="#eec1a0", hair="#6a4a3a", iris="#6a8fb0", style="beanie", top=ct.MUSTARD, trim=ct.CREAM,
               bottom="#7a6a60", detail="stripe", dress=False, legs="#7a6a60", sock=None, shoes=ct.CREAM, extra=None,
               hat=ct.TERRA)


def courier_skin():
    im = ct.paint_customer(COURIER)
    im.save(os.path.join(ASSETS, "textures", "entity", "customer_8.png"))
    return im


# ------------------------------------------------------------------ the delivery box (item)
def delivery_box():
    cv = Canvas()
    ds.plate(cv, 28, 13, 2.6)
    # cardboard cube with a tape strip and a label
    ds.block(cv, 5, 11, 17, 14, 6, [("cap", 14)], "cap")
    tape = RAMPS["paper"]
    cv.rect(12, 11, 14, 24, tape[2])                          # tape across the front
    cv.rect(12, 11, 12, 24, tape[3])
    for dy in range(1, 7):                                    # ... and over the top
        cv.px(12 + dy, 11 - dy, tape[2]); cv.px(13 + dy, 11 - dy, tape[2]); cv.px(14 + dy, 11 - dy, tape[1])
    # label with a little cup
    lb = RAMPS["paper"]
    cv.rect(15, 16, 20, 21, lb[3]); cv.rect(15, 21, 20, 21, lb[1])
    cv.rect(16, 17, 18, 19, RAMPS["coffee"][1]); cv.px(19, 18, RAMPS["coffee"][1]); cv.px(16, 17, RAMPS["coffee"][3])
    # a heart-shaped sticker and a dashed edge
    for (x, y) in ((7, 15), (9, 15), (7, 16), (8, 16), (9, 16), (8, 17)):
        cv.px(x, y, RAMPS["berry"][1])
    cv.px(7, 15, RAMPS["berry"][3])
    cv.rect(6, 23, 10, 23, RAMPS["cap"][0]); cv.rect(7, 22, 9, 22, RAMPS["cap"][0])
    im = base.save(cv, "delivery_box")
    return im


# ------------------------------------------------------------------ the terminal (block)
def terminal():
    W, H = 64, 32
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    sg, cr, cp, ic, pa = RAMPS["sage"], RAMPS["porcelain"], RAMPS["cap"], RAMPS["ice"], RAMPS["paper"]

    def fill(x0, y0, x1, y1, c):
        d.rectangle([x0, y0, x1, y1], fill=rgb(c))

    def panel(x0, y0, x1, y1, ramp):
        fill(x0, y0, x1, y1, ramp[1])
        fill(x0, y0, x1, y0, ramp[2]); fill(x0, y0, x0, y1, ramp[2])
        fill(x0, y1, x1, y1, ramp[0]); fill(x1, y0, x1, y1, ramp[0])

    # cell sizes: side 12x11 @ (0,0), front 14x11 @ (16,0), back 14x11 @ (32,0), top 14x12 @ (0,16), bottom 14x12 @ (16,16)
    panel(0, 0, 11, 10, sg)
    fill(0, 5, 11, 5, sg[0])                                   # a seam
    fill(4, 7, 7, 9, cp[1]); fill(4, 7, 7, 7, cp[2]); fill(4, 9, 7, 9, cp[0]); fill(5, 7, 5, 9, pa[2])   # a box emblem

    panel(16, 0, 29, 10, sg)
    fill(17, 1, 28, 1, cr[2])                                  # cream trim on top
    fill(18, 3, 19, 4, ds.RAMPS["gold"][1]); fill(18, 3, 18, 3, ds.RAMPS["gold"][3])      # the "ready" light
    for i in range(3):                                         # keypad
        for j in range(2):
            fill(22 + i * 2, 3 + j * 2, 22 + i * 2, 3 + j * 2, cr[3])
            fill(23 + i * 2, 3 + j * 2, 23 + i * 2, 3 + j * 2, cr[1])
    fill(18, 6, 27, 9, INK)                                    # the hatch the courier uses
    fill(19, 7, 26, 8, "#2f1f19")
    fill(18, 6, 27, 6, cr[0])

    panel(32, 0, 45, 10, sg)
    for y in (2, 4, 6, 8):
        fill(34, y, 43, y, sg[0])                              # vents

    panel(0, 16, 13, 27, cr)
    fill(3, 19, 10, 24, cp[1]); fill(3, 19, 10, 19, cp[2]); fill(3, 24, 10, 24, cp[0])
    fill(6, 19, 7, 24, pa[2])                                  # tape on the top

    panel(16, 16, 29, 27, sg)
    fill(16, 16, 29, 27, sg[0])

    # monitor on top: front 10x5 @ (46,0), side 2x5 @ (58,0), top 10x2 @ (46,6), back 10x5 @ (46,9)
    fill(46, 0, 55, 4, ic[1])
    fill(46, 0, 55, 0, ic[0]); fill(46, 4, 55, 4, ic[0]); fill(46, 0, 46, 4, ic[0]); fill(55, 0, 55, 4, ic[0])
    cols = [RAMPS["berry"][1], ds.RAMPS["gold"][1], RAMPS["mint"][1], RAMPS["rose"][1], RAMPS["cap"][1], RAMPS["pink"][1]]
    for i in range(4):
        fill(47 + i * 2, 1, 48 + i * 2, 2, cols[i])
        fill(47 + i * 2, 3, 48 + i * 2, 3, ic[2])
    fill(58, 0, 59, 4, sg[0])
    fill(46, 6, 55, 7, cr[1])
    fill(46, 9, 55, 13, sg[0])
    return im


def terminal_model():
    """Block model (UVs in 0..16 of the 64x32 texture: px / 4 horizontally, px / 2 vertically)."""
    def uv(x0, y0, x1, y1):
        return [round(x0 / 4, 4), round(y0 / 2, 4), round(x1 / 4, 4), round(y1 / 2, 4)]

    def face(*px):
        return {"uv": uv(*px), "texture": "#t"}

    body = {
        "name": "body", "from": [1, 0, 2], "to": [15, 11, 14],
        "faces": {
            "north": face(16, 0, 30, 11), "south": face(32, 0, 46, 11),
            "east": face(0, 0, 12, 11), "west": face(0, 0, 12, 11),
            "up": face(0, 16, 14, 28), "down": face(16, 16, 30, 28)}}
    monitor = {
        "name": "monitor", "from": [3, 11, 6], "to": [13, 16, 8],
        "faces": {
            "north": face(46, 0, 56, 5), "south": face(46, 9, 56, 14),
            "east": face(58, 0, 60, 5), "west": face(58, 0, 60, 5),
            "up": face(46, 6, 56, 8), "down": face(46, 6, 56, 8)}}
    return {
        "texture_size": [64, 32],
        "textures": {"particle": "aestheticjobs:block/supplier_terminal", "t": "aestheticjobs:block/supplier_terminal"},
        "elements": [body, monitor],
        "display": {
            "gui": {"rotation": [30, 225, 0], "translation": [0, -1, 0], "scale": [0.62, 0.62, 0.62]},
            "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.25, 0.25, 0.25]},
            "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [0.5, 0.5, 0.5]},
            "thirdperson_righthand": {"rotation": [75, 45, 0], "translation": [0, 2.5, 0], "scale": [0.375, 0.375, 0.375]},
            "firstperson_righthand": {"rotation": [0, 45, 0], "translation": [0, 0, 0], "scale": [0.4, 0.4, 0.4]}}}


def main():
    os.makedirs(os.path.join(ASSETS, "textures", "block"), exist_ok=True)
    skin = courier_skin()
    box = delivery_box()
    tex = terminal()
    tex.save(os.path.join(ASSETS, "textures", "block", "supplier_terminal.png"))
    with open(os.path.join(ASSETS, "models", "block", "supplier_terminal.json"), "w") as f:
        json.dump(terminal_model(), f, indent=2)
    if len(sys.argv) > 1:
        sheet = Image.new("RGBA", (64 * 6 + 32 * 6 * 2 + 60, 32 * 6 + 20), (74, 66, 62, 255))
        t6 = tex.resize((64 * 6, 32 * 6), Image.NEAREST)
        sheet.paste(t6, (10, 10), t6)
        b6 = box.resize((32 * 6, 32 * 6), Image.NEAREST)
        sheet.paste(b6, (64 * 6 + 20, 10), b6)
        s6 = skin.resize((32 * 6, 32 * 6), Image.NEAREST)
        sheet.paste(s6, (64 * 6 + 32 * 6 + 30, 10), s6)
        sheet.save(sys.argv[1])
    print("ok")


if __name__ == "__main__":
    main()
