package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Server -> client: the animated receipt after a cup was served. total = what was paid for the cup (tip included),
 * bonuses = why the tip grew, prize = streak prize and task rewards on top of it.
 */
public record ReceiptPayload(int customer, int drink, int stars, long total, long tip, long prize, int streak,
                             int masteryUp, int guest, List<Bonus> bonuses, List<Integer> tasks) implements CustomPacketPayload {
    /** Kinds of bonus lines (the language key is hud.aestheticjobs.bonus.&lt;kind&gt;). */
    public static final int STREAK = 0, MASTERY = 1, DAILY = 2, GUEST = 3, WISH = 4, COMFORT = 5, HANDMADE = 6;

    public record Bonus(int kind, int percent) {}

    public static final Type<ReceiptPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "receipt"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ReceiptPayload> STREAM_CODEC =
            StreamCodec.of(ReceiptPayload::write, ReceiptPayload::read);

    private static void write(RegistryFriendlyByteBuf buf, ReceiptPayload p) {
        buf.writeVarInt(p.customer);
        buf.writeVarInt(p.drink);
        buf.writeVarInt(p.stars);
        buf.writeVarLong(p.total);
        buf.writeVarLong(p.tip);
        buf.writeVarLong(p.prize);
        buf.writeVarInt(p.streak);
        buf.writeVarInt(p.masteryUp);
        buf.writeVarInt(p.guest);
        buf.writeVarInt(p.bonuses.size());
        for (Bonus b : p.bonuses) {
            buf.writeVarInt(b.kind());
            buf.writeVarInt(b.percent());
        }
        buf.writeVarInt(p.tasks.size());
        for (int t : p.tasks) buf.writeVarInt(t);
    }

    private static ReceiptPayload read(RegistryFriendlyByteBuf buf) {
        int customer = buf.readVarInt(), drink = buf.readVarInt(), stars = buf.readVarInt();
        long total = buf.readVarLong(), tip = buf.readVarLong(), prize = buf.readVarLong();
        int streak = buf.readVarInt(), masteryUp = buf.readVarInt(), guest = buf.readVarInt();
        List<Bonus> bonuses = new ArrayList<>();
        for (int i = 0, n = Math.min(buf.readVarInt(), 16); i < n; i++) bonuses.add(new Bonus(buf.readVarInt(), buf.readVarInt()));
        List<Integer> tasks = new ArrayList<>();
        for (int i = 0, n = Math.min(buf.readVarInt(), 8); i < n; i++) tasks.add(buf.readVarInt());
        return new ReceiptPayload(customer, drink, stars, total, tip, prize, streak, masteryUp, guest, bonuses, tasks);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
