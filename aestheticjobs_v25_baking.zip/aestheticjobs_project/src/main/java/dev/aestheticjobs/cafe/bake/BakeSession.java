package dev.aestheticjobs.cafe.bake;

/**
 * What is going on in one pastry oven: IDLE -> MIX -> BAKE -> DECORATE -> IDLE (pure Java). Every method checks the
 * stage it belongs to, so a late or repeated click can never skip a step or hand out a dessert twice.
 */
public final class BakeSession {
    public enum Stage { IDLE, MIX, BAKE, DECORATE }
    /** What the block shows; the ordinal is the value of the block state. */
    public enum Look { IDLE, MIX, BAKING, GOLDEN, BURNT, DECORATE }
    public enum Pull { NOT_BAKING, RAW, TAKEN, BURNT }

    private Stage stage = Stage.IDLE;
    private String dessert = "croissant";
    private String owner = "";
    private String topping = "";
    private long stageStart;
    private long lastAction = -1000L;
    private int beats = -1, mixTotal, peeks, bakeScore;
    private boolean paid;

    public Stage stage() { return stage; }
    public String dessert() { return dessert; }
    public String owner() { return owner; }
    public String topping() { return topping; }
    public long stageStart() { return stageStart; }
    public long lastAction() { return lastAction; }
    /** Scored beats so far (-1 = the rhythm has not started yet). */
    public int beats() { return beats; }
    public int mixTotal() { return mixTotal; }
    public int peeks() { return peeks; }
    public int bakeScore() { return bakeScore; }
    /** The ingredients really came out of an inventory (creative mode takes nothing). */
    public boolean paid() { return paid; }

    public Baking.Category category() {
        return Baking.categoryOf(dessert);
    }

    public int mixScore() {
        return beats <= 0 ? 0 : Math.round(mixTotal / (float) beats);
    }

    /** Chooses what to make; only an empty station can be changed. */
    public boolean select(String id) {
        if (stage != Stage.IDLE || Baking.categoryOf(id) == null) return false;
        dessert = id;
        return true;
    }

    public boolean mayUse(String player, long now) {
        return stage == Stage.IDLE || owner.equals(player) || now - lastAction > Baking.ABANDONED_AFTER;
    }

    /** Another player took over an abandoned station. */
    public void claim(String player) {
        owner = player;
    }

    public boolean start(String player, long now, boolean takesIngredients) {
        if (stage != Stage.IDLE) return false;
        if (heldDown(now)) return false;
        stage = Stage.MIX;
        owner = player;
        paid = takesIngredients;
        stageStart = lastAction = now;
        beats = -1;
        mixTotal = peeks = bakeScore = 0;
        topping = "";
        return true;
    }

    /**
     * A stroke of the whisk. Returns the score of the beat, -1 for the first one (it sets the pace), -2 when the click
     * does not count. After the last beat the food goes into the oven.
     */
    public int beat(long now) {
        if (stage != Stage.MIX) return -2;
        if (beats >= 0 && now - lastAction < Baking.MIN_BEAT_GAP) return -2;
        int score = -1;
        if (beats >= 0) {
            score = Baking.beatScore(now - lastAction, category().tempo());
            mixTotal += score;
        }
        beats++;
        lastAction = now;
        if (beats >= Baking.BEATS) {
            stage = Stage.BAKE;
            stageStart = now;
        }
        return score;
    }

    public Pull pull(long now) {
        if (stage != Stage.BAKE) return Pull.NOT_BAKING;
        long elapsed = now - stageStart;
        int ideal = category().bakeTicks();
        if (heldDown(now)) return Pull.NOT_BAKING;             // the whisk's last clicks do not open the door
        lastAction = now;
        if (elapsed < Baking.SETTLE) return Pull.NOT_BAKING;
        if (Baking.raw(elapsed, ideal)) {
            peeks++;
            return Pull.RAW;
        }
        if (Baking.burnt(elapsed, ideal)) {
            reset();
            return Pull.BURNT;
        }
        bakeScore = Baking.bakeScore(elapsed, ideal);
        stage = Stage.DECORATE;
        stageStart = now;
        topping = Baking.TOPPINGS.get((int) Math.floorMod(now + dessert.hashCode(), (long) Baking.TOPPINGS.size()));
        return Pull.TAKEN;
    }

    /** Ends the recipe: returns the quality, or -1 when there is nothing to finish. */
    public int finish(boolean topped, long now) {
        if (stage != Stage.DECORATE || heldDown(now)) return -1;
        int quality = Baking.quality(mixScore(), bakeScore, peeks, topped);
        lastAction = now;
        reset();
        return quality;
    }

    /**
     * A held mouse button repeats the click every 4 ticks: a click this soon after the last step is not a new decision.
     * It pushes the guard further, so holding the button never walks through the steps.
     */
    private boolean heldDown(long now) {
        if (now < lastAction || now - lastAction >= Baking.STEP_GUARD) return false;
        lastAction = now;
        return true;
    }

    /** Should the ingredients drop when the block is broken now? Not for an empty station and not for charcoal. */
    public boolean refundable(long now) {
        if (!paid || stage == Stage.IDLE) return false;
        return stage != Stage.BAKE || !Baking.burnt(now - stageStart, category().bakeTicks());
    }

    public Look look(long now) {
        return switch (stage) {
            case IDLE -> Look.IDLE;
            case MIX -> Look.MIX;
            case DECORATE -> Look.DECORATE;
            case BAKE -> {
                long elapsed = now - stageStart;
                int ideal = category().bakeTicks();
                if (Baking.burnt(elapsed, ideal)) yield Look.BURNT;
                yield elapsed >= ideal - Baking.PERFECT && elapsed <= ideal + Baking.PERFECT ? Look.GOLDEN : Look.BAKING;
            }
        };
    }

    public void reset() {
        stage = Stage.IDLE;
        owner = "";
        topping = "";
        beats = -1;
        mixTotal = peeks = bakeScore = 0;
        paid = false;
    }

    /** Restores a saved session; anything that does not make sense becomes an empty station. */
    public void load(int savedStage, String savedDessert, String savedOwner, String savedTopping, long start, long last,
                     int savedBeats, int total, int savedPeeks, int score, boolean savedPaid) {
        reset();
        if (Baking.categoryOf(savedDessert) != null) dessert = savedDessert;
        else return;
        if (savedStage <= 0 || savedStage >= Stage.values().length) return;
        stage = Stage.values()[savedStage];
        owner = savedOwner;
        topping = Baking.TOPPINGS.contains(savedTopping) ? savedTopping : Baking.TOPPINGS.get(0);
        stageStart = start;
        lastAction = last;
        beats = Math.max(-1, Math.min(Baking.BEATS, savedBeats));
        mixTotal = Math.max(0, total);
        peeks = Math.max(0, savedPeeks);
        bakeScore = Math.max(0, Math.min(100, score));
        paid = savedPaid;
    }
}
