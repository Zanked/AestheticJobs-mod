package dev.aestheticjobs.cafe.bake;

import java.util.List;

/**
 * The recipes and scores of the pastry oven (pure Java, no Minecraft types; tested by tools/tests/BakingTest).
 * Items are named by their registry ids.
 */
public final class Baking {
    /** Beats of the whisk that are scored (the first click only starts the rhythm). */
    public static final int BEATS = 6;
    /** A click closer than this to the previous one is ignored (a double fire, not a beat). */
    public static final int MIN_BEAT_GAP = 3;
    /** Ticks that must pass before a click may start, open or finish something. */
    public static final int STEP_GUARD = 9;
    /** Right after the dough went in the door stays shut, so one whisk stroke too many costs nothing. */
    public static final int SETTLE = 30;
    /** Ticks around the ideal moment: inside PERFECT the bake is flawless, inside GOOD it is still fine. */
    public static final int PERFECT = 20, GOOD = 60, BURNT_AFTER = 140;
    /** Another player may take over a station nobody touched for this long. */
    public static final long ABANDONED_AFTER = 600L;
    public static final int PEEK_PENALTY = 8, TOPPING_BONUS = 10, NO_TOPPING_MAX = 84;

    public static final String WHEAT = "minecraft:wheat", EGG = "minecraft:egg", SUGAR = "minecraft:sugar",
            COCOA = "minecraft:cocoa_beans", APPLE = "minecraft:apple", MILK = "aestheticjobs:milk_carton",
            CREAM = "aestheticjobs:cream_carton", BERRIES = "minecraft:sweet_berries";
    public static final List<String> TOPPINGS = List.of(SUGAR, COCOA, BERRIES);

    /** A family of desserts: the same ingredients, rhythm (ticks between beats) and baking time. */
    public enum Category {
        BUNS("buns", 10, 160, List.of(WHEAT, EGG, SUGAR),
                "croissant", "donut_pink", "donut_choc", "muffin_blueberry", "cream_puff", "eclair", "cinnamon_roll"),
        COOKIES("cookies", 9, 120, List.of(WHEAT, SUGAR, COCOA),
                "cookie_choc", "cookie_heart", "gingerbread_man", "macaron_pink", "macaron_mint", "macaron_lemon"),
        CAKES("cakes", 12, 220, List.of(WHEAT, EGG, MILK),
                "cupcake_pink", "cupcake_choc", "cake_pop", "cheesecake", "cake_strawberry", "cake_choc", "tiramisu", "medovik"),
        PIES("pies", 11, 200, List.of(WHEAT, APPLE, SUGAR),
                "apple_pie", "brownie", "waffle", "pancakes", "fruit_tart", "baklava"),
        CREAMS("creams", 14, 180, List.of(CREAM, EGG, SUGAR),
                "ice_cream_cone", "sundae", "creme_brulee", "panna_cotta", "flan");

        private final String id;
        private final int tempo, bakeTicks;
        private final List<String> ingredients, desserts;

        Category(String id, int tempo, int bakeTicks, List<String> ingredients, String... desserts) {
            this.id = id;
            this.tempo = tempo;
            this.bakeTicks = bakeTicks;
            this.ingredients = ingredients;
            this.desserts = List.of(desserts);
        }

        public String id() { return id; }
        public int tempo() { return tempo; }
        public int bakeTicks() { return bakeTicks; }
        public List<String> ingredients() { return ingredients; }
        public List<String> desserts() { return desserts; }

        public Category next() {
            return values()[(ordinal() + 1) % values().length];
        }
    }

    private Baking() {}

    /** The family of a dessert, null for an unknown id. */
    public static Category categoryOf(String dessert) {
        for (Category c : Category.values()) {
            if (c.desserts.contains(dessert)) return c;
        }
        return null;
    }

    /** The next dessert of the same family (round and round). */
    public static String nextDessert(String dessert) {
        Category c = categoryOf(dessert);
        if (c == null) return Category.BUNS.desserts.get(0);
        return c.desserts.get((c.desserts.indexOf(dessert) + 1) % c.desserts.size());
    }

    public static boolean isIngredient(String item) {
        for (Category c : Category.values()) {
            if (c.ingredients.contains(item)) return true;
        }
        return false;
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(100, v));
    }

    /** One beat: how close the time since the last click is to the rhythm. Two ticks of slack cover the network. */
    public static int beatScore(long gap, int tempo) {
        long off = Math.abs(gap - tempo);
        return off <= 2 ? 100 : clamp((int) (100 - (off - 2) * 18));
    }

    /** How good it is to take the food out "elapsed" ticks after it went in (only meaningful between raw and burnt). */
    public static int bakeScore(long elapsed, int ideal) {
        long off = Math.abs(elapsed - ideal);
        if (off <= PERFECT) return 100;
        if (off <= GOOD) return (int) (99 - 29 * (off - PERFECT) / (GOOD - PERFECT));
        return elapsed < ideal ? 0 : 40;
    }

    public static boolean raw(long elapsed, int ideal) {
        return elapsed < ideal - GOOD;
    }

    public static boolean burnt(long elapsed, int ideal) {
        return elapsed > ideal + BURNT_AFTER;
    }

    public static int quality(int mix, int bake, int peeks, boolean topped) {
        int q = clamp(Math.round(mix * 0.45F + bake * 0.55F) - peeks * PEEK_PENALTY);
        return topped ? clamp(q + TOPPING_BONUS) : Math.min(q, NO_TOPPING_MAX);
    }

    /** Extra tip (percent) for serving a plate somebody baked by hand. */
    public static int handmadeBonus(int stars) {
        return stars >= 5 ? 20 : stars == 4 ? 10 : 0;
    }

    public static int stars(int quality) {
        return quality >= 90 ? 5 : quality >= 75 ? 4 : quality >= 55 ? 3 : quality >= 35 ? 2 : 1;
    }
}
