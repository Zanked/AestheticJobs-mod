package dev.aestheticjobs.block;

import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.CupData;
import dev.aestheticjobs.cafe.Plate;
import dev.aestheticjobs.cafe.bake.BakeSession;
import dev.aestheticjobs.cafe.bake.Baking;
import dev.aestheticjobs.entity.CafeStaffEntity;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.job.Shift;
import dev.aestheticjobs.registry.ModBlockEntities;
import dev.aestheticjobs.registry.ModComponents;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * The server side of the pastry oven. All rules are in {@link BakeSession}; this class takes the ingredients, gives out
 * the dessert, keeps the block's look up to date and sends the session to the clients (for the hint panel and renderer).
 * Idle ovens do no work in their tick.
 */
public class PastryOvenBlockEntity extends BlockEntity {
    private final BakeSession session = new BakeSession();

    // client only: the rhythm shown on the hint panel is counted from the player's own click, so lag does not shift it
    private int clientTicks;
    private int clientClick = -1;

    public PastryOvenBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.PASTRY_OVEN.get(), pos, state);
    }

    public BakeSession session() {
        return session;
    }

    public int clientTicks() {
        return clientTicks;
    }

    /** Client ticks since the last own click, -1 when there was none. */
    public int sinceClick() {
        return clientClick < 0 ? -1 : clientTicks - clientClick;
    }

    public void clientClicked() {
        if (clientClick < 0 || clientTicks - clientClick >= Baking.MIN_BEAT_GAP) clientClick = clientTicks;
    }

    // ------------------------------------------------------------------ the player's click

    public void use(ServerPlayer player) {
        if (!(level instanceof ServerLevel sl)) return;
        long now = sl.getGameTime();
        String me = player.getUUID().toString();
        if (!session.mayUse(me, now)) {
            tell(player, Component.translatable("bake.aestheticjobs.busy"));
            return;
        }
        if (session.stage() != BakeSession.Stage.IDLE && !session.owner().equals(me)) session.claim(me);
        if (CafeLogic.isWorking(player)) Shift.touch(player);
        ItemStack held = player.getMainHandItem();
        String heldId = held.isEmpty() ? "" : BuiltInRegistries.ITEM.getKey(held.getItem()).toString();
        switch (session.stage()) {
            case IDLE -> idleClick(sl, player, held, heldId, now);
            case MIX -> whisk(sl, now);
            case BAKE -> open(sl, player, now);
            case DECORATE -> decorate(sl, player, held, heldId, now);
        }
    }

    private void idleClick(ServerLevel sl, ServerPlayer player, ItemStack held, String heldId, long now) {
        if (session.category().ingredients().contains(heldId)) {
            start(sl, player, now);
        } else if (Baking.isIngredient(heldId)) {
            tell(player, Component.translatable("bake.aestheticjobs.wrong_ingredient", dessert(session.dessert()).displayName()));
        } else if (player.isShiftKeyDown()) {
            session.select(session.category().next().desserts().get(0));
            play(sl, SoundEvents.BOOK_PAGE_TURN, 0.8F, 0.9F);
            changed();
        } else if (held.isEmpty()) {
            session.select(Baking.nextDessert(session.dessert()));
            play(sl, SoundEvents.BOOK_PAGE_TURN, 0.6F, 1.3F);
            changed();
        }
    }

    private void start(ServerLevel sl, ServerPlayer player, long now) {
        boolean free = player.getAbilities().instabuild;
        List<String> needed = session.category().ingredients();
        if (!free) {
            for (String id : needed) {
                if (find(player, item(id)).isEmpty()) {
                    tell(player, Component.translatable("bake.aestheticjobs.missing", item(id).getDescription()));
                    return;
                }
            }
        }
        if (!session.start(player.getUUID().toString(), now, !free)) return;
        if (!free) {
            for (String id : needed) find(player, item(id)).shrink(1);
        }
        play(sl, SoundEvents.WOOL_PLACE, 0.8F, 1.4F);
        puff(sl, ParticleTypes.POOF, 6, 1.0);
        changed();
    }

    private void whisk(ServerLevel sl, long now) {
        int score = session.beat(now);
        if (score == -2) return;
        // the better the beat, the higher the note
        play(sl, SoundEvents.SLIME_BLOCK_STEP, 0.7F, score < 0 ? 1.0F : 0.7F + score / 140.0F);
        puff(sl, score >= 80 ? ParticleTypes.HAPPY_VILLAGER : ParticleTypes.POOF, score >= 80 ? 4 : 2, 0.95);
        if (session.stage() == BakeSession.Stage.BAKE) play(sl, SoundEvents.IRON_TRAPDOOR_CLOSE, 0.7F, 1.2F);
        changed();
    }

    private void open(ServerLevel sl, ServerPlayer player, long now) {
        switch (session.pull(now)) {
            case RAW -> {
                tell(player, Component.translatable("bake.aestheticjobs.raw", Baking.PEEK_PENALTY));
                play(sl, SoundEvents.IRON_TRAPDOOR_OPEN, 0.5F, 1.5F);
                changed();
            }
            case BURNT -> {
                tell(player, Component.translatable("bake.aestheticjobs.burnt"));
                player.getInventory().placeItemBackInInventory(new ItemStack(net.minecraft.world.item.Items.CHARCOAL));
                play(sl, SoundEvents.FIRE_EXTINGUISH, 0.6F, 0.9F);
                puff(sl, ParticleTypes.LARGE_SMOKE, 12, 0.9);
                changed();
            }
            case TAKEN -> {
                play(sl, SoundEvents.IRON_TRAPDOOR_OPEN, 0.8F, 1.1F);
                puff(sl, ParticleTypes.CLOUD, 5, 1.0);
                changed();
            }
            case NOT_BAKING -> {}
        }
    }

    private void decorate(ServerLevel sl, ServerPlayer player, ItemStack held, String heldId, long now) {
        boolean topped = heldId.equals(session.topping());
        if (!topped && !held.isEmpty()) {
            tell(player, Component.translatable("bake.aestheticjobs.need_topping", item(session.topping()).getDescription()));
            return;
        }
        Dessert dessert = dessert(session.dessert());
        Baking.Category category = session.category();
        int quality = session.finish(topped, now);
        if (quality < 0 || dessert == null) return;
        if (topped && !player.getAbilities().instabuild) held.shrink(1);
        int stars = Baking.stars(quality);
        if (CafeLogic.isWorking(player)) {
            Plate plate = new Plate(dessert.ordinal(), now + CafeStaffEntity.PLATE_LIFE, stars);
            player.getInventory().placeItemBackInInventory(CafeLogic.makePlate(plate));
        } else {
            player.getInventory().placeItemBackInInventory(treat(dessert, category, stars));
        }
        tell(player, Component.translatable("bake.aestheticjobs.done", dessert.displayName(), CupData.starText(stars)));
        play(sl, SoundEvents.EXPERIENCE_ORB_PICKUP, 0.8F, 0.8F + stars * 0.12F);
        puff(sl, stars >= 5 ? ParticleTypes.HEART : ParticleTypes.HAPPY_VILLAGER, 3 + stars * 2, 1.15);
        if (stars >= 5) play(sl, SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F, 1.2F);
        changed();
    }

    /**
     * The desserts for a player who is not at work: one below three stars, two from three stars on. Five stars make them a
     * masterpiece with a short pleasant effect of their family (given by cafe/CafeTreat when it is eaten).
     */
    private static ItemStack treat(Dessert dessert, Baking.Category category, int stars) {
        ItemStack stack = new ItemStack(dessert.item(), stars >= 3 ? 2 : 1);
        if (stars < 5) return stack;
        stack.set(ModComponents.MASTERPIECE.get(), category.ordinal());
        stack.set(DataComponents.LORE, new ItemLore(List.of(
                Component.translatable("bake.aestheticjobs.masterpiece").withStyle(ChatFormatting.GOLD),
                Component.translatable("bake.aestheticjobs.effect." + category.id()).withStyle(ChatFormatting.GRAY))));
        return stack;
    }

    public void dropIngredients() {
        if (level == null || !session.refundable(level.getGameTime())) return;
        for (String id : session.category().ingredients()) Block.popResource(level, worldPosition, new ItemStack(item(id)));
        session.reset();
    }

    // ------------------------------------------------------------------ helpers

    public static Item item(String id) {
        return BuiltInRegistries.ITEM.get(ResourceLocation.parse(id));
    }

    public static Dessert dessert(String id) {
        for (Dessert d : Dessert.values()) {
            if (d.id().equals(id)) return d;
        }
        return null;
    }

    /** A stack of the item anywhere in the inventory, the off hand included. */
    private static ItemStack find(ServerPlayer player, Item item) {
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack s = player.getInventory().getItem(i);
            if (s.is(item)) return s;
        }
        return ItemStack.EMPTY;
    }

    private static void tell(ServerPlayer player, Component message) {
        player.displayClientMessage(message, true);
    }

    private void play(ServerLevel sl, SoundEvent sound, float volume, float pitch) {
        sl.playSound(null, worldPosition, sound, SoundSource.BLOCKS, volume, pitch);
    }

    private void puff(ServerLevel sl, ParticleOptions particle, int count, double height) {
        sl.sendParticles(particle, worldPosition.getX() + 0.5, worldPosition.getY() + height, worldPosition.getZ() + 0.5,
                count, 0.2, 0.1, 0.2, 0.01);
    }

    private void changed() {
        if (level == null) return;
        setChanged();
        BlockState state = getBlockState();
        int look = session.look(level.getGameTime()).ordinal();
        if (state.getValue(PastryOvenBlock.LOOK) != look) {
            state = state.setValue(PastryOvenBlock.LOOK, look);
            level.setBlock(worldPosition, state, Block.UPDATE_ALL);
        }
        level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_CLIENTS);
    }

    // ------------------------------------------------------------------ ticking

    public static void serverTick(Level level, BlockPos pos, BlockState state, PastryOvenBlockEntity oven) {
        if (oven.session.stage() != BakeSession.Stage.BAKE || !(level instanceof ServerLevel sl)) return;
        long now = level.getGameTime();
        if (now % 4 != 0) return;
        BakeSession.Look look = oven.session.look(now);
        if (state.getValue(PastryOvenBlock.LOOK) != look.ordinal()) {
            level.setBlock(pos, state.setValue(PastryOvenBlock.LOOK, look.ordinal()), Block.UPDATE_ALL);
            if (look == BakeSession.Look.GOLDEN) oven.play(sl, SoundEvents.AMETHYST_BLOCK_CHIME, 1.4F, 1.5F);
            if (look == BakeSession.Look.BURNT) oven.play(sl, SoundEvents.FIRE_EXTINGUISH, 0.5F, 0.7F);
        }
        if (now % 12 == 0) {
            if (look == BakeSession.Look.GOLDEN) oven.puff(sl, ParticleTypes.WAX_ON, 4, 0.85);
            else if (look == BakeSession.Look.BURNT) oven.puff(sl, ParticleTypes.LARGE_SMOKE, 2, 1.0);
        }
        if (look == BakeSession.Look.BAKING && now % 40 == 0) oven.play(sl, SoundEvents.FURNACE_FIRE_CRACKLE, 0.6F, 1.0F);
    }

    /** The metronome: a soft tick one beat after the player's own click. */
    public static void clientTick(Level level, BlockPos pos, BlockState state, PastryOvenBlockEntity oven) {
        oven.clientTicks++;
        if (oven.session.stage() != BakeSession.Stage.MIX) return;
        int since = oven.sinceClick();
        int tempo = oven.session.category().tempo();
        if (since > 0 && since <= tempo * 3 && since % tempo == 0) {
            level.playLocalSound(pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5,
                    SoundEvents.NOTE_BLOCK_HAT.value(), SoundSource.BLOCKS, 0.8F, 1.4F, false);
        }
    }

    // ------------------------------------------------------------------ saving and syncing

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("stage", session.stage().ordinal());
        tag.putString("dessert", session.dessert());
        tag.putString("owner", session.owner());
        tag.putString("topping", session.topping());
        tag.putLong("start", session.stageStart());
        tag.putLong("last", session.lastAction());
        tag.putInt("beats", session.beats());
        tag.putInt("mix", session.mixTotal());
        tag.putInt("peeks", session.peeks());
        tag.putInt("baked", session.bakeScore());
        tag.putBoolean("paid", session.paid());
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        session.load(tag.getInt("stage"), tag.getString("dessert"), tag.getString("owner"), tag.getString("topping"),
                tag.getLong("start"), tag.getLong("last"), tag.getInt("beats"), tag.getInt("mix"), tag.getInt("peeks"),
                tag.getInt("baked"), tag.getBoolean("paid"));
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
