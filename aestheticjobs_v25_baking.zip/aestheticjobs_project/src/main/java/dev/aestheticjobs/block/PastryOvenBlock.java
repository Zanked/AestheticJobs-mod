package dev.aestheticjobs.block;

import com.mojang.serialization.MapCodec;
import dev.aestheticjobs.cafe.bake.BakeSession;
import dev.aestheticjobs.registry.ModBlockEntities;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * The pastry oven: a player bakes any dessert of the cafe on it, right in the world (no window).
 * Choose, add the ingredients, whisk in rhythm, take it out golden, decorate. See {@link PastryOvenBlockEntity}.
 */
public class PastryOvenBlock extends HorizontalDirectionalBlock implements EntityBlock {
    public static final MapCodec<PastryOvenBlock> CODEC = simpleCodec(PastryOvenBlock::new);
    /** BakeSession.Look as a number: idle, mixing bowl, baking, golden, burnt, decorating. */
    public static final IntegerProperty LOOK = IntegerProperty.create("look", 0, BakeSession.Look.values().length - 1);

    private static final VoxelShape SHAPE = Block.box(1, 0, 1, 15, 12, 15);

    public PastryOvenBlock(BlockBehaviour.Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(LOOK, 0));
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, LOOK);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new PastryOvenBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (type != ModBlockEntities.PASTRY_OVEN.get()) return null;
        if (level.isClientSide) {
            return (lvl, pos, st, be) -> PastryOvenBlockEntity.clientTick(lvl, pos, st, (PastryOvenBlockEntity) be);
        }
        return (lvl, pos, st, be) -> PastryOvenBlockEntity.serverTick(lvl, pos, st, (PastryOvenBlockEntity) be);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }

    @Override
    protected BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }

    /** Every click with the main hand belongs to the oven, so eggs are not thrown and apples are not eaten at it. */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        if (hand != InteractionHand.MAIN_HAND) return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        use(level, pos, player);
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        use(level, pos, player);
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    private static void use(Level level, BlockPos pos, Player player) {
        if (!(level.getBlockEntity(pos) instanceof PastryOvenBlockEntity oven)) return;
        if (player instanceof ServerPlayer server) oven.use(server);
        else if (level.isClientSide) oven.clientClicked();
    }

    /** A broken oven gives back what is being made in it. */
    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide
                && level.getBlockEntity(pos) instanceof PastryOvenBlockEntity oven) {
            oven.dropIngredients();
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }
}
