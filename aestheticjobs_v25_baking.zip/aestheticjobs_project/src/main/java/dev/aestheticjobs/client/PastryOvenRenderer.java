package dev.aestheticjobs.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.aestheticjobs.block.PastryOvenBlock;
import dev.aestheticjobs.block.PastryOvenBlockEntity;
import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.bake.BakeSession;
import dev.aestheticjobs.item.Dessert;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/**
 * Shows the real 3D dessert: turning above an idle oven (what will be made), inside the open window while it bakes
 * (glowing when golden, black when burnt) and on its plate on the counter while it waits for the topping.
 * The places are the ones of tools/gen_oven.py.
 */
public class PastryOvenRenderer implements BlockEntityRenderer<PastryOvenBlockEntity> {
    private final ItemRenderer items;
    private final ItemStack[] desserts = new ItemStack[Dessert.values().length];
    private final ItemStack[] plates = new ItemStack[Dessert.values().length];

    public PastryOvenRenderer(BlockEntityRendererProvider.Context context) {
        this.items = context.getItemRenderer();
    }

    @Override
    public void render(PastryOvenBlockEntity oven, float pt, PoseStack pose, MultiBufferSource buffers, int light, int overlay) {
        BakeSession session = oven.session();
        Dessert dessert = PastryOvenBlockEntity.dessert(session.dessert());
        if (dessert == null || oven.getLevel() == null) return;
        int look = oven.getBlockState().getValue(PastryOvenBlock.LOOK);
        float time = oven.clientTicks() + pt;

        pose.pushPose();
        pose.translate(0.5, 0.0, 0.5);
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - oven.getBlockState().getValue(PastryOvenBlock.FACING).toYRot()));
        switch (session.stage()) {
            case IDLE -> {
                float bob = (float) Math.sin(time * 0.08F) * 0.02F;
                draw(oven, pose, buffers, stack(dessert), 0.0, 0.86 + bob, -0.06, 0.42F, time * 1.5F, light, overlay);
            }
            case MIX -> draw(oven, pose, buffers, stack(dessert), 0.0, 1.06, -0.06, 0.26F, time * 3.0F, light, overlay);
            case BAKE -> {
                int glow = look == BakeSession.Look.GOLDEN.ordinal() ? LightTexture.FULL_BRIGHT
                        : look == BakeSession.Look.BURNT.ordinal() ? 0 : LightTexture.pack(11, 8);
                draw(oven, pose, buffers, stack(dessert), 0.0, 2.0 / 16.0, -0.27, 0.36F, 180.0F, glow, overlay);
            }
            case DECORATE -> draw(oven, pose, buffers, plate(dessert), 0.0, 12.0 / 16.0, -0.06, 0.55F, time * 1.0F, light, overlay);
        }
        pose.popPose();
    }

    /** Draws the item model with its bottom at (x, y, z), turned around its own axis. */
    private void draw(PastryOvenBlockEntity oven, PoseStack pose, MultiBufferSource buffers, ItemStack stack,
                      double x, double y, double z, float scale, float turn, int light, int overlay) {
        pose.pushPose();
        pose.translate(x, y + 0.5 * scale, z);
        pose.mulPose(Axis.YP.rotationDegrees(turn));
        pose.scale(scale, scale, scale);
        items.renderStatic(stack, ItemDisplayContext.NONE, light, overlay, pose, buffers, oven.getLevel(), 0);
        pose.popPose();
    }

    private ItemStack stack(Dessert d) {
        ItemStack s = desserts[d.ordinal()];
        if (s == null) desserts[d.ordinal()] = s = new ItemStack(d.item());
        return s;
    }

    private ItemStack plate(Dessert d) {
        ItemStack s = plates[d.ordinal()];
        if (s == null) plates[d.ordinal()] = s = CafeLogic.makePlate(d.ordinal(), Long.MAX_VALUE);
        return s;
    }

    @Override
    public int getViewDistance() {
        return 32;
    }
}
