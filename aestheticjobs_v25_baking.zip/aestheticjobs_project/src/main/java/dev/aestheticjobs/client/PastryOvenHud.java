package dev.aestheticjobs.client;

import dev.aestheticjobs.block.PastryOvenBlock;
import dev.aestheticjobs.block.PastryOvenBlockEntity;
import dev.aestheticjobs.cafe.bake.BakeSession;
import dev.aestheticjobs.cafe.bake.Baking;
import dev.aestheticjobs.item.Dessert;
import java.util.List;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/** The little recipe card under the crosshair while the player looks at a pastry oven: what to do now. */
public final class PastryOvenHud {
    private static final int W = 176;
    private static final int PAPER = 0xF0FFF8E8, FRAME = 0xFF8A6450, INK = 0xFF4A342C, SOFT = 0xFF8C7466,
            GOOD = 0xFF4E8A4A, BAD = 0xFFB0483C, GOLD = 0xFFD9A02E;

    private PastryOvenHud() {}

    public static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || mc.screen != null || mc.options.hideGui) return;
        if (!(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        if (!(mc.level.getBlockEntity(hit.getBlockPos()) instanceof PastryOvenBlockEntity oven)) return;
        BakeSession s = oven.session();
        Dessert dessert = PastryOvenBlockEntity.dessert(s.dessert());
        if (dessert == null) return;

        Font font = mc.font;
        int x = g.guiWidth() / 2 - W / 2, y = g.guiHeight() / 2 + 16;
        boolean mine = s.stage() == BakeSession.Stage.IDLE || s.owner().equals(player.getUUID().toString());
        switch (s.stage()) {
            case IDLE -> {
                card(g, font, x, y, 70, dessert.displayName());
                line(g, font, x, y + 17, Component.translatable("bake.aestheticjobs.family." + s.category().id()), SOFT);
                List<String> needed = s.category().ingredients();
                int ix = x + W / 2 - needed.size() * 11;
                for (String id : needed) {
                    Item item = PastryOvenBlockEntity.item(id);
                    boolean has = player.getAbilities().instabuild || carries(player, item);
                    g.fill(ix + 1, y + 28, ix + 21, y + 48, has ? 0x554E8A4A : 0x55B0483C);
                    g.renderItem(new ItemStack(item), ix + 3, y + 30);
                    ix += 22;
                }
                line(g, font, x, y + 50, Component.translatable("bake.aestheticjobs.hint.start"), INK);
                line(g, font, x, y + 60, Component.translatable("bake.aestheticjobs.hint.choose"), SOFT);
            }
            case MIX -> {
                card(g, font, x, y, 62, Component.translatable("bake.aestheticjobs.mix"));
                int tempo = s.category().tempo();
                int since = oven.sinceClick();
                // the track: the dot runs from the left to the mark in exactly one beat
                int left = x + 12, mark = x + W - 40, top = y + 20;
                g.fill(left, top + 3, x + W - 12, top + 5, 0x558A6450);
                g.fill(mark - 4, top - 1, mark + 5, top + 9, 0x66D9A02E);
                g.fill(mark, top - 2, mark + 1, top + 10, GOLD);
                boolean now = false;
                if (since >= 0) {
                    float t = Math.min(since + delta.getGameTimeDeltaPartialTick(false), tempo * 1.4F);
                    int dot = left + Math.round((mark - left) * t / tempo);
                    now = Math.abs(t - tempo) <= 2.0F;
                    g.fill(dot - 3, top + 1, dot + 4, top + 7, now ? GOOD : INK);
                }
                int done = Math.max(0, s.beats());
                for (int i = 0; i < Baking.BEATS; i++) {
                    int bx = x + W / 2 - Baking.BEATS * 6 + i * 12;
                    g.fill(bx + 2, y + 34, bx + 10, y + 40, i < done ? GOLD : 0x558A6450);
                }
                line(g, font, x, y + 43, s.beats() > 0
                        ? Component.translatable("bake.aestheticjobs.rhythm", s.mixScore())
                        : Component.translatable("bake.aestheticjobs.hint.first"), INK);
                line(g, font, x, y + 52, Component.translatable(now ? "bake.aestheticjobs.hint.now" : "bake.aestheticjobs.hint.beat"),
                        now ? GOOD : SOFT);
            }
            case BAKE -> {
                int look = oven.getBlockState().getValue(PastryOvenBlock.LOOK);
                String key = look == BakeSession.Look.GOLDEN.ordinal() ? "golden"
                        : look == BakeSession.Look.BURNT.ordinal() ? "burning" : "baking";
                card(g, font, x, y, 38, dessert.displayName());
                line(g, font, x, y + 17, Component.translatable("bake.aestheticjobs." + key),
                        key.equals("golden") ? GOOD : key.equals("burning") ? BAD : INK);
                line(g, font, x, y + 27, Component.translatable("bake.aestheticjobs.hint." + key), SOFT);
            }
            case DECORATE -> {
                Item topping = PastryOvenBlockEntity.item(s.topping());
                card(g, font, x, y, 60, Component.translatable("bake.aestheticjobs.decorate"));
                g.renderItem(new ItemStack(topping), x + W / 2 - 8, y + 17);
                line(g, font, x, y + 36, Component.translatable("bake.aestheticjobs.hint.topping", topping.getDescription()), INK);
                line(g, font, x, y + 47, Component.translatable("bake.aestheticjobs.hint.plain"), SOFT);
            }
        }
        if (!mine) line(g, font, x, y - 12, Component.translatable("bake.aestheticjobs.busy"), 0xFFFFD0C0);
    }

    private static boolean carries(LocalPlayer player, Item item) {
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            if (player.getInventory().getItem(i).is(item)) return true;
        }
        return false;
    }

    private static void card(GuiGraphics g, Font font, int x, int y, int h, Component title) {
        g.fill(x + 2, y + 3, x + W + 2, y + h + 3, 0x55000000);
        g.fill(x - 1, y - 1, x + W + 1, y + h + 1, FRAME);
        g.fill(x, y, x + W, y + h, PAPER);
        g.fill(x, y, x + W, y + 13, FRAME);
        line(g, font, x, y + 3, title, 0xFFFFF6E2);
    }

    /** One centred line; a text wider than the card is shrunk to fit. */
    private static void line(GuiGraphics g, Font font, int x, int y, Component text, int color) {
        int width = font.width(text);
        float k = Math.min(1.0F, (W - 6) / (float) Math.max(1, width));
        g.pose().pushPose();
        g.pose().translate(x + W / 2.0F - width * k / 2.0F, y, 0.0F);
        g.pose().scale(k, k, 1.0F);
        g.drawString(font, text, 0, 0, color, false);
        g.pose().popPose();
    }
}
