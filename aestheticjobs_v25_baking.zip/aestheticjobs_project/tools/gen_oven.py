#!/usr/bin/env python3
"""The pastry oven: a small mint stove with a brass window, a marble counter and a tiled back, in five looks
(idle, mixing bowl, baking, golden, burnt).

    python3 tools/gen_oven.py            # textures, block/item models, blockstates, loot table, recipe, tag
    python3 tools/gen_oven.py --check    # verifies the written models

Model units (16 = one block), front = north. The places of the desserts inside are in client/PastryOvenRenderer.
"""
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gen_decor as gd  # noqa: E402
import gen_table as gt  # noqa: E402
from smooth import box, octagon, ring  # noqa: E402
import smooth  # noqa: E402
from voxel_food import mix, rgb, rnd  # noqa: E402

NAME = "pastry_oven"
LOOKS = ["", "_mix", "_baking", "_golden", "_burnt", ""]        # the model of every value of the block state "look"
ALL = ("north", "south", "east", "west", "up", "down")

MINT, MINT_L, MINT_D = "9CC7B4", "C4E2D2", "6E9C8C"
CREAM, CREAM_D = "F6EAD2", "D9C4A2"
BRASS, BRASS_L, BRASS_D = "D2A654", "F4D993", "94702E"
WOOD, WOOD_D = "B5834F", "855A36"


def enamel(x, y, z, f):
    a, b, c = gt.px(x, y, z)
    r = rnd(a, b, c, 3)
    return rgb(MINT_L) if r < 0.05 else mix(rgb(MINT), rgb(MINT_D), 0.35) if r > 0.93 else rgb(MINT)


def drawer(x, y, z, f):
    if f == "north" and 2.5 < x < 13.5 and (abs(y - 9.25) > 0.6 or abs(x - 8) > 5.0):
        return rgb(MINT_L) if y > 10.0 else rgb(MINT)
    return enamel(x, y, z, f)


def marble(x, y, z, f):
    a, b, c = gt.px(x, y, z)
    if (a * 3 + c * 2 + int(rnd(a // 3, 0, c // 3, 5) * 5)) % 17 == 0:
        return rgb(CREAM_D)
    return rgb("FFF8E8") if rnd(a, b, c, 4) < 0.18 else rgb(CREAM)


def brass(x, y, z, f):
    r = rnd(*gt.px(x, y, z), 6)
    return rgb(BRASS_L) if r < 0.18 else rgb(BRASS_D) if r > 0.9 else rgb(BRASS)


def wood(x, y, z, f):
    a, b, c = gt.px(x, y, z)
    return rgb(WOOD_D) if (c + a // 2) % 5 == 0 else rgb(WOOD)


def tiles(x, y, z, f):
    """A rose and cream checkered back wall."""
    a, b, c = gt.px(x, y, z)
    if a % 4 == 0 or (b - 24) % 4 == 3:
        return rgb("CDB9A2")
    return rgb("E9A9AE") if ((a - 1) // 4 + (b - 24) // 4) % 2 else rgb("FBF0DE")


def dial(x, y, z, f):
    a, b = gt.px(x, y, z)[:2]
    hands = {(15, 27), (15, 28), (16, 27)}
    if (a, b) in hands:
        return rgb("4A342C")
    return rgb("FFF8E8")


def inside(state):
    """The walls of the baking chamber."""
    glow = {"idle": ("3C332F", "2A2322", "51453E"), "baking": ("C4601E", "8A3A14", "F29A32"),
            "golden": ("F2A528", "C46C1C", "FFDC6A"), "burnt": ("26201E", "141010", "3E3430")}[state]

    def sh(x, y, z, f):
        base, dark, light = (rgb(h) for h in glow)
        a, b, c = gt.px(x, y, z)
        if f == "south" or (f == "north" and z > 6.0):             # the back: heating coils
            if b in (6, 7, 12, 13):
                return light if (a + b) % 3 else base
            return dark if rnd(a, b, c, 8) < 0.3 else base
        if f == "up":                                              # the floor: a wire rack
            return light if c % 3 == 0 else dark
        return mix(base, dark, min(1.0, max(0.0, (9.0 - z) / 8.0)) * 0.7) if f != "down" else dark
    return sh


def oven(state):
    p = []
    glow = inside(state)
    for x0, z0 in ((1.5, 1.5), (12.5, 1.5), (1.5, 12.5), (12.5, 12.5)):
        p.append(box((x0, 0.0, z0), (x0 + 2, 1.0, z0 + 2), brass, ("north", "south", "east", "west", "down")))
    p.append(box((1, 1, 1), (15, 2, 15), {"*": enamel, "up": glow}))
    p.append(box((1, 2, 1), (3.5, 8, 15), {"*": enamel, "east": glow}, ("north", "south", "east", "west")))
    p.append(box((12.5, 2, 1), (15, 8, 15), {"*": enamel, "west": glow}, ("north", "south", "east", "west")))
    p.append(box((3.5, 2, 7), (12.5, 8, 15), {"*": enamel, "north": glow}, ("north", "south")))
    p.append(box((1, 8, 1), (15, 11, 15), {"*": drawer, "down": glow}, ("north", "south", "east", "west", "down")))
    # the brass frame of the window, the door handle and the two knobs
    front = ("north", "east", "west", "up", "down")
    p.append(box((2.9, 2.0, 0.6), (3.8, 8.0, 1.0), brass, front))
    p.append(box((12.2, 2.0, 0.6), (13.1, 8.0, 1.0), brass, front))
    p.append(box((3.8, 7.4, 0.6), (12.2, 8.0, 1.0), brass, ("north", "up", "down")))
    p.append(box((3.8, 2.0, 0.6), (12.2, 2.5, 1.0), brass, ("north", "up", "down")))
    p.append(box((4.5, 8.3, 0.4), (11.5, 8.9, 1.0), brass, front))
    for x0 in (2.2, 12.4):
        p.append(box((x0, 9.0, 0.4), (x0 + 1.4, 10.4, 1.0), {"*": brass, "north": gt.flat("FFF0C0")}, front))
    # counter and back wall
    p.append(box((0.5, 11, 0.5), (15.5, 12, 15.5), marble))
    p.append(box((1, 12, 13.5), (15, 15.2, 15), tiles, ("north", "south", "east", "west")))
    p.append(box((0.7, 15.2, 13.2), (15.3, 16, 15.2), wood))
    p.append(box((6.5, 12.6, 13.1), (9.5, 14.8, 13.5), {"*": brass, "north": dial}, front))
    # a sugar jar on the right, a rolling pin on the left
    p += octagon(13.2, 11.4, 1.3, 12.0, 14.2, gt.speck("F3E4D8", "FFFFFF", "D6BCAE", 9), bottom=False)
    p += octagon(13.2, 11.4, 1.0, 14.2, 14.9, wood, bottom=False)
    p.append(box((1.5, 12.0, 4.0), (3.1, 13.6, 10.0), gt.speck("D9AE76", "F0CE9C", "B3854E", 2), ("north", "south", "east", "west", "up")))
    p.append(box((1.9, 12.4, 2.8), (2.7, 13.2, 4.0), wood, ("north", "east", "west", "up", "down")))
    p.append(box((1.9, 12.4, 10.0), (2.7, 13.2, 11.2), wood, ("south", "east", "west", "up", "down")))
    return p


def bowl():
    """The mixing bowl with batter and a whisk, standing on the counter."""
    def china(x, y, z, f):
        a, b, c = gt.px(x, y, z)
        if b == 26:
            return rgb("5E86B8")
        return rgb("FFFFFF") if rnd(a, b, c, 11) < 0.15 else rgb("EEF0F4")
    batter = gt.speck("F2D28A", "FFE9B4", "D9AE60", 12, 0.3)
    p = octagon(8.0, 7.0, 2.4, 12.0, 12.6, china, bottom=False)
    p += ring(8.0, 7.0, 3.3, 0.8, 12.6, 14.6, china)
    p += octagon(8.0, 7.0, 2.6, 12.6, 13.7, batter, bottom=False)
    for dx in (-0.9, 0.5):                                       # the wires of the whisk
        p.append(box((8.6 + dx, 13.7, 6.8), (9.0 + dx, 15.0, 7.2), gt.flat("B9BEC6"), ("north", "south", "east", "west")))
    p.append(box((7.7, 15.0, 6.7), (9.5, 15.4, 7.3), gt.flat("D3D7DD")))
    p.append(box((8.25, 15.4, 6.7), (8.95, 16.0, 7.3), gt.speck("C0605A", "E08A80", "8C3A38", 13), ALL))
    return p


MODELS = {
    "": lambda: oven("idle"),
    "_mix": lambda: oven("idle") + bowl(),
    "_baking": lambda: oven("baking"),
    "_golden": lambda: oven("golden"),
    "_burnt": lambda: oven("burnt"),
}


def main():
    for suffix, build in MODELS.items():
        n, size = gt.write(NAME + suffix, build(), None)
        print(f"{NAME}{suffix}: {n} elements, {size} px")
    gd.write_json(os.path.join(gd.ASSETS, "blockstates", NAME + ".json"), {"variants": {
        f"facing={f},look={i}": gd.variant(NAME + s, f) for f in gd.Y for i, s in enumerate(LOOKS)}})
    gd.write_json(os.path.join(gd.ASSETS, "models", "item", NAME + ".json"), {"parent": "aestheticjobs:block/" + NAME})
    gd.loot(NAME)
    gd.write_json(os.path.join(gd.DATA, "recipe", NAME + ".json"), {
        "type": "minecraft:crafting_shaped", "category": "misc", "pattern": ["III", "IFI", "BBB"],
        "key": {k: {"item": "minecraft:" + v} for k, v in (("I", "iron_ingot"), ("F", "furnace"), ("B", "brick"))},
        "result": {"id": "aestheticjobs:" + NAME, "count": 1}})


def check():
    saved = gt.BLOCKS
    gt.BLOCKS = {NAME + s: (None,) for s in MODELS}
    try:
        gt.check()
    finally:
        gt.BLOCKS = saved


if __name__ == "__main__":
    check() if "--check" in sys.argv else main()
