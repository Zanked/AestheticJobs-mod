import dev.aestheticjobs.cafe.bake.BakeSession;
import dev.aestheticjobs.cafe.bake.Baking;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.regex.Pattern;

/**
 * javac -d /tmp/t src/main/java/dev/aestheticjobs/cafe/bake/*.java tools/tests/BakingTest.java && java -cp /tmp/t BakingTest
 * (run from the project folder: it reads item/Dessert.java)
 */
public class BakingTest {
    static void check(boolean ok, String what) {
        if (!ok) throw new AssertionError(what);
    }

    static long mix(BakeSession s, long t, int gap) {
        check(s.beat(t) == -1, "first beat only sets the pace");
        for (int i = 0; i < Baking.BEATS; i++) {
            t += gap;
            check(s.beat(t) >= 0, "beat counts");
        }
        check(s.stage() == BakeSession.Stage.BAKE, "into the oven");
        return t;
    }

    public static void main(String[] args) throws Exception {
        // every dessert of the mod has exactly one recipe
        var m = Pattern.compile("^    [A-Z_]+\\(\"([a-z_]+)\",", Pattern.MULTILINE)
                .matcher(Files.readString(Path.of("src/main/java/dev/aestheticjobs/item/Dessert.java")));
        List<String> mod = new ArrayList<>();
        while (m.find()) mod.add(m.group(1));
        List<String> recipes = new ArrayList<>();
        for (Baking.Category c : Baking.Category.values()) recipes.addAll(c.desserts());
        check(mod.size() == 32, "desserts in the mod: " + mod.size());
        check(recipes.size() == 32 && new java.util.HashSet<>(recipes).equals(new java.util.HashSet<>(mod)), "recipes " + recipes);
        for (Baking.Category c : Baking.Category.values()) {
            String d = c.desserts().get(0);
            for (int i = 0; i < c.desserts().size(); i++) d = Baking.nextDessert(d);
            check(d.equals(c.desserts().get(0)), "cycle " + c);
            check(Baking.beatScore(4, c.tempo()) < 60, "holding the button is not a rhythm " + c);
            check(c.bakeTicks() > Baking.GOOD + Baking.SETTLE + 10, "there is a raw phase " + c);
        }

        // a perfect run in every family
        for (Baking.Category c : Baking.Category.values()) {
            BakeSession s = new BakeSession();
            check(s.select(c.desserts().get(1)), "select");
            check(s.start("a", 1000, true), "start");
            check(!s.start("a", 1001, true) && !s.select("croissant"), "busy");
            long t = mix(s, 1000, c.tempo());
            check(s.mixScore() == 100, "mix");
            check(s.look(t + 1) == BakeSession.Look.BAKING, "baking");
            check(s.look(t + c.bakeTicks()) == BakeSession.Look.GOLDEN, "golden");
            check(s.pull(t + 1) == BakeSession.Pull.NOT_BAKING, "a stray whisk click");
            check(s.refundable(t + 50), "refund");
            check(s.pull(t + c.bakeTicks()) == BakeSession.Pull.TAKEN, "taken");
            check(Baking.TOPPINGS.contains(s.topping()), "topping");
            check(s.pull(t + c.bakeTicks() + 20) == BakeSession.Pull.NOT_BAKING, "no second take");
            check(s.finish(true, t + c.bakeTicks() + 30) == 100, "perfect");
            check(s.finish(true, t + c.bakeTicks() + 60) == -1, "no double reward");
            check(s.stage() == BakeSession.Stage.IDLE && !s.refundable(t + 999), "empty again");
        }

        // raw, burnt, abandoned, without topping
        BakeSession s = new BakeSession();
        s.start("a", 0, false);
        long t = mix(s, 0, 10);
        check(!s.refundable(t), "creative gets nothing back");
        check(s.pull(t + 14) == BakeSession.Pull.NOT_BAKING && s.peeks() == 0, "an extra whisk stroke");
        check(s.pull(t + 40) == BakeSession.Pull.RAW && s.peeks() == 1, "raw");
        check(!s.mayUse("b", t + 100) && s.mayUse("a", t + 100) && s.mayUse("b", t + 2000), "owner");
        check(s.look(t + 1000) == BakeSession.Look.BURNT, "burnt look");
        check(s.pull(t + 1000) == BakeSession.Pull.BURNT && s.stage() == BakeSession.Stage.IDLE, "charcoal");
        s.start("a", 0, true);
        t = mix(s, 0, 10);
        check(!s.refundable(t + 1000), "charcoal is not refunded");
        s.pull(t + 160);
        check(s.finish(false, t + 200) == Baking.NO_TOPPING_MAX, "no topping, no five stars");
        check(Baking.stars(Baking.NO_TOPPING_MAX) < 5, "stars");

        // loading nonsense
        s.load(99, "croissant", "x", "?", 0, 0, 99, -5, -5, 999, true);
        check(s.stage() == BakeSession.Stage.IDLE, "bad stage");
        s.load(2, "nothing", "x", "?", 0, 0, 0, 0, 0, 0, true);
        check(s.stage() == BakeSession.Stage.IDLE && s.category() != null, "bad dessert");
        s.load(3, "flan", "x", "?", 0, 0, 99, -5, -5, 999, true);
        check(s.stage() == BakeSession.Stage.DECORATE && Baking.TOPPINGS.contains(s.topping()) && s.bakeScore() == 100, "clamped");

        // random clicking never breaks the order of the steps or leaves the score range
        Random r = new Random(7);
        s = new BakeSession();
        long now = 0;
        int rewards = 0, starts = 0;
        for (int i = 0; i < 2_000_000; i++) {
            now += r.nextInt(40);
            BakeSession.Stage before = s.stage();
            switch (r.nextInt(5)) {
                case 0 -> { if (s.start("a", now, true)) starts++; }
                case 1 -> s.beat(now);
                case 2 -> s.pull(now);
                case 3 -> {
                    int q = s.finish(r.nextBoolean(), now);
                    if (q >= 0) {
                        rewards++;
                        check(before == BakeSession.Stage.DECORATE && q <= 100, "reward only after decorating");
                    }
                }
                default -> s.select(Baking.nextDessert(s.dessert()));
            }
            int d = s.stage().ordinal() - before.ordinal();
            check(d == 0 || d == 1 || s.stage() == BakeSession.Stage.IDLE, "steps in order");
            check(s.mixScore() >= 0 && s.mixScore() <= 100, "mix range");
        }
        check(rewards > 100 && rewards <= starts, "never more desserts than starts: " + rewards + "/" + starts);
        System.out.println("Baking ok: " + starts + " starts, " + rewards + " desserts");
    }
}
