package dev.aestheticjobs.entity;

import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.CafeOrders;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.Pairing;
import dev.aestheticjobs.cafe.Personality;
import dev.aestheticjobs.cafe.Plate;
import dev.aestheticjobs.cafe.anim.PoseInput;
import dev.aestheticjobs.cafe.anim.Poses;
import dev.aestheticjobs.cafe.anim.StaffAction;
import dev.aestheticjobs.cafe.Order;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.network.OpenChefPayload;
import dev.aestheticjobs.registry.ModBlocks;
import dev.aestheticjobs.registry.ModItems;
import dev.aestheticjobs.registry.ModSounds;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.AbstractFurnaceBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The staff of the cafe, two roles (two entity types, the same class):
 *
 * CHEF: a pastry chef. Nothing is given to him and he is not paid. Right-click: a menu of all desserts; the chosen one
 * is baked again and again in a regular furnace next to him (the furnace lights up while he bakes) onto a tray of
 * {@link #TRAY} plates, every plate goes cold after {@link #PLATE_LIFE} ticks. A barista takes the plates from the tray.
 *
 * BARISTA: an NPC barista. He serves the NPC customers (nobody gets any money for it: it is not printed) and the paid
 * orders of real players when no player barista takes them. The buyer collects the order from him by right-click.
 */
public class CafeStaffEntity extends PathfinderMob implements CafePerson {
    public enum Role { CHEF, BARISTA }

    public static final int TRAY = 3;
    public static final long PLATE_LIFE = 6000L;          // 5 minutes
    public static final int BAKE_TICKS = 600;             // 30 seconds a plate
    public static final int MAX_CHEFS = 4;
    public static final int MAX_BARISTAS = 2;
    /** The NPC barista makes a paid order of a player in this time (a player barista is faster). */
    public static final long COOK_TICKS = 600L;
    /** A paid order waits this long for a player barista before the NPC barista takes it (when nobody takes it earlier). */
    public static final long NPC_TAKES_AFTER = 800L;
    /** A ready order is kept this long for the buyer. */
    public static final long READY_LIFE = 6000L;
    private static final long CUSTOMER_WORK_TICKS = 800L;

    private static final net.minecraft.network.syncher.EntityDataAccessor<Integer> DATA_ACTION =
            net.minecraft.network.syncher.SynchedEntityData.defineId(CafeStaffEntity.class,
                    net.minecraft.network.syncher.EntityDataSerializers.INT);

    private final Role role;
    /** Server: what the staff does (synced to the client animation) and the timers that drive it. */
    private boolean working;
    private int oneShotUntil = -1;
    private int oneShotAction;
    private int wipeAt = 400;
    /** Client: tick when the current action started. */
    private int clientActionStart;

    // ---- chef ----
    private final List<Plate> tray = new ArrayList<>();
    /** Desserts the baristas asked this chef to bake (in order); they are baked before the dessert chosen in the menu. */
    private final java.util.ArrayDeque<Integer> queue = new java.util.ArrayDeque<>();
    public static final int MAX_QUEUE = 6;
    private int selected = -1;
    private int bake;
    @Nullable private BlockPos furnace;
    @Nullable private BlockPos lit;

    // ---- barista ----
    @Nullable private BlockPos register;
    @Nullable private UUID customer;
    private long customerWorkUntil;
    private boolean customerPlated;
    private int customerCooldown = 600;

    private boolean limitChecked;
    private String shownName = "";

    public CafeStaffEntity(EntityType<? extends CafeStaffEntity> type, Level level, Role role) {
        super(type, level);
        this.role = role;
        setInvulnerable(true);
        setPersistenceRequired();
        setCustomNameVisible(true);
    }

    @Override
    protected void defineSynchedData(net.minecraft.network.syncher.SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_ACTION, StaffAction.IDLE);
    }

    public int action() {
        return entityData.get(DATA_ACTION);
    }

    @Override
    public void onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (DATA_ACTION.equals(key) && level().isClientSide) clientActionStart = tickCount;
    }

    /** Server: plays a one-shot animation (serve a cup, present a plate) with something in the hand. */
    private void playOnce(int action, int ticks, ItemStack held) {
        oneShotAction = action;
        oneShotUntil = tickCount + ticks;
        setItemSlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND, held);
        setDropChance(net.minecraft.world.entity.EquipmentSlot.MAINHAND, 0.0F);
    }

    private void setHeld(ItemStack held) {
        if (!ItemStack.matches(getMainHandItem(), held)) {
            setItemSlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND, held);
            setDropChance(net.minecraft.world.entity.EquipmentSlot.MAINHAND, 0.0F);
        }
    }

    private void faceBlock(@Nullable BlockPos p) {
        if (p == null) return;
        double dx = p.getX() + 0.5D - getX(), dz = p.getZ() + 0.5D - getZ();
        if (dx * dx + dz * dz < 0.04D) return;
        float yaw = (float) (net.minecraft.util.Mth.atan2(dz, dx) * 57.29578D) - 90.0F;
        float turned = net.minecraft.util.Mth.approachDegrees(yBodyRot, yaw, 14.0F);
        setYRot(turned);
        setYBodyRot(turned);
        setYHeadRot(turned);
    }

    /** Server, every tick: decides which animation plays (barista: machine / serve / wipe; chef: knead / oven / watch / present). */
    private void updateAction() {
        int a = StaffAction.IDLE;
        ItemStack held = ItemStack.EMPTY;
        BlockPos target = null;
        if (oneShotUntil > tickCount) {
            a = oneShotAction;
            held = getMainHandItem();
            target = role == Role.CHEF ? furnace : register;
        } else if (role == Role.BARISTA) {
            if (working) {
                a = StaffAction.MACHINE;
                held = new ItemStack(ModItems.EMPTY_CUP.get());
                target = register;
            } else if (wipeAt <= tickCount && wipeAt + StaffAction.WIPE_TICKS > tickCount && register != null) {
                a = StaffAction.WIPE;
                target = register;
            } else if (wipeAt + StaffAction.WIPE_TICKS <= tickCount) {
                wipeAt = tickCount + 500 + random.nextInt(900);
            }
        } else {
            Dessert d = Dessert.byIndex(queue.isEmpty() ? selected : queue.peekFirst());
            if (d != null && tray.size() < TRAY && furnace != null) {
                target = furnace;
                if (bake < 330) a = StaffAction.KNEAD;
                else if (bake < 520) a = StaffAction.WATCH;
                else {
                    a = StaffAction.OVEN;
                    held = new ItemStack(ModItems.DESSERT_PLATE.get());
                }
            }
        }
        if (a != action()) entityData.set(DATA_ACTION, a);
        setHeld(held);
        if (target != null) faceBlock(target);
    }

    // ------------------------------------------------------------------ the player-like model (client)

    @Override
    public void fillPose(PoseInput in, float ageInTicks) {
        in.age = ageInTicks;
        in.seed = getId();
        in.mode = action();
        in.t = ageInTicks - clientActionStart;
    }

    @Override
    public int personSkin() {
        return role == Role.CHEF ? 8 : 9;
    }

    @Override
    public int faceIndex(float ageInTicks) {
        int mood = StaffAction.mood(action());
        return Poses.face(mood, Poses.blink(ageInTicks, getId()));
    }

    @Override
    public boolean wearsToque() {
        return role == Role.CHEF;
    }

    public Role role() {
        return role;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    // ------------------------------------------------------------------ helpers for the register (chefs and baristas near it)

    private static List<CafeStaffEntity> staffNear(ServerLevel level, BlockPos at, Role role) {
        double r = CafeLogic.STAFF_RADIUS;
        return level.getEntitiesOfClass(CafeStaffEntity.class, new AABB(at).inflate(r), e -> e.role == role && e.isAlive());
    }

    /** The desserts that lie on the trays of the chefs near the register (without repeats). */
    public static List<Integer> availableDesserts(ServerLevel level, BlockPos register) {
        long now = level.getGameTime();
        Set<Integer> set = new LinkedHashSet<>();
        for (CafeStaffEntity chef : staffNear(level, register, Role.CHEF)) {
            for (Plate p : chef.tray) if (p.fresh(now)) set.add(p.dessert());
        }
        return new ArrayList<>(set);
    }

    /** Is there a chef near the register at all? (Then every dessert can be ordered: he bakes it on demand.) */
    public static boolean hasChef(ServerLevel level, BlockPos register) {
        return !staffNear(level, register, Role.CHEF).isEmpty();
    }

    /** Does a chef near the register have room in the queue for one more dessert? */
    public static boolean canRequest(ServerLevel level, BlockPos register) {
        for (CafeStaffEntity chef : staffNear(level, register, Role.CHEF)) {
            if (chef.queue.size() < MAX_QUEUE) return true;
        }
        return false;
    }

    /** The barista tells a chef (the least busy one) to bake this dessert. False if there is no chef or all have a full queue. */
    public static boolean request(ServerLevel level, BlockPos register, int dessert) {
        if (Dessert.byIndex(dessert) == null) return false;
        CafeStaffEntity best = null;
        for (CafeStaffEntity chef : staffNear(level, register, Role.CHEF)) {
            if (chef.queue.size() >= MAX_QUEUE) continue;
            if (best == null || chef.queue.size() + chef.tray.size() < best.queue.size() + best.tray.size()) best = chef;
        }
        if (best == null) return false;
        best.queue.addLast(dessert);
        return true;
    }

    /** Takes one plate of this dessert off a tray near the register. False if there is none. */
    public static boolean takePlate(ServerLevel level, BlockPos register, int dessert) {
        long now = level.getGameTime();
        for (CafeStaffEntity chef : staffNear(level, register, Role.CHEF)) {
            for (int i = 0; i < chef.tray.size(); i++) {
                Plate p = chef.tray.get(i);
                if (p.dessert() == dessert && p.fresh(now)) {
                    chef.tray.remove(i);
                    return true;
                }
            }
        }
        return false;
    }

    @Nullable
    public static CafeStaffEntity baristaNear(ServerLevel level, BlockPos register) {
        List<CafeStaffEntity> list = staffNear(level, register, Role.BARISTA);
        return list.isEmpty() ? null : list.get(0);
    }

    // ------------------------------------------------------------------ chef: the menu

    public int selected() {
        return selected;
    }

    public List<Plate> tray() {
        return tray;
    }

    public void sendMenu(ServerPlayer player) {
        long now = level().getGameTime();
        List<Integer> dessert = new ArrayList<>();
        List<Integer> seconds = new ArrayList<>();
        for (Plate p : tray) {
            dessert.add(p.dessert());
            seconds.add((int) Math.max(0L, (p.expires() - now) / 20L));
        }
        findFurnace();
        PacketDistributor.sendToPlayer(player, new OpenChefPayload(getId(), selected, dessert, seconds,
                bake * 100 / BAKE_TICKS, furnace != null));
    }

    public void select(int dessert) {
        selected = Dessert.byIndex(dessert) == null ? -1 : dessert;
        bake = 0;
    }

    /** A player takes the plate in this tray slot. */
    public void giveTo(ServerPlayer player, int slot) {
        if (slot < 0 || slot >= tray.size()) return;
        Plate p = tray.get(slot);
        if (!p.fresh(level().getGameTime())) return;
        tray.remove(slot);
        player.getInventory().placeItemBackInInventory(CafeLogic.makePlate(p.dessert(), p.expires()));
        level().playSound(null, blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.NEUTRAL, 0.6F, 1.2F);
    }

    // ------------------------------------------------------------------ interaction

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!level().isClientSide && player instanceof ServerPlayer sp) {
            if (role == Role.CHEF) {
                sendMenu(sp);
            } else {
                baristaInteract(sp);
            }
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    private void baristaInteract(ServerPlayer player) {
        CafeOrders orders = CafeOrders.get(player.server);
        CafeOrders.Entry e = orders.ofBuyer(player.getUUID());
        if (e == null) {
            player.displayClientMessage(Component.translatable("staff.barista.hint"), true);
            return;
        }
        if (e.status != CafeOrders.READY) {
            player.displayClientMessage(Component.translatable("staff.barista.not_ready"), true);
            return;
        }
        Drink drink = Drink.byIndex(e.drink);
        if (drink == null) {
            orders.remove(e);
            return;
        }
        for (ItemStack out : CafeLogic.purchaseItems(e, CafeLogic.npcCup(drink))) {
            player.getInventory().placeItemBackInInventory(out);
        }
        orders.remove(e);
        level().playSound(null, blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.NEUTRAL, 0.9F, 1.3F);
        player.sendSystemMessage(Component.translatable("cafe.order.received", getDisplayName()));
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (!limitChecked && tickCount > 2) {
            limitChecked = true;
            if (overLimit()) return;
        }
        if (role == Role.CHEF) {
            tickChef();
        } else {
            tickBarista();
        }
        updateAction();
        if (tickCount % 20 == 0) refreshName();
    }

    /** Too many staff of this role around: the newest one is taken back as a spawn egg. */
    private boolean overLimit() {
        ServerLevel sl = (ServerLevel) level();
        int limit = role == Role.CHEF ? MAX_CHEFS : MAX_BARISTAS;
        int older = 0;
        for (CafeStaffEntity e : sl.getEntitiesOfClass(CafeStaffEntity.class, getBoundingBox().inflate(CafeLogic.STAFF_RADIUS),
                x -> x != this && x.role == role && x.tickCount > tickCount)) {
            older++;
        }
        if (older < limit) return false;
        ItemStack egg = new ItemStack(role == Role.CHEF ? ModItems.CAFE_CHEF_SPAWN_EGG.get() : ModItems.CAFE_BARISTA_SPAWN_EGG.get());
        spawnAtLocation(egg);
        Player p = sl.getNearestPlayer(this, 8.0D);
        if (p != null) {
            p.displayClientMessage(Component.translatable("staff.limit", limit), true);
        }
        discard();
        return true;
    }

    private void refreshName() {
        Component name;
        if (role == Role.CHEF) {
            Dessert d = Dessert.byIndex(selected);
            if (furnace == null && d != null) {
                name = Component.translatable("staff.chef.no_furnace");
            } else if (d == null) {
                name = Component.translatable("staff.chef.idle");
            } else if (tray.size() >= TRAY) {
                name = Component.translatable("staff.chef.full", d.displayName());
            } else {
                name = Component.translatable("staff.chef.baking", d.displayName(), bake * 100 / BAKE_TICKS);
            }
        } else {
            name = Component.translatable("staff.barista.name");
        }
        String key = name.getString();
        if (!key.equals(shownName)) {
            shownName = key;
            setCustomName(name);
        }
    }

    // ---- chef ----

    private void findFurnace() {
        if (furnace != null && level().getBlockState(furnace).is(Blocks.FURNACE)) return;
        furnace = null;
        BlockPos c = blockPosition();
        double best = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-4, -2, -4), c.offset(4, 2, 4))) {
            if (!level().getBlockState(p).is(Blocks.FURNACE)) continue;
            double d = p.distSqr(c);
            if (d < best) {
                best = d;
                furnace = p.immutable();
            }
        }
    }

    private void light(boolean on) {
        if (on) {
            if (furnace == null) return;
            BlockState st = level().getBlockState(furnace);
            if (st.is(Blocks.FURNACE) && !st.getValue(AbstractFurnaceBlock.LIT)) {
                level().setBlock(furnace, st.setValue(AbstractFurnaceBlock.LIT, true), 3);
            }
            lit = furnace;
        } else if (lit != null) {
            BlockState st = level().getBlockState(lit);
            if (st.is(Blocks.FURNACE) && st.getValue(AbstractFurnaceBlock.LIT)) {
                level().setBlock(lit, st.setValue(AbstractFurnaceBlock.LIT, false), 3);
            }
            lit = null;
        }
    }

    private void tickChef() {
        ServerLevel sl = (ServerLevel) level();
        long now = sl.getGameTime();
        tray.removeIf(p -> !p.fresh(now));
        if (tickCount % 40 == 1) findFurnace();

        Integer asked = queue.peekFirst();
        Dessert d = Dessert.byIndex(asked != null ? asked : selected);
        boolean baking = d != null && tray.size() < TRAY && furnace != null;
        if (!baking) {
            if (lit != null) light(false);
            return;
        }
        if (lit == null || !lit.equals(furnace)) {
            light(false);
            light(true);
        }
        bake++;
        if (bake % 30 == 0) {
            sl.sendParticles(ParticleTypes.SMOKE, furnace.getX() + 0.5D, furnace.getY() + 1.1D, furnace.getZ() + 0.5D, 2, 0.15D, 0.05D, 0.15D, 0.01D);
        }
        if (bake >= BAKE_TICKS) {
            bake = 0;
            tray.add(new Plate(d.ordinal(), now + PLATE_LIFE));
            if (asked != null) queue.pollFirst();
            playOnce(StaffAction.PRESENT, StaffAction.PRESENT_TICKS, new ItemStack(ModItems.DESSERT_PLATE.get()));
            sl.playSound(null, blockPosition(), SoundEvents.NOTE_BLOCK_CHIME.value(), SoundSource.NEUTRAL, 0.8F, 1.5F);
            sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 2.0D, getZ(), 4, 0.25D, 0.2D, 0.25D, 0.0D);
        }
    }

    @Override
    public void remove(RemovalReason reason) {
        if (!level().isClientSide && lit != null) light(false);       // do not leave a furnace burning for nothing
        super.remove(reason);
    }

    // ---- barista ----

    private void findRegister() {
        if (register != null && level().getBlockState(register).is(ModBlocks.CAFE_REGISTER.get())) return;
        register = null;
        BlockPos c = blockPosition();
        double best = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-8, -3, -8), c.offset(8, 3, 8))) {
            if (!level().getBlockState(p).is(ModBlocks.CAFE_REGISTER.get())) continue;
            double d = p.distSqr(c);
            if (d < best) {
                best = d;
                register = p.immutable();
            }
        }
    }

    private void tickBarista() {
        if (tickCount % 20 != 0) return;
        ServerLevel sl = (ServerLevel) level();
        working = false;
        if (tickCount % 100 == 0 || register == null) findRegister();
        if (register == null) return;
        long now = sl.getGameTime();
        CafeOrders orders = CafeOrders.get(sl.getServer());

        // 1. a paid order of a player that I am making
        for (CafeOrders.Entry e : orders.all()) {
            if (e.status == CafeOrders.COOKING && getUUID().equals(e.worker)) {
                working = true;
                if (now >= e.readyAt) {
                    if (e.dessert >= 0 && !e.plated) {                    // the chef is still baking it: wait for the plate
                        if (!takePlate(sl, register, e.dessert)) {
                            working = false;
                            return;
                        }
                        e.plated = true;
                        orders.changed();
                    }
                    Drink made = Drink.byIndex(e.drink);
                    if (made != null) playOnce(StaffAction.SERVE, StaffAction.SERVE_TICKS, CafeLogic.npcCup(made));
                    working = false;
                    e.status = CafeOrders.READY;
                    e.readyAt = now;
                    orders.changed();
                    sl.playSound(null, blockPosition(), ModSounds.BARISTA_DING.get(), SoundSource.NEUTRAL, 1.0F, 1.0F);
                    sl.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 1.6D, getZ(), 6, 0.2D, 0.1D, 0.2D, 0.01D);
                    ServerPlayer buyer = sl.getServer().getPlayerList().getPlayer(e.buyer);
                    if (buyer != null) buyer.sendSystemMessage(Component.translatable("cafe.order.ready"));
                }
                return;                                                   // busy with it
            }
        }

        // 2. a paid order of a player that waits for a barista for too long (or nobody else is at work)
        CafeOrders.Entry open = orders.nextPending(sl.dimension().location().toString(), register, CafeLogic.STAFF_RADIUS);
        if (open != null && (now - open.created >= NPC_TAKES_AFTER || !playerBaristaAtWork(sl))) {
            open.status = CafeOrders.COOKING;
            open.worker = getUUID();
            open.readyAt = now + COOK_TICKS;
            orders.changed();
            return;
        }

        // 3. a customer NPC: wait for one to come, make its drink, no money for anybody
        serveCustomer(sl, now);
    }

    private static boolean playerBaristaAtWork(ServerLevel sl) {
        for (ServerPlayer p : sl.getServer().getPlayerList().getPlayers()) {
            if (CafeLogic.isWorking(p)) return true;
        }
        return false;
    }

    private void serveCustomer(ServerLevel sl, long now) {
        CafeCustomerEntity current = null;
        if (customer != null) {
            net.minecraft.world.entity.Entity e = sl.getEntity(customer);
            if (e instanceof CafeCustomerEntity c && c.isAlive()) current = c;
            else customer = null;
        }
        if (current != null) {
            if (current.getState() == CafeCustomerEntity.STATE_WAITING) {
                working = true;
                if (customerWorkUntil == 0L) customerWorkUntil = now + CUSTOMER_WORK_TICKS;
                if (now >= customerWorkUntil) {
                    working = false;
                    if (current.getDessert() >= 0 && !customerPlated) {      // the plate comes from the chef
                        if (!takePlate(sl, register, current.getDessert())) return;
                        customerPlated = true;
                    }
                    customerPlated = false;
                    Drink made = Drink.byIndex(current.getDrink());
                    if (made != null) playOnce(StaffAction.SERVE, StaffAction.SERVE_TICKS, CafeLogic.npcCup(made));
                    current.receiveByNpc(position());
                    sl.playSound(null, blockPosition(), ModSounds.BARISTA_DING.get(), SoundSource.NEUTRAL, 0.8F, 1.1F);
                    customer = null;
                    customerWorkUntil = 0L;
                    customerCooldown = 1200 + random.nextInt(1200);
                }
            }
            return;
        }
        customerCooldown -= 20;
        if (customerCooldown > 0) return;
        if (sl.getNearestPlayer(this, 48.0D) == null) {                   // nobody to watch: do not spawn anything
            customerCooldown = 600;
            return;
        }
        BlockState rs = sl.getBlockState(register);
        Direction facing = rs.hasProperty(net.minecraft.world.level.block.HorizontalDirectionalBlock.FACING)
                ? rs.getValue(net.minecraft.world.level.block.HorizontalDirectionalBlock.FACING) : Direction.NORTH;
        int variant = random.nextInt(Order.CUSTOMERS);
        Personality person = Personality.of(variant);
        Drink drink = CafeLogic.pickDrink(person, random);
        int dessert = -1;
        boolean plated = true;
        if (random.nextFloat() < person.dessertChance() && hasChef(sl, register)) {     // any dessert: the chef bakes it on request
            int pick = CafeLogic.pickDessert(person, drink, random);
            if (pick >= 0) {
                if (takePlate(sl, register, pick)) {
                    dessert = pick;
                } else if (request(sl, register, pick)) {
                    dessert = pick;
                    plated = false;
                }
            }
        }
        CafeCustomerEntity npc = CafeCustomerEntity.spawnFor(sl, register, facing, getUUID(), variant, drink.ordinal(), dessert, now, true);
        if (npc == null) {
            customerCooldown = 600;
            return;
        }
        customer = npc.getUUID();
        customerWorkUntil = 0L;
        customerPlated = plated;
    }

    // ------------------------------------------------------------------ save / load

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Selected", selected);
        tag.putInt("Bake", bake);
        int[] q = new int[queue.size()];
        int qi = 0;
        for (int x : queue) q[qi++] = x;
        tag.putIntArray("Queue", q);
        ListTag list = new ListTag();
        for (Plate p : tray) {
            CompoundTag t = new CompoundTag();
            t.putInt("d", p.dessert());
            t.putLong("e", p.expires());
            list.add(t);
        }
        tag.put("Tray", list);
        if (lit != null) tag.putLong("Lit", lit.asLong());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        selected = tag.contains("Selected") ? tag.getInt("Selected") : -1;
        bake = tag.getInt("Bake");
        queue.clear();
        for (int x : tag.getIntArray("Queue")) queue.addLast(x);
        tray.clear();
        ListTag list = tag.getList("Tray", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size() && i < TRAY; i++) {
            CompoundTag t = list.getCompound(i);
            tray.add(new Plate(t.getInt("d"), t.getLong("e")));
        }
        lit = tag.contains("Lit") ? BlockPos.of(tag.getLong("Lit")) : null;     // put out on the first tick if nothing is baking
    }
}
