#!/usr/bin/env python3
"""Icons of the resume (blank form and filled form), 32x32, pastel like the rest of the mod.

  textures/item/resume.png          the blank form
  textures/item/resume_filled.png   the form with the lines written and a signature

Run: python3 tools/gen_resume_textures.py
"""
import os
from PIL import Image, ImageDraw

ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets",
                      "aestheticjobs", "textures", "item")

PAPER = (255, 246, 226, 255)
PAPER_SHADE = (239, 225, 194, 255)
BORDER = (106, 74, 58, 255)
LINE = (191, 169, 130, 255)
INK = (74, 50, 40, 255)
CLIP = (212, 156, 104, 255)
GREEN = (127, 160, 112, 255)


def sheet():
    im = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rectangle((7, 3, 25, 29), fill=PAPER, outline=BORDER)
    d.rectangle((8, 27, 24, 28), fill=PAPER_SHADE)
    d.rectangle((13, 1, 19, 5), fill=CLIP, outline=BORDER)        # the clip
    d.rectangle((15, 2, 17, 3), fill=(255, 246, 226, 255))
    # the photo box and the name line
    d.rectangle((10, 8, 14, 14), outline=LINE)
    return im, d


def blank():
    im, d = sheet()
    for y in (9, 12):
        d.line((16, y, 23, y), fill=LINE)
    for y in (17, 20, 23):
        d.line((10, y, 23, y), fill=LINE)
    return im


def filled():
    im, d = sheet()
    d.rectangle((11, 9, 13, 13), fill=(238, 193, 160, 255))       # a little portrait
    d.rectangle((11, 9, 13, 10), fill=(90, 58, 42, 255))
    for y, x1 in ((9, 23), (12, 21)):
        d.line((16, y, x1, y), fill=INK)
    for y, x1 in ((17, 23), (19, 20), (21, 22)):
        d.line((10, y, x1, y), fill=INK)
    # the signature
    pts = [(10, 25), (12, 23), (13, 26), (15, 24), (17, 26), (19, 24), (22, 25)]
    d.line(pts, fill=(80, 110, 170, 255))
    # the green tick
    d.line((19, 14, 20, 15, 23, 10), fill=GREEN, width=1)
    return im


def main():
    os.makedirs(ASSETS, exist_ok=True)
    blank().save(os.path.join(ASSETS, "resume.png"))
    filled().save(os.path.join(ASSETS, "resume_filled.png"))
    print("ok")


if __name__ == "__main__":
    main()
