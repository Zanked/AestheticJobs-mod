#!/usr/bin/env python3
"""
HD skins (x2) of every person in the cafe: 8 customers (0..7), the pastry chef (8), the NPC barista (9), the three managers (10..12).

Each skin is 128x256: the ordinary player-skin layout (slim "Alex" arms) at DOUBLE resolution (128x128), and below it
the chef's hat. The model (client/CafePersonModel) is defined on a 64x128 grid; the UVs are normalised, so any multiple
of it works without code changes. Four faces per person: 0 neutral, 1 blink, 2 happy, 3 angry.

  textures/entity/person_<skin>_<face>.png

Run: python3 tools/gen_person_skins.py   (needs Pillow and numpy)
"""
import math
import os
import numpy as np
from PIL import Image

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets",
                   "aestheticjobs", "textures", "entity")
S = 2
W, H = 64 * S, 128 * S


# ------------------------------------------------------------------ colour helpers
def hexc(s):
    s = s.lstrip("#")
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16))


def shade(c, f):
    """f > 0 lighter, f < 0 darker."""
    if f >= 0:
        return tuple(int(round(v + (255 - v) * f)) for v in c[:3])
    return tuple(int(round(v * (1 + f))) for v in c[:3])


def mix(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def hsh(x, y, s=0):
    n = (x * 374761393 + y * 668265263 + s * 2147483647) & 0xFFFFFFFF
    n = ((n ^ (n >> 13)) * 1274126177) & 0xFFFFFFFF
    n ^= n >> 16
    return (n & 0xFFFF) / 65535.0


def nz(x, y, s=0):
    return hsh(x, y, s) * 2.0 - 1.0


# ------------------------------------------------------------------ texture and faces
class Tex:
    def __init__(self):
        self.a = np.zeros((H, W, 4), np.uint8)

    def set(self, x, y, c, a=255):
        if 0 <= x < W and 0 <= y < H:
            self.a[y, x] = (c[0], c[1], c[2], a)

    def get(self, x, y):
        return tuple(int(v) for v in self.a[y, x])

    def image(self):
        return Image.fromarray(self.a, "RGBA")


class Face:
    """One face of a box: local coordinates (0,0) = its top-left pixel. Writes into the texture."""

    def __init__(self, tex, name, x, y, w, h):
        self.t, self.name, self.x, self.y, self.w, self.h = tex, name, x, y, w, h

    def set(self, lx, ly, c):
        if 0 <= lx < self.w and 0 <= ly < self.h:
            self.t.set(self.x + lx, self.y + ly, c)

    def get(self, lx, ly):
        return self.t.get(self.x + lx, self.y + ly)

    def fill(self, lx, ly, w, h, c):
        for j in range(h):
            for i in range(w):
                self.set(lx + i, ly + j, c)

    def each(self, fn):
        for j in range(self.h):
            for i in range(self.w):
                c = fn(i, j)
                if c is not None:
                    self.set(i, j, c)


def box(tex, u, v, w, h, d):
    """Faces of a box at logical (u, v) with size w x h x d (the 64x64 skin layout), scaled by S."""
    u, v, w, h, d = u * S, v * S, w * S, h * S, d * S
    r = {
        "top": (u + d, v, w, d), "bottom": (u + d + w, v, w, d),
        "right": (u, v + d, d, h), "front": (u + d, v + d, w, h),
        "left": (u + d + w, v + d, d, h), "back": (u + 2 * d + w, v + d, w, h),
    }
    return {k: Face(tex, k, *val) for k, val in r.items()}


HEAD = (0, 0, 8, 8, 8)
HAT = (32, 0, 8, 8, 8)
BODY = (16, 16, 8, 12, 4)
JACKET = (16, 32, 8, 12, 4)
RARM = (40, 16, 3, 12, 4)
RSLV = (40, 32, 3, 12, 4)
LARM = (32, 48, 3, 12, 4)
LSLV = (48, 48, 3, 12, 4)
RLEG = (0, 16, 4, 12, 4)
RPANT = (0, 32, 4, 12, 4)
LLEG = (16, 48, 4, 12, 4)
LPANT = (0, 48, 4, 12, 4)

# ------------------------------------------------------------------ characters
PEOPLE = [
    dict(name="Emma", skin="#f6d8bc", hair="#d9a066", hairstyle="long", eyes="#4f9a68", top="#f2a7c3", trim="#ffffff",
         sleeve=4, bottom="#7f9fd2", shoes="#f4f4f4", lash=True, sweater=True),
    dict(name="Liam", skin="#e8b98f", hair="#3a2a22", hairstyle="short", eyes="#5a3a2a", top="#5b8bd6", trim="#e8eefc",
         sleeve=12, bottom="#4a5a7a", shoes="#e8e8e8", hoodie=True),
    dict(name="Sofia", skin="#f2cfae", hair="#1f1a1c", hairstyle="bun", eyes="#3a3236", top="#f4ecd8", trim="#c9a97e",
         sleeve=12, bottom="#2e2a30", shoes="#1c1a1e", coat="#c9a97e", lash=True, lips="#c0485a"),
    dict(name="Noah", skin="#d9a67c", hair="#6b4a2e", hairstyle="messy", eyes="#4a3220", top="#f0a35e", trim="#fbe3c4",
         sleeve=4, bottom="#b9a57a", shoes="#6a4a32", stripes=True),
    dict(name="Mia", skin="#fbe0c8", hair="#f4d36a", hairstyle="pigtails", eyes="#5b8fd0", top="#f7d65c", trim="#fff3b8",
         sleeve=3, bottom="#f7d65c", shoes="#d6584e", lash=True, skirt=5),
    dict(name="Oliver", skin="#e6c2a2", hair="#b9b9b9", hairstyle="short", eyes="#4a4a52", top="#8b6a4a", trim="#f2ead8",
         sleeve=12, bottom="#55504a", shoes="#2a2622", beard="#b0b0b0", cardigan=True),
    dict(name="Lily", skin="#f6d3b8", hair="#a6482c", hairstyle="braid", eyes="#6a7a4a", top="#78b08a", trim="#a8d4b6",
         sleeve=12, bottom="#3f4a6b", shoes="#6a4a32", glasses="#3a2a28", lash=True, sweater=True),
    dict(name="Max", skin="#c68e63", hair="#1a1a1a", hairstyle="cap", eyes="#2a1c14", top="#d65a4e", trim="#f2b0a8",
         sleeve=4, bottom="#3d4f78", shoes="#f2f2f2", cap="#2f6fb5", tee=True),
    dict(name="Chef", skin="#f0cba8", hair="#6a4a3a", hairstyle="short", eyes="#6a8fb0", top="#fffaf0", trim="#d8d2c4",
         sleeve=12, bottom="#7a7a84", shoes="#3a3030", chef=True, mustache="#5a3e30"),
    dict(name="Barista", skin="#eec1a0", hair="#4a3830", hairstyle="ponytail", eyes="#5a8a5a", top="#f4e6c8", trim="#a0714f",
         sleeve=8, bottom="#5a4636", shoes="#3a2a22", apron="#8a5a3a", beanie="#b07a52", lash=True),
    # the managers who interview (10 cafe, 11 office, 12 shop)
    dict(name="CafeManager", skin="#f2cfae", hair="#5a3a2a", hairstyle="bun", eyes="#4f7a9a", top="#fbf3e4", trim="#a0714f",
         sleeve=12, bottom="#4a3a34", shoes="#2e2a30", coat="#8a5a3a", lash=True, lips="#c0485a"),
    dict(name="OfficeManager", skin="#e8b98f", hair="#2a2a30", hairstyle="short", eyes="#3a4a5a", top="#e8eef6", trim="#c9d3e0",
         sleeve=12, bottom="#3a3f52", shoes="#1c1a1e", coat="#3d4458", glasses="#3a2a28"),
    dict(name="ShopManager", skin="#c68e63", hair="#8a3a2a", hairstyle="ponytail", eyes="#6a7a4a", top="#7fb59a", trim="#cfe8da",
         sleeve=8, bottom="#4a5a6a", shoes="#f2f2f2", apron="#d9a86a", lash=True),
]
FACES = ["neutral", "blink", "happy", "angry"]

# hair shape: fringe depth per column of the front (16 cols), sideburn width/depth, how much of the side/back is covered
HAIR = {
    "short": dict(fr=[4, 3, 4, 3, 3, 2, 3, 3, 3, 3, 2, 3, 3, 4, 3, 4], sb=2, sbd=7, backw=4, backd=9, side=5),
    "messy": dict(fr=[5, 3, 4, 2, 5, 3, 2, 4, 3, 5, 2, 4, 3, 5, 3, 4], sb=2, sbd=8, backw=4, backd=10, side=5),
    "long": dict(fr=[5, 5, 4, 4, 3, 3, 2, 2, 2, 2, 3, 3, 4, 4, 5, 5], sb=3, sbd=16, backw=16, backd=16, side=5),
    "bun": dict(fr=[4, 3, 3, 3, 3, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 4], sb=1, sbd=5, backw=5, backd=9, side=5),
    "pigtails": dict(fr=[4, 4, 3, 3, 3, 3, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4], sb=2, sbd=7, backw=5, backd=10, side=5),
    "braid": dict(fr=[6, 6, 5, 5, 4, 4, 3, 3, 3, 2, 2, 2, 2, 2, 2, 3], sb=2, sbd=11, backw=11, backd=13, side=5),
    "cap": dict(fr=[0] * 16, sb=2, sbd=7, backw=4, backd=9, side=4),
    "ponytail": dict(fr=[4, 3, 3, 3, 3, 2, 3, 3, 3, 3, 2, 3, 3, 3, 3, 4], sb=2, sbd=7, backw=4, backd=11, side=5),
}


def covered(p, face, x, y):
    """Is this pixel of the head covered by hair? (x, y local, 16x16 face)"""
    h = HAIR[p["hairstyle"]]
    if face == "top":
        return True
    if face == "front":
        if y < h["fr"][x]:
            return True
        return (x < h["sb"] or x > 15 - h["sb"]) and y < h["sbd"]
    if face == "back":
        d = h["backd"] - (2 if x in (0, 15) else 1 if x in (1, 14) else 0)
        if p["hairstyle"] in ("short", "messy", "cap") and 5 < y:
            d = min(d, 6 + (3 if 3 < x < 12 else 0))
        return y < d
    # sides: x = 0 is the back of the head on the right face, the front on the left face
    dist_back = x if face == "right" else 15 - x
    dist_front = 15 - dist_back
    if y < h["side"]:
        return True
    if dist_front < h["sb"] and y < h["sbd"]:
        return True
    return dist_back < h["backw"] and y < h["backd"]


def hair_color(p, face, x, y):
    base = hexc(p["hair"])
    streak = nz(x // 1 + (3 if face == "back" else 0), 7, 5) * 0.10
    wave = math.sin(x * 0.9 + y * 0.35) * 0.04
    gloss = 0.0
    if face in ("front", "top"):
        gloss = 0.16 * max(0.0, 1.0 - abs(y - (2.0 if face == "front" else 6.0)) / 1.5)
    root = -0.12 if (face == "front" and y == 0) else 0.0
    return shade(base, streak + wave + gloss + root + nz(x, y, 9) * 0.03)


# ------------------------------------------------------------------ head
def skin_c(p, x, y, shadow=0.0):
    return shade(hexc(p["skin"]), nz(x, y, 3) * 0.012 + shadow)


def paint_head(T, p, face):
    skin = hexc(p["skin"])
    hair = hexc(p["hair"])
    hd = box(T, *HEAD)
    ht = box(T, *HAT)
    # skin on all faces, then hair on both layers
    for n, f in hd.items():
        f.each(lambda x, y, n=n: skin_c(p, x, y, -0.06 if n == "bottom" else 0.0))
    for n in ("front", "right", "left", "back", "top"):
        f, g = hd[n], ht[n]
        for y in range(16):
            for x in range(16):
                if covered(p, n, x, y):
                    c = hair_color(p, n, x, y)
                    f.set(x, y, shade(c, -0.05))
                    g.set(x, y, c)
    # hairline shadow on the forehead and ears
    fr = hd["front"]
    for x in range(16):
        d = HAIR[p["hairstyle"]]["fr"][x]
        if d < 8 and not (x < HAIR[p["hairstyle"]]["sb"] or x > 15 - HAIR[p["hairstyle"]]["sb"]):
            fr.set(x, d, skin_c(p, x, d, -0.10))
    for n in ("right", "left"):
        f = hd[n]
        for y in range(7, 12):
            for x in range(6, 10):
                if not covered(p, n, x, y):
                    edge = x in (6, 9) or y in (7, 11)
                    f.set(x, y, skin_c(p, x, y, -0.12 if edge else 0.04))
                    if not edge:
                        f.set(x, y, mix(skin_c(p, x, y), (232, 150, 140), 0.25))

    # style extras on the hat layer
    st = p["hairstyle"]
    if st == "bun":
        for y in range(2, 11):
            for x in range(3, 13):
                r = math.hypot(x - 7.5, y - 6.0)
                if r < 4.6:
                    ht["top"].set(x + 0 if x < 16 else 15, y, shade(hair, 0.10 - r * 0.045 + nz(x, y, 2) * 0.03))
        ht["back"].fill(5, 7, 6, 1, shade(hair, -0.3))               # the hair tie
    if st == "pigtails":
        tie = hexc(p["shoes"])
        for n in ("right", "left"):
            for y in range(5, 9):
                for x in range(5, 11):
                    ht[n].set(x, y, shade(hair, nz(x, y, 6) * 0.08 + (0.1 if y < 6 else 0)))
            ht[n].fill(7, 5, 3, 2, tie)
            ht[n].set(8, 5, shade(tie, 0.3))
    if st == "ponytail":
        for y in range(2, 11):
            for x in range(5, 11):
                ht["back"].set(x, y, shade(hair, 0.05 + 0.08 * math.sin(x * 1.6 + y * 0.4) + nz(x, y, 11) * 0.04))
        ht["back"].fill(5, 3, 6, 2, hexc(p["trim"]))
        ht["back"].fill(6, 3, 4, 1, shade(hexc(p["trim"]), 0.25))
    if st == "braid":
        for y in range(7, 16):
            for x in range(10, 14):
                k = (y + (x - 10)) % 3
                ht["back"].set(x, y, shade(hair, (-0.14, 0.0, 0.1)[k] + nz(x, y, 8) * 0.03))
        ht["back"].fill(10, 15, 4, 1, hexc(p["shoes"]))

    if p.get("cap"):
        cap = hexc(p["cap"])
        for n in ("front", "right", "left", "back", "top"):
            for y in range(16):
                for x in range(16):
                    lim = 4 if n != "front" else 5
                    if n == "top" or y < lim:
                        sh = 0.0
                        if n == "top":
                            sh = 0.08 + (0.1 if (x == 7 or x == 8) else 0.0)
                            if abs(x - 7.5) < 0.6 or abs(y - 7.5) < 0.6:
                                sh -= 0.12                       # panel seams
                        elif y == lim - 1:
                            sh = -0.14                          # the headband
                        ht[n].set(x, y, shade(cap, sh + nz(x, y, 12) * 0.025))
        # peak: a darker brim row sticking out under the front
        for x in range(16):
            ht["front"].set(x, 5, shade(cap, -0.30))
            if 2 < x < 13:
                ht["front"].set(x, 6, shade(cap, -0.42))
        ht["front"].fill(6, 1, 4, 3, shade(cap, 0.30))             # little cup badge
        ht["front"].fill(7, 2, 2, 1, (255, 255, 255))
    if p.get("beanie"):
        bn = hexc(p["beanie"])
        for n in ("front", "right", "left", "back", "top"):
            for y in range(16):
                for x in range(16):
                    lim = 6
                    if n == "top" or y < lim:
                        sh = 0.0
                        if n != "top":
                            if y >= lim - 2:
                                sh = 0.10 + (0.06 if (x + y) % 2 == 0 else -0.04)     # ribbed cuff
                            else:
                                sh = 0.05 * math.sin(x * 1.2) + (0.04 if y % 2 == 0 else 0)
                        ht[n].set(x, y, shade(bn, sh + nz(x, y, 13) * 0.02))
        # the fringe is still visible under the cuff, a little
        for x in range(2, 14):
            ht["front"].set(x, 6, shade(hair, -0.1 + nz(x, 6, 1) * 0.05)) if x % 3 != 0 else None
    if p.get("chef"):
        for x in range(16):
            ht["front"].set(x, 0, shade(hair, -0.1))

    # ---- the face (front 16x16)
    paint_face(T, p, face, hd["front"], ht["front"])
    if p.get("beard"):
        paint_beard(T, p, hd, ht)
    if p.get("glasses"):
        paint_glasses(p, ht["front"], ht["right"], ht["left"])


def paint_face(T, p, face, f, g):
    skin = hexc(p["skin"])
    hair = hexc(p["hair"])
    iris = hexc(p["eyes"])
    lid = shade(skin, -0.38)
    lash = mix(shade(hair, -0.2), shade(skin, -0.55), 0.55) if sum(hair) > 200 else (74, 58, 62)
    if p["hair"] == "#b9b9b9":
        lash = (110, 110, 118)
    brow = shade(hair, 0.06) if sum(hair) < 200 else shade(hair, -0.12)
    if p["hair"] == "#b9b9b9":
        brow = (150, 150, 155)
    lips = hexc(p.get("lips", "#c4665a"))
    white = (246, 246, 250)
    blush = (238, 140, 140)
    angry, happy, blink = face == "angry", face == "happy", face == "blink"
    # blush / cheek light and nose
    for (cx, cy) in ((3.5, 11.0), (12.5, 11.0)):
        for y in range(8, 14):
            for x in range(16):
                r = math.hypot(x + 0.5 - cx, (y + 0.5 - cy) * 1.4)
                if r < 2.4:
                    c = f.get(x, y)
                    if c[3]:
                        k = (0.30 if happy else 0.12) * (1 - r / 2.4)
                        f.set(x, y, mix(c[:3], blush, k))
    f.set(7, 10, skin_c(p, 7, 10, -0.10)); f.set(8, 10, skin_c(p, 8, 10, -0.14))
    f.set(7, 9, skin_c(p, 7, 9, 0.05))
    f.set(8, 11, skin_c(p, 8, 11, -0.07))

    # eyes: left eye x 3..6, right eye x 9..12, rows 7..9
    for ex in (3, 9):
        mirror = ex == 9
        if blink:
            f.fill(ex, 8, 4, 1, lid)
            f.set(ex if not mirror else ex + 3, 9, lash if p.get("lash") else lid)
            f.fill(ex, 7, 4, 1, skin_c(p, ex, 7, -0.05))
        elif happy:
            f.set(ex + 1, 8, lash); f.set(ex + 2, 8, lash)
            f.set(ex, 9, lash); f.set(ex + 3, 9, lash)
            f.fill(ex + 1, 9, 2, 1, skin_c(p, ex, 9, 0.05))
            if p.get("lash"):
                f.set(ex - 1 if not mirror else ex + 4, 8, lash)
        else:
            f.fill(ex, 7, 4, 1, lash)                         # upper lid line
            if p.get("lash"):
                f.set(ex - 1 if not mirror else ex + 4, 7, lash)
                f.set(ex - 1 if not mirror else ex + 4, 8, lash)
            # eyeball
            f.set(ex, 8, white); f.set(ex + 3, 8, white)
            f.set(ex, 9, shade(white, -0.12)); f.set(ex + 3, 9, shade(white, -0.12))
            f.set(ex + 1, 8, shade(iris, 0.22)); f.set(ex + 2, 8, shade(iris, -0.5))
            f.set(ex + 1, 9, shade(iris, -0.1)); f.set(ex + 2, 9, iris)
            f.set(ex + (1 if not mirror else 1), 8, (255, 255, 255))      # the glint
            f.set(ex + 1, 8, mix(shade(iris, 0.5), (255, 255, 255), 0.6))
            f.set(ex + 2, 8, shade(iris, -0.55))
            if angry:
                f.set(ex + 1, 7, lash); f.set(ex + 2, 7, lash)
    # brows
    if angry:
        for k, y in enumerate((5, 5, 6, 6)):
            f.set(3 + k, y, brow)
            f.set(12 - k, y, brow)
        f.set(3, 4, brow); f.set(12, 4, brow)
    else:
        raise_ = 1 if happy else 0
        for k in range(4):
            f.set(3 + k, 5 - raise_ + (1 if k == 0 else 0), brow)
            f.set(9 + k, 5 - raise_ + (1 if k == 3 else 0), brow)
    # mouth
    lipd = shade(lips, -0.25)
    if happy:
        f.set(5, 12, lipd); f.set(10, 12, lipd)
        f.fill(6, 13, 4, 1, lipd)
        f.fill(6, 12, 4, 1, white)
        f.set(6, 12, shade(white, -0.1)); f.set(9, 12, shade(white, -0.1))
        f.fill(7, 14, 2, 1, mix(lips, (255, 120, 130), 0.5))
    elif angry:
        f.fill(6, 13, 4, 1, lipd)
        f.set(5, 14, lipd); f.set(10, 14, lipd)
        f.fill(7, 14, 2, 1, mix(skin, lips, 0.3))
    else:
        f.fill(6, 13, 4, 1, lipd)
        f.fill(7, 14, 2, 1, lips)
        f.set(5, 13, mix(skin, lips, 0.45)); f.set(10, 13, mix(skin, lips, 0.45))
    if p.get("mustache"):
        m = hexc(p["mustache"])
        for x in range(5, 11):
            f.set(x, 12, m)
        f.set(4, 13, m); f.set(11, 13, m)
        f.fill(6, 11, 4, 1, shade(m, 0.1))
        if face == "happy":
            f.fill(6, 13, 4, 1, shade(lips, -0.25))


def paint_beard(T, p, hd, ht):
    b = hexc(p["beard"])
    f, g = hd["front"], ht["front"]
    for y in range(10, 16):
        for x in range(16):
            edge = abs(x - 7.5)
            if y >= 12 and edge < 6.5 - (y - 12) * 0.4 and not (12 <= y <= 13 and 5 <= x <= 10) or (y == 11 and (x < 3 or x > 12)):
                g.set(x, y, shade(b, nz(x, y, 21) * 0.08))
            elif y >= 14 and edge < 5:
                g.set(x, y, shade(b, nz(x, y, 22) * 0.08))
    for y in range(8, 16):
        for x in range(0, 5):
            g.set(x, y, shade(b, nz(x, y, 23) * 0.08)) if (y > 9 and x < 2) else None
            g.set(15 - x, y, shade(b, nz(x, y, 24) * 0.08)) if (y > 9 and x < 2) else None
    for n in ("left", "right"):
        for y in range(11, 16):
            for x in range(0, 16):
                dist_front = (15 - x) if n == "right" else x
                if dist_front < 11:
                    ht[n].set(x, y, shade(b, nz(x, y, 25) * 0.08))


def paint_glasses(p, f, r, l):
    c = hexc(p["glasses"])
    glass = (210, 230, 245)
    for ex in (2, 9):
        for x in range(ex, ex + 5):
            f.set(x, 6, c); f.set(x, 10, c)
        for y in range(6, 11):
            f.set(ex, y, c); f.set(ex + 4, y, c)
        for y in range(7, 10):
            for x in range(ex + 1, ex + 4):
                a = f.get(x, y)
        f.set(ex + 1, 7, (255, 255, 255))
    f.set(7, 7, c); f.set(8, 7, c)                              # bridge
    for y in range(6, 8):
        r.set(15, y, c); l.set(0, y, c)
    for x in range(10, 16):
        r.set(x, 6, c)
    for x in range(0, 6):
        l.set(x, 6, c)


# ------------------------------------------------------------------ clothes
def fabric(c, x, y, seed=1, amt=0.02):
    return shade(c, nz(x, y, seed) * amt + (0.012 if (x + y) % 2 == 0 else -0.012))


def ao(f, strength=0.06, vertical=True):
    """Soft edge darkening of a box face (looks like ambient occlusion)."""
    for j in range(f.h):
        for i in range(f.w):
            c = f.get(i, j)
            if not c[3]:
                continue
            k = 0.0
            if i == 0 or i == f.w - 1:
                k += strength
            if vertical and j == f.h - 1:
                k += strength * 0.6
            if f.name not in ("top", "bottom") and f.h > 16:
                k += 0.07 * j / f.h - 0.02
            if k:
                f.set(i, j, shade(c[:3], -k))


def paint_body(T, p):
    top, trim, bottom, skin = hexc(p["top"]), hexc(p["trim"]), hexc(p["bottom"]), hexc(p["skin"])
    b = box(T, *BODY)
    j = box(T, *JACKET)
    shoes = hexc(p["shoes"])
    dress = p.get("skirt")
    shirt = top
    for n, f in b.items():
        if n in ("top", "bottom"):
            f.each(lambda x, y: fabric(shirt if n == "top" else bottom, x, y))
            continue
        def px(x, y, n=n, f=f):
            if y >= f.h - 4:                                   # trousers / skirt top
                return fabric(top if dress else bottom, x, y, 2)
            return fabric(shirt, x, y)
        f.each(px)
    # --- shirt details on the base layer
    fr, bk = b["front"], b["back"]
    if p.get("stripes"):
        for n in ("front", "back", "left", "right"):
            f = b[n]
            for y in range(0, f.h - 4):
                if (y // 3) % 2 == 1:
                    for x in range(f.w):
                        f.set(x, y, fabric(trim, x, y, 4))
    # shading: slightly darker sides of the torso
    for n in ("front", "back"):
        f = b[n]
        for y in range(f.h):
            for x in range(f.w):
                c = f.get(x, y)
                k = 0.0
                if x < 2 or x > f.w - 3:
                    k = -0.05
                if y == f.h - 5 and not dress:
                    k = -0.08
                if k:
                    f.set(x, y, shade(c[:3], k))
    # neckline
    if not p.get("hoodie") and not p.get("chef") and not p.get("apron"):
        for y in range(0, 3):
            for x in range(5, 11):
                if y < 2 or 6 <= x <= 9:
                    fr.set(x, y, skin_c(p, x, y, -0.03 - y * 0.02))
        for x in range(4, 12):
            fr.set(x, 3 if x in (4, 11) else 2, shade(trim, -0.05)) if x in (4, 5, 10, 11) else None
        for x in range(4, 12):
            fr.set(x, 3, shade(top, -0.12)) if 4 < x < 11 and p.get("sweater") else None
    else:
        for x in range(6, 10):
            fr.set(x, 0, skin_c(p, x, 0, -0.04))
    # belt / waistline
    if not dress and not p.get("chef"):
        for n in ("front", "back", "left", "right"):
            f = b[n]
            for x in range(f.w):
                f.set(x, f.h - 5, shade(bottom, -0.35))
                f.set(x, f.h - 4, shade(bottom, -0.18))
        fr.fill(7, fr.h - 5, 2, 2, (210, 190, 120))
        fr.fill(7, fr.h - 4, 2, 1, (170, 150, 90))
    if p.get("chef"):
        for x in range(16):
            for y in range(fr.h - 4, fr.h):
                fr.set(x, y, fabric(bottom, x, y, 2))
    for f in b.values():
        ao(f)

    # --- second layer (jacket): transparent unless drawn
    def jfill(f, x0, y0, x1, y1, fn):
        for y in range(y0, y1):
            for x in range(x0, x1):
                c = fn(x, y)
                if c is not None:
                    f.set(x, y, c)

    jf, jb, jl, jr = j["front"], j["back"], j["left"], j["right"]
    if p.get("hoodie"):
        hood = shade(top, -0.07)
        for f in (jf, jb, jl, jr):
            jfill(f, 0, 0, f.w, f.h - 4, lambda x, y: None)
        # the hood hangs on the back of the neck
        jfill(jb, 3, 0, 13, 6, lambda x, y: fabric(shade(top, -0.1 + 0.03 * (y % 2)), x, y, 7))
        jfill(jl, 0, 0, 8, 3, lambda x, y: fabric(hood, x, y, 8))
        jfill(jr, 0, 0, 8, 3, lambda x, y: fabric(hood, x, y, 9))
        jfill(jf, 3, 0, 13, 2, lambda x, y: fabric(hood, x, y, 10) if not (6 <= x <= 9) else None)
        # drawstrings and the pocket
        for y in range(2, 9):
            jf.set(6, y, (235, 235, 240)); jf.set(9, y, (235, 235, 240))
        jf.set(6, 9, (200, 200, 210)); jf.set(9, 9, (200, 200, 210))
        for x in range(4, 12):
            jf.set(x, 12, shade(top, -0.18)); jf.set(x, 17, shade(top, -0.14))
        for y in range(12, 18):
            jf.set(4, y, shade(top, -0.16)); jf.set(11, y, shade(top, -0.16))
        jfill(jf, 5, 13, 11, 17, lambda x, y: fabric(shade(top, -0.04), x, y, 11))
        # ribbed hem
        for n, f in (("f", jf), ("b", jb), ("l", jl), ("r", jr)):
            for x in range(f.w):
                for y in range(f.h - 7, f.h - 4):
                    f.set(x, y, shade(top, -0.05 + (0.05 if x % 2 == 0 else -0.04)))
    if p.get("sweater"):
        for f in (jf, jb):
            for y in range(f.h - 7, f.h - 4):
                for x in range(f.w):
                    f.set(x, y, shade(top, 0.06 + (0.05 if x % 2 == 0 else -0.06)))
            for y in range(3, 14):                              # a cable pattern
                for x in (4, 11):
                    f.set(x, y, shade(top, 0.08)); f.set(x + 1, y, shade(top, -0.06))
        for y in range(2, 5):                                   # the collar
            for x in range(4, 12):
                if y == 2 and 5 < x < 10:
                    continue
                jf.set(x, y, shade(top, 0.08 + (0.05 if x % 2 == 0 else -0.04)))
        for x in range(4, 12):
            jb.set(x, 1, shade(top, 0.08)); jb.set(x, 2, shade(top, 0.06 + (0.05 if x % 2 == 0 else -0.04)))
    if p.get("tee"):
        c1 = (255, 255, 255)
        for y in range(7, 13):                                  # a little cup print
            for x in range(6, 10):
                if (y in (7, 12)) or (x in (6, 9) and y < 12):
                    jf.set(x, y, c1)
        jf.fill(7, 8, 2, 3, (130, 78, 52))
        jf.set(10, 9, c1); jf.set(10, 10, c1); jf.set(11, 9, c1)
        for x in range(5, 11):
            jf.set(x, 2, shade(top, -0.18)); jf.set(x, 3, shade(top, -0.10))
    if p.get("cardigan"):
        card = top
        inner = trim
        for y in range(0, jf.h - 4):
            for x in range(16):
                if 5 <= x <= 10:
                    jf.set(x, y, fabric(inner, x, y, 31))
                else:
                    jf.set(x, y, fabric(card, x, y, 32))
        for y in range(0, jf.h - 4):
            jf.set(5, y, shade(card, -0.2)); jf.set(10, y, shade(card, -0.2))
        for y in (4, 9, 14):
            jf.fill(5, y, 1, 2, (235, 215, 160)); jf.set(5, y, (255, 240, 190))
        for x in range(1, 5):
            jf.set(x, 15, shade(card, -0.15)); jf.set(x, 20 - 4, shade(card, -0.15))
        for y in range(15, 20 - 3):
            jf.set(1, y, shade(card, -0.15)); jf.set(4, y, shade(card, -0.15))
        for y in range(2, 6):                                  # the shawl collar
            for x in range(3, 13):
                if not (6 <= x <= 9 and y < 3):
                    jf.set(x, y, shade(card, 0.10 - 0.02 * y))
        for x in range(16):
            for y in range(jf.h - 7, jf.h - 4):
                if not 5 <= x <= 10:
                    jf.set(x, y, shade(card, 0.05 + (0.05 if x % 2 == 0 else -0.05)))
        jfill(jb, 0, 0, 16, jb.h - 4, lambda x, y: fabric(card, x, y, 33))
        for y in range(jb.h - 7, jb.h - 4):
            for x in range(16):
                jb.set(x, y, shade(card, 0.05 + (0.05 if x % 2 == 0 else -0.05)))
        for f in (jl, jr):
            jfill(f, 0, 0, 8, f.h - 4, lambda x, y: fabric(card, x, y, 34))
    if p.get("coat"):
        coat = hexc(p["coat"])
        for f in (jf, jb, jl, jr):
            jfill(f, 0, 0, f.w, f.h, lambda x, y: fabric(coat, x, y, 41))
        for y in range(0, jf.h):                                # the opening and the lapels
            for x in range(16):
                w = 3 + (jf.h - 1 - y) * 0.0
                if abs(x - 7.5) < 1.2 + (0.4 if y < 10 else 0):
                    jf.set(x, y, shade(top, 0.0 + y * 0.002))
        for y in range(0, 9):
            for x in range(16):
                dx = abs(x - 7.5)
                if 1.2 + y * 0.07 < dx < 3.4 and y < 8:
                    jf.set(x, y, shade(coat, 0.15 - 0.02 * y + (0.05 if x % 2 == 0 else 0)))
        for x in range(16):
            jf.set(x, 14, shade(coat, -0.3)); jf.set(x, 15, shade(coat, -0.15))
            jb.set(x, 14, shade(coat, -0.3)); jb.set(x, 15, shade(coat, -0.15))
        jf.fill(7, 14, 2, 2, (200, 170, 90)); jf.set(7, 14, (255, 235, 160))
        for y in (7, 11, 18):
            jf.set(9, y, shade(coat, -0.4)); jf.set(10, y, shade(coat, -0.3))
        # the coat is shorter than the trousers
    if dress:
        sk = bottom
        for f in (jf, jb, jl, jr):
            for y in range(f.h - 8, f.h):
                for x in range(f.w):
                    fold = 0.04 * math.sin(x * 1.1 + y * 0.2) + (0.05 if y == f.h - 8 else 0.0)
                    f.set(x, y, shade(sk, fold + nz(x, y, 51) * 0.02 - (0.06 if y > f.h - 3 else 0.0)))
        for x in range(16):
            jf.set(x, jf.h - 8, shade(sk, -0.18)); jb.set(x, jb.h - 8, shade(sk, -0.18))
        for y in range(2, 6):                                   # a little collar and white dots on the bodice
            for x in range(3, 13):
                if abs(x - 7.5) > 1.6 or y > 3:
                    jf.set(x, y, shade((255, 255, 255), -0.04)) if y < 4 and abs(x - 7.5) < 3.4 and abs(x - 7.5) > 1.2 else None
        for (x, y) in ((4, 7), (7, 9), (10, 7), (5, 12), (9, 13), (12, 11), (3, 14), (11, 15)):
            jf.set(x, y, trim); jf.set(x + 1, y, trim)
    if p.get("chef"):
        w = (252, 250, 244)
        for f in (jf, jb, jl, jr):
            jfill(f, 0, 0, f.w, f.h - 4, lambda x, y: fabric(w, x, y, 61, 0.012))
        for y in range(0, jf.h - 4):
            jf.set(8, y, shade(w, -0.12)); jf.set(7, y, shade(w, -0.05))
        for k, y in enumerate((5, 9, 13, 17)):
            for x in (5, 10):
                jf.set(x, y, (140, 145, 155)); jf.set(x + 1, y, (190, 195, 205)); jf.set(x, y + 1, (190, 195, 205))
        for y in range(0, jf.h - 4):
            jf.set(3, y, shade(w, -0.08)) if y > 4 else None
            jf.set(12, y, shade(w, -0.08)) if y > 4 else None
        for y in range(2, 5):                                   # the collar band and the red neckerchief
            for x in range(4, 12):
                jf.set(x, y, shade(w, -0.04))
        for y in range(2, 7):
            for x in range(6, 10):
                if y < 4 or abs(x - 7.5) < 2 - (y - 4) * 0.8:
                    jf.set(x, y, (205, 60, 60) if (x + y) % 3 else (230, 90, 85))
        for x in range(4, 12):
            jb.set(x, 1, shade(w, -0.06)); jb.set(x, 2, (205, 60, 60))
        for x in range(16):
            jf.set(x, jf.h - 5, shade(w, -0.1)); jb.set(x, jb.h - 5, shade(w, -0.1))
        jf.fill(10, 8, 4, 3, shade(w, -0.06))                   # breast pocket
        jf.fill(10, 8, 4, 1, shade(w, -0.2))
        jf.fill(11, 6, 1, 3, (60, 90, 160))                     # a pen
    if p.get("apron"):
        ap = hexc(p["apron"])
        for y in range(4, jf.h):
            x0 = 4 if y < 12 else 2
            x1 = 12 if y < 12 else 14
            for x in range(x0, x1):
                jf.set(x, y, fabric(ap, x, y, 71, 0.025))
        for y in range(4, jf.h):
            x0 = 4 if y < 12 else 2
            x1 = 11 if y < 12 else 13
            jf.set(x0, y, shade(ap, -0.22)); jf.set(x1, y, shade(ap, -0.22))
        for x in range(4, 12):
            jf.set(x, 4, shade(ap, -0.22)); jf.set(x, 12, shade(ap, -0.30))
        for x in range(2, 14):
            jf.set(x, jf.h - 1, shade(ap, -0.30))
        for y in range(0, 5):                                   # straps over the shoulders
            jf.set(4, y, shade(ap, -0.12)); jf.set(5, y, ap)
            jf.set(10, y, ap); jf.set(11, y, shade(ap, -0.12))
        for x in range(2, 14):
            jf.set(x, 13, shade(ap, -0.35)); jf.set(x, 14, shade(ap, 0.0))
        jf.fill(5, 16, 6, 5, shade(ap, -0.1))                   # the big pocket
        jf.fill(5, 16, 6, 1, shade(ap, -0.35))
        for y in range(16, 21):
            jf.set(5, y, shade(ap, -0.3)); jf.set(10, y, shade(ap, -0.3))
        jf.fill(7, 17, 2, 2, hexc(p["trim"]))
        jf.set(7, 17, (250, 245, 235))
        for y in range(0, 5):
            jb.set(4, y, ap); jb.set(5, y, shade(ap, -0.1)); jb.set(10, y, shade(ap, -0.1)); jb.set(11, y, ap)
        for y in range(5, 14):
            jb.set(3 + (y - 5) // 2, y, shade(ap, -0.1)); jb.set(12 - (y - 5) // 2, y, shade(ap, -0.1))
        for x in range(0, 16):
            jb.set(x, 13, shade(ap, -0.3)); jb.set(x, 14, ap)
        for y in range(14, 20):
            jb.set(7, y, ap); jb.set(8, y, shade(ap, -0.15))
        for y in range(15, 18):
            jl.set(2 + (y % 2), y, ap); jr.set(13 - (y % 2), y, ap)
    for f in j.values():
        ao(f, 0.05)


def paint_arms(T, p):
    top, trim, skin = hexc(p["top"]), hexc(p["trim"]), hexc(p["skin"])
    sl = p["sleeve"] * S
    long_sleeve = p["sleeve"] >= 8
    for (au, sv) in ((RARM, RSLV), (LARM, LSLV)):
        a = box(T, *au)
        s2 = box(T, *sv)
        for n, f in a.items():
            def px(x, y, n=n, f=f):
                if n == "top":
                    return fabric(top, x, y)
                if n == "bottom":
                    return skin_c(p, x, y, -0.06)
                if y < sl:
                    return fabric(top, x, y, 5)
                return skin_c(p, x, y)
            f.each(px)
            if n in ("front", "back", "left", "right"):
                # shading of the arm: darker toward the body, a fold at the elbow
                for y in range(f.h):
                    for x in range(f.w):
                        c = f.get(x, y)
                        if y in (11, 12) and y >= sl:
                            f.set(x, y, shade(c[:3], -0.05))
                        if y == sl - 1 and sl < f.h:
                            f.set(x, y, shade(trim, -0.05) if not p.get("stripes") else shade(top, -0.18))
                        if y == sl and sl < f.h:
                            f.set(x, y, skin_c(p, x, y, -0.12))
                # fingers: the last rows of the hand
                if y_hand(f) and n == "front":
                    for x in (1, 2, 3, 4):
                        f.set(x, f.h - 1, skin_c(p, x, 0, -0.10 + 0.0))
                    for x in (2, 4):
                        f.set(x - 1, f.h - 2, skin_c(p, x, 0, -0.08))
                    f.set(5, f.h - 4, skin_c(p, 5, 0, -0.07))
            ao(f, 0.05)
            if p.get("stripes") and n not in ("top", "bottom"):
                for y in range(0, min(sl, f.h)):
                    if (y // 3) % 2 == 1:
                        for x in range(f.w):
                            f.set(x, y, fabric(trim, x, y, 4))
        if p.get("chef") or p.get("cardigan") or p.get("coat") or p.get("hoodie") or p.get("sweater") or p.get("apron"):
            col = hexc(p["coat"]) if p.get("coat") else (252, 250, 244) if p.get("chef") else top
            for n, f in s2.items():
                if n in ("top", "bottom"):
                    continue
                if p.get("apron"):
                    continue
                for y in range(0, min(sl, f.h)):
                    for x in range(f.w):
                        f.set(x, y, fabric(col, x, y, 81, 0.015))
                cuff = 3
                for y in range(max(0, sl - cuff), min(sl, f.h)):
                    for x in range(f.w):
                        if p.get("chef"):
                            f.set(x, y, fabric((236, 232, 220), x, y, 82))
                        else:
                            f.set(x, y, shade(col, 0.06 + (0.05 if x % 2 == 0 else -0.05)))
                if p.get("chef"):
                    f.set(0, sl - 3, (140, 145, 155)) if n == "front" else None
        if p.get("apron"):                                     # rolled-up sleeves: a thick roll at the elbow
            for n, f in s2.items():
                if n in ("top", "bottom"):
                    continue
                for y in range(sl - 3, sl + 1):
                    for x in range(f.w):
                        f.set(x, y, shade(top, -0.05 + (0.08 if y == sl - 3 else 0.0) - (0.1 if y == sl else 0.0)))


def y_hand(f):
    return f.h >= 24


def paint_legs(T, p):
    bottom, shoes, skin = hexc(p["bottom"]), hexc(p["shoes"]), hexc(p["skin"])
    top = hexc(p["top"])
    skirt = p.get("skirt")
    for (lu, pu) in ((RLEG, RPANT), (LLEG, LPANT)):
        l = box(T, *lu)
        pn = box(T, *pu)
        for n, f in l.items():
            def px(x, y, n=n, f=f):
                if n == "top":
                    return fabric(bottom, x, y)
                if n == "bottom":
                    return shade(shoes, -0.35)
                if y >= f.h - 4:
                    # shoe: sole at the bottom, toe cap, laces
                    if y >= f.h - 1:
                        return shade(shoes, -0.5)
                    return fabric(shoes, x, y, 91, 0.03) if not (n == "front" and y == f.h - 4 and 1 < x < f.w - 2) else shade(shoes, 0.18)
                if skirt and y >= skirt * S:
                    # bare leg + a sock
                    if y >= f.h - 8:
                        return fabric((250, 250, 252), x, y, 92)
                    return skin_c(p, x, y, -0.02)
                return fabric(bottom, x, y, 93)
            f.each(px)
            if n in ("front", "back", "left", "right") and not skirt:
                for y in range(f.h - 4):
                    for x in range(f.w):
                        c = f.get(x, y)
                        k = 0.0
                        if y in (9, 10) and n in ("front",):
                            k = -0.04                           # the knee fold
                        if n == "front" and x == f.w // 2 and y > 2:
                            k += 0.04                           # the crease
                        if n == "back" and y == 4 and 2 <= x <= f.w - 3:
                            k = -0.12                           # pocket edge
                        if k:
                            f.set(x, y, shade(c[:3], k))
                if p.get("chef"):
                    chk = shade(bottom, -0.13)
                    for y in range(0, f.h - 4):
                        for x in range(f.w):
                            if ((x // 2) + (y // 2)) % 2 == 0:
                                f.set(x, y, fabric(chk, x, y, 94))
                for x in range(f.w):                            # the hem
                    f.set(x, f.h - 5, shade(bottom, -0.2))
            if n in ("front", "back", "left", "right"):
                # shoe details: a dark sole line and a light highlight on top
                for x in range(f.w):
                    f.set(x, f.h - 4, shade(shoes, 0.1)) if n != "front" or not (1 < x < f.w - 2) else f.set(x, f.h - 4, shade(shoes, 0.25))
                if n == "front":
                    for x in (3, 4):
                        f.set(x, f.h - 3, (240, 240, 240)) if sum(shoes) < 400 else None
            ao(f, 0.05)
        if skirt:
            sk = bottom
            for n, f in pn.items():
                if n in ("top", "bottom"):
                    continue
                for y in range(0, skirt * S + 2):
                    for x in range(f.w):
                        f.set(x, y, shade(sk, 0.03 * math.sin(x * 1.3) + nz(x, y, 95) * 0.02 - (0.1 if y >= skirt * S + 1 else 0)))
        elif p.get("chef"):
            pass
        for f in pn.values():
            pass


def paint_toque(T):
    white = (252, 250, 244)
    fold = (226, 222, 212)
    pf = box(T, 0, 64, 8, 6, 8)
    for n, f in pf.items():
        def px(x, y, n=n, f=f):
            if n == "top":
                r = math.hypot(x - f.w / 2 + 0.5, y - f.h / 2 + 0.5)
                return shade(white, -0.04 * (r / 8) + nz(x, y, 97) * 0.015)
            if n == "bottom":
                return shade(white, -0.12)
            pleat = math.sin(x * 1.7) * 0.5 + 0.5
            return shade(white, -0.08 * pleat + (-0.05 if y == f.h - 1 else 0.0) + nz(x, y, 98) * 0.012)
        f.each(px)
    bf = box(T, 0, 80, 9, 3, 9)
    for n, f in bf.items():
        def px(x, y, n=n, f=f):
            if n in ("top", "bottom"):
                return shade(white, -0.1)
            return shade(white, -0.04 + (-0.10 if y == f.h - 1 else 0.0) + (0.04 if y == 0 else 0.0) + nz(x, y, 99) * 0.012)
        f.each(px)


def make(p, face):
    T = Tex()
    paint_body(T, p)
    paint_arms(T, p)
    paint_legs(T, p)
    paint_head(T, p, face)
    if p.get("chef"):
        paint_toque(T)
    return T.image()


def main():
    os.makedirs(OUT, exist_ok=True)
    for i, p in enumerate(PEOPLE):
        for k, face in enumerate(FACES):
            make(p, face).save(os.path.join(OUT, "person_%d_%d.png" % (i, k)))
    print("wrote", len(PEOPLE) * len(FACES), "skins", W, "x", H)


if __name__ == "__main__":
    main()
