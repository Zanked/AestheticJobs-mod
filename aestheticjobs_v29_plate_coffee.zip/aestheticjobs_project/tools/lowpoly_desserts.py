"""The 32 desserts as low-poly miniatures with hand-painted 32x textures (2 texture pixels per model unit), in the
spirit of cosy decoration mods: a few big cuboids and true octagons, and all the fine detail painted pixel by pixel.

Coordinates are model units (16 = one block), y is up, the dessert stands on y = 0 around the middle (8, 8) and its
front looks north (small z). Every dessert function returns a list of parts (see tools/smooth.py).

A paint is a function p -> colour, where p says which texture pixel is painted: p.x, p.y, p.z are its place counted in
texture pixels, p.face the side, and p.top / p.bottom / p.rim tell that it lies on the upper edge, the lower edge or the
outline of the shape. Light edges and shaded feet are added automatically, so a paint only says what the food looks like.
"""
import math
import zlib
from collections import namedtuple

from PIL import Image

import smooth
import style

P = namedtuple("P", "x y z face top bottom rim u v")
SIDES = ("north", "south", "east", "west")
ALL = SIDES + ("up", "down")


def rgb(c):
    return (int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)) if isinstance(c, str) else c


def rnd(a, b, c=0, salt=0):
    return (zlib.crc32(bytes((a & 255, b & 255, c & 255, salt & 255))) & 0xFFFF) / 65535.0


def tones(base, light, dark, salt=0, spots=0.16, cell=2):
    """A painted material: the base colour with small clusters of its light and dark tone (never single-pixel noise
    on every pixel: clusters of `cell` pixels, shifted row by row so that no grid shows)."""
    def paint(p):
        shift = int(rnd(p.y, p.z // cell, 0, salt + 3) * cell)
        n = rnd((p.x + shift) // cell, p.y, p.z // cell, salt)
        return light if n < spots else dark if n > 1.0 - spots else base
    return paint


def solid(c):
    return lambda p: c


def _value(paint, p):
    return rgb(paint(p) if callable(paint) else paint)


def _lit(c, p, lift, foot):
    """The same light on every dessert: a bright upper edge, a bright rim on top, a shaded foot."""
    if p.face == "up":
        return style.shade(c, 1.0, 0.22 * lift) if p.rim else c
    if p.face == "down":
        return style.shade(c, 0.86)
    if p.top:
        return style.shade(c, 1.0, 0.20 * lift)
    if p.bottom and foot:
        return style.shade(c, 0.84)
    return c


# ------------------------------------------------------------------------------------------------ the two shapes
def box(x0, y0, z0, x1, y1, z1, side, top=None, rot=0, faces=ALL, lift=1.0, foot=True):
    """One cuboid. rot turns it around its own vertical axis (0, +-22.5 or +-45 degrees)."""
    top = side if top is None else top
    ox, oz = (x0 + x1) / 2.0, (z0 + z1) / 2.0

    def shader(x, y, z, face):
        lx, lz = (smooth.turn(x, z, -rot, ox, oz) if rot else (x, z))
        rim = face == "up" and (lx - x0 < 0.5 or x1 - lx < 0.5 or lz - z0 < 0.5 or z1 - lz < 0.5)
        u = (lx - x0) / (x1 - x0)
        v = (lz - z0) / (z1 - z0)
        p = P(int(math.floor(lx * 2)), int(math.floor(y * 2)), int(math.floor(lz * 2)), face,
              y1 - y < 0.5, y - y0 < 0.5, rim, u, v)
        return _lit(_value(top if face in ("up", "down") else side, p), p, lift, foot and y1 - y0 > 1.0)
    part = smooth.box((x0, y0, z0), (x1, y1, z1), shader, faces, (rot, ox, oz) if rot else None)
    part["raw"] = True
    return [part]


def _oct_shader(cx, cz, r, y0, y1, side, top, lift, foot, inner_r=None):
    def shader(x, y, z, face):
        dx, dz = x - cx, z - cz
        d = max(abs(dx), abs(dz), (abs(dx) + abs(dz)) / (1 + smooth.K))
        rim = face == "up" and r >= 1.5 and d > r - 0.5
        p = P(int(math.floor(x * 2)), int(math.floor(y * 2)), int(math.floor(z * 2)), face,
              y1 - y < 0.5, y - y0 < 0.5, rim, dx / r, dz / r)
        return _lit(_value(top if face in ("up", "down") else side, p), p, lift, foot and y1 - y0 > 1.0)
    return shader


def disc(r, y0, y1, side, top=None, cx=8.0, cz=8.0, lift=1.0, foot=True, bottom=True):
    """A true octagon; in paints p.u and p.v are the place from its middle, -1..1."""
    sh = _oct_shader(cx, cz, r, y0, y1, side, side if top is None else top, lift, foot)
    parts = smooth.octagon(cx, cz, r, y0, y1, sh, sh, bottom)
    for part in parts:                                     # the rim is painted above, not a second time by smooth
        part["faces"] = {f: sh for f in part["faces"]}
        part["raw"] = True
    return parts


def ring(r, thick, y0, y1, side, top=None, cx=8.0, cz=8.0, lift=1.0):
    """A hollow octagon (donuts, tart walls, the rim of a ramekin)."""
    sh = _oct_shader(cx, cz, r, y0, y1, side, side if top is None else top, lift, True)
    parts = smooth.ring(cx, cz, r, thick, y0, y1, sh, sh, sh, True)
    for part in parts:
        part["raw"] = True
    return parts


# ------------------------------------------------------------------------------------------------ materials
BAKED = tones("DE9F52", "EDB668", "C4853F", 1)
DOUGH = tones("EBBB74", "F7D190", "D8A25A", 2)
SPONGE = tones("F4D391", "FCE3AE", "E2BA70", 3)
SPONGE_C = tones("74432F", "89533B", "5E3424", 4)
CHOC = tones("603526", "774534", "4C291D", 5, 0.12)
CREAM = tones("FFF3DE", "FFFBF0", "F2DDBC", 6, 0.12)
PINK = tones("F5A9C0", "FCC4D5", "E08BA6", 7, 0.12)
CUSTARD = tones("F6C75F", "FFDA80", "E5AE45", 8, 0.12)
WHITE = "FFFAF0"
RED, RED_L, RED_D = "DA4552", "F1737A", "AC2F3E"
LEAF, LEAF_L, LEAF_D = "6BA84E", "8FC86C", "4E8438"
GOLD = "F3C95C"
SPRINKLES = ("FFF6E8", "7FCBC0", "F6D35A", "8FA6E8", "E4566A")


def sprinkled(base, salt, density=0.17, colors=SPRINKLES):
    """Little two-pixel sprinkles lying in both directions on a base paint."""
    def paint(p):
        for dx, dz, along in ((0, 0, 0), (1, 0, 1), (0, 1, 2)):
            x, z = p.x - dx, p.z - dz
            n = rnd(x, z, 0, salt)
            if (x + 2 * z) % 3 == 0 and n < density and (along == 0 or (along == 1) == (rnd(x, z, 1, salt) < 0.5)):
                return colors[int(n / density * len(colors)) % len(colors)]
        return _value(base, p)
    return paint


def gloss(base, light, cu=-0.4, cv=-0.4, radius=0.3):
    """A small highlight on a glazed top (the front left corner catches the light)."""
    def paint(p):
        if p.face == "up" and (p.u - cu) ** 2 + (p.v - cv) ** 2 < radius ** 2 and (p.x + p.z) % 4 != 0:
            return light
        return _value(base, p)
    return paint


def leaf(x, y, z):
    return box(x, y, z, x + 1.5, y + 0.5, z + 1.0, solid(LEAF), solid(LEAF_L), 22.5)


def strawberry(cx, y, cz, s=2.5):
    h = s / 2.0

    def skin(p):
        return "F8D970" if (p.x * 3 + p.y * 5 + p.z * 2) % 7 == 0 else RED if p.y < (y + h) * 2 else RED_L
    top = y + s * 0.8
    return (box(cx - h, y, cz - h, cx + h, top, cz + h, skin, skin)
            + box(cx - h * 0.6, top, cz - h * 0.6, cx + h * 0.6, top + 0.5, cz + h * 0.6, solid(LEAF), solid(LEAF_L), 45))


def cherry(cx, y, cz):
    def skin(p):
        return "FFB4B4" if p.face == "north" and p.top and p.u < 0.5 else RED
    return (box(cx - 1.0, y, cz - 1.0, cx + 1.0, y + 1.8, cz + 1.0, skin, gloss(RED, RED_L, -0.4, -0.4, 0.6))
            + box(cx - 0.25, y + 1.8, cz - 0.25, cx + 0.25, y + 3.3, cz + 0.25, solid("5F8E3C"), foot=False))


def blueberry(cx, y, cz, s=1.5):
    h = s / 2.0
    return box(cx - h, y, cz - h, cx + h, y + s, cz + h, solid("4F579C"),
               lambda p: "2F3568" if abs(p.u - 0.5) < 0.2 and abs(p.v - 0.5) < 0.2 else "7C86C4")


# ------------------------------------------------------------------------------------------------ pastry
CROISSANT_TURN = -45.0


def roll(cx, cz, long, deep, high, angle):
    """One turn of a croissant: a box lying at any multiple of 22.5 degrees (past 45 its sides change places)."""
    cx, cz = smooth.turn(cx, cz, CROISSANT_TURN, 8.0, 8.0)
    angle += CROISSANT_TURN
    rot = angle - 90.0 if angle > 45 else angle + 90.0 if angle < -45 else angle
    w, d = (deep, long) if rot != angle else (long, deep)

    def bake(p):
        x, z = (p.x + 0.5) / 2.0, (p.z + 0.5) / 2.0
        along = (smooth.turn(x, z, -angle, cx, cz)[0] - cx) / long + 0.5
        if along < 0.16 or along > 0.84:
            return "B96C28"                                              # the seam between two turns of the dough
        if p.face == "up":
            return "F8CE78" if 0.36 < along < 0.64 else tones("E39F48", "EDB058", "D48C39", 9)(p)
        return "F4C672" if 0.36 < along < 0.64 and p.y > 1 else "E4A250" if p.y > 1 else "D08D40"
    return box(cx - w / 2, 0, cz - d / 2, cx + w / 2, high, cz + d / 2, bake, rot=rot)


def croissant():
    return (roll(8.0, 8.75, 5.0, 5.5, 4.5, 0) + roll(4.5, 7.75, 3.75, 4.5, 3.25, -22.5) + roll(11.5, 7.75, 3.75, 4.5, 3.25, 22.5)
            + roll(2.5, 5.5, 2.5, 3.0, 2.0, -45) + roll(13.5, 5.5, 2.5, 3.0, 2.0, 45))


def donut(glaze, light, colors, salt):
    def dough(p):
        drip = 1 + int(rnd(p.x // 2, p.z // 2, 0, salt) * 2.6)          # the glaze runs down in drops
        if p.face not in ("up", "down") and p.y >= 5 - drip:
            return glaze
        if p.face != "up" and p.y == 1:
            return "F8DCA2"                                              # the pale waist of a fried donut
        return DOUGH(p)
    top = sprinkled(gloss(glaze, light, -0.55, -0.55, 0.35), salt, 0.3, colors)
    return ring(6.0, 4.0, 0, 2.5, dough, DOUGH) + ring(5.75, 3.5, 2.5, 3.5, solid(glaze), top)


def donut_pink():
    return donut("F59DBA", "FFD0DE", SPRINKLES[:4], 11)


def donut_choc():
    return donut("5A3022", "8A5440", ("FFF6E8", "F5A9C0", "F6D35A", "7FCBC0"), 12)


def wrapper(light, dark):
    def paint(p):
        if p.top:
            return light
        return light if (p.x + p.z) % 3 == 0 else dark
    return paint


def cupcake(paper_l, paper_d, cake, frost, frost_d, frost_l, salt):
    def piped(p):                                                        # slanted grooves of the piping bag
        return frost_d if (p.x + p.y + p.z) % 4 == 0 else frost
    top = sprinkled(gloss(frost, frost_l), salt, 0.16)
    return (disc(3.5, 0, 3.5, wrapper(paper_l, paper_d), cake) + disc(4.5, 3.5, 4.5, cake)
            + disc(4.0, 4.5, 6.0, piped, top) + disc(3.0, 6.0, 7.5, piped, top) + disc(1.75, 7.5, 8.75, piped, top)
            + cherry(8.0, 8.75, 8.0))


def cupcake_pink():
    return cupcake("A9E0D2", "79BEB2", SPONGE, "F7AEC4", "E58CA8", "FFD6E1", 13)


def cupcake_choc():
    return cupcake("F6B9CB", "D98AA3", SPONGE_C, "7A4632", "5C3224", "A16A50", 14)


def muffin_blueberry():
    def crumb(p):
        if rnd(p.x // 2, p.y // 2, p.z // 2, 15) < 0.08:
            return "5A5FA8" if (p.x + p.z) % 2 else "444A8C"
        return tones("E3A455", "F2BC6C", "C98A40", 15)(p)
    return (disc(3.5, 0, 4.0, wrapper("B7A6E4", "8B7BC0"), SPONGE) + disc(5.0, 4.0, 6.0, crumb) + disc(3.75, 6.0, 7.25, crumb)
            + blueberry(6.5, 7.25, 7.0) + blueberry(9.5, 7.25, 9.0) + blueberry(11.5, 6.0, 6.25, 1.0))


def cream_puff():
    choux = tones("E5A957", "F4C374", "C8873C", 16)

    def sugared(p):
        return WHITE if rnd(p.x, p.z, 0, 17) < 0.22 and p.u * p.u + p.v * p.v < 0.75 else choux(p)

    def cream(p):
        return "F0D9B4" if (p.x + p.z) % 3 == 0 else "FFF4E0"
    return (disc(4.5, 0, 2.5, choux) + disc(5.0, 2.5, 4.0, cream, CREAM) + disc(4.5, 4.0, 6.0, choux, sugared)
            + disc(3.0, 6.0, 7.5, choux, sugared) + disc(1.25, 7.5, 8.25, choux, sugared))


def eclair():
    def side(p):
        if p.y == 3:
            return "FFF4E0" if p.x % 3 else "EFD6AC"                      # the line of cream
        return BAKED(p)

    def zigzag(p):
        wave = (0, 1, 2, 1)[p.x % 4]
        return "FFEFD6" if p.z in (14 + wave, 15 + wave) else CHOC(p)
    return (box(2.5, 0, 5.5, 13.5, 3.0, 10.5, side) + box(1.25, 0.25, 6.0, 2.5, 2.75, 10.0, side)
            + box(13.5, 0.25, 6.0, 14.75, 2.75, 10.0, side)
            + box(2.0, 3.0, 6.0, 14.0, 4.0, 10.0, CHOC, zigzag) + box(3.0, 4.0, 6.5, 6.0, 4.25, 7.5, solid("8E5A45")))


def cinnamon_roll():
    def spiral(p):
        d = math.hypot(p.u, p.v)
        turn = (d * 3.2 - math.atan2(p.v, p.u) / (2 * math.pi)) % 1.0
        if rnd(p.x + p.z, p.x // 3, 0, 18) < 0.55 and (p.x + p.z) % 5 in (0, 1) and d < 0.9:
            return "FFF8EA"                                               # the drizzled icing
        return "8A4418" if turn < 0.4 else "F2C680"

    def side(p):
        if p.y >= 5 and rnd(p.x // 2, p.z // 2, 0, 19) < 0.45:
            return "FFF8EA"
        return "B96F34" if p.y == 2 else DOUGH(p)
    return (disc(5.5, 0, 3.0, side, spiral) + disc(3.5, 3.0, 4.0, side, lambda p: spiral(p._replace(u=p.u * 0.64, v=p.v * 0.64)))
            + disc(1.5, 4.0, 4.75, side, lambda p: spiral(p._replace(u=p.u * 0.27, v=p.v * 0.27))))


# ------------------------------------------------------------------------------------------------ cookies
def cookie_choc():
    def baked(p):
        if p.face == "up" and rnd(p.x // 2, p.z // 2, p.y, 20) < 0.11:
            return "5A3122"
        d = math.hypot(p.u, p.v)
        base = "CB8840" if d > 0.78 else "E6AC5E"
        return tones(base, "F0C076" if d < 0.78 else "DA9A50", "BC7A36", 21)(p)
    chips = []
    for x, z, y, s in ((5.0, 6.0, 2.0, 2.0), (9.5, 4.75, 2.0, 1.5), (8.5, 9.0, 2.0, 2.0), (4.75, 10.0, 2.0, 1.5),
                       (11.0, 8.0, 2.0, 1.5)):
        chips += box(x, y, z, x + s, y + 0.75, z + s, CHOC, gloss(CHOC, "94604A", -0.5, -0.5, 0.9), 22.5)
    return disc(6.0, 0, 2.0, baked) + chips


NORMALS = {"north": (0, -1), "south": (0, 1), "east": (1, 0), "west": (-1, 0)}


def turned(parts, angle):
    """Flat cookies are turned towards the viewer of the inventory (angle: a multiple of 45 degrees). A box that would
    end up past +-45 degrees gets its sides swapped instead, and its paint turns along."""
    out = []
    for part in parts:
        q = dict(part)
        cx, cz = (part["f"][0] + part["t"][0]) / 2.0, (part["f"][2] + part["t"][2]) / 2.0
        w, d = part["t"][0] - part["f"][0], part["t"][2] - part["f"][2]
        old = part["rot"][0] if part["rot"] else 0
        if part["rot"]:
            cx, cz = smooth.turn(cx, cz, *part["rot"])
        cx, cz = smooth.turn(cx, cz, angle, 8.0, 8.0)
        total = old + angle
        rot = total - 90 if total > 45 else total + 90 if total < -45 else total
        if rot != total:
            w, d = d, w
        q["f"] = [cx - w / 2, part["f"][1], cz - d / 2]
        q["t"] = [cx + w / 2, part["t"][1], cz + d / 2]
        q["rot"] = (rot, cx, cz) if rot else None
        faces = {}
        for face, shader in part["faces"].items():
            if face in NORMALS:
                nx, nz = smooth.turn(*NORMALS[face], total - rot, 0, 0)
                face = min(NORMALS, key=lambda f: math.hypot(NORMALS[f][0] - nx, NORMALS[f][1] - nz))
            faces[face] = (lambda x, y, z, side, s=shader: s(*_back(x, y, z, angle), side))
        q["faces"] = faces
        out.append(q)
    return out


def _back(x, y, z, angle):
    px, pz = smooth.turn(x, z, -angle, 8.0, 8.0)
    return px, y, pz


HEART_ROWS = ((11.5, 14.5, ((3.5, 6.5), (9.5, 12.5))), (8.5, 11.5, ((2.5, 13.5),)), (6.5, 8.5, ((3.5, 12.5),)),
              (4.5, 6.5, ((4.5, 11.5),)), (2.5, 4.5, ((6.0, 10.0),)), (1.0, 2.5, ((7.0, 9.0),)))


def _in_heart(x, z):
    return any(z0 <= z < z1 and any(a <= x < b for a, b in spans) for z0, z1, spans in HEART_ROWS)


def cookie_heart():
    def icing(p):
        x, z = (p.x + 0.5) / 2.0, (p.z + 0.5) / 2.0
        def inside(margin):
            return all(_in_heart(x + dx * margin, z + dz * margin) for dx in (-1, 0, 1) for dz in (-1, 0, 1))
        if not inside(0.5):
            return "F6D08C"
        if not inside(1.0):
            return "FFF6EC"                                               # the white piped line
        if 4.5 <= x < 6.0 and 10.0 <= z < 11.5:
            return "FFD3DF"
        return PINK(p)
    parts = []
    for z0, z1, spans in HEART_ROWS:
        for a, b in spans:
            def shader(x, y, z, face):
                p = P(int(math.floor(x * 2)), int(math.floor(y * 2)), int(math.floor(z * 2)), face, 1.5 - y < 0.5,
                      y < 0.5, False, 0, 0)
                return _lit(_value(icing if face == "up" else DOUGH, p), p, 0.5, True)
            part = smooth.box((a, 0, z0), (b, 1.5, z1), shader, ALL)
            part["raw"] = True
            parts.append(part)
    return turned(parts, -45)


def gingerbread_man():
    ginger = tones("BE7434", "CD8844", "A86228", 22)

    def head(p):
        x, z = p.x, p.z
        if (x in (14, 17)) and z in (24, 25):
            return "3E2218"
        if (z == 21 and x in (15, 16)) or (z == 22 and x in (14, 17)):
            return WHITE
        if x in (13, 18) and z == 22:
            return "F08C98"
        return ginger(p)

    def body(p):
        if p.x in (15, 16) and p.z in (11, 12, 15, 16):
            return RED if p.z < 14 else "6FB86A"
        return ginger(p)

    def cuff(edge):
        def paint(p):
            return WHITE if p.x in edge and (p.z % 2 == 0 or p.x % 2 == 0) else ginger(p)
        return paint

    def shoe(p):
        return WHITE if p.z in (3, 4) and p.x % 2 == 0 or p.z == 4 else ginger(p)
    return turned(disc(3.0, 0, 2.0, ginger, head, 8.0, 11.75) + box(6.0, 0, 4.5, 10.0, 1.75, 9.0, ginger, body)
            + box(2.0, 0, 6.5, 6.0, 1.5, 9.0, ginger, cuff((5, 6))) + box(10.0, 0, 6.5, 14.0, 1.5, 9.0, ginger, cuff((25, 26)))
            + box(4.5, 0, 1.0, 7.0, 1.6, 5.5, ginger, shoe, -22.5) + box(9.0, 0, 1.0, 11.5, 1.6, 5.5, ginger, shoe, 22.5), -45)


def macaron(base, light, dark, filling, filling_d, salt):
    shell = tones(base, light, base, salt, 0.08)

    def foot(p):                                                          # the ruffled foot of a macaron
        return dark if (p.x + p.y * 2 + p.z) % 3 == 0 else light if (p.x + p.z) % 3 == 1 else base

    def cream(p):
        return filling_d if p.bottom or (p.x + p.z) % 5 == 0 else filling
    top = gloss(shell, "FFFDF6", -0.45, -0.45, 0.3)
    return (disc(4.5, 0, 1.75, shell) + disc(5.0, 1.75, 2.5, foot, lift=0.3) + disc(4.25, 2.5, 4.0, cream)
            + disc(5.0, 4.0, 4.75, foot, lift=0.3) + disc(4.5, 4.75, 6.25, shell) + disc(3.25, 6.25, 7.0, shell, top))


def macaron_pink():
    return macaron("F5A8C0", "FFC8D8", "D97F9E", "FFF0E2", "EBD2BC", 23)


def macaron_mint():
    return macaron("9EDCC4", "C2EEDC", "70B89C", "7A4A36", "5C3426", 24)


def macaron_lemon():
    return macaron("F8DC78", "FFEEA6", "D9B44C", "FFF8E4", "EEDDB4", 25)


def cake_pop():
    glaze = sprinkled(PINK, 26, 0.22, ("FFF6E8", "7FCBC0", "F6D35A", "8FA6E8"))

    def side(p):
        if p.y >= 19 and rnd(p.x, p.z, p.y, 27) < 0.12:
            return "FFF6E8"
        return glaze(p) if p.face == "up" else PINK(p)
    return (disc(3.0, 0, 1.0, solid("E7D5C2"), tones("FFF4E4", "FFFDF4", "EEDCC4", 28))
            + box(7.5, 1.0, 7.5, 8.5, 6.5, 8.5, lambda p: "FFFDF6" if p.u < 0.5 else "DCD0C4", foot=False)
            + disc(2.5, 6.5, 7.75, side, glaze) + disc(3.75, 7.75, 11.75, side, glaze) + disc(2.5, 11.75, 13.0, side, glaze)
            + box(6.5, 5.5, 7.0, 7.5, 6.5, 9.0, solid("7FCBC0"), solid("A8E2D8"))
            + box(8.5, 5.5, 7.0, 9.5, 6.5, 9.0, solid("7FCBC0"), solid("A8E2D8")))


# ------------------------------------------------------------------------------------------------ slices of cake
APEX, BACK = 2.5, 13.0
SLOPE = math.tan(math.radians(22.5))


def wedge(y0, y1, side, top, back=None):
    """A slice of cake pointing to the front: two sides slanted by 22.5 degrees, filled by a few straight boxes."""
    cos, sin = math.cos(math.radians(22.5)), math.sin(math.radians(22.5))

    def shader(x, y, z, face):
        inner = min(SLOPE * (z - APEX) - abs(x - 8.0), (BACK - z), z - APEX - 0.5)
        p = P(int(math.floor(x * 2)), int(math.floor(y * 2)), int(math.floor(z * 2)), face, y1 - y < 0.5, y - y0 < 0.5,
              face == "up" and inner < 0.5, (x - 8.0) / 4.5, (z - APEX) / (BACK - APEX))
        paint = top if face in ("up", "down") else back if back is not None and face == "south" else side
        return _lit(_value(paint, p), p, 0.6, y1 - y0 > 1.0)

    def piece(x0, z0, x1, z1, rot=0):
        part = smooth.box((x0, y0, z0), (x1, y1, z1), shader, ALL, (rot, 8.0, APEX) if rot else None)
        part["raw"] = True
        return [part]
    wide = 1.5
    start, end = 1.25, (BACK - APEX - wide * sin) / cos
    parts = (piece(8.0 - wide, APEX + start, 8.0, APEX + end, 22.5 if smooth.turn(8.0, APEX + 5, 22.5, 8.0, APEX)[0] > 8 else -22.5)
             + piece(8.0, APEX + start, 8.0 + wide, APEX + end, -22.5 if smooth.turn(8.0, APEX + 5, 22.5, 8.0, APEX)[0] > 8 else 22.5))
    parts += piece(7.625, APEX + 0.25, 8.375, APEX + 2.0)
    for z0, z1 in ((4.25, 6.5), (6.5, 9.75), (9.75, BACK - 0.01)):
        w = math.floor(SLOPE * (z0 - APEX + 0.5) * 4) / 4.0
        parts += piece(8.0 - w, z0, 8.0 + w, z1)
    return parts


def cream_dot(cx, y, cz, paint=CREAM):
    return box(cx - 1.25, y, cz - 1.25, cx + 1.25, y + 1.0, cz + 1.25, paint, rot=45) + \
        box(cx - 0.75, y + 1.0, cz - 0.75, cx + 0.75, y + 1.75, cz + 0.75, paint)


def cheesecake():
    filling = tones("FCE9B4", "FFF3CC", "F0D698", 30, 0.12)

    def side(p):
        if p.y < 2:
            return tones("C8863E", "DA9C52", "AE702E", 31, 0.3, 1)(p)       # the biscuit base
        if p.y >= 9 or (p.y == 8 and rnd(p.x // 2, p.z // 2, 0, 32) < 0.4):
            return RED_D if p.y == 8 else RED
        return filling(p)
    jelly = gloss(tones(RED, "E9606A", "C23847", 33, 0.14), "FF9C9C", 0.0, -0.2, 0.3)
    return (wedge(0, 5.0, side, jelly) + strawberry(6.5, 5.0, 10.75) + strawberry(10.0, 5.0, 11.25, 2.0)
            + blueberry(8.0, 5.0, 7.75) + leaf(8.5, 5.0, 9.0))


def cake_strawberry():
    def side(p):
        if p.y in (4, 5) and p.face != "up":
            return RED if (p.x + p.z) % 4 < 2 else "FFF4E0"                 # strawberries between the layers
        if p.y in (3, 6) or p.y >= 11 or (p.y == 10 and rnd(p.x // 2, p.z // 2, 0, 34) < 0.4):
            return CREAM(p)
        return SPONGE(p)
    return (wedge(0, 6.0, side, CREAM, back=lambda p: CREAM(p) if p.y >= 2 else SPONGE(p))
            + cream_dot(8.0, 6.0, 11.0) + strawberry(8.0, 7.75, 11.0, 2.0) + leaf(5.0, 6.0, 10.0))


def cake_choc():
    def side(p):
        if p.y in (3, 7):
            return "B07A5C" if (p.x + p.z) % 5 else "C99274"                # milk chocolate cream
        if p.y >= 11 or (p.y >= 9 and rnd(p.x // 2, p.z // 2, 0, 35) < 0.45):
            return "42221A"                                               # the dripping ganache
        return SPONGE_C(p)
    top = gloss(tones("46241A", "5A3023", "3A1D15", 36, 0.12), "8A5A46", -0.1, -0.1, 0.35)
    curl = lambda p: "9A6448" if (p.x + p.y) % 3 == 0 else "6A3C2C"
    return (wedge(0, 6.0, side, top) + cream_dot(8.0, 6.0, 11.0, CHOC) + cherry(8.0, 7.75, 11.0)
            + box(5.0, 6.0, 10.5, 6.0, 7.5, 12.5, curl, rot=22.5) + box(10.0, 6.0, 9.0, 12.0, 6.75, 10.0, curl, rot=-22.5))


def apple_pie():
    def side(p):
        if p.y < 2:
            return BAKED(p)
        if p.y >= 6:
            return "E9AC5A" if (p.x + p.z) % 3 else "C98840"
        n = rnd((p.x + p.y) // 3, p.y // 2, p.z // 3, 37)
        return "F7D27A" if n < 0.4 else "E79A36" if n < 0.75 else "C9661E"    # apple pieces in cinnamon

    def lattice(p):
        a, b = (p.x + p.z) % 6, (p.x - p.z) % 6
        if a < 2:
            return "F6C673" if a == 0 else "DC9A48"
        if b < 2:
            return "EDB260" if b == 0 else "CE8A3C"
        return "B4561C" if (p.x + p.z) % 5 else "D9802C"

    def crimp(p):
        return "F2BE6C" if (p.x // 2) % 2 == 0 else "C07C34"
    return wedge(0, 4.0, side, lattice) + box(2.25, 0, 13.0, 13.75, 5.0, 14.5, crimp, crimp)


def medovik():
    def side(p):
        if p.y % 2 == 1 and p.y < 11:
            return "FFF0D4" if (p.x + p.z) % 6 else "F2DCB4"                 # thin layers of sour cream
        return tones("D18A3C", "E2A04E", "B8742E", 38, 0.2)(p)

    def crumbs(p):
        return tones("E6A755", "F6C377", "BF7E36", 39, 0.28, 1)(p)

    return (wedge(0, 6.0, side, crumbs, crumbs) + cream_dot(8.0, 6.0, 11.0)
            + box(7.0, 7.75, 10.0, 9.0, 8.75, 12.0, solid("E7A03A"), gloss("F2B54A", "FFE29A", -0.4, -0.4, 0.7), 22.5)
            + leaf(9.0, 6.0, 8.5))


def tiramisu():
    def side(p):
        if p.y in (0, 1, 5, 6):
            return tones("8A5636", "A56C46", "6E4028", 40, 0.3, 1)(p)        # coffee soaked biscuits
        if p.y >= 9:
            return "5C3020" if p.y == 9 or rnd(p.x, p.z, 0, 41) < 0.5 else "734030"
        return CREAM(p)

    def cocoa(p):
        n = rnd(p.x, p.z, 0, 42)
        return "8A5038" if n < 0.18 else "532A1C" if n > 0.8 else "6C3A27"
    return (box(3.0, 0, 3.5, 13.0, 5.0, 12.5, side, cocoa) + cream_dot(10.5, 5.0, 10.0)
            + box(5.0, 5.0, 6.0, 6.5, 5.75, 7.0, solid("3E1F14"), solid("7A4A30"), 22.5) + leaf(6.0, 5.0, 8.5))


def brownie():
    fudge = tones("55291C", "683526", "421F15", 43, 0.2)

    def crust(p):
        crack = (p.x + 2 * (p.z // 3) % 5) % 7 == 0 and rnd(p.x // 3, p.z, 0, 44) < 0.75
        return "3A1A11" if crack else tones("7E4630", "96593F", "6A3826", 45, 0.2)(p)

    def side(p):
        return crust(p) if p.y >= 7 else fudge(p)
    nut = tones("DDAA66", "F0C888", "B98744", 46, 0.3, 1)
    return (box(3.5, 0, 4.0, 12.5, 4.0, 12.5, side, crust)
            + box(5.0, 4.0, 5.5, 7.0, 5.25, 7.5, nut, rot=22.5) + box(9.0, 4.0, 8.5, 11.0, 5.25, 10.5, nut, rot=-22.5)
            + box(9.5, 4.0, 5.0, 11.0, 5.0, 6.5, nut, rot=45) + box(5.0, 4.0, 9.5, 6.5, 5.0, 11.0, nut))


# ------------------------------------------------------------------------------------------------ sweets on the table
def waffle():
    golden = tones("E7A64E", "F4BC66", "CC8A38", 47)
    raised = tones("F2B860", "FFD084", "DC9C46", 48)

    def hole(p):
        return "A9661F" if p.x % 6 in (2, 3) and p.z % 6 in (2, 3) else "C07C2C"
    parts = box(3.0, 0, 3.0, 13.0, 1.0, 13.0, golden, hole)
    for a in (3.0, 6.0, 9.0, 12.0):                                        # the raised grid
        parts += box(a, 1.0, 3.0, a + 1.0, 2.0, 13.0, golden, raised)
        for x0 in (4.0, 7.0, 10.0):
            parts += box(x0, 1.0, a, x0 + 2.0, 2.0, a + 1.0, golden, raised)
    butter = tones("FBE27C", "FFF0A8", "EBCA58", 50, 0.1)
    return (parts + box(6.5, 2.0, 6.5, 9.5, 3.25, 9.5, butter, rot=22.5) + strawberry(10.75, 2.0, 5.25, 2.0)
            + strawberry(5.25, 2.0, 10.25, 2.0) + blueberry(10.5, 2.0, 10.75) + blueberry(5.25, 2.0, 5.25))


def pancakes():
    def edge(p):
        if p.face != "up" and (p.bottom or p.top):
            return "D99846"
        return "F8D58C" if rnd(p.x, p.y, p.z, 51) > 0.15 else "E9B866"

    def browned(p):
        d = math.hypot(p.u, p.v)
        return tones("C9782C", "DA8C3A", "B46620", 52)(p) if d < 0.72 else "DE9A46"
    syrup = gloss(tones("B85E14", "CC7220", "A25010", 53, 0.12), "F6B45C", -0.45, -0.35, 0.32)
    drip = solid("B4590F")
    return (disc(6.0, 0, 2.0, edge, browned) + disc(5.75, 2.0, 4.0, edge, browned, 8.25, 7.75)
            + disc(5.75, 4.0, 6.0, edge, browned, 7.75, 8.25) + disc(4.0, 6.0, 6.5, solid("B4590F"), syrup, 7.75, 8.25, foot=False)
            + box(5.75, 3.5, 2.05, 7.25, 6.05, 2.5, drip, foot=False) + box(13.55, 4.5, 8.5, 14.0, 6.05, 10.0, drip, foot=False)
            + box(1.5, 3.0, 7.5, 2.0, 6.05, 9.0, drip, foot=False)
            + box(6.25, 6.5, 7.0, 9.25, 7.75, 9.75, tones("FBE27C", "FFF0A8", "EBCA58", 54, 0.1), rot=22.5)
            + blueberry(10.25, 6.5, 9.5) + blueberry(5.75, 6.5, 10.5, 1.25))


def ice_cream_cone():
    def waffled(p):
        a, b = (p.x + p.z + p.y) % 4, (p.x + p.z - p.y) % 4
        return "A96A25" if a == 0 or b == 0 else "EDB966" if a == 2 else "DB9E4A"
    rose = tones("F8B1C4", "FFCDDA", "E690A8", 55, 0.14)
    vanilla = tones("FFF0C0", "FFF9E0", "EED796", 56, 0.14)

    def scoop(base, shade, salt):
        def paint(p):                                                      # the ragged lower edge of a scoop
            return shade if p.bottom and rnd(p.x // 2, p.z // 2, p.y, salt) < 0.55 else base(p)
        return paint
    return (disc(1.25, 0, 2.0, waffled) + disc(2.0, 2.0, 4.0, waffled) + disc(2.75, 4.0, 6.0, waffled)
            + disc(3.5, 6.0, 7.5, waffled) + disc(3.9, 7.5, 8.5, tones("F0C274", "FCD692", "D9A452", 57))
            + disc(4.5, 8.5, 11.0, scoop(rose, "D9789A", 58), rose) + disc(3.25, 11.0, 12.0, rose)
            + disc(3.5, 12.0, 14.0, scoop(vanilla, "DDBE74", 59), sprinkled(vanilla, 60, 0.2))
            + disc(2.25, 14.0, 15.25, vanilla, sprinkled(vanilla, 61, 0.3))
            + box(9.0, 11.5, 6.5, 10.25, 17.0, 8.0, lambda p: "9A6448" if (p.y + p.x) % 4 == 0 else "5C3022", CHOC, 22.5,
                  foot=False))


def glass(layers, salt):
    """The paint of a filled glass: layers = ((upper texture row, colour), ...) seen through it, with a shine."""
    def paint(p):
        for upto, colour in layers:
            if p.y < upto:
                break
        if p.face == "north" and p.x in (13, 14) or p.face == "west" and p.z == 13:
            return style.shade(rgb(colour), 1.0, 0.55)
        return colour
    return paint


def sundae():
    clear, clear_l = "D5EBEF", "F5FCFD"
    fill = glass(((9, "EAF7F8"), (12, "FFF0C4"), (13, "6A3828"), (16, "F8B1C4"), (17, RED_D), (19, "FFF0C4")), 62)
    return (disc(3.25, 0, 0.75, solid(clear), solid(clear_l))
            + box(7.25, 0.75, 7.25, 8.75, 3.5, 8.75, lambda p: clear_l if p.u < 0.5 else clear, foot=False)
            + disc(2.75, 3.5, 5.0, fill, foot=False) + disc(3.75, 5.0, 7.0, fill, foot=False)
            + disc(4.5, 7.0, 9.5, fill, foot=False) + ring(5.0, 0.75, 9.5, 10.25, solid(clear), solid(clear_l))
            + disc(3.75, 9.5, 11.25, tones("F8B1C4", "FFCDDA", "E690A8", 63), sprinkled(PINK, 64, 0.12, ("6A3828",)))
            + disc(2.75, 11.25, 12.75, CREAM, sprinkled(CREAM, 65, 0.2, ("6A3828", "8C5440")))
            + disc(1.5, 12.75, 13.75, CREAM) + cherry(8.0, 13.75, 8.0)
            + box(10.25, 10.0, 8.5, 11.25, 16.0, 9.5, lambda p: RED if (p.y // 2) % 2 else WHITE, rot=45, foot=False))


def ramekin_side(p):
    if p.top:
        return "FFFDF8"
    return "DCD2CC" if (p.x + p.z) % 3 == 0 else "F6F1EC"


def creme_brulee():
    def burnt(p):
        n = rnd(p.x // 2, (p.z + p.x // 2) // 2, 0, 66) * 0.75 + math.hypot(p.u, p.v) * 0.4
        return "84401A" if n > 0.88 else "BC6A22" if n > 0.66 else "E59A34" if n > 0.34 else "F7C258"
    return (disc(5.5, 0, 1.0, solid("D8CCC6"), "D8CCC6") + disc(6.0, 1.0, 3.5, ramekin_side, burnt)
            + ring(6.5, 1.0, 3.0, 4.25, ramekin_side, solid("FFFDF8")) + strawberry(6.75, 3.5, 9.25, 2.0)
            + blueberry(9.0, 3.5, 8.0) + blueberry(8.0, 3.5, 10.75, 1.0) + leaf(8.75, 3.5, 9.25))


def panna_cotta():
    milk = tones("FDF3E6", "FFFCF6", "F0E0CC", 67, 0.1)

    def upper(p):
        return RED_D if p.y >= 11 - int(rnd(p.x // 2, p.z // 2, 0, 68) * 3.4) else milk(p)
    sauce = gloss(tones("C93A4A", "DC4C5A", "B02C3C", 69, 0.14), "FF9AA0", -0.45, -0.4, 0.32)
    return (disc(5.25, 0, 2.5, milk) + disc(4.75, 2.5, 4.0, milk) + disc(4.25, 4.0, 6.0, upper, sauce)
            + strawberry(8.0, 6.0, 8.0, 2.5) + leaf(9.25, 6.0, 9.0))


def flan():
    def upper(p):
        return "9C4A10" if p.y >= 10 - int(rnd(p.x // 2, p.z // 2, 0, 70) * 3.4) else CUSTARD(p)
    caramel = gloss(tones("A9540F", "C06A1C", "92440A", 71, 0.14), "F2A84E", -0.45, -0.4, 0.32)
    return (disc(5.75, 0, 2.0, CUSTARD) + disc(5.0, 2.0, 3.75, CUSTARD) + disc(4.25, 3.75, 5.5, upper, caramel)
            + cherry(8.0, 5.5, 8.0))


def fruit_tart():
    def fluted(p):
        return "F2BA66" if (p.x + p.z) % 4 < 2 else "C88236"
    custard = tones("FCE6A0", "FFF2C0", "EFD080", 72, 0.12)

    def kiwi(p):
        d = math.hypot(p.u, p.v)
        if d < 0.28:
            return "F6F4CC"
        if d < 0.68:
            return "3A3C20" if (p.x + p.z) % 2 == 0 else "9CD04C"
        return "7DAA34"
    return (disc(5.75, 0, 1.0, fluted, BAKED) + disc(5.5, 1.0, 2.25, fluted, custard)
            + ring(6.5, 1.25, 0.75, 3.25, fluted, tones("EDB462", "FCCC80", "D49A48", 73))
            + disc(1.75, 2.25, 3.0, solid("7DAA34"), kiwi, 10.0, 9.25, foot=False)
            + disc(1.75, 2.25, 3.0, solid("7DAA34"), kiwi, 5.5, 8.75, foot=False)
            + strawberry(6.25, 2.25, 5.75, 2.25) + strawberry(10.0, 2.25, 5.75, 2.0) + strawberry(8.25, 2.25, 11.25, 2.25)
            + blueberry(8.0, 2.25, 8.0) + blueberry(11.25, 2.25, 11.25, 1.25) + blueberry(5.0, 2.25, 11.0, 1.25)
            + leaf(8.0, 2.25, 9.0))


def baklava():
    nuts = tones("91A943", "B3C660", "6F8730", 74, 0.3, 1)

    def filo(p):
        if p.y in (3, 4):
            return nuts(p)
        return "F6C066" if p.y % 2 == 0 else "C47A26"
    syrup = gloss(tones("E59A2C", "F4B240", "CC8220", 75, 0.2), "FFE098", -0.4, -0.4, 0.4)
    parts = []
    for cx, cz in ((5.0, 6.0), (11.0, 6.5), (8.0, 11.25)):
        parts += box(cx - 2.25, 0, cz - 2.25, cx + 2.25, 4.5, cz + 2.25, filo, syrup, 45)
        parts += box(cx - 0.75, 4.5, cz - 0.75, cx + 0.75, 5.25, cz + 0.75, nuts)
    return parts


# ------------------------------------------------------------------------------------------------ the plate
def plate():
    """A white octagonal plate, 1 unit high: a gold line, a blue-grey step and little posies around the rim."""
    posy = {}
    for i, (px, pz) in enumerate(((15, 4), (23, 8), (27, 15), (23, 23), (16, 27), (8, 23), (4, 16), (8, 8))):
        petal = ("EE98AE", "93AEE6")[i % 2]
        for dx, dz, c in ((0, 0, "F6D35A"), (-1, 0, petal), (1, 0, petal), (0, -1, petal), (0, 1, petal),
                          (2, 1, "8FB86A") if px < 20 else (-2, 1, "8FB86A")):
            posy[(px + dx, pz + dz)] = c

    def china(p):
        x, z = (p.x + 0.5) / 2.0 - 8.0, (p.z + 0.5) / 2.0 - 8.0
        d = max(abs(x), abs(z), (abs(x) + abs(z)) / (1 + smooth.K))
        if d > 6.5:
            return "FFFDF8"
        if d > 6.0:
            return GOLD
        if 4.0 < d <= 4.5:
            return "D9D5DA"
        return posy.get((p.x, p.z), "F8F5EF")
    edge = lambda p: "FFFDF8" if p.top else "E4DEDC"
    return disc(5.0, 0, 0.5, solid("D3CCCB"), foot=False) + disc(7.0, 0.5, 1.0, edge, china, lift=0.3, foot=False)


DESSERTS = {f.__name__: f for f in (
    croissant, donut_pink, donut_choc, cupcake_pink, cupcake_choc, muffin_blueberry, cream_puff, eclair, cinnamon_roll,
    cookie_choc, cookie_heart, gingerbread_man, macaron_pink, macaron_mint, macaron_lemon, cake_pop, cheesecake,
    cake_strawberry, cake_choc, tiramisu, apple_pie, medovik, brownie, waffle, pancakes, ice_cream_cone, sundae,
    creme_brulee, panna_cotta, flan, fruit_tart, baklava)}


# ------------------------------------------------------------------------------------------------ the model
def moved(parts, dx, dy, dz):
    """The same dessert somewhere else (its paint moves with it)."""
    out = []
    d = (dx, dy, dz)
    for part in parts:
        q = dict(part)
        q["f"] = [part["f"][i] + d[i] for i in range(3)]
        q["t"] = [part["t"][i] + d[i] for i in range(3)]
        if part["rot"]:
            q["rot"] = (part["rot"][0], part["rot"][1] + dx, part["rot"][2] + dz)
        q["faces"] = {f: (lambda x, y, z, face, s=s: s(x - dx, y - dy, z - dz, face)) for f, s in part["faces"].items()}
        out.append(q)
    return out


def corners(part):
    """The 8 corners of a part, turned with it."""
    out = []
    for x in (part["f"][0], part["t"][0]):
        for y in (part["f"][1], part["t"][1]):
            for z in (part["f"][2], part["t"][2]):
                px, pz = smooth.turn(x, z, *part["rot"]) if part["rot"] else (x, z)
                out.append((px, y, pz))
    return out


class Shape:
    """What the display transforms of tools/voxel_food.py need to know about a model (in half units, like voxels)."""

    def __init__(self, parts):
        self.points = [c for p in parts for c in corners(p)]

    def bounds(self):
        xs, ys, zs = zip(*self.points)
        return (min(xs) * 2, min(ys) * 2, min(zs) * 2), (max(xs) * 2, max(ys) * 2, max(zs) * 2)

    def cells(self):
        # display() looks at the corners (c, c + 1) of every cell: pull the cell in on the upper side
        mid = [sum(c) / len(c) for c in zip(*self.points)]
        return {tuple(v * 2 - (1 if v > mid[i] else 0) for i, v in enumerate(p)) for p in self.points}


def build(parts):
    """-> (elements, atlas image)."""
    patches, index, jobs = [], {}, []
    for part in parts:
        ids = {}
        for face, im, w, h in smooth.patches_of(part):
            key = (w, h, im.tobytes())
            if key not in index:
                index[key] = len(patches)
                patches.append(im)
            ids[face] = index[key]
        jobs.append((part, ids))
    patches = [style.grade(p) for p in patches]
    atlas, place = smooth.pack(patches)
    k = 16.0 / atlas.shape[0]
    elements = []
    for part, ids in jobs:
        uvs = {}
        for face, i in ids.items():
            px, py = place[i]
            h, w = patches[i].shape[:2]
            uvs[face] = [px * k, py * k, (px + w) * k, (py + h) * k]
        elements.append(smooth.element(part["f"], part["t"], uvs, part["rot"]))
    settle(elements)
    return elements, Image.fromarray(atlas, "RGBA")


def settle(elements):
    """Where two pieces share a level (overlapping segments at the same height) the later one steps a hair inside, so
    that their faces never flicker."""
    for _ in range(12):
        todo = {(max(i, j), face) for i, j, face, _ in smooth.fighting_faces(elements) if face in ("up", "down")}
        if not todo:
            return
        for i, face in sorted(todo):
            if face == "up":
                elements[i]["to"][1] = round(elements[i]["to"][1] - 0.012, 4)
            else:
                elements[i]["from"][1] = round(elements[i]["from"][1] + 0.012, 4)
