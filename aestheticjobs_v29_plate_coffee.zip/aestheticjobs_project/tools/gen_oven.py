#!/usr/bin/env python3
"""The pastry oven: a small mint stove with a brass window, a marble counter and a tiled back, in three looks
(idle, baking, ready).

    python3 tools/gen_oven.py            # textures, block/item models, blockstates, loot table, recipe, tag
    python3 tools/gen_oven.py --check    # verifies the written models

Model units (16 = one block), front = north. The places of the desserts inside are in client/PastryOvenRenderer.
"""
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gen_decor as gd  # noqa: E402
import gen_table as gt  # noqa: E402
from smooth import box, octagon, ring  # noqa: E402
import smooth  # noqa: E402
from voxel_food import mix, rgb, rnd  # noqa: E402

NAME = "pastry_oven"
LOOKS = ["", "_baking", "_golden"]        # the model of every value of the block state "look" (Job.State: idle, working, ready)
ALL = ("north", "south", "east", "west", "up", "down")

MINT, MINT_L, MINT_D = "9CC7B4", "C4E2D2", "6E9C8C"
CREAM, CREAM_D = "F6EAD2", "D9C4A2"
BRASS, BRASS_L, BRASS_D = "D2A654", "F4D993", "94702E"
WOOD, WOOD_D = "B5834F", "855A36"


enamel_soft = gt.speck(MINT, MINT_L, MINT_D, 3, 0.1)
cream_soft = gt.speck(CREAM, "FFF8E8", CREAM_D, 4, 0.2)


def enamel(x, y, z, f):
    return enamel_soft(x, y, z, f)


def drawer(x, y, z, f):
    if f == "north" and 2.5 < x < 13.5 and (abs(y - 9.25) > 0.6 or abs(x - 8) > 5.0):
        return rgb(MINT_L) if y > 10.0 else rgb(MINT)
    return enamel(x, y, z, f)


def marble(x, y, z, f):
    a, b, c = gt.px(x, y, z)
    vein = abs(math.sin((a + c * 0.6) * 0.33 + math.sin(c * 0.27) * 1.6))           # long soft veins
    base = cream_soft(x, y, z, f)
    return mix(base, rgb(CREAM_D), 0.7 * max(0.0, 1.0 - vein * 5.0))


def brass(x, y, z, f):
    glint = math.sin((x + y + z) * 0.9)
    return mix(rgb(BRASS), rgb(BRASS_L if glint > 0 else BRASS_D), abs(glint) ** 3 * 0.75)


def wood(x, y, z, f):
    a, b, c = gt.px(x, y, z)
    grain = math.sin(c * 1.15 + math.sin(a * 0.35) * 1.4)
    return mix(rgb(WOOD), rgb(WOOD_D), max(0.0, grain) ** 2 * 0.65)


def tiles(x, y, z, f):
    """A rose and cream checkered back wall."""
    a, b, c = gt.px(x, y, z)
    if a % 4 == 0 or (b - 24) % 4 == 3:
        return rgb("CDB9A2")
    return rgb("E9A9AE") if ((a - 1) // 4 + (b - 24) // 4) % 2 else rgb("FBF0DE")


def dial(x, y, z, f):
    a, b = gt.px(x, y, z)[:2]
    hands = {(15, 27), (15, 28), (16, 27)}
    if (a, b) in hands:
        return rgb("4A342C")
    return rgb("FFF8E8")


def inside(state):
    """The walls of the baking chamber."""
    glow = {"idle": ("3C332F", "2A2322", "51453E"), "baking": ("C4601E", "8A3A14", "F29A32"),
            "golden": ("F2A528", "C46C1C", "FFDC6A")}[state]

    def sh(x, y, z, f):
        base, dark, light = (rgb(h) for h in glow)
        a, b, c = gt.px(x, y, z)
        if f == "south" or (f == "north" and z > 6.0):             # the back: heating coils
            if b in (6, 7, 12, 13):
                return light if (a + b) % 3 else base
            return mix(base, dark, 0.5 * gt.style.soft(a, b, c, 8, 3))
        if f == "up":                                              # the floor: a wire rack
            return light if c % 3 == 0 else dark
        return mix(base, dark, min(1.0, max(0.0, (9.0 - z) / 8.0)) * 0.7) if f != "down" else dark
    return sh


def oven(state):
    p = []
    glow = inside(state)
    for x0, z0 in ((1.5, 1.5), (12.5, 1.5), (1.5, 12.5), (12.5, 12.5)):
        p.append(box((x0, 0.0, z0), (x0 + 2, 1.0, z0 + 2), brass, ("north", "south", "east", "west", "down")))
    p.append(box((1, 1, 1), (15, 2, 15), {"*": enamel, "up": glow}))
    p.append(box((1, 2, 1), (3.5, 8, 15), {"*": enamel, "east": glow}, ("north", "south", "east", "west")))
    p.append(box((12.5, 2, 1), (15, 8, 15), {"*": enamel, "west": glow}, ("north", "south", "east", "west")))
    p.append(box((3.5, 2, 7), (12.5, 8, 15), {"*": enamel, "north": glow}, ("north", "south")))
    p.append(box((1, 8, 1), (15, 11, 15), {"*": drawer, "down": glow}, ("north", "south", "east", "west", "down")))
    # the brass frame of the window, the door handle and the two knobs
    front = ("north", "east", "west", "up", "down")
    p.append(box((2.9, 2.0, 0.6), (3.8, 8.0, 1.0), brass, front))
    p.append(box((12.2, 2.0, 0.6), (13.1, 8.0, 1.0), brass, front))
    p.append(box((3.8, 7.4, 0.6), (12.2, 8.0, 1.0), brass, ("north", "up", "down")))
    p.append(box((3.8, 2.0, 0.6), (12.2, 2.5, 1.0), brass, ("north", "up", "down")))
    p.append(box((4.5, 8.3, 0.4), (11.5, 8.9, 1.0), brass, front))
    for x0 in (2.2, 12.4):
        p.append(box((x0, 9.0, 0.4), (x0 + 1.4, 10.4, 1.0), {"*": brass, "north": gt.flat("FFF0C0")}, front))
    # counter and back wall
    p.append(box((0.5, 11, 0.5), (15.5, 12, 15.5), marble))
    p.append(box((1, 12, 13.5), (15, 15.2, 15), tiles, ("north", "south", "east", "west")))
    p.append(box((0.7, 15.2, 13.2), (15.3, 16, 15.2), wood))
    p.append(box((6.5, 12.6, 13.1), (9.5, 14.8, 13.5), {"*": brass, "north": dial}, front))
    # a sugar jar on the right, a rolling pin on the left
    p += octagon(13.2, 11.4, 1.3, 12.0, 14.2, gt.speck("F3E4D8", "FFFFFF", "D6BCAE", 9), bottom=False)
    p += octagon(13.2, 11.4, 1.0, 14.2, 14.9, wood, bottom=False)
    p.append(box((1.5, 12.0, 4.0), (3.1, 13.6, 10.0), gt.speck("D9AE76", "F0CE9C", "B3854E", 2), ("north", "south", "east", "west", "up")))
    p.append(box((1.9, 12.4, 2.8), (2.7, 13.2, 4.0), wood, ("north", "east", "west", "up", "down")))
    p.append(box((1.9, 12.4, 10.0), (2.7, 13.2, 11.2), wood, ("south", "east", "west", "up", "down")))
    return p


MODELS = {
    "": lambda: oven("idle"),
    "_baking": lambda: oven("baking"),
    "_golden": lambda: oven("golden"),
}


def main():
    for suffix, build in MODELS.items():
        n, size = gt.write(NAME + suffix, build(), None)
        print(f"{NAME}{suffix}: {n} elements, {size} px")
    gd.write_json(os.path.join(gd.ASSETS, "blockstates", NAME + ".json"), {"variants": {
        f"facing={f},look={i}": gd.variant(NAME + s, f) for f in gd.Y for i, s in enumerate(LOOKS)}})
    gd.write_json(os.path.join(gd.ASSETS, "models", "item", NAME + ".json"), {"parent": "aestheticjobs:block/" + NAME})
    gd.loot(NAME)
    gd.write_json(os.path.join(gd.DATA, "recipe", NAME + ".json"), {
        "type": "minecraft:crafting_shaped", "category": "misc", "pattern": ["III", "IFI", "BBB"],
        "key": {k: {"item": "minecraft:" + v} for k, v in (("I", "iron_ingot"), ("F", "furnace"), ("B", "brick"))},
        "result": {"id": "aestheticjobs:" + NAME, "count": 1}})


def check():
    saved = gt.BLOCKS
    gt.BLOCKS = {NAME + s: (None,) for s in MODELS}
    try:
        gt.check()
    finally:
        gt.BLOCKS = saved


if __name__ == "__main__":
    check() if "--check" in sys.argv else main()
