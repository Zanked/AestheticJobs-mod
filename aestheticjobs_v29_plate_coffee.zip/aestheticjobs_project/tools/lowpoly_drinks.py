"""The cups of the cafe in the style of the desserts (lowpoly_desserts.py): octagonal porcelain and glass with all the
fine detail painted at 32x: flowers around the cups, latte art on the coffee, layers shining through the glasses.

Handles are on the east side (+x), as the display transforms of voxel_food.display expect.
"""
import math

import smooth
from lowpoly_desserts import box, disc, ring, rnd, solid, sprinkled, tones

PORC, PORC_L, PORC_D, PORC_DD = "F8F5EF", "FFFDF8", "E2DBD8", "C6BCBA"
GOLD, GOLD_L = "E8BC54", "F8DC8C"
PINK, PINK_L, PINK_D = "F2A3BA", "FBC8D6", "DB7E9B"
SKY, SKY_L, SKY_D = "9CC4E4", "C4DEF2", "759FC8"
MINT, MINT_L, MINT_D = "9FD6C2", "C4EADC", "74B29C"
LEAF = "85AE68"
CREMA, CREMA_L, CREMA_D = "C8894E", "DCA468", "A4672F"
MILK, FOAM, FOAM_D = "FFF9EE", "FBEED2", "EDD8AE"
ESPRESSO, COFFEE, COFFEE_L = "3C2218", "5F3826", "86543A"
LATTE, LATTE_L = "BE8A5C", "DDB486"
CHOC, CHOC_L, CHOC_D = "5C3022", "7E4A34", "42201A"
CARAMEL, CARAMEL_L, CARAMEL_D = "D88C30", "F2B456", "AC6418"
GLASS, GLASS_L, GLASS_D = "D4EBEF", "F6FDFE", "A9CCD6"

# pixel art for the surface of the coffee, one character per texture pixel (14 x 14, the middle of the cup)
TULIP = ("....MM....",
         "...MMMM...",
         "....MM....",
         ".M......M.",
         ".MMMMMMMM.",
         "...MMMM...",
         "M........M",
         "MMM....MMM",
         ".MMMMMMMM.",
         "...MMMM...")
HEART = ("........",
         ".MM..MM.",
         "MMMMMMMM",
         "MMMMMMMM",
         ".MMMMMM.",
         "..MMMM..",
         "...MM...",
         "........")


def art(y, rows, ink, ground, edge=None):
    """Latte art: pixel art lying on the coffee, turned so that it stands upright in the inventory. y = the surface."""
    n = len(rows)

    def paint(p):
        i = (n - 1) - min(n - 1, int(p.u * n))
        j = (n - 1) - min(n - 1, int(p.v * n))
        if rows[j][i] == "M":
            return ink
        if edge and any(0 <= j + dj < n and 0 <= i + di < n and rows[j + dj][i + di] == "M"
                        for di, dj in ((1, 0), (-1, 0), (0, 1), (0, -1))):
            return edge
        return ground(p) if callable(ground) else ground
    h = n / 4.0
    return box(8.0 - h, y - 0.25, 8.0 - h, 8.0 + h, y + 0.03, 8.0 + h, paint, paint, -45, faces=("up",), lift=0.0, foot=False)


def around(p, r):
    """The place around an octagonal wall, in texture pixels."""
    return int(math.floor((math.atan2(p.v, p.u) + math.pi) * r * 2.0))


# ------------------------------------------------------------------------------------------------ porcelain
def saucer(r, petal, petal_l):
    flowers = {}
    ring_r = r - 1.4
    for k in range(8):
        a = math.pi / 4 * (k + 0.5)
        x = int(math.floor((8 + math.cos(a) * ring_r) * 2))
        z = int(math.floor((8 + math.sin(a) * ring_r) * 2))
        for dx, dz, c in ((0, 0, GOLD), (1, 0, petal), (-1, 0, petal_l), (0, 1, petal_l), (0, -1, petal)):
            flowers[(x + dx, z + dz)] = c
        flowers[(x + (2 if math.sin(a) < 0 else -2), z + (2 if math.cos(a) > 0 else -2))] = LEAF

    def china(p):
        x, z = (p.x + 0.5) / 2.0 - 8.0, (p.z + 0.5) / 2.0 - 8.0
        d = max(abs(x), abs(z), (abs(x) + abs(z)) / (1 + smooth.K))
        if d > r - 0.5:
            return GOLD if d <= r - 0.1 else PORC_L
        return flowers.get((p.x, p.z), PORC_L if d > r - 2.2 else PORC_D if d > r - 2.7 else PORC)
    edge = lambda p: PORC_L if p.top else PORC_D
    return (disc(r - 1.75, 0, 0.5, solid(PORC_DD), foot=False)
            + disc(r, 0.5, 1.0, edge, china, lift=0.3, foot=False))


def painted_wall(r, y1, petal, petal_l, petal_d):
    """The outside of a porcelain cup: a gold lip, a band of little roses with leaves and a coloured foot."""
    mid = int(round((1.0 + y1) / 2.0 * 2)) - 1                               # the texture row of the flowers
    flower = {(0, 0): GOLD_L, (-1, 0): petal, (1, 0): petal_d, (0, 1): petal_l, (0, -1): petal_d,
              (-1, 1): petal_l, (1, -1): petal_d, (-1, -1): petal, (1, 1): petal,
              (-2, -1): LEAF, (2, 1): LEAF, (3, 1): LEAF}

    def paint(p):
        s = around(p, r)
        if p.y >= int(y1 * 2) - 1:
            return GOLD
        if p.y == 2:
            return petal_l
        d = s % 10 - 4
        c = flower.get((d, p.y - mid))
        if c:
            return c
        if d in (-4, 5) and p.y == mid:
            return petal_l                                                   # a dot between two roses
        return PORC
    return paint


def handle(r, y1, body=PORC, shade=PORC_D, tip=GOLD_L):
    """A ring handle on the east side, from the cup wall outward."""
    x = 8.0 + r
    low, high = 1.75, y1 - 0.5
    return (box(x, high - 1.0, 7.25, x + 2.0, high, 8.75, solid(body), solid(tip), faces=_NOT_WEST, foot=False)
            + box(x, low, 7.25, x + 2.0, low + 1.0, 8.75, solid(shade), solid(body), faces=_NOT_WEST, foot=False)
            + box(x + 1.0, low + 1.0, 7.25, x + 2.0, high - 1.0, 8.75, solid(body), foot=False))


_NOT_WEST = ("north", "south", "east", "up", "down")


def china_cup(r, y1, surface, petal, petal_l, petal_d, saucer_r, deep=0.5):
    """A cup on its saucer. y1 = the height of the lip, the drink stands `deep` under it."""
    wall = painted_wall(r, y1, petal, petal_l, petal_d)
    level = y1 - deep

    def lip(p):
        return GOLD_L
    inner = lambda p: wall(p) if p.u * p.u + p.v * p.v > 0.72 else PORC_D       # inside the cup: plain porcelain
    return (saucer(saucer_r, petal, petal_l) + disc(r, 1.0, level, wall, surface)
            + ring(r, 0.75, level, y1, inner, lip) + handle(r, y1))


def cup_espresso():
    def crema(p):
        d = math.hypot(p.x - 15.5, p.z - 15.5)
        if d > 3.6:
            return CREMA_D
        return CREMA_L if 1.2 < d < 2.6 and (p.x + p.z) % 5 else CREMA
    return china_cup(3.25, 4.75, crema, SKY, SKY_L, SKY_D, 5.5)


def cup_flat_white():
    crema = lambda p: CREMA if math.hypot(p.x - 15.5, p.z - 15.5) < 6.2 else CREMA_D
    return (china_cup(4.5, 5.25, crema, MINT, MINT_L, MINT_D, 6.75, 0.25)
            + art(5.0, TULIP, MILK, CREMA, LATTE_L))


def cup_cappuccino():
    r, y1 = 4.5, 5.5
    foam = tones(FOAM, MILK, FOAM_D, 81, 0.18)
    return (china_cup(r, y1, foam, PINK, PINK_L, PINK_D, 6.75, 0.25)
            + disc(3.5, y1 - 0.25, y1 + 0.5, foam, foam, foot=False) + disc(3.0, y1 + 0.5, y1 + 1.0, foam, foam, foot=False)
            + art(y1 + 1.0, HEART, CHOC_L, foam, "C49470"))


def empty_cup():
    def bottom(p):
        d = math.hypot(p.x - 15.5, p.z - 15.5)
        return GOLD_L if 2.4 < d < 3.2 else PORC if d < 2.4 else PORC_D
    return china_cup(4.25, 5.5, bottom, PINK, PINK_L, PINK_D, 6.5, 3.0)


# ------------------------------------------------------------------------------------------------ glasses
def coaster(r, base, light, dark):
    """A round knitted coaster."""
    def top(p):
        d = max(abs(p.u), abs(p.v), (abs(p.u) + abs(p.v)) / (1 + smooth.K))
        if d > 0.86:
            return light if (p.x + p.z) % 2 else base
        return dark if (p.x + p.z) % 4 == 0 else light if (p.x - p.z) % 4 == 0 else base
    return disc(r, 0, 0.75, lambda p: dark if (p.x + p.z) % 2 else base, top, lift=0.4, foot=False)


def layers_paint(layers, r, y1, salt):
    """The wall of a filled glass: layers = ((up to this height, colour), ...) with soft wavy borders and a shine."""
    def paint(p):
        wave = 1 if rnd(around(p, r) // 3, 0, 0, salt) < 0.45 else 0
        if p.y >= int(y1 * 2) - 1:
            return GLASS_L
        for upto, colour in layers:
            if p.y + wave < upto * 2:
                break
        else:
            colour = GLASS
        s = around(p, r)
        total = int(2 * math.pi * r * 2)
        shine = (s - int(total * 0.17)) % total
        if p.y > 2 and (shine < 2 or shine == 3) and p.y < int(y1 * 2) - 2:
            return _light(colour, 0.55 if shine < 2 else 0.3)
        if p.y <= 2:
            return GLASS_D
        return colour
    return paint


def _light(colour, k):
    return tuple(int(int(colour[i:i + 2], 16) * (1 - k) + 255 * k) for i in (0, 2, 4))


def glass(r, y1, level, layers, surface, salt, mat):
    wall = layers_paint(layers, r, y1, salt)
    return (coaster(r + 1.5, *mat) + disc(r, 0.75, level, wall, surface, foot=False)
            + ring(r, 0.5, level, y1, wall, solid(GLASS_L), lift=0.5))


def cup_latte():
    crema = tones(CREMA, CREMA_L, CREMA_D, 82, 0.14)
    return (glass(3.5, 11.5, 11.25, ((3.25, MILK), (5.25, LATTE_L), (8.0, LATTE), (9.0, LATTE_L), (11.5, FOAM)),
                  crema, 83, (SKY, SKY_L, SKY_D))
            + art(11.25, HEART, MILK, crema, LATTE_L))


def cup_macchiato():
    def lattice(p):
        if p.x % 4 == 1 or p.z % 4 == 1:
            return CARAMEL_L if (p.x + p.z) % 6 == 0 else CARAMEL
        return FOAM
    r, y1 = 3.5, 11.5
    drip = lambda x, z, w, d, low: box(x, low, z, x + w, y1 + 0.25, z + d, solid(CARAMEL), solid(CARAMEL_L), foot=False)
    return (glass(r, y1, 11.25, ((3.75, MILK), (5.0, LATTE_L), (7.5, ESPRESSO), (8.25, LATTE), (11.5, FOAM)),
                  lattice, 84, (PINK, PINK_L, PINK_D))
            + drip(7.0, 8.0 - r - 0.25, 0.75, 0.25, 8.75) + drip(8.0 - r - 0.25, 8.25, 0.25, 0.75, 9.75))


def cup_americano():
    def surface(p):
        d = math.hypot(p.x - 15.5, p.z - 15.5)
        return CREMA_L if 1.5 < d < 3.0 and (p.x + p.z) % 3 else CREMA
    r, y1 = 3.75, 8.75
    return (glass(r, y1, 8.0, ((6.75, ESPRESSO), (7.25, COFFEE), (8.0, CREMA)), surface, 85, (MINT, MINT_L, MINT_D))
            + handle(r, y1, GLASS, GLASS_D, GLASS_L))


def whipped(y, base, shade, topping):
    """Whipped cream piped in three turns."""
    def piped(p):
        return shade if (p.x + p.y * 2 + p.z) % 5 == 0 else base
    return (disc(3.25, y, y + 1.5, piped, topping, foot=False) + disc(2.25, y + 1.5, y + 2.75, piped, topping, foot=False)
            + disc(1.25, y + 2.75, y + 3.75, piped, topping, foot=False))


def cup_raf():
    r, y1 = 3.75, 8.75
    sugar = sprinkled(tones(MILK, "FFFFFF", FOAM, 86, 0.14), 87, 0.2, (CARAMEL, CARAMEL_L, "F8DC8C"))
    return (glass(r, y1, 8.5, ((2.75, COFFEE_L), (4.75, LATTE), (6.75, LATTE_L), (9.0, FOAM)), solid(FOAM), 88,
                  ("E8C468", "F8E09C", "C49C40"))
            + handle(r, y1, GLASS, GLASS_D, GLASS_L) + whipped(8.5, MILK, FOAM_D, sugar)
            + box(7.25, 12.25, 7.25, 8.75, 13.0, 8.75, solid(CARAMEL), solid(CARAMEL_L), 45, foot=False))


def cup_mocha():
    r, y1 = 3.75, 8.75

    def drizzle(p):
        return CHOC if (p.x + p.z) % 5 == 0 or (p.x - p.z) % 7 == 0 else MILK

    def wafer(p):
        return "9A6448" if (p.y + p.x) % 3 == 0 else CHOC
    return (glass(r, y1, 8.5, ((2.75, CHOC_D), (5.0, CHOC), (6.75, CHOC_L), (9.0, FOAM)), solid(FOAM), 89,
                  (PINK, PINK_L, PINK_D))
            + handle(r, y1, GLASS, GLASS_D, GLASS_L) + whipped(8.5, MILK, FOAM_D, drizzle)
            + box(9.25, 9.5, 8.5, 10.25, 14.5, 9.75, wafer, solid(CHOC_L), 22.5, foot=False)
            + box(5.75, 10.0, 6.0, 6.75, 10.75, 7.0, solid(CHOC_D), solid(CHOC_L), 45, foot=False))


DRINKS = {f.__name__: f for f in (cup_espresso, cup_americano, cup_latte, cup_cappuccino, cup_flat_white, cup_raf,
                                  cup_mocha, cup_macchiato, empty_cup)}
