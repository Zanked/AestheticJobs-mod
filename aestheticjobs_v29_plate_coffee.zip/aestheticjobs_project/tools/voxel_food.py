"""A tiny voxel kit for the 3D food: paint shapes into a 32x32x32 grid (1 voxel = 0.5 model units), then turn it into
a Minecraft item model with only the visible faces, merged into as few quads as possible, plus its texture atlas.

Because the geometry comes from one grid there are no overlapping faces (no z-fighting), no hidden faces and no holes.
"""
import math
import zlib

import numpy as np
from PIL import Image

import smooth
import style

N = 32


def rgb(h):
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


def mix(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def rnd(x, y, z, salt=0):
    """A stable pseudo random number 0..1 for a voxel."""
    return (zlib.crc32(bytes((x & 255, y & 255, z & 255, salt & 255))) & 0xFFFF) / 65535.0


def grain(base, light, dark, salt=0, amount=0.22):
    """A softly shaded material: broad patches between the base and its light and dark tone, no speckle."""
    base, light, dark = rgb(base), rgb(light), rgb(dark)

    def col(x, y, z):
        v = (style.soft(x, y, z, salt & 255, 4) - 0.5) * 2.0
        return mix(base, light if v > 0 else dark, min(0.55, abs(v) * (0.35 + amount)))
    return col


class Vox:
    def __init__(self):
        self.g = {}                     # voxel -> colour
        self.parts = []                 # smooth elements (octagons and boxes in model units)
        self.solid = set()              # voxels filled by smooth parts: nothing is drawn there, but food can rest on them

    # ------------------------------------------------------------ smooth shapes (voxel coordinates, like the voxels)
    def shader(self, col):
        def sh(x, y, z, face):
            p = (int(math.floor(x * 2)), int(math.floor(y * 2)), int(math.floor(z * 2)))
            c = col(*p) if callable(col) else col
            c = rgb(c) if isinstance(c, str) else c
            k = 1.03 if face == "up" else 1.0
            return tuple(max(0, min(255, int(round(v * k)))) for v in c)
        return sh

    def _occupy(self, cx, cz, r, y0, y1, r_in=0.0):
        for y in range(y0, y1):
            for z in range(N):
                for x in range(N):
                    dx, dz = abs(x + 0.5 - cx), abs(z + 0.5 - cz)
                    d = max(dx, dz, (dx + dz) / (1 + smooth.K))
                    if r_in <= d <= r:
                        self.solid.add((x, y, z))

    def disc(self, r, y0, y1, col, cx=16.0, cz=16.0, top=None):
        """A smooth octagonal prism; col paints the sides, top (if given) the upper face."""
        self.parts += smooth.octagon(cx / 2, cz / 2, r / 2, y0 / 2, y1 / 2, self.shader(col),
                                     self.shader(top if top is not None else col))
        self._occupy(cx, cz, r, y0, y1)

    def ring(self, r, thick, y0, y1, col, cx=16.0, cz=16.0, top=None, inner=None):
        """A smooth hollow octagonal wall."""
        self.parts += smooth.ring(cx / 2, cz / 2, r / 2, thick / 2, y0 / 2, y1 / 2, self.shader(col),
                                  self.shader(inner if inner is not None else col),
                                  self.shader(top if top is not None else col))
        self._occupy(cx, cz, r, y0, y1, r - thick)

    def slab(self, x0, y0, z0, x1, y1, z1, col):
        """A plain smooth box (handles, sticks): one element, never overlapping the voxels."""
        self.parts.append(smooth.box((x0 / 2, y0 / 2, z0 / 2), (x1 / 2, y1 / 2, z1 / 2), self.shader(col)))
        for y in range(int(y0), int(math.ceil(y1))):
            for z in range(int(z0), int(math.ceil(z1))):
                for x in range(int(x0), int(math.ceil(x1))):
                    self.solid.add((x, y, z))

    # ------------------------------------------------------------ painting
    def put(self, x, y, z, col):
        if 0 <= x < N and 0 <= y < N and 0 <= z < N:
            if isinstance(col, str):
                col = rgb(col)
            elif callable(col):
                col = col(x, y, z)
                if isinstance(col, str):
                    col = rgb(col)
            self.g[(x, y, z)] = col

    def fill(self, pred, col, y0=0, y1=N):
        for y in range(y0, y1):
            for z in range(N):
                for x in range(N):
                    if pred(x + 0.5, y + 0.5, z + 0.5):
                        self.put(x, y, z, col)

    def box(self, x0, y0, z0, x1, y1, z1, col):
        for y in range(y0, y1):
            for z in range(z0, z1):
                for x in range(x0, x1):
                    self.put(x, y, z, col)

    def cyl(self, r, y0, y1, col, cx=16.0, cz=16.0, r_in=0.0):
        self.fill(lambda x, y, z: r_in ** 2 <= (x - cx) ** 2 + (z - cz) ** 2 <= r * r, col, y0, y1)

    def ball(self, cx, cy, cz, rx, col, ry=None, rz=None, ymin=0, ymax=N):
        ry = ry or rx
        rz = rz or rx
        self.fill(lambda x, y, z: ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 + ((z - cz) / rz) ** 2 <= 1.0, col,
                  max(0, ymin), min(N, ymax))

    def paint(self, pred, col):
        """Recolours voxels that already exist."""
        for (x, y, z) in list(self.g):
            if pred(x, y, z):
                self.put(x, y, z, col)

    def tops(self, pred, col, depth=1):
        """Recolours the top voxels of every column (icing, glaze, sugar)."""
        best = {}
        for (x, y, z) in self.g:
            best[(x, z)] = max(y, best.get((x, z), 0))
        for (x, z), y in best.items():
            for k in range(depth):
                if (x, y - k, z) in self.g and pred(x, y - k, z):
                    self.put(x, y - k, z, col)

    def top(self, x, z):
        ys = [y for (a, y, b) in list(self.g) + list(self.solid) if a == x and b == z]
        return max(ys) if ys else -1

    def sprinkle(self, colors, count, salt, pred=lambda x, y, z: True):
        """Single voxels lying on the top surface."""
        tops = {}
        for (x, y, z) in self.g:
            tops[(x, z)] = max(y, tops.get((x, z), 0))
        high = {}
        for (x, y, z) in self.solid:
            high[(x, z)] = max(y, high.get((x, z), 0))
        for k, y in high.items():                                   # on smooth shapes the grain lies on top of them
            if y >= tops.get(k, -1):
                tops[k] = y + 1
        cand = sorted((x, y, z) for (x, z), y in tops.items() if pred(x, y, z))
        cand.sort(key=lambda p: rnd(p[0], p[1], p[2], salt))
        for i, (x, y, z) in enumerate(cand[:count]):
            self.put(x, y, z, colors[i % len(colors)])

    # ------------------------------------------------------------ transforms
    def cells(self):
        return set(self.g) | self.solid

    def bounds(self):
        xs, ys, zs = zip(*self.cells())
        return (min(xs), min(ys), min(zs)), (max(xs) + 1, max(ys) + 1, max(zs) + 1)

    def moved(self, dx, dy, dz):
        v = Vox()
        v.g = {(x + dx, y + dy, z + dz): c for (x, y, z), c in self.g.items()}
        v.solid = {(x + dx, y + dy, z + dz) for x, y, z in self.solid}
        for p in self.parts:
            q = dict(p)
            d = (dx / 2, dy / 2, dz / 2)
            q["f"] = [p["f"][i] + d[i] for i in range(3)]
            q["t"] = [p["t"][i] + d[i] for i in range(3)]
            if p["rot"]:
                q["rot"] = (p["rot"][0], p["rot"][1] + d[0], p["rot"][2] + d[2])
            q["faces"] = {f: (lambda x, y, z, face, s=s, d=d: s(x - d[0], y - d[1], z - d[2], face)) for f, s in p["faces"].items()}
            v.parts.append(q)
        return v

    def over(self, other):
        v = Vox()
        v.g = dict(self.g)
        v.g.update(other.g)
        v.parts = self.parts + other.parts
        v.solid = self.solid | other.solid
        return v


# ---------------------------------------------------------------- meshing
# face: axis, direction, the two in-plane axes as (u axis, u sign, v axis, v sign) following Minecraft's default UV orientation
FACES = {
    "north": (2, -1, 0, -1, 1, -1), "south": (2, 1, 0, 1, 1, -1),
    "east": (0, 1, 2, -1, 1, -1), "west": (0, -1, 2, 1, 1, -1),
    "up": (1, 1, 0, 1, 2, 1), "down": (1, -1, 0, 1, 2, -1),
}


def face_color(g, p, axis, d, solid=frozenset(), span=(0, 1)):
    """The colour of a voxel face: soft ambient occlusion, mottling, light from above and defined edges."""
    c = g[p]
    other = [a for a in range(3) if a != axis]

    def filled(dx, dy, dz):
        q = (p[0] + dx, p[1] + dy, p[2] + dz)
        return q in g or q in solid
    n = 0
    for du, dv in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        q = list(p)
        q[axis] += d
        q[other[0]] += du
        q[other[1]] += dv
        n += tuple(q) in g or tuple(q) in solid
    k = (1.0 - 0.06 * min(n, 3)) * style.mottle(*p)
    light = 0.0
    if axis != 1:
        height = max(1, span[1] - span[0])
        k *= 0.94 + 0.11 * (p[1] - span[0]) / height
        if not filled(0, 1, 0):
            light = 0.17
        elif not filled(0, -1, 0) and p[1] > span[0]:
            k *= 0.88
    elif d == 1:
        if not filled(-1, 0, 0) or not filled(0, 0, -1):
            light = 0.12
        elif not filled(1, 0, 0) or not filled(0, 0, 1):
            k *= 0.95
    return style.shade(c, k, light)


def quads_of(g, solid=frozenset()):
    """Greedy meshing: [(face, plane, a0, b0, a1, b1)] with a, b = the two in-plane axes.

    Every visible voxel face is covered exactly once. A rectangle may also run over faces that are buried inside the
    food (nobody can ever see them): one big quad is cheaper than several small ones around them.
    """
    out = []
    for name, (axis, d, ua, us, va, vs) in FACES.items():
        planes, buried = {}, {}
        for p in g:
            q = list(p)
            q[axis] += d
            if tuple(q) in solid:                                      # pressed against a smooth shape: unseen
                continue
            (buried if tuple(q) in g else planes).setdefault(p[axis], set()).add((p[ua], p[va]))
        for plane, cells in sorted(planes.items()):
            todo = set(cells)
            free = set(buried.get(plane, ()))
            while todo:
                a0, b0 = min(todo, key=lambda c: (c[1], c[0]))
                best = (1, 1, 1)                                       # visible cells, width, height
                width = 10 ** 6
                h = 0
                counts = []
                while True:
                    w, row = 0, []
                    while w < width and ((a0 + w, b0 + h) in todo or (a0 + w, b0 + h) in free):
                        row.append((row[-1] if row else 0) + ((a0 + w, b0 + h) in todo))
                        w += 1
                    if w == 0:
                        break
                    width = w
                    counts.append(row)
                    h += 1
                    for cw in range(1, width + 1):
                        n = sum(r[cw - 1] for r in counts)
                        if n > best[0] or (n == best[0] and cw * h < best[1] * best[2]):
                            best = (n, cw, h)
                _, w, h = best
                for j in range(h):
                    for i in range(w):
                        todo.discard((a0 + i, b0 + j))
                        free.discard((a0 + i, b0 + j))
                out.append((name, plane, a0, b0, a0 + w, b0 + h))
    return out


def build(vox):
    """-> (elements, atlas image). Element faces use the texture variable #t."""
    g = {p: c for p, c in vox.g.items() if p not in vox.solid}       # voxels swallowed by a smooth shape are not drawn
    quads = quads_of(g, vox.solid)
    patches, index = [], {}
    jobs = []
    ys = [y for _, y, _ in vox.cells()]
    span = (min(ys), max(ys) + 1)
    for name, plane, a0, b0, a1, b1 in quads:
        axis, d, ua, us, va, vs = FACES[name]
        w, h = a1 - a0, b1 - b0
        im = np.zeros((h, w, 4), np.uint8)
        for j in range(h):
            for i in range(w):
                p = [0, 0, 0]
                p[axis] = plane
                p[ua] = a0 + i if us > 0 else a1 - 1 - i
                p[va] = b0 + j if vs > 0 else b1 - 1 - j
                im[j, i] = face_color(g, tuple(p), axis, d, vox.solid, span) + (255,)
        key = (w, h, im.tobytes())
        if key not in index:                                          # identical patches share their pixels
            index[key] = len(patches)
            patches.append(im)
        jobs.append((name, plane, a0, b0, a1, b1, index[key]))

    extra = []
    for part in vox.parts:
        ids = {}
        for face, im, w, h in smooth.patches_of(part):
            key = (w, h, im.tobytes())
            if key not in index:
                index[key] = len(patches)
                patches.append(im)
            ids[face] = (index[key], w, h)
        extra.append((part, ids))

    patches = [style.grade(p) for p in patches]
    atlas, place = smooth.pack(patches)
    size = atlas.shape[0]
    k = 16.0 / size

    def uv(i):
        px, py = place[i]
        h, w = patches[i].shape[:2]
        return [px * k, py * k, (px + w) * k, (py + h) * k]

    elements = []
    for name, plane, a0, b0, a1, b1, pi in jobs:
        axis, d, ua, us, va, vs = FACES[name]
        lo, hi = [0.0] * 3, [0.0] * 3
        lo[axis] = hi[axis] = (plane + (1 if d > 0 else 0)) / 2.0
        lo[ua], hi[ua] = a0 / 2.0, a1 / 2.0
        lo[va], hi[va] = b0 / 2.0, b1 / 2.0
        elements.append(smooth.element(lo, hi, {name: uv(pi)}))
    for part, ids in extra:
        elements.append(smooth.element(part["f"], part["t"], {f: uv(i) for f, (i, w, h) in ids.items()}, part["rot"]))
    return elements, Image.fromarray(atlas, "RGBA")


# ---------------------------------------------------------------- display transforms
def _rot(rx, ry):
    a, b = math.radians(rx), math.radians(ry)
    mx = np.array([[1, 0, 0], [0, math.cos(a), -math.sin(a)], [0, math.sin(a), math.cos(a)]])
    my = np.array([[math.cos(b), 0, math.sin(b)], [0, 1, 0], [-math.sin(b), 0, math.cos(b)]])
    return mx @ my


def display(vox, handle=False):
    """Transforms fitted to the size of the model: the icon fills the slot, the food sits nicely in hands and on the ground."""
    (x0, y0, z0), (x1, y1, z1) = vox.bounds()
    # the real voxels, not the box: round food fills the slot and the frame better that way
    corners = np.array([[x + i, y + j, z + k] for (x, y, z) in vox.cells() for i in (0, 1) for j in (0, 1) for k in (0, 1)]) / 2.0 - 8.0
    r = lambda *v: [round(float(a), 3) for a in v]

    def fit(rotation, room, biggest):
        """Rotates the model and returns (rotated corners, scale that fits `room` units, translation that centres it)."""
        q = corners @ _rot(rotation[0], rotation[1]).T
        lo, hi = q.min(axis=0), q.max(axis=0)
        s = min(room / max(hi[0] - lo[0], hi[1] - lo[1]), biggest)
        return q, s, -(lo[0] + hi[0]) / 2 * s, -(lo[1] + hi[1]) / 2 * s

    _, gs, gx, gy = fit((30, 225), 15.0, 1.35)
    q, fs, fx, fy = fit((-30, 45), 11.0, 0.9)
    fz = 0.9 - q[:, 2].max() * fs                                     # nothing sinks into the wall behind an item frame
    center_y = (y0 + y1) / 4.0
    height = (y1 - y0) / 2.0

    def lift(s, target):                                              # puts the middle of the food at `target` units
        return round(target - (center_y - 8.0) * s, 2)
    def in_hand(s):
        """Third person: the arm of a holding player points 18 degrees forward, so the item is turned 72 degrees around x
        to stand level (exactly as vanilla blocks do), and moved so that its bottom rests in the palm."""
        half = height * s / 2.0
        d = (center_y - 8.0) * s
        a = math.radians(72.0)
        return {"rotation": [72, -90 if handle else 0, 0],
                "translation": r(0, 0.4 + 0.31 * half - d * math.cos(a), 0.5 + 0.95 * half - d * math.sin(a)), "scale": [s, s, s]}
    first = {"rotation": [8, -45 if handle else 160, 0], "translation": [0, lift(0.42, 3.4), 0], "scale": [0.42, 0.42, 0.42]}

    return {
        "gui": {"rotation": [30, 225, 0], "translation": r(gx, gy, 0), "scale": r(gs, gs, gs)},
        "ground": {"rotation": [0, 0, 0], "translation": [0, lift(0.5, 2.0), 0], "scale": [0.5, 0.5, 0.5]},
        "fixed": {"rotation": [-30, 45, 0], "translation": r(fx, fy, fz), "scale": r(fs, fs, fs)},
        "thirdperson_righthand": in_hand(0.42),
        "firstperson_righthand": first,
        "firstperson_lefthand": first,
        "head": {"rotation": [0, 0, 0], "translation": [0, lift(0.7, 12.0), 0], "scale": [0.7, 0.7, 0.7]},
    }
