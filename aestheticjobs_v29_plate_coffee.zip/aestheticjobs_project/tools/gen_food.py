#!/usr/bin/env python3
"""The 3D food of the cafe: 8 drinks, 32 desserts (also each of them on a plate), the supplies and the empty cup.
The cups (lowpoly_drinks.py), the desserts and the plates (lowpoly_desserts.py) are low-poly miniatures with
hand-painted textures; the supplies are smooth voxel models (voxel_food.py).

    python3 tools/gen_food.py                 # writes models/item/*.json and textures/item/food3d/*.png
    python3 tools/gen_food.py --check         # verifies the written models (no flicker, nothing floating, UVs, overrides)

The 2D sprites textures/item/<id>.png stay: the screens of the mod (ticket, menus, bubbles) draw them.
Coordinates are voxels (32 per block side), y is up, the front of the food looks north (small z).
"""
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import lowpoly_desserts as lowpoly  # noqa: E402
import lowpoly_drinks as cups  # noqa: E402
from voxel_food import Vox, build, display, grain, rnd  # noqa: E402
import smooth  # noqa: E402
from smooth import fighting_faces  # noqa: E402

ASSETS = os.path.join(HERE, "..", "src", "main", "resources", "assets", "aestheticjobs")
FOOD = {}


def food(fn):
    FOOD[fn.__name__] = fn
    return fn


# ------------------------------------------------------------------------------------------------ materials
GOLD, GOLD_L = "D9B25E", "F2D78E"
MILK = "FFF8EC"
CHOC, CHOC_L = "62392A", "855540"

choc = grain(CHOC, "6F4332", "583224", 8, 0.18)


def angle(x, z, cx=16.0, cz=16.0):
    return math.atan2(z + 0.5 - cz, x + 0.5 - cx)


# ------------------------------------------------------------------------------------------------ supplies
@food
def coffee_beans():
    v = Vox()
    weave = lambda x, y, z: "D8BA86" if (x + y) % 3 == 0 else "A68650" if (z + y) % 4 == 0 else "C4A26C"
    v.disc(8.8, 0, 8, weave)
    v.disc(8.2, 8, 12, weave)
    v.ring(9.4, 2.2, 12, 14, "E2C894", top="EBD4A4")
    beans = lambda x, y, z: ("8A5638", "5E3422", "432216", "6E3F28")[int(rnd(x // 2, y, z // 2, 48) * 3.99)]
    v.disc(7.2, 12, 13, beans)
    v.disc(4.8, 13, 15, beans)
    v.disc(2.4, 15, 16, beans)
    v.slab(13, 2, 6.7, 19, 7, 7.2, lambda x, y, z: "E2C894" if x == 15 + (y > 4) else "5E3422")
    for x, z in ((4, 5), (25, 5), (8, 2)):
        v.box(x, 0, z, x + 3, 2, z + 2, "5E3422")
        v.put(x + 1, 1, z, "8A5638")
    return v


def carton(body, accent, accent_d, picture):
    v = Vox()
    v.box(10, 0, 10, 22, 17, 22, lambda x, y, z: accent if 3 <= y < 6 else accent_d if y == 6 else body)
    for i, y in enumerate(range(17, 22)):
        v.box(10, y, 11 + i, 22, y + 1, 21 - i, accent)
    v.box(10, 22, 15, 22, 24, 17, accent_d)
    for x, y, c in picture:
        v.put(x, y, 10, c)
    v.box(18, 19, 11, 21, 21, 13, MILK)
    return v


@food
def milk_carton():
    cow = [(x, y, "4A4440") for x, y in ((13, 14), (14, 14), (13, 13), (18, 10), (19, 10), (19, 11), (17, 14))]
    drop = [(x, y, "7FB2DE") for x, y in ((15, 12), (16, 12), (15, 11), (16, 11), (14, 10), (15, 10), (16, 10), (17, 10),
                                          (15, 9), (16, 9), (15, 13))]
    return carton("F8F6F0", "A9CDEB", "7FB2DE", cow + drop)


@food
def cream_carton():
    pic = [(x, y, "E8A6B8") for x, y in ((13, 10), (14, 10), (15, 10), (16, 10), (17, 10), (18, 10), (14, 11), (15, 11),
                                         (16, 11), (17, 11), (15, 12), (16, 12), (15, 13))]
    return carton("FFF2D8", "F4B8C6", "DC8CA0", pic)


def syrup(liquid, liquid_l, label, cap, icon):
    v = Vox()

    def bottle(x, y, z):
        if 4 <= y < 11:
            return liquid if (x, y) in icon and z < 16 else label
        if -2.45 < angle(x, z) < -2.0:
            return liquid_l
        return liquid
    v.disc(6.4, 0, 15, bottle, top=liquid_l)
    v.disc(5.0, 15, 17, liquid)
    v.disc(2.6, 17, 21, liquid_l)
    v.disc(3.4, 21, 23, cap)
    v.slab(15, 23, 15, 17, 25, 17, cap)
    v.slab(11, 25, 15, 17, 27, 17, GOLD)
    return v


@food
def syrup_vanilla():
    return syrup("D9A84E", "F2D084", "FFF6E2", "6A4435",
                 ((15, 9), (16, 9), (13, 8), (14, 8), (17, 8), (18, 8), (15, 7), (16, 7), (15, 5), (15, 6)))


@food
def syrup_caramel():
    return syrup("A85A1E", "D88636", "F6DCA8", "47271C",
                 ((14, 9), (15, 9), (16, 9), (17, 9), (13, 8), (13, 7), (14, 6), (15, 6), (16, 6), (17, 7), (16, 8)))


@food
def chocolate():
    v = Vox()
    v.box(8, 0, 5, 24, 3, 27, choc)
    for i in range(2):
        for j in range(2):
            v.box(9 + i * 8, 3, 6 + j * 6, 15 + i * 8, 4, 11 + j * 6, CHOC_L)
            v.box(10 + i * 8, 4, 7 + j * 6, 14 + i * 8, 5, 10 + j * 6, choc)
    v.box(7, 0, 18, 25, 5, 28, lambda x, y, z: "F4ABC0" if (z in (21, 22)) else "FFF0DC" if z == 20 or z == 23 else "DF7F9C")
    v.box(7, 0, 17, 25, 5, 18, lambda x, y, z: GOLD_L if x % 2 else GOLD)
    return v


# ------------------------------------------------------------------------------------------------ files
DRINKS = ["espresso", "americano", "latte", "cappuccino", "flat_white", "raf", "mocha", "macchiato"]
DESSERTS = ["croissant", "donut_pink", "donut_choc", "cupcake_pink", "cupcake_choc", "muffin_blueberry", "cream_puff", "eclair",
            "cinnamon_roll", "cookie_choc", "cookie_heart", "gingerbread_man", "macaron_pink", "macaron_mint", "macaron_lemon",
            "cake_pop", "cheesecake", "cake_strawberry", "cake_choc", "tiramisu", "apple_pie", "medovik", "brownie", "waffle",
            "pancakes", "ice_cream_cone", "sundae", "creme_brulee", "panna_cotta", "flan", "fruit_tart", "baklava"]


def on_plate(name):
    """-> the parts of the plate with the dessert standing on it (the plate is 1 unit high)."""
    return lowpoly.plate() + lowpoly.moved(lowpoly.DESSERTS[name](), 0.0, 1.0, 0.0)


HANDLED = {"cup_espresso", "cup_americano", "cup_flat_white", "cup_cappuccino", "cup_raf", "cup_mocha", "empty_cup"}


def write(model_id, model_of, overrides=None):
    """model_of: a voxel model (Vox) or the parts of a low-poly one (a list)."""
    low = isinstance(model_of, list)
    elements, atlas = lowpoly.build(model_of) if low else build(model_of)
    os.makedirs(os.path.join(ASSETS, "textures", "item", "food3d"), exist_ok=True)
    atlas.save(os.path.join(ASSETS, "textures", "item", "food3d", model_id + ".png"), optimize=True)
    tex = "aestheticjobs:item/food3d/" + model_id
    # crumbs of an eaten dessert are cut from the flat sprite of the food (the model texture is a sheet of patches)
    sprite = model_id[len("dessert_plate_"):] if model_id.startswith("dessert_plate_") else "cup_latte" if model_id == "coffee_cup" else model_id
    assert os.path.exists(os.path.join(ASSETS, "textures", "item", sprite + ".png")), sprite
    model = {"credit": "tools/gen_food.py", "gui_light": "side", "texture_size": [atlas.width, atlas.height],
             "textures": {"particle": "aestheticjobs:item/" + sprite, "t": tex}, "elements": elements,
             "display": display(lowpoly.Shape(model_of) if low else model_of, model_id in HANDLED)}
    if overrides:
        model["overrides"] = overrides
    with open(os.path.join(ASSETS, "models", "item", model_id + ".json"), "w") as f:
        json.dump(model, f, separators=(",", ":"))
        f.write("\n")
    return len(elements), atlas.width


def write_plate_block():
    """The plate that stands in the world (block/PlateBlock) and its item: the same low-poly plate."""
    elements, atlas = lowpoly.build(lowpoly.plate())
    atlas.save(os.path.join(ASSETS, "textures", "block", "serving_plate.png"), optimize=True)
    tex = "aestheticjobs:block/serving_plate"
    block = {"credit": "tools/gen_food.py", "ambientocclusion": False, "texture_size": [atlas.width, atlas.height],
             "textures": {"particle": tex, "t": tex}, "elements": elements}
    item = {"credit": "tools/gen_food.py", "parent": "aestheticjobs:block/serving_plate", "gui_light": "side",
            "display": display(lowpoly.Shape(lowpoly.plate()), False)}
    for folder, model in (("block", block), ("item", item)):
        with open(os.path.join(ASSETS, "models", folder, "serving_plate.json"), "w") as f:
            json.dump(model, f, separators=(",", ":"))
            f.write("\n")


def cmd(ids, prefix):
    return [{"predicate": {"custom_model_data": i + 1}, "model": "aestheticjobs:item/" + prefix + n} for i, n in enumerate(ids)]


def main():
    stats = {}
    assert list(lowpoly.DESSERTS) == DESSERTS and {"cup_" + d for d in DRINKS} | {"empty_cup"} == set(cups.DRINKS)
    for name, fn in FOOD.items():
        stats[name] = write(name, fn())
    for name, fn in lowpoly.DESSERTS.items():
        stats[name] = write(name, fn())
    for name, fn in cups.DRINKS.items():
        stats[name] = write(name, fn())
    write_plate_block()
    stats["coffee_cup"] = write("coffee_cup", cups.DRINKS["cup_latte"](), cmd(DRINKS, "cup_"))
    stats["dessert_plate"] = write("dessert_plate", lowpoly.plate(), cmd(DESSERTS, "dessert_plate_"))
    for name in DESSERTS:
        stats["dessert_plate_" + name] = write("dessert_plate_" + name, on_plate(name))
    q = [s[0] for s in stats.values()]
    print(f"{len(stats)} models, elements: average {sum(q) // len(q)}, max {max(q)}, textures up to {max(s[1] for s in stats.values())} px")


# ------------------------------------------------------------------------------------------------ verification
def unsupported(elements):
    """The elements that do not touch (through others) anything standing on the lowest level."""
    boxes = []
    for e in elements:
        r = e.get("rotation")
        pts = [smooth.turn(x, z, r["angle"], r["origin"][0], r["origin"][2]) if r else (x, z)
               for x in (e["from"][0], e["to"][0]) for z in (e["from"][2], e["to"][2])]
        xs, zs = zip(*pts)
        boxes.append(((min(xs), e["from"][1], min(zs)), (max(xs), e["to"][1], max(zs))))
    ground = min(lo[1] for lo, _ in boxes)
    done = {i for i, (lo, _) in enumerate(boxes) if lo[1] <= ground + 0.05}
    todo = list(done)
    while todo:
        a_lo, a_hi = boxes[todo.pop()]
        for i, (lo, hi) in enumerate(boxes):
            if i not in done and all(lo[k] <= a_hi[k] + 0.05 and hi[k] >= a_lo[k] - 0.05 for k in range(3)):
                done.add(i)
                todo.append(i)
    return [i for i in range(len(boxes)) if i not in done]


def check():
    """Reads the written files back: nothing flickers, nothing floats, voxel faces all covered, UVs and links are fine."""
    from PIL import Image
    ids = list(FOOD) + list(cups.DRINKS) + DESSERTS + ["coffee_cup", "dessert_plate"] + ["dessert_plate_" + n for n in DESSERTS]
    axis_of = {"north": (2, -1), "south": (2, 1), "east": (0, 1), "west": (0, -1), "up": (1, 1), "down": (1, -1)}
    for mid in ids:
        m = json.load(open(os.path.join(ASSETS, "models", "item", mid + ".json")))
        low = mid not in FOOD
        vox = None if low else FOOD[mid]()
        im = Image.open(os.path.join(ASSETS, "textures", m["textures"]["t"].split(":")[1] + ".png"))
        assert im.width == im.height and im.width & (im.width - 1) == 0 and im.width <= 256, (mid, im.size)
        seen = set()
        for e in m["elements"]:
            assert all(-16 <= a <= b <= 32 for a, b in zip(e["from"], e["to"])), (mid, e)
            if "rotation" in e:
                assert e["rotation"]["angle"] in (-45, -22.5, 0, 22.5, 45), (mid, e)
            for data in e["faces"].values():
                assert all(0 <= v <= 16 for v in data["uv"]), (mid, data)
                assert data["uv"][2] > data["uv"][0] and data["uv"][3] > data["uv"][1], (mid, data)
            for face in e["faces"]:
                axis, d = axis_of[face]
                others = [a for a in range(3) if a != axis]
                lo, hi = [v * 2 for v in e["from"]], [v * 2 for v in e["to"]]
                if low or "rotation" in e or any(abs(v - round(v)) > 1e-3 for v in lo + hi):
                    continue
                lo, hi = [int(round(v)) for v in lo], [int(round(v)) for v in hi]
                for i in range(lo[others[0]], hi[others[0]]):
                    for j in range(lo[others[1]], hi[others[1]]):
                        p = [0, 0, 0]
                        p[axis], p[others[0]], p[others[1]] = (hi[axis] - 1 if d > 0 else lo[axis]), i, j
                        seen.add((face, tuple(p)))
        for p in (set(vox.g) - vox.solid if vox else ()):                               # every visible voxel face is drawn
            for face, (axis, d) in axis_of.items():
                q = list(p)
                q[axis] += d
                if tuple(q) not in vox.g and tuple(q) not in vox.solid:
                    assert (face, p) in seen, (mid, "hole", face, p)
        fight = fighting_faces(m["elements"])
        assert not fight, (mid, "flickering faces", len(fight), [(m["elements"][i], m["elements"][j]) for i, j, f, o in fight[:1]])
        for key, tr in m["display"].items():
            assert all(abs(v) <= 80 for v in tr["translation"]) and all(0 < v <= 4 for v in tr["scale"]), (mid, key, tr)
        for o in m.get("overrides", []):
            assert os.path.exists(os.path.join(ASSETS, "models", "item", o["model"].split("/")[-1] + ".json")), (mid, o)
        if low:
            assert len(m["elements"]) <= 90, (mid, "not low poly", len(m["elements"]))
            loose = unsupported(m["elements"])
            assert not loose, (mid, "floating pieces", [m["elements"][i] for i in loose[:2]])
            continue
        cells = vox.cells()
        left, groups = set(cells), []
        while left:
            stack = [left.pop()]
            group = [stack[0]]
            while stack:
                x, y, z = stack.pop()
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        for dz in (-1, 0, 1):
                            n = (x + dx, y + dy, z + dz)
                            if n in left:
                                left.remove(n)
                                stack.append(n)
                                group.append(n)
            groups.append(group)
        floating = [g for g in groups if min(p[1] for p in g) > min(p[1] for p in cells)]
        assert not floating, (mid, "floating pieces", [sorted(g)[:3] for g in floating])
    print("checked", len(ids), "models: no flickering faces, nothing floating, UVs, display and overrides fine")


if __name__ == "__main__":
    if "--check" in sys.argv:
        check()
    else:
        main()
