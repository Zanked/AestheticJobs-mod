#!/usr/bin/env python3
"""The pictures of the kitchen: the screen backgrounds and widgets, and the 32x32 icons of every drink, dessert and
addition. Everything is drawn with smooth shapes at 8x and scaled down, with soft light and a warm outline.

    python3 tools/gen_kitchen_art.py            # writes textures/gui/*.png and textures/item/<icon>.png
    python3 tools/gen_kitchen_art.py --sheet out.png     # a contact sheet of all icons
"""
import json
import math
import os
import random
import sys

import numpy as np
from PIL import Image, ImageChops, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
TEX = os.path.join(HERE, "..", "src", "main", "resources", "assets", "aestheticjobs", "textures")
K = 8                      # drawing scale
N = 32 * K


def rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def mix(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


WHITE, SHADE = (255, 250, 236), (96, 52, 66)
OUTLINE = (92, 54, 50)


class Icon:
    """Shapes in icon pixels (0..32). Every shape is lit from the upper left and may have its own soft edge line."""

    def __init__(self):
        self.im = Image.new("RGBA", (N, N), (0, 0, 0, 0))
        self.steam = []

    def mask(self):
        m = Image.new("L", (N, N), 0)
        return m, ImageDraw.Draw(m)

    def paint(self, m, color, light=0.38, dark=0.34, edge=True):
        box = m.getbbox()
        if not box:
            return
        base = rgb(color) if isinstance(color, str) else color
        x0, y0, x1, y1 = box
        yy, xx = np.mgrid[0:N, 0:N].astype(np.float32)
        t = ((xx - x0) / max(1, x1 - x0)) * 0.35 + ((yy - y0) / max(1, y1 - y0)) * 0.65      # 0 lit .. 1 shaded
        c = np.zeros((N, N, 3), np.float32) + base
        hi = np.clip((0.5 - t) * 2, 0, 1)[..., None] * light
        lo = np.clip((t - 0.5) * 2, 0, 1)[..., None] * dark
        c += (np.array(WHITE) - c) * hi
        c += (np.array(SHADE) - c) * lo
        layer = Image.fromarray(np.dstack([c, np.array(m, np.float32)]).clip(0, 255).astype(np.uint8), "RGBA")
        if edge:                                                    # a thin darker line separates the shape from what is below
            ring = ImageChops.subtract(m.filter(ImageFilter.MaxFilter(5)), m)
            line = Image.new("RGBA", (N, N), mix(base, SHADE, 0.35) + (0,))
            below = self.im.getchannel("A")
            line.putalpha(ImageChops.multiply(ring, below).point(lambda v: v * 5 // 10))
            self.im.alpha_composite(line)
        self.im.alpha_composite(layer)

    @staticmethod
    def s(v):
        return [a * K for a in v]

    def oval(self, x0, y0, x1, y1, color, **kw):
        m, d = self.mask()
        d.ellipse(self.s((x0, y0, x1, y1)), fill=255)
        self.paint(m, color, **kw)

    def rect(self, x0, y0, x1, y1, color, r=1.0, **kw):
        m, d = self.mask()
        d.rounded_rectangle(self.s((x0, y0, x1, y1)), radius=r * K, fill=255)
        self.paint(m, color, **kw)

    def poly(self, pts, color, smooth=0.0, **kw):
        m, d = self.mask()
        d.polygon([(x * K, y * K) for x, y in pts], fill=255)
        if smooth:
            m = m.filter(ImageFilter.GaussianBlur(smooth * K)).point(lambda v: max(0, min(255, (v - 128) * 6 + 128)))
        self.paint(m, color, **kw)

    def line(self, pts, color, w=1.0, **kw):
        m, d = self.mask()
        p = [(x * K, y * K) for x, y in pts]
        d.line(p, fill=255, width=int(w * K), joint="curve")
        for x, y in (p[0], p[-1]):
            d.ellipse((x - w * K / 2, y - w * K / 2, x + w * K / 2, y + w * K / 2), fill=255)
        kw.setdefault("edge", False)
        self.paint(m, color, **kw)

    def dot(self, x, y, r, color, **kw):
        kw.setdefault("edge", False)
        self.oval(x - r, y - r, x + r, y + r, color, **kw)

    def ring(self, x0, y0, x1, y1, hole, color, **kw):
        m, d = self.mask()
        d.ellipse(self.s((x0, y0, x1, y1)), fill=255)
        d.ellipse(self.s(hole), fill=0)
        self.paint(m, color, **kw)

    def sprinkle(self, seed, cx, cy, rx, ry, colors, n=14, long=True):
        r = random.Random(seed)
        for _ in range(n):
            a, q = r.random() * math.tau, math.sqrt(r.random())
            x, y = cx + math.cos(a) * q * rx, cy + math.sin(a) * q * ry
            c = r.choice(colors)
            if long:
                b = r.random() * math.pi
                self.line([(x - math.cos(b) * .7, y - math.sin(b) * .5), (x + math.cos(b) * .7, y + math.sin(b) * .5)], c, .7)
            else:
                self.dot(x, y, .55, c)

    def gloss(self, x, y, rx, ry, a=150):
        m, d = self.mask()
        d.ellipse(self.s((x - rx, y - ry, x + rx, y + ry)), fill=a)
        m = ImageChops.multiply(m.filter(ImageFilter.GaussianBlur(K * 0.35)), self.im.getchannel("A"))
        g = Image.new("RGBA", (N, N), WHITE + (0,))
        g.putalpha(m)
        self.im.alpha_composite(g)

    def done(self, shadow=True):
        # no drawn outline: the shape is held by its own colour, a slightly deeper lower rim and a soft shadow
        out = Image.new("RGBA", (N, N), (0, 0, 0, 0))
        a = self.im.getchannel("A")
        if shadow:
            sh = Image.new("RGBA", (N, N), SHADE + (0,))
            sh.putalpha(ImageChops.offset(a, 0, int(1.1 * K)).filter(ImageFilter.GaussianBlur(K * 0.8)).point(lambda v: v * 3 // 10))
            out.alpha_composite(sh)
        out.alpha_composite(self.im)
        px = np.array(self.im).astype(np.float32)
        solid = px[..., 3] > 90
        inner = np.array(a.point(lambda v: 255 if v > 90 else 0).filter(ImageFilter.MinFilter(K + 1))) > 0
        rim = solid & ~inner
        deep = px.copy()
        deep[..., :3] = deep[..., :3] * 0.62 + np.array(SHADE, np.float32) * 0.38
        deep[..., 3] = np.where(rim, px[..., 3] * 0.55, 0)
        out.alpha_composite(Image.fromarray(deep.clip(0, 255).astype(np.uint8), "RGBA"))
        for pts in self.steam:                                       # soft, without the outline
            m = Image.new("L", (N, N), 0)
            ImageDraw.Draw(m).line([(x * K, y * K) for x, y in pts], fill=225, width=int(1.1 * K), joint="curve")
            wisp = Image.new("RGBA", (N, N), (214, 176, 164, 0))
            wisp.putalpha(m.filter(ImageFilter.GaussianBlur(K * 0.25)))
            out.alpha_composite(wisp)
        return out.resize((32, 32), Image.LANCZOS)


# ------------------------------------------------------------------------------------------ drinks
def cup(liquid, foam=None, art=None, extra=None, glass=False, small=False):
    i = Icon()
    i.oval(2, 22, 30, 30, "F4EAD8")                       # saucer
    i.oval(7, 23, 25, 28, "DCCBB4", edge=False)
    w = 7.5 if small else 10
    top = 13 if small else 10
    body = "D9EEF2" if glass else "FBF3E6"
    i.line([(16 + w - 1, top + 3), (16 + w + 3.4, top + 4), (16 + w + 2.6, top + 8), (16 + w - 2.5, top + 10)], body, 2.2, edge=True)
    i.poly([(16 - w, top), (16 + w, top), (16 + w - 1.2, top + 9), (16 + w - 5, 26), (16 - w + 5, 26), (16 - w + 1.2, top + 9)], body, smooth=.5)
    if glass:
        i.poly([(16 - w + 1.2, top + 3), (16 + w - 1.2, top + 3), (16 + w - 2, top + 8), (16 - w + 2, top + 8)], "F6E6CC", edge=False)
        i.poly([(16 - w + 2, top + 8), (16 + w - 2, top + 8), (16 + w - 5.4, 24.5), (16 - w + 5.4, 24.5)], liquid, smooth=.4, edge=False)
    else:
        i.rect(16 - w + 2.4, top + 8, 16 + w - 2.4, top + 10, "E58E86", r=.8, edge=False)   # a painted band
        for dx in (-4, 0, 4):
            i.dot(16 + dx, top + 12.6, .8, "8FB8A6")
    i.oval(16 - w, top - 3.2, 16 + w, top + 3.2, body)
    i.oval(16 - w + 1.2, top - 2.2, 16 + w - 1.2, top + 2.4, liquid, light=.15, dark=.1, edge=False)
    if foam:
        i.oval(16 - w + 2.2, top - 1.7, 16 + w - 2.2, top + 1.9, foam, light=.25, dark=.08, edge=False)
    if art == "heart":
        i.poly([(16, top + 1.9), (12.8, top - .2), (13.8, top - 1.4), (16, top - .4), (18.2, top - 1.4), (19.2, top - .2)], "A8683E", smooth=.25, edge=False)
        i.poly([(16, top + 1.1), (14.2, top - .1), (14.9, top - .6), (16, top + .1), (17.1, top - .6), (17.8, top - .1)], "FFF4DC", smooth=.15, edge=False)
    if art == "leaf":
        for k in range(4):
            i.line([(12.6 + k, top - 1.2 + k * .75), (16, top - .1 + k * .75), (19.4 - k, top - 1.2 + k * .75)], "FFF4DC", .75)
    if extra == "cocoa":
        i.sprinkle(3, 16, top, 6, 1.5, ["6A3C2A", "8A5438"], 18, long=False)
    if extra == "whip":
        for x, y, r in ((12.5, top - 1, 3), (19.5, top - 1, 3), (16, top - 2.4, 4), (16, top - 5.6, 2.4)):
            i.oval(x - r, y - r * .75, x + r, y + r * .75, "FFF8EA", dark=.18)
        i.line([(13, top - 3), (17, top - 1.4), (15.4, top - 5), (18.6, top - 3.6)], "7A4630", .8)
    if extra == "caramel":
        for k in (-4, 0, 4):
            i.line([(16 + k - 2.5, top - 1.4), (16 + k + 2.5, top + 1.4)], "D8902E", .8)
            i.line([(16 + k + 2.5, top - 1.4), (16 + k - 2.5, top + 1.4)], "D8902E", .8)
    if not glass:
        i.gloss(16 - w + 3.4, top + 6, 1.2, 2.8)
    if not extra == "whip":
        for x in (13, 18):
            i.steam.append([(x, top - 4.4), (x + .9, top - 5.4), (x + 1.1, top - 6.4), (x + .2, top - 7.4), (x + .5, top - 8.6)])
    return i


# ------------------------------------------------------------------------------------------ desserts
def donut(glaze, spr):
    i = Icon()
    i.ring(3, 8, 29, 28, (12.5, 14.5, 19.5, 19.5), "DDA35C")
    m, d = i.mask()
    pts = []
    for k in range(48):
        a = k / 48 * math.tau
        wob = 1 + 0.07 * math.sin(a * 7)
        pts.append(((16 + math.cos(a) * 12 * wob) * K, (16 + math.sin(a) * 8.6 * wob) * K))
    d.polygon(pts, fill=255)
    d.ellipse(i.s((12, 13.6, 20, 18.6)), fill=0)
    i.paint(m, glaze)
    i.gloss(10, 11.6, 3.4, 1.4)
    i.sprinkle(5, 16, 15.5, 10, 6, spr, 16)
    i.oval(12.8, 14.2, 19.2, 18, "9A6034", dark=.5, edge=False)
    return i


def cupcake(frost, topping, spr=("FFF0A0", "8FD0C0", "FFFFFF")):
    i = Icon()
    i.poly([(7, 18), (25, 18), (22, 29), (10, 29)], "E7969C" if frost != "F2A8BE" else "8FC0B0", smooth=.3)
    for x in (10.5, 14, 18, 21.5):
        i.line([(x, 19.5), (x + (16 - x) * .18, 27.8)], "FFF2E8", .8)
    i.oval(5, 12, 27, 21, "C98A4C")
    for x0, y0, x1, y1 in ((6, 11.5, 26, 19), (8.5, 7.5, 23.5, 14.5), (11.5, 5, 20.5, 10.5)):
        i.oval(x0, y0, x1, y1, frost)
    i.gloss(11, 10.5, 2.6, 1.3)
    i.sprinkle(8, 16, 13, 8, 4, list(spr), 10)
    if topping == "cherry":
        i.oval(13.6, 2.4, 19, 7.4, "D2303A")
        i.gloss(15.3, 3.8, .9, .7, 220)
        i.line([(16.6, 3), (19.6, 1.2)], "5E8A3A", .8)
    else:
        i.rect(13.2, 2.8, 19.4, 7.4, "6E3E2C", r=.8)
    return i


def muffin():
    i = Icon()
    i.poly([(7, 17), (25, 17), (22.4, 29), (9.6, 29)], "C9894A", smooth=.3)
    for x in (10.5, 14, 18, 21.5):
        i.line([(x, 18.5), (x + (16 - x) * .15, 28)], "A86A34", .7)
    for b in ((4, 10, 28, 21), (7, 6, 25, 17)):
        i.oval(*b, "E4AC62")
    for x, y, r in ((10, 13, 2), (18, 9.5, 2.2), (22.5, 15, 1.8), (14.5, 17, 1.7), (15, 12, 1.4)):
        i.oval(x - r, y - r, x + r, y + r, "4E5AA8")
        i.gloss(x - r * .35, y - r * .4, .6, .5, 200)
    return i


def croissant():
    i = Icon()
    parts = [((5.4, 23), (3.2, 5), .55), ((26.6, 23), (3.2, 5), -.55), ((9, 17), (4.6, 7), .8), ((23, 17), (4.6, 7), -.8),
             ((16, 15), (6.4, 8.2), 0)]
    for (cx, cy), (rx, ry), a in parts:
        pts = []
        for k in range(40):
            t = k / 40 * math.tau
            x, y = math.cos(t) * rx, math.sin(t) * ry
            pts.append((cx + x * math.cos(a) - y * math.sin(a), cy + x * math.sin(a) + y * math.cos(a)))
        i.poly(pts, "DC9840")
        c, n = math.cos(a), math.sin(a)
        i.line([(cx + dx * c - dy * n, cy + dx * n + dy * c) for dx, dy in ((-rx * .45, -ry * .35), (0, -ry * .55), (rx * .45, -ry * .35))],
               "F8D084", 1.4)
    return i


def puff():
    i = Icon()
    i.oval(5, 17, 27, 28, "D99C50")
    i.oval(6, 13.5, 26, 22, "FFF4DE", dark=.2)
    for x in (9, 13.5, 18, 22.5):
        i.oval(x - 3, 15.4, x + 3, 21, "FFF4DE", dark=.2, edge=False)
    i.oval(6, 5, 26, 18, "E8B062")
    i.sprinkle(2, 16, 9, 7, 3, ["FFFFFF"], 22, long=False)
    return i


def eclair():
    i = Icon()
    i.rect(2.5, 15, 29.5, 25, "DCA058", r=5)
    i.line([(5, 21), (27, 21)], "FFF0D2", 1.6)
    i.rect(3.5, 11.5, 28.5, 19, "6E3E2A", r=4)
    i.line([(7, 15.5), (11, 13.5), (15, 16), (19, 13.5), (23, 16), (26, 14)], "F6D9A8", .8)
    i.gloss(9, 13.4, 3.4, .9)
    return i


def roll():
    i = Icon()
    i.oval(3, 11, 29, 28, "C8843E")
    i.oval(4, 7, 28, 23, "E9B468")
    pts = [(16 + math.cos(t) * t * .88, 15 + math.sin(t) * t * .57) for t in np.arange(.6, 12.6, .25)]
    i.line(pts, "9A5428", 1.5)
    for p in (((7, 9), (12, 13), (15, 9), (21, 14), (25, 10)), ((8, 20), (14, 17), (19, 21), (25, 18))):
        i.line(list(p), "FFF8EA", 1.4)
    return i


def cookie(base, chips, heart=False):
    i = Icon()
    if heart:
        pts = [(16 + 13 * (math.sin(t) ** 3), 15 - (13 * math.cos(t) - 5 * math.cos(2 * t) - 2 * math.cos(3 * t) - math.cos(4 * t)) * .86)
               for t in np.linspace(0, math.tau, 60)]
        i.poly(pts, base)
        inner = [(16 + (x - 16) * .66, 15.2 + (y - 15.2) * .66) for x, y in pts]
        i.poly(inner, "E8647E", edge=False)
        i.sprinkle(4, 16, 14, 6, 5, ["FFFFFF", "FFD8E0"], 9, long=False)
        i.gloss(11.5, 10.5, 2.4, 1.4)
        return i
    i.oval(3, 7, 29, 29, mix(rgb(base), SHADE, .25))
    i.oval(3, 4.5, 29, 26.5, base)
    for x, y, r in chips:
        i.oval(x - r, y - r * .85, x + r, y + r * .85, "5A3022")
        i.gloss(x - r * .3, y - r * .35, .7, .4, 120)
    i.sprinkle(11, 16, 15, 10, 8, [mix(rgb(base), SHADE, .3)], 12, long=False)
    return i


def gingerbread():
    i = Icon()
    c = "C27C3C"
    i.line([(9, 15.5), (23, 15.5)], c, 5.4, edge=True, light=.3, dark=.3)
    i.line([(16, 19), (10.6, 27)], c, 5.6, edge=True, light=.3, dark=.3)
    i.line([(16, 19), (21.4, 27)], c, 5.6, edge=True, light=.3, dark=.3)
    i.rect(11.6, 11.5, 20.4, 22, c, r=3)
    i.oval(9.5, 2, 22.5, 14, c)
    for x in (13.2, 18.8):
        i.dot(x, 7.4, 1.05, "3E241C")
    i.line([(13, 10.2), (16, 11.6), (19, 10.2)], "FFF6E6", .9)
    for y, col in ((15.5, "E0505A"), (19, "6EA86A")):
        i.dot(16, y, 1.25, col)
    for a, b in (((8.2, 14.2), (8.8, 17)), ((23.8, 14.2), (23.2, 17)), ((8.8, 24.6), (12.4, 26.8)), ((23.2, 24.6), (19.6, 26.8))):
        i.line([a, b], "FFF6E6", .8)
    return i


def macaron(c):
    i = Icon()
    i.oval(4, 17.5, 28, 28, c)
    i.rect(4.5, 14.5, 27.5, 21, "FFF1DA", r=3)
    for x in np.arange(6, 27, 2.6):
        i.dot(x, 20.4, 1.1, mix(rgb(c), SHADE, .08))
    i.oval(4, 6, 28, 18, c)
    for x in np.arange(6.4, 27, 2.6):
        i.dot(x, 15.6 - abs(x - 16) * .05, 1.15, c)
    i.gloss(11, 9, 3.6, 1.6)
    return i


def cake_pop():
    i = Icon()
    i.line([(16, 17), (16, 30)], "F6EEE0", 2, edge=True)
    i.oval(6, 3, 26, 22, "F29AB6")
    i.poly([(6.5, 11), (9, 14), (12, 12), (15, 15.5), (19, 12.5), (22, 15), (25.5, 11), (24, 6.5), (16, 3.4), (8.5, 6.5)], "7A4430", smooth=.7, edge=False)
    i.sprinkle(9, 16, 8, 7, 4, ["FFF0A0", "FFFFFF", "8FD0C0", "FF9CB0"], 14)
    i.gloss(11, 7, 2.8, 1.6)
    return i


def slice_cake(layers, top, topping=None, drip=None):
    """A wedge: the cut face in front and the top running back to the right."""
    i = Icon()
    x0, x1, y0, y1 = 3.5, 21.5, 14.0, 28.0
    h = (y1 - y0) / len(layers)
    i.poly([(x1, y0), (29, 8.5), (29, 22), (x1, y1)], mix(rgb(top), SHADE, .18))
    for k, c in enumerate(layers):
        i.rect(x0, y0 + k * h, x1, y0 + (k + 1) * h + .1, c, r=.2, light=.2, dark=.16, edge=False)
    i.poly([(x0, y0), (18.5, 6), (29, 8.5), (x1, y0)], top, smooth=.2)
    i.line([(x0, y0), (x1, y0)], top, 1.5)
    if drip:
        for x, ln in ((5, 3.4), (9.4, 2), (13.5, 4.2), (18, 2.4)):
            i.line([(x, y0), (x, y0 + ln)], drip, 1.7)
    if topping == "strawberry":
        i.poly([(12.6, 6), (19.4, 6.4), (18, 10.4), (15.6, 12), (13.4, 10)], "DC3C46", smooth=.7)
        i.sprinkle(1, 16, 8.4, 2.4, 2, ["FFE08A"], 5, long=False)
        i.poly([(13, 6.4), (16, 3.4), (19, 6.4), (16, 6)], "62A04A")
    elif topping == "berry":
        for x, y, c in ((13, 9.6, "B02A50"), (17.4, 8, "4E5AA8"), (20.6, 10, "B02A50")):
            i.oval(x - 2.2, y - 2.2, x + 2.2, y + 2.2, c)
            i.gloss(x - .7, y - .8, .6, .5, 210)
    elif topping == "cocoa":
        i.sprinkle(6, 17, 10, 8, 2.4, ["4A2A1E"], 26, long=False)
        i.poly([(15, 9.4), (18.6, 6.6), (21, 9.6), (18, 10.4)], "7ABA6A", smooth=.3)
    elif topping == "cherry":
        i.oval(14, 4, 19.6, 9.6, "D2303A")
        i.gloss(15.8, 5.4, .9, .7, 220)
    return i


def pie(filling, lattice=True, fruits=None):
    i = Icon()
    i.poly([(3, 15), (29, 15), (25.5, 27.5), (6.5, 27.5)], "C9863C", smooth=.5)
    for x in np.arange(7, 27, 3.4):
        i.line([(x, 20), (x + (16 - x) * .1, 26)], "E8AE5C", 1)
    i.oval(2.5, 7, 29.5, 22.5, "EBB462")
    i.oval(5.5, 9, 26.5, 20, filling, edge=True)
    if lattice:
        for a in (-1, 1):
            for off in (-6, 0, 6):
                i.line([(16 + off - 5, 14.5 - a * 4.4), (16 + off + 5, 14.5 + a * 4.4)], "F2C474", 1.7)
    for x, y, r, c in fruits or []:
        i.oval(x - r, y - r * .8, x + r, y + r * .8, c)
        i.gloss(x - r * .3, y - r * .3, .6, .4, 190)
    for k in range(18):
        a = k / 18 * math.tau
        i.dot(16 + math.cos(a) * 12.3, 14.6 + math.sin(a) * 6.8, 1.25, "EFBE6C")
    return i


def brownie():
    i = Icon()
    i.poly([(4, 15), (19, 18.5), (19, 28), (4, 24)], "5A2E20")
    i.poly([(19, 18.5), (28.5, 12.5), (28.5, 21.5), (19, 28)], "44201A")
    i.poly([(4, 15), (13.5, 8.5), (28.5, 12.5), (19, 18.5)], "7C442C")
    i.line([(8, 14.2), (14, 12), (13, 15.6), (20, 12.6), (21, 15.4), (25, 13)], "A8683E", .8)
    for x, y in ((12, 11.6), (22, 12.6), (17, 15.4)):
        i.oval(x - 1.9, y - 1.4, x + 1.9, y + 1.4, "C98E50")
    return i


def waffle():
    i = Icon()
    i.poly([(2.5, 17), (16, 7), (29.5, 17), (29.5, 20.5), (16, 30), (2.5, 20.5)], "C98434", smooth=.8)
    i.poly([(2.5, 16.5), (16, 6.5), (29.5, 16.5), (16, 26.5)], "EDB45A", smooth=.8)
    for k in (-1, 0, 1):
        for j in (-1, 0, 1):
            cx, cy = 16 + (k - j) * 4.1, 16.5 + (k + j) * 3.05
            i.poly([(cx - 2.6, cy), (cx, cy - 1.9), (cx + 2.6, cy), (cx, cy + 1.9)], "C8862F", edge=False)
    i.oval(11.5, 10.5, 20.5, 17, "FFF2D8")
    i.line([(13, 12.5), (18, 14.5), (21, 19), (20.6, 23)], "B4601C", 1.5)
    i.oval(18, 7.5, 23.4, 12.6, "D2303A")
    i.gloss(19.8, 8.9, .9, .7, 220)
    return i


def pancakes():
    i = Icon()
    i.oval(2, 21, 30, 30, "F4EAD8")
    for y in (19, 15, 11):
        i.oval(4.5, y, 27.5, y + 8.5, "B8722C")
        i.oval(4.5, y - 1.4, 27.5, y + 6, "EDB25C")
    i.poly([(7, 11.5), (12, 8.8), (20, 8.8), (25, 11.5), (23, 13.6), (22, 19), (20.4, 14.2), (14, 15), (12, 21), (10.4, 14), (8, 13)], "B8641A", smooth=.5)
    i.poly([(13, 8), (19.4, 8.4), (18.8, 12.2), (12.8, 11.8)], "FFE27A", smooth=.3)
    i.gloss(10, 11, 2.2, .9)
    return i


def cone():
    i = Icon()
    i.poly([(9, 16), (23, 16), (16, 31)], "D9983E", smooth=.3)
    for k in range(4):
        i.line([(10 + k * 2.4, 17), (16 + k * 1.1, 28 - k * 3.2)], "F0C070", .7)
        i.line([(22 - k * 2.4, 17), (16 - k * 1.1, 28 - k * 3.2)], "F0C070", .7)
    i.oval(6.5, 9.5, 18.5, 19, "FFE9B8")
    i.oval(13.5, 9.5, 25.5, 19, "A8DCC6")
    i.oval(9, 1.5, 23, 13.5, "F6A0B8")
    i.sprinkle(13, 16, 6, 5, 3.4, ["FFFFFF", "7A4430", "FFE08A"], 12)
    i.gloss(12.4, 4.6, 2.2, 1.4)
    return i


def sundae():
    i = Icon()
    i.oval(9, 26, 23, 30.5, "CFEAF0")
    i.line([(16, 22), (16, 28)], "CFEAF0", 2.4, edge=True)
    i.poly([(5, 13), (27, 13), (22, 22), (10, 22)], "D4EEF4", smooth=.8)
    i.poly([(8, 16), (24, 16), (21.4, 20.6), (10.6, 20.6)], "E8808E", smooth=.5, edge=False)
    i.oval(5.5, 8, 17, 17, "FFEAC0")
    i.oval(15, 8, 26.5, 17, "F6A0B8")
    i.oval(10, 3.5, 22, 13, "FFF2D6")
    i.poly([(10.5, 7), (16, 3.6), (21.5, 7), (20, 10.4), (18, 8.4), (16, 11.6), (14, 8.6), (12, 9.6)], "6E3A26", smooth=.5, edge=False)
    i.oval(13.6, 1, 18.8, 6, "D2303A")
    i.gloss(15.2, 2.3, .9, .7, 220)
    i.line([(23, 3), (20, 10)], "E8B45A", 1.8, edge=True)
    return i


def ramekin(cream, top, deco):
    i = Icon()
    i.poly([(4, 14), (28, 14), (25, 27), (7, 27)], "E98E86" if deco == "brulee" else "8FC4D8", smooth=.8)
    for x in np.arange(7.5, 26, 3.7):
        i.line([(x, 18), (x + (16 - x) * .08, 25.5)], "FFF2E4", 1)
    i.oval(3, 8.5, 29, 20, "FBF2E4")
    i.oval(5.5, 10, 26.5, 18.4, top, edge=True)
    if deco == "brulee":
        i.sprinkle(7, 16, 14, 8, 3, ["A8561A", "7A3410"], 16, long=False)
        i.gloss(11, 12.4, 3, .9, 190)
        i.oval(18.4, 9, 23.4, 13.4, "D2303A")
    else:
        for x, y, c in ((12.4, 13, "D2303A"), (18, 12, "B02A50"), (17, 15.6, "4E5AA8")):
            i.oval(x - 2.3, y - 2.1, x + 2.3, y + 2.1, c)
            i.gloss(x - .8, y - .8, .6, .5, 210)
        i.poly([(19.6, 15), (24.4, 12.4), (23.4, 16)], "62A04A", smooth=.3)
    return i


def flan():
    i = Icon()
    i.oval(2, 20, 30, 29.5, "F4EAD8")
    i.poly([(9, 9), (23, 9), (27, 23.5), (23, 26), (9, 26), (5, 23.5)], "F6CE62", smooth=1.1)
    i.oval(8.6, 6, 23.4, 13, "8A3E12")
    for x, ln in ((10.5, 7), (14.5, 4), (18.5, 8), (21.8, 4.6)):
        i.line([(x, 10.4), (x - (16 - x) * .1, 10.4 + ln)], "A8521A", 1.8)
    i.gloss(12.4, 8.2, 2.8, 1, 190)
    return i


def baklava():
    i = Icon()
    i.poly([(3, 14), (16, 19), (16, 29), (3, 23.5)], "C8842E")
    i.poly([(16, 19), (29, 14), (29, 23.5), (16, 29)], "A86422")
    for y in (3, 6):
        i.line([(3.6, 14.6 + y), (16, 19.4 + y), (28.4, 14.6 + y)], "F6CA6E", 1.1)
    i.poly([(3, 14), (16, 8), (29, 14), (16, 19)], "EDB652")
    i.sprinkle(15, 16, 13.6, 7, 3, ["86B24A", "5E8A30"], 24, long=False)
    i.gloss(11, 12.4, 3, 1, 150)
    return i


def tart():
    return pie("FFE9A6", False, [(11, 12.5, 3, "D2303A"), (18, 11.4, 2.8, "7ABA4A"), (22.6, 15, 2.6, "F2A030"),
                                 (15, 16.4, 2.8, "4E5AA8"), (9.4, 16, 2.1, "F2A030"), (18.6, 16.6, 2.4, "D2303A"), (16, 13.6, 2, "FFD24A")])


DRINKS = {
    "espresso": lambda: cup("6A361C", "C8823E", small=True),
    "americano": lambda: cup("5A2C18", "8A5030"),
    "latte": lambda: cup("D9A66C", "F2D4A6", "heart"),
    "cappuccino": lambda: cup("C98E58", "FFF2DA", extra="cocoa"),
    "flat_white": lambda: cup("A8683E", "EAC494", "leaf"),
    "raf": lambda: cup("E8C07C", "FFEBC0", "heart"),
    "mocha": lambda: cup("6E3826", "9A5C3E", extra="whip"),
    "macchiato": lambda: cup("8A4A24", "FFF0D4", extra="caramel", glass=True),
}
DESSERTS = {
    "croissant": croissant, "donut_pink": lambda: donut("F28CAE", ["FFF0A0", "FFFFFF", "8FD8E0"]),
    "donut_choc": lambda: donut("74402A", ["FF9CB0", "FFF0A0", "A8E0C8"]),
    "cupcake_pink": lambda: cupcake("F2A8BE", "cherry"), "cupcake_choc": lambda: cupcake("8A5036", "choc"),
    "muffin_blueberry": muffin, "cream_puff": puff, "eclair": eclair, "cinnamon_roll": roll,
    "cookie_choc": lambda: cookie("E2A656", [(10, 11, 2.2), (19, 9.4, 1.9), (22, 18, 2.3), (12, 20, 2), (16.4, 15, 1.6)]),
    "cookie_heart": lambda: cookie("EEBC6C", [], heart=True), "gingerbread_man": gingerbread,
    "macaron_pink": lambda: macaron("F49AB6"), "macaron_mint": lambda: macaron("96D8BC"), "macaron_lemon": lambda: macaron("F8DA62"),
    "cake_pop": cake_pop,
    "cheesecake": lambda: slice_cake(["FFE7A8", "FFE7A8", "FFE7A8", "B8742E"], "F2B450", "berry"),
    "cake_strawberry": lambda: slice_cake(["F8D89A", "F28C9C", "F8D89A", "FFF2E0", "F8D89A"], "FFF4E6", "strawberry"),
    "cake_choc": lambda: slice_cake(["7A4028", "C89468", "7A4028", "C89468", "7A4028"], "5E2E1E", "cherry", "4A2014"),
    "tiramisu": lambda: slice_cake(["FFEBC4", "8A5434", "FFEBC4", "8A5434", "FFEBC4"], "A86A44", "cocoa"),
    "apple_pie": lambda: pie("D8842A"),
    "medovik": lambda: slice_cake(["D9943C", "FFEBC0", "D9943C", "FFEBC0", "D9943C", "FFEBC0", "D9943C"], "E8AE56", None, "D08428"),
    "brownie": brownie, "waffle": waffle, "pancakes": pancakes, "ice_cream_cone": cone, "sundae": sundae,
    "creme_brulee": lambda: ramekin("FFE9A6", "E8A236", "brulee"), "panna_cotta": lambda: ramekin("FFF4E0", "FFF4E0", "panna"),
    "flan": flan, "fruit_tart": tart, "baklava": baklava,
}


# ------------------------------------------------------------------------------------------ additions
# ------------------------------------------------------------------------------------------ tools of the stations
def portafilter(full):
    i = Icon()
    i.line([(17, 17), (27.5, 27)], "8A5A3A", 4.6)
    i.line([(25.6, 25.2), (27.6, 27.1)], "5E3A26", 5.2)
    i.dot(18.2, 18.2, 2.4, "E8C070")
    i.oval(3, 7, 21, 21, "98A4AE")
    i.oval(3, 5, 21, 17.5, "DDE4EA")
    i.oval(5.4, 6.8, 18.6, 15.6, "5A3420" if full else "7C8892")
    if full:
        i.oval(7.5, 7.0, 16.5, 12.8, "7A4A2C", edge=False)
        i.sprinkle(5, 12, 10, 4.6, 2.6, ["4A2A18", "9A6640", "6A4026"], n=22, long=False)
    else:
        i.gloss(9.5, 10.0, 2.6, 1.2)
    return i


def whisk():
    i = Icon()
    for bend in (-5.2, -1.8, 1.8, 5.2):
        pts = [(13.5, 18.5), (10 + bend * 0.7, 14 - bend * 0.35), (5.5 + bend * 0.5, 6.5 - bend * 0.5), (4.5, 4.5)]
        i.line(pts, "C9D3DA", 1.15)
    i.line([(13, 19), (16, 22)], "98A4AE", 3.4)
    i.line([(16.5, 22.5), (27, 28)], "D89A62", 4.4)
    i.line([(24.8, 26.8), (27.4, 28.2)], "A86C42", 4.8)
    return i


def dough():
    i = Icon()
    i.oval(2.5, 21, 29.5, 29, "C99466")
    i.oval(2.5, 19.5, 29.5, 27, "E6B988")
    i.oval(5, 9, 27, 25.5, "F3D592")
    i.oval(8, 7, 22, 18, "F8E3AC", edge=False)
    i.line([(10, 18), (15, 20.5), (21, 18.5)], "E2BC74", 1.2)
    i.gloss(12.5, 11.5, 3.6, 1.8)
    return i


def recipe_book():
    i = Icon()
    i.rect(5, 5, 28, 29, "8A4A5C", r=2.5)
    i.rect(6, 6, 27, 27, "FFF4DC", r=1.5)
    i.rect(4, 3, 25, 26, "D8728A", r=2.5)
    i.rect(4, 3, 8, 26, "B2546C", r=1.5, edge=False)
    i.rect(10.5, 8, 21.5, 18.5, "FFF0D0", r=2)
    i.oval(12.5, 12.5, 19.5, 17, "FFFFFF")
    i.oval(13.6, 13.0, 18.4, 15.2, "9A6240", edge=False)
    i.line([(15, 11), (16, 9.8), (15.2, 8.8)], "C9A090", 0.8)
    i.rect(19, 25, 21.5, 30.5, "F0C860", r=0.6)
    return i


TOOLS = {"portafilter": lambda: portafilter(False), "portafilter_full": lambda: portafilter(True),
         "whisk": whisk, "dough": dough, "recipe_book": recipe_book}


def write_item_model(name, extra=None):
    model = {"parent": "minecraft:item/%s" % ("handheld" if name in ("whisk", "portafilter", "portafilter_full") else "generated"),
             "textures": {"layer0": "aestheticjobs:item/" + name}}
    if extra:
        model.update(extra)
    with open(os.path.join(TEX, "..", "models", "item", name + ".json"), "w") as f:
        json.dump(model, f, indent=2)
        f.write("\n")


def main():
    for name, f in DRINKS.items():
        f().done().save(os.path.join(TEX, "item", f"cup_{name}.png"), optimize=True)
    for name, f in DESSERTS.items():
        f().done().save(os.path.join(TEX, "item", f"{name}.png"), optimize=True)
    for name, f in TOOLS.items():
        im = f().done()
        if name.startswith(("portafilter", "whisk")):          # a held tool has its handle at the lower left
            im = im.transpose(Image.FLIP_LEFT_RIGHT)
        im.save(os.path.join(TEX, "item", name + ".png"), optimize=True)
        write_item_model(name)
    write_item_model("portafilter", {"overrides": [{"predicate": {"custom_model_data": 1},
                                                    "model": "aestheticjobs:item/portafilter_full"}]})
    print("drawn:", len(DRINKS), "drinks,", len(DESSERTS), "desserts,", len(TOOLS), "tools")


def sheet(out):
    paths = ["cup_" + n for n in DRINKS] + list(DESSERTS) + list(TOOLS)
    img = Image.new("RGBA", (9 * 136, 5 * 136), (250, 240, 218, 255))
    for k, n in enumerate(paths):
        im = Image.open(os.path.join(TEX, "item", n + ".png")).resize((128, 128), Image.NEAREST)
        img.alpha_composite(im, (k % 9 * 136 + 4, k // 9 * 136 + 4))
    img.save(out)


if __name__ == "__main__":
    if "--sheet" in sys.argv:
        sheet(sys.argv[sys.argv.index("--sheet") + 1])
    else:
        main()
