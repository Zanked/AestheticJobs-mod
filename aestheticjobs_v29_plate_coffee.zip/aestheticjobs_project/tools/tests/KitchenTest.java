import dev.aestheticjobs.cafe.career.Wish;
import dev.aestheticjobs.cafe.kitchen.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Pattern;

/**
 * javac -d /tmp/t src/main/java/dev/aestheticjobs/cafe/kitchen/*.java src/main/java/dev/aestheticjobs/cafe/career/Wish.java \
 *   tools/tests/KitchenTest.java && java -cp /tmp/t KitchenTest     (from the project folder)
 */
public class KitchenTest {
    static void check(boolean ok, String what) {
        if (!ok) throw new AssertionError(what);
    }

    static List<String> ids(String file, String regex) throws Exception {
        var m = Pattern.compile(regex, Pattern.MULTILINE).matcher(Files.readString(Path.of(file)));
        List<String> out = new ArrayList<>();
        while (m.find()) out.add(m.group(1));
        return out;
    }

    /** Pours the drink the way a player does: shots first, then its parts, then the additions. */
    static BrewState brew(int drink, int mask) {
        BrewState m = new BrewState();
        check(!m.pull(0) && m.putCup() && !m.putCup(), "cup");
        check(!m.canPour(Pantry.SUGAR, 0), "no coffee yet");
        long now = 0;
        for (int i = 0; i < CupRecipe.shots(drink); i++) {
            check(m.putGrounds(now) && !m.putGrounds(now) && m.pull(now) && !m.pull(now), "shot");
            check(m.pulling(now + BrewState.SHOT_TICKS - 1) && !m.canPour(Pantry.SUGAR, now + 1), "running");
            now += BrewState.SHOT_TICKS;
        }
        for (Pantry p : CupRecipe.contents(drink, mask)) check(m.pour(p, now), "pour " + p + " " + drink + " " + mask);
        return m;
    }

    /** Whether pouring the parts first and then the additions really ends in this drink. */
    static boolean pourable(int drink, int mask) {
        BrewState m = new BrewState();
        m.putCup();
        for (int i = 0; i < CupRecipe.shots(drink); i++) {
            m.putGrounds(i * 100L);
            m.pull(i * 100L);
        }
        for (Pantry p : CupRecipe.contents(drink, mask)) if (!m.pour(p, 1000)) return false;
        CupRecipe.Result r = m.drink();
        return r != null && r.drink() == drink && r.mask() == mask;
    }

    static void stations() {
        for (int d = 0; d < Menu.DRINKS; d++) {
            CupRecipe.Result r = brew(d, 0).drink();
            check(r != null && r.drink() == d && r.mask() == 0, "plain drink " + d + " " + r);
        }
        for (Signature s : Signature.values()) {
            if (!s.isDrink()) continue;
            CupRecipe.Result r = brew(s.base(), s.mask()).drink();
            check(r != null && r.drink() == s.base() && r.mask() == s.mask(), "signature reachable " + s + " " + r);
        }
        BrewState m = brew(0, 0);
        check(m.pour(Pantry.WATER, 99) && m.drink().drink() == 1 && !m.canPour(Pantry.MILK, 99) && !m.canPour(Pantry.WATER, 99), "americano closed");
        m = brew(2, 0);                                                        // latte, then a second shot: flat white
        check(m.putGrounds(99) && m.pull(99) && m.drink().drink() == 4 && !m.putGrounds(999), "flat white after the milk");
        long[] saved = m.save();
        BrewState copy = new BrewState();
        copy.load(saved);
        check(copy.drink().equals(m.drink()) && copy.cup(), "brew reload");
        copy.load(new long[]{1, 1, 99, -3, 0, -5, 77});
        check(copy.shots() == 2 && copy.art() >= 0 && copy.count(Pantry.WATER) == 0, "brew garbage");
        copy.takeCup();
        check(copy.grounds() && !copy.cup() && copy.drink() == null, "grounds stay");
        m = brew(0, Extra.CREAM.bit() | Extra.APPLE.bit() | Extra.BERRY.bit());
        check(!m.canPour(Pantry.SUGAR, 999), "three additions");

        for (int d = 0; d < Menu.DRINKS; d++) {                                  // every wish can be poured
            for (Wish w : Wish.values()) {
                if (w == Wish.NONE) continue;
                boolean possible = false;
                for (int mask = 0; mask <= Cooking.ALL_EXTRAS && !possible; mask++) {
                    if (!Cooking.valid(d, mask) || !w.granted(d, mask)) continue;
                    possible = pourable(d, mask);
                }
                check(possible, "wish can be brewed " + w + " " + Menu.get(d).id());
            }
            List<String> need = new ArrayList<>(Menu.get(d).ingredients());
            need.removeIf(id -> id.endsWith("empty_cup") || id.endsWith("coffee_beans"));
            List<String> parts = new ArrayList<>();
            for (Pantry p : CupRecipe.parts(d)) parts.add(p.item());
            Collections.sort(need);
            Collections.sort(parts);
            check(need.equals(parts), "menu and cup agree " + Menu.get(d).id() + need + parts);
            check(Collections.frequency(Menu.get(d).ingredients(), "aestheticjobs:coffee_beans") == CupRecipe.shots(d), "beans " + d);
        }

        GrinderState g = new GrinderState();
        check(!g.turn() && !g.takeGround() && g.addBean(), "grinder");
        for (int i = 0; i < GrinderState.TURNS; i++) check(g.turn(), "turn");
        check(g.beans() == 0 && g.ground() == 1, "ground");
        for (int i = 0; i < 3; i++) check(g.addBean(), "more");
        check(!g.addBean() && g.takeGround() && !g.takeGround() && g.addBean(), "capacity");
        GrinderState g2 = new GrinderState();
        g2.load(g.save());
        check(g2.beans() == g.beans(), "grinder reload");

        for (int d = Menu.DRINKS; d < Menu.size(); d++) {
            BowlState b = new BowlState();
            check(!b.choose(0) && !b.add("minecraft:wheat") && b.choose(d), "choose");
            check(!b.whisk() && !b.add("minecraft:dirt"), "empty");
            List<String> need = new ArrayList<>(Menu.get(d).ingredients());
            Collections.reverse(need);
            for (String id : need) check(b.add(id), "add " + id);
            check(b.full() && !b.add(need.get(0)) && !b.choose(d) && !b.mixed(), "full");
            for (int i = 0; i < BowlState.WHISKS; i++) check(b.whisk(), "whisk");
            check(b.mixed() && !b.whisk(), "mixed");
            BowlState c = new BowlState();
            c.load(b.save());
            check(c.mixed() && c.recipe() == d, "bowl reload");
            b.pourOut();
            check(b.empty() && b.recipe() == d, "keeps the recipe");

            OvenState o = new OvenState();
            check(!o.put(0, 0) && o.put(d, 10) && !o.put(d, 11), "oven");
            long t = 10 + Menu.get(d).ticks();
            check(o.stage(t - 1) == OvenState.Stage.BAKING && !o.takeOut(t - 1) && !o.decorate(Extra.SUGAR, t), "baking");
            check(o.stage(t) == OvenState.Stage.GOLDEN && o.stage(t + 600) == OvenState.Stage.DARK
                    && o.stage(t + 1200) == OvenState.Stage.BURNT && !o.takeOut(t + 1200), "window");
            check(o.takeOut(t + 5) && o.stage(t + 99999) == OvenState.Stage.PLATE && o.quality() == 65, "plate");
            check(o.decorate(Extra.CREAM, t) && !o.decorate(Extra.CREAM, t), "once");
            OvenState p = new OvenState();
            p.load(o.save());
            check(p.mask() == o.mask() && p.stage(t) == OvenState.Stage.PLATE, "oven reload");
            o.clear();
            o.put(d, 0);
            check(o.takeOut(Menu.get(d).ticks() + 700) && o.quality() == 45, "too dark costs");
        }
    }

    public static void main(String[] args) throws Exception {
        List<String> drinks = ids("src/main/java/dev/aestheticjobs/cafe/Drink.java", "^    [A-Z_]+\\(\"([a-z_]+)\",");
        List<String> desserts = ids("src/main/java/dev/aestheticjobs/item/Dessert.java", "^    [A-Z_]+\\(\"([a-z_]+)\",");
        check(drinks.size() == Menu.DRINKS && desserts.size() == Menu.DESSERTS && Menu.size() == 40, "sizes " + drinks + desserts);
        for (int i = 0; i < 8; i++) check(Menu.get(i).id().equals(drinks.get(i)) && Menu.get(i).isDrink(), "drink order " + i);
        for (int i = 0; i < 32; i++) check(Menu.get(8 + i).id().equals(desserts.get(i)) && !Menu.get(8 + i).isDrink(), "dessert order " + i);

        Set<String> sig = new HashSet<>();
        check(Signature.values().length <= 64, "bits");
        for (Signature s : Signature.values()) {
            check(s.base() >= 0 && Integer.bitCount(s.mask()) == 2 && sig.add(s.base() + ":" + s.mask()), "signature " + s);
            check(Cooking.quality(s.base(), s.mask()) == 100, "signature quality " + s);
        }
        for (int b = 0; b < Menu.size(); b++) {
            Menu.Base base = Menu.get(b);
            check((base.likes() & base.dislikes()) == 0, "both " + base.id());
            check(Integer.bitCount(base.likes()) >= 3 && base.dislikes() != 0, "choice " + base.id());
            check(Cooking.stars(Cooking.quality(b, 0)) == 3, "plain is three stars " + base.id());
            int best = 0, fiveStar = 0, combos = 0;
            for (int m = 0; m <= Cooking.ALL_EXTRAS; m++) {
                if (!Cooking.valid(b, m)) {
                    check(Cooking.quality(b, m) == 0, "invalid");
                    continue;
                }
                int q = Cooking.quality(b, m);
                check(q >= 0 && q <= 100, "range");
                if (q > best) best = q;
                if (Cooking.stars(q) == 5) fiveStar++;
                combos++;
            }
            check(combos == 130 && best >= 90 && fiveStar >= 3 && fiveStar < combos / 3, base.id() + " 5*: " + fiveStar + "/" + combos);
            for (Wish w : Wish.values()) {                                      // every wish can be granted on every base
                if (w == Wish.NONE) continue;
                boolean possible = false;
                for (int m = 0; m <= Cooking.ALL_EXTRAS && !possible; m++) possible = Cooking.valid(b, m) && w.granted(b, m);
                check(possible, "wish " + w + " " + base.id());
            }
            Random r = new Random(b);
            for (int i = 0; i < 200; i++) {
                Wish w = Wish.pick(r, b);
                check(w != Wish.NONE && (w == Wish.PLAIN || !w.granted(b, 0)), "pick");
            }
        }

        Knowledge k = new Knowledge();
        Signature s = Signature.HONEY_LATTE;
        check(!k.knows(s.base(), s.mask()) && k.knows(s.base(), 0), "unknown");
        check(k.learn(s.base(), Extra.HONEY.bit()) == null && k.tried(s.base(), Extra.HONEY), "tried");
        k.learn(s.base(), Extra.VANILLA.bit());
        check(!k.knows(s.base(), s.mask()), "a signature stays secret until cooked");
        check(k.learn(s.base(), s.mask()) == s && k.learn(s.base(), s.mask()) == null && k.foundCount() == 1, "found once");
        Knowledge copy = new Knowledge();
        copy.load(k.triedCopy(), k.foundBits());
        check(copy.knows(s) && copy.tried(s.base(), Extra.VANILLA), "reload");
        copy.load(new int[]{-1}, -1L);
        check(copy.foundCount() == Signature.values().length, "garbage is masked");

        stations();

        for (int b = 0; b < 8; b++) {
            for (int style = 0; style < LatteArt.STYLES.length; style++) {
                for (int m : new int[]{0, Extra.CREAM.bit() | Extra.CARAMEL.bit() | Extra.COCOA.bit()}) {
                    String p = LatteArt.picture(b, m, style);
                    check(p.length() == 256 && p.matches("[0-6]+"), "art");
                }
            }
        }
        for (int a = 0; a < 6; a++) {
            for (int c = a + 1; c < 6; c++) check(!LatteArt.picture(2, 0, a).equals(LatteArt.picture(2, 0, c)), "styles differ " + a + c);
        }
        if (args.length > 0) {
            for (int style = 0; style < 6; style++) System.out.println(LatteArt.picture(2, 0, style).replaceAll("(.{16})", "$1\n").replace('0', ' ').replace('5', '.').replace('1', '#'));
        }
        System.out.println("Kitchen ok");
    }
}
