import dev.aestheticjobs.cafe.anim.FoodMotion;

/** javac -d /tmp/t src/main/java/dev/aestheticjobs/cafe/anim/FoodMotion.java tools/tests/FoodMotionTest.java && java -cp /tmp/t FoodMotionTest */
public class FoodMotionTest {
    static void check(boolean ok, String what) {
        if (!ok) throw new AssertionError(what);
    }

    public static void main(String[] args) {
        int d = 32;
        check(FoodMotion.raise(0) == 0 && FoodMotion.raise(7) == 1 && FoodMotion.raise(40) == 1, "raise");
        check(FoodMotion.progress(0, d) == 0 && FoodMotion.progress(32, d) == 1, "progress");
        int gulps = 0, bites = 0, taken = 0;
        float lastRaise = 0, lastGulp = 0, lastBite = 0;
        for (float t = 0; t <= 33; t += 0.05F) {
            float r = FoodMotion.raise(t), g = FoodMotion.gulp(t, d), b = FoodMotion.bite(t, d);
            check(r >= lastRaise - 1e-5 && r - lastRaise < 0.05F, "raise is smooth");
            check(g >= 0 && g <= 1 && Math.abs(g - lastGulp) < 0.1F, "gulp is smooth " + t);
            check(b >= 0 && b <= 1 && Math.abs(b - lastBite) < 0.15F, "bite is smooth " + t);
            if (lastGulp < 0.5F && g >= 0.5F) gulps++;
            if (lastBite < 0.5F && b >= 0.5F) bites++;
            int n = FoodMotion.bitesTaken(t, d);
            check(n >= taken && n - taken <= 1, "bites disappear one by one");
            taken = n;
            check(Math.abs(FoodMotion.chew(t, d)) <= 1, "chew");
            check(FoodMotion.foodScale(t, d) > 0.5F && FoodMotion.foodScale(t, d) <= 1, "scale");
            lastRaise = r;
            lastGulp = g;
            lastBite = b;
        }
        check(gulps == FoodMotion.GULPS, "gulps " + gulps);
        check(bites == FoodMotion.BITES && taken == FoodMotion.BITES, "bites " + bites + " " + taken);
        check(FoodMotion.progress(1, 1) >= 0, "very short use does not divide by zero");
        System.out.println("FoodMotion ok");
    }
}
