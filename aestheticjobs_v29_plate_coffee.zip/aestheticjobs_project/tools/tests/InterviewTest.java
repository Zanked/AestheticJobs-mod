import dev.aestheticjobs.job.interview.InterviewFlow;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * javac -d /tmp/t src/main/java/dev/aestheticjobs/job/interview/Interview{Flow,Script}.java tools/tests/InterviewTest.java \
 *   && java -cp /tmp/t InterviewTest     (from the project folder)
 */
public class InterviewTest {
    static final int[] THRESHOLD = {55, 65, 58};
    static final int[][] VALUED = {{7, 2, 3}, {1, 4, 3}, {2, 4, 0}};
    static final int[] TRAIT = {3, 2, 1};
    static final String[] ID = {"cafe_manager", "office_manager", "shop_manager"};
    static final Set<String> keys = new TreeSet<>();

    static void check(boolean ok, String what) {
        if (!ok) throw new AssertionError(what);
    }

    static InterviewFlow flow(int kind, int exp, int skills, int truth, long seed) {
        return new InterviewFlow(new InterviewFlow.Boss(kind, ID[kind], THRESHOLD[kind], VALUED[kind], TRAIT[kind]),
                new InterviewFlow.Claim(exp, skills, 0, 2), truth, false, 2, new Random(seed));
    }

    static void collect(InterviewFlow.View v) {
        if (!v.react().isEmpty()) keys.add(v.react());
        if (!v.line().isEmpty()) keys.add(v.line());
        for (String o : v.options()) if (!o.isEmpty()) keys.add(o);
    }

    static boolean over(InterviewFlow.Stage s) {
        return s == InterviewFlow.Stage.HIRED || s == InterviewFlow.Stage.REJECTED || s == InterviewFlow.Stage.LEFT;
    }

    /** The key the best (or the worst) player picks. */
    static int pick(InterviewFlow.View v, boolean best) {
        List<String> o = v.options();
        for (int i = 0; i < o.size(); i++) {
            String k = o.get(i);
            if (best && (k.endsWith(".0") || k.endsWith(".a0") || k.equals("interview.trial.accept") || k.equals("interview.contract.sign"))) return i;
            if (!best && (k.endsWith(".2") || k.endsWith(".a2") || k.equals("interview.trial.skip"))) return i;
        }
        return 0;
    }

    public static void main(String[] args) throws Exception {
        int hired = 0, rejected = 0, left = 0;
        for (int run = 0; run < 60000; run++) {
            Random r = new Random(run);
            int kind = run % 3, mode = run % 4;            // 0 best, 1 worst, else random
            int skills = 0;
            for (int i = 0; i < 3; i++) skills |= 1 << r.nextInt(8);
            if (run % 11 == 0) skills = 0;
            int truth = r.nextInt(4), exp = mode == 0 ? truth : r.nextInt(4);
            InterviewFlow f = flow(kind, exp, skills, truth, run);
            InterviewFlow.View v = f.start("Alex", List.of("a", "b", "c"));
            collect(v);
            int steps = 0;
            while (!over(f.stage())) {
                check(++steps < 60, "ends");
                check(!v.options().isEmpty() && f.impression() >= 0 && f.impression() <= 100, "view " + v);
                check(f.progress() >= 0 && f.progress() <= 4, "progress");
                check(f.answer(-1) == v && f.answer(9) == v, "bad index changes nothing");
                if (f.stage() == InterviewFlow.Stage.TRIAL) {
                    check(f.answer(0) == v, "alright keeps waiting");
                    if (mode == 1 || mode == 3 && r.nextBoolean()) {
                        collect(f.remind("interview.trial.wrong"));
                        collect(f.remind("interview.trial.missing"));
                        v = f.answer(1);
                    } else {
                        v = f.trialDone(mode == 0 ? 18 : r.nextInt(25) - 6);
                    }
                } else {
                    check(f.trialDone(10) == v, "no trial now");
                    int i = mode < 2 ? pick(v, mode == 0) : r.nextInt(v.options().size());
                    v = f.answer(i);
                }
                collect(v);
                check(v.stage() == f.stage(), "stage");
            }
            int sheet = f.sheet();
            check((sheet >> 14 & 255 & ~skills) == 0 && (sheet >> 22 & 255 & ~skills) == 0, "marks only on claims");
            check((sheet >> 14 & sheet >> 22 & 255) == 0, "one mark");
            if (mode == 0) check(f.stage() == InterviewFlow.Stage.HIRED, "a perfect applicant is hired " + kind + " " + f.impression() + v);
            if (mode == 1) check(f.stage() != InterviewFlow.Stage.HIRED, "a hopeless one is not " + kind);
            check(f.rankOffer() >= 0 && f.rankOffer() <= 2, "rank");
            if (f.stage() == InterviewFlow.Stage.HIRED) hired++;
            else if (f.stage() == InterviewFlow.Stage.REJECTED) rejected++;
            else left++;
        }
        for (int s = 0; s < 8; s++) for (String p : new String[]{"q", "a0", "a1", "a2"}) keys.add("interview.skill." + s + "." + p);
        for (String q : new String[]{"g1", "g2", "g3", "g4", "g5", "g6", "c1", "c2", "c3", "o1", "o2", "o3", "s1", "s2", "s3"}) {
            keys.add("interview.q." + q);
            for (int i = 0; i < 3; i++) keys.add("interview.a." + q + "." + i);
        }
        for (String lang : new String[]{"ru_ru", "en_us"}) {
            String json = Files.readString(Path.of("src/main/resources/assets/aestheticjobs/lang/" + lang + ".json"));
            for (String k : keys) check(json.contains("\"" + k + "\""), lang + " misses " + k);
        }
        System.out.println("Interview ok: hired " + hired + ", rejected " + rejected + ", left " + left + ", keys " + keys.size());
    }
}
