import dev.aestheticjobs.cafe.anim.PlateMotion;

/** javac -d /tmp/t src/main/java/dev/aestheticjobs/cafe/anim/PlateMotion.java tools/tests/PlateMotionTest.java && java -cp /tmp/t PlateMotionTest */
public class PlateMotionTest {
    static void check(boolean ok, String what) {
        if (!ok) throw new AssertionError(what);
    }

    public static void main(String[] args) {
        check(PlateMotion.size(0) == 1 && PlateMotion.size(PlateMotion.BITES) == 0 && PlateMotion.size(-3) == 1
                && PlateMotion.size(99) == 0, "size ends");
        for (int i = 1; i <= PlateMotion.BITES; i++) check(PlateMotion.size(i) < PlateMotion.size(i - 1), "every bite shrinks");
        check(PlateMotion.above(0) == 1 && PlateMotion.above(PlateMotion.DIP) == 0, "dip");
        check(PlateMotion.travel(PlateMotion.DIP) == 0 && PlateMotion.travel(PlateMotion.ARRIVE) == 1, "travel");
        check(PlateMotion.arc(PlateMotion.DIP) == 0 && PlateMotion.arc(PlateMotion.ARRIVE) == 0, "arc ends");
        check(PlateMotion.forkSize(PlateMotion.ARRIVE - 1) == 1 && PlateMotion.forkSize(PlateMotion.END) == 0, "fork size");
        check(PlateMotion.END <= PlateMotion.BITE_TICKS && PlateMotion.ARRIVE < PlateMotion.BITE_TICKS, "one bite ends before the next");
        float above = 1, travel = 0, fork = 1;
        for (float t = 0; t <= PlateMotion.BITE_TICKS; t += 0.05F) {
            float a = PlateMotion.above(t), p = PlateMotion.travel(t), f = PlateMotion.forkSize(t), arc = PlateMotion.arc(t);
            check(a <= above + 1e-5 && above - a < 0.05F, "above is smooth " + t);
            check(p >= travel - 1e-5 && p - travel < 0.05F, "travel is smooth " + t);
            check(f <= fork + 1e-5 && fork - f < 0.05F, "fork is smooth " + t);
            check(arc >= 0 && arc <= 1.0001F, "arc");
            above = a;
            travel = p;
            fork = f;
        }
        check(PlateMotion.showsFork(0) && !PlateMotion.showsFork(-100) && !PlateMotion.showsFork(PlateMotion.END), "fork shown");
        System.out.println("PlateMotion ok");
    }
}
