#!/usr/bin/env python3
"""Bakes a 32x32 texture for a 3D item model out of its 2D sprite.

How it works (all automatic, called from gen_3d_models.py for the items listed in TEXTURED there):
  1. the model's silhouette seen from the GUI camera is fitted onto the sprite's silhouette (scale + shift search);
  2. the texture is a small "triplanar" atlas: a TOP view, a FRONT view and a SIDE view of the model, each texel
     holding the colour of the surface point that is nearest to the viewer along that axis;
  3. each colour is picked from the sprite at the position where that surface point shows up in the GUI view, so
     the painted detail (glaze, layers, highlights, outline) of the sprite lands on the 3D model;
  4. every box face gets UVs into its view of the atlas. Faces the GUI camera can't see share the colours of the opposite side.

Uses the finished model json (elements with from/to/rotation) so it is independent of how the model was built.
"""
import math
import os

import numpy as np
from PIL import Image
from scipy import ndimage as ndi

TEX = 32
ANG_X, ANG_Y = 30.0, 225.0                       # the GUI rotation of every model (display.gui.rotation)

# --- face definitions: (top-left, bottom-right) corner of the face seen from outside, as (x?, y?, z?) picks of from/to
FACES = {
    "up":    (("f", "t", "f"), ("t", "t", "t")),
    "down":  (("f", "f", "t"), ("t", "f", "f")),
    "north": (("t", "t", "f"), ("f", "f", "f")),
    "south": (("f", "t", "t"), ("t", "f", "t")),
    "east":  (("t", "t", "t"), ("t", "f", "f")),
    "west":  (("f", "t", "f"), ("f", "f", "t")),
}
VIEW_OF = {"up": "top", "north": "front", "south": "front", "east": "side", "west": "side", "down": "bottom"}


# ------------------------------------------------------------------------------------------------ geometry helpers
def _rot(e):
    r = e.get("rotation")
    if not r:
        return None
    return r["angle"], r["origin"][0], r["origin"][2]


def to_world(e, p):
    """Local point of a (possibly turned) element -> model space."""
    rot = _rot(e)
    if not rot:
        return p
    a, cx, cz = rot
    c, s = math.cos(math.radians(a)), math.sin(math.radians(a))
    x, y, z = p
    return (cx + (x - cx) * c + (z - cz) * s, y, cz - (x - cx) * s + (z - cz) * c)


def to_local(e, p):
    rot = _rot(e)
    if not rot:
        return p
    a, cx, cz = rot
    c, s = math.cos(math.radians(a)), math.sin(math.radians(a))
    x, y, z = p
    dx, dz = x - cx, z - cz
    return (cx + dx * c - dz * s, y, cz + dx * s + dz * c)


def to_local_dir(e, d):
    rot = _rot(e)
    if not rot:
        return d
    a = rot[0]
    c, s = math.cos(math.radians(a)), math.sin(math.radians(a))
    return (d[0] * c - d[2] * s, d[1], d[0] * s + d[2] * c)


def corners(e):
    x0, y0, z0 = e["from"]
    x1, y1, z1 = e["to"]
    return [to_world(e, (x, y, z)) for x in (x0, x1) for y in (y0, y1) for z in (z0, z1)]


def ray_hit(elements, o, d, skip_eps=0.0):
    """Nearest hit of the ray o + t*d against all boxes -> (t, element) or (None, None). t > skip_eps."""
    best, bel = None, None
    for e in elements:
        lo, hi = e["from"], e["to"]
        ol, dl = to_local(e, o), to_local_dir(e, d)
        t0, t1 = -1e9, 1e9
        ok = True
        for i in range(3):
            if abs(dl[i]) < 1e-9:
                if ol[i] < lo[i] or ol[i] > hi[i]:
                    ok = False
                    break
            else:
                a, b = (lo[i] - ol[i]) / dl[i], (hi[i] - ol[i]) / dl[i]
                if a > b:
                    a, b = b, a
                t0, t1 = max(t0, a), min(t1, b)
                if t0 > t1:
                    ok = False
                    break
        if ok and t1 > skip_eps:
            t = t0 if t0 > skip_eps else t1
            if best is None or t < best:
                best, bel = t, e
    return best, bel


def view(p):
    """GUI view of a point relative to the model centre: x right, y up, z towards the camera (same as gen_3d_models)."""
    x, y, z = p
    a = math.radians(ANG_X)
    y, z = y * math.cos(a) + z * math.sin(a), -y * math.sin(a) + z * math.cos(a)
    b = math.radians(ANG_Y)
    x, z = x * math.cos(b) + z * math.sin(b), -x * math.sin(b) + z * math.cos(b)
    return x, y, z


def cam_dir():
    """Model-space direction pointing towards the GUI camera (the inverse of view() applied to +z)."""
    basis = [view(v) for v in ((1, 0, 0), (0, 1, 0), (0, 0, 1))]            # columns of the (orthonormal) view matrix
    return tuple(basis[i][2] for i in range(3))                              # M^T * (0,0,1)


# ------------------------------------------------------------------------------------------------ silhouette fit
def fit_to_sprite(elements, centre, alpha):
    """Find sprite = (cx + sx*vx, cy - sy*vy) so the model's GUI silhouette overlaps the sprite's best."""
    R, EXT = 8, 14.0                                                          # mask px per unit, half-size in units
    n = int(2 * EXT * R)
    from PIL import ImageDraw
    mask = Image.new("L", (n, n), 0)
    dr = ImageDraw.Draw(mask)
    for e in elements:
        x0, y0, z0 = e["from"]
        x1, y1, z1 = e["to"]
        for f in FACES:
            tl, br = FACES[f]
            pts = []
            # the 4 corners of the face: take the axis-aligned face rectangle
            ax = {"up": (1, 1), "down": (1, 1)}
            fixed = {"up": (1, "t"), "down": (1, "f"), "north": (2, "f"), "south": (2, "t"), "east": (0, "t"), "west": (0, "f")}[f]
            axis, side = fixed
            others = [i for i in range(3) if i != axis]
            ranges = [(e["from"][i], e["to"][i]) for i in others]
            for a in ranges[0]:
                for b in ranges[1]:
                    q = [0, 0, 0]
                    q[axis] = e["to"][axis] if side == "t" else e["from"][axis]
                    q[others[0]], q[others[1]] = a, b
                    pts.append(to_world(e, tuple(q)))
            pts = [pts[0], pts[1], pts[3], pts[2]]
            poly = []
            for p in pts:
                vx, vy, _ = view((p[0] - centre[0], p[1] - centre[1], p[2] - centre[2]))
                poly.append((n / 2 + vx * R, n / 2 - vy * R))
            dr.polygon(poly, fill=255)
    m = np.asarray(mask) > 127
    ys, xs = np.nonzero(m)
    mw, mh = (xs.max() - xs.min() + 1) / R, (ys.max() - ys.min() + 1) / R
    mcx, mcy = ((xs.max() + xs.min()) / 2 - n / 2) / R, ((ys.max() + ys.min()) / 2 - n / 2) / R   # model bbox centre (view units, y down)

    SS = 4                                                                    # supersampling of the sprite for the overlap test
    spr = np.kron(alpha, np.ones((SS, SS))) > 0.5
    ay, ax_ = np.nonzero(alpha > 0.5)
    sw, sh = ax_.max() - ax_.min() + 1, ay.max() - ay.min() + 1
    scx, scy = (ax_.max() + ax_.min() + 1) / 2, (ay.max() + ay.min() + 1) / 2
    gy, gx = np.mgrid[0:TEX * SS, 0:TEX * SS]
    px, py = (gx + 0.5) / SS, (gy + 0.5) / SS                                 # sprite pixel coordinates

    def score(sx, sy, tx, ty):
        # sprite px = tx + sx * (view x), ty + sy * (view y down)  ->  invert to the mask
        vx = (px - tx) / sx
        vy = (py - ty) / sy
        mx, my = n / 2 + vx * R, n / 2 + vy * R
        samp = ndi.map_coordinates(m.astype(np.float32), [my, mx], order=0, cval=0) > 0.5
        inter = np.logical_and(samp, spr).sum()
        union = np.logical_or(samp, spr).sum()
        return inter / max(1, union)

    sx0, sy0 = sw / mw, sh / mh
    best = (sx0, sy0, scx - sx0 * mcx, scy - sy0 * mcy)
    bs = score(*best)
    step = [0.06, 0.06, 0.6, 0.6]
    for _ in range(5):
        improved = True
        while improved:
            improved = False
            for i in range(4):
                for sgn in (-1, 1):
                    c = list(best)
                    c[i] += sgn * step[i] * (best[i] if i < 2 else 1)
                    if not (0.75 * sx0 <= c[0] <= 1.3 * sx0 and 0.75 * sy0 <= c[1] <= 1.3 * sy0):
                        continue
                    sc = score(*c)
                    if sc > bs + 1e-6:
                        best, bs, improved = tuple(c), sc, True
        step = [s / 2 for s in step]
    return best, bs


# ------------------------------------------------------------------------------------------------ atlas layout
def pack(sizes, gap):
    """Place rectangles into TEX x TEX. sizes: {name: (w, h)} -> {name: (x, y)} or None."""
    import itertools
    names = list(sizes)
    for order in itertools.permutations(names):
        placed = {}
        ok = True
        for nme in order:
            w, h = sizes[nme]
            spot = None
            for y in range(0, TEX - h + 1):
                for x in range(0, TEX - w + 1):
                    if all(x + w + gap <= px or px + pw + gap <= x or y + h + gap <= py or py + ph + gap <= y
                           for (px, py), (pw, ph) in ((placed[k], sizes[k]) for k in placed)):
                        spot = (x, y)
                        break
                if spot:
                    break
            if not spot:
                ok = False
                break
            placed[nme] = spot
        if ok:
            return placed
    return None


# ------------------------------------------------------------------------------------------------ the bake
def bake(name, data, sprite_path, ang=(25.0, 200.0)):
    """data: the finished model json. ang = the GUI camera (pitch, yaw) the sprite is matched from: the sprites are drawn
    from the front, a bit from above, so the GUI view of the textured models is turned to that (display.gui.rotation).
    Returns (new json, PIL image 32x32, info)."""
    global ANG_X, ANG_Y
    ANG_X, ANG_Y = ang
    els = data["elements"]
    pts = [p for e in els for p in corners(e)]
    lo = [min(p[i] for p in pts) for i in range(3)]
    hi = [max(p[i] for p in pts) for i in range(3)]
    ext = [hi[i] - lo[i] for i in range(3)]
    centre = [(lo[i] + hi[i]) / 2 for i in range(3)]

    spr = np.asarray(Image.open(sprite_path).convert("RGBA")).astype(np.float32)
    alpha = (spr[:, :, 3] > 127).astype(np.float32)
    (sx, sy, tx, ty), iou = fit_to_sprite(els, centre, alpha)

    # nearest opaque sprite pixel for every pixel (for points that fall outside the sprite)
    _, (iy, ix) = ndi.distance_transform_edt(alpha == 0, return_indices=True)

    def sprite_colour(p):
        vx, vy, _ = view((p[0] - centre[0], p[1] - centre[1], p[2] - centre[2]))
        u, v = tx + sx * vx, ty - sy * vy
        x = int(min(TEX - 1, max(0, math.floor(u))))
        y = int(min(TEX - 1, max(0, math.floor(v))))
        yy, xx = iy[y, x], ix[y, x]
        return spr[yy, xx, :3]

    def colour_at(p):
        return sprite_colour(p)

    # choose the texel density: as high as the three views + a 2x2 swatch fit in 32x32
    placed, d = None, None
    for dd in np.arange(2.0, 0.49, -0.125):
        sizes = {"top": (math.ceil(ext[0] * dd), math.ceil(ext[2] * dd)),
                 "front": (math.ceil(ext[0] * dd), math.ceil(ext[1] * dd)),
                 "side": (math.ceil(ext[2] * dd), math.ceil(ext[1] * dd)),
                 "bottom": (2, 2)}
        if any(w > TEX or h > TEX for w, h in sizes.values()):
            continue
        for gap in (1, 0):
            placed = pack(sizes, gap)
            if placed:
                break
        if placed:
            d = float(dd)
            break
    assert placed, name

    img = np.zeros((TEX, TEX, 4), np.uint8)
    img[:, :, 3] = 255
    filled = np.zeros((TEX, TEX), bool)
    big = 1000.0

    def put(vname, fn):
        x0, y0 = placed[vname]
        w, h = sizes[vname]
        for r in range(h):
            for c in range(w):
                P = fn((c + 0.5) / d, (r + 0.5) / d)
                if P is None:
                    continue
                img[y0 + r, x0 + c, :3] = np.clip(colour_at(P), 0, 255).astype(np.uint8)
                filled[y0 + r, x0 + c] = True

    def top(a, b):
        x, z = lo[0] + a, lo[2] + b
        t, _ = ray_hit(els, (x, big, z), (0, -1, 0))
        return None if t is None else (x, big - t, z)

    def front(a, b):
        x, y = lo[0] + a, hi[1] - b
        t, _ = ray_hit(els, (x, y, -big), (0, 0, 1))
        return None if t is None else (x, y, -big + t)

    def side(a, b):
        z, y = lo[2] + a, hi[1] - b
        t, _ = ray_hit(els, (big, y, z), (-1, 0, 0))
        return None if t is None else (big - t, y, z)

    sizes = sizes
    put("top", top)
    put("front", front)
    put("side", side)

    # fill the texels no ray hit (silhouette corners) with the nearest filled texel of their own view
    for vname in ("top", "front", "side"):
        x0, y0 = placed[vname]
        w, h = sizes[vname]
        sub = filled[y0:y0 + h, x0:x0 + w]
        if sub.any() and not sub.all():
            _, (jy, jx) = ndi.distance_transform_edt(~sub, return_indices=True)
            region = img[y0:y0 + h, x0:x0 + w, :3].copy()
            img[y0:y0 + h, x0:x0 + w, :3] = region[jy, jx]
    # the bottom swatch: the darkened average of the lowest row of the front view
    x0, y0 = placed["front"]
    w, h = sizes["front"]
    row = img[y0 + h - 1, x0:x0 + w, :3].astype(np.float32)
    bot = np.clip(row.mean(axis=0) * 0.82, 0, 255).astype(np.uint8)
    bx, by = placed["bottom"]
    img[by:by + 2, bx:bx + 2, :3] = bot

    # --- the UVs
    origin = {"top": lo[0], "front": lo[0], "side": lo[2], "bottom": lo[0]}

    def uvpt(view_name, p):
        x0, y0 = placed[view_name]
        if view_name == "top":
            U, V = p[0] - lo[0], p[2] - lo[2]
        elif view_name == "front":
            U, V = p[0] - lo[0], hi[1] - p[1]
        elif view_name == "side":
            U, V = p[2] - lo[2], hi[1] - p[1]
        else:
            return (x0 + 1) / 2.0, (y0 + 1) / 2.0                            # the middle of the 2x2 swatch
        w, h = sizes[view_name]
        U = min(max(U * d, 0.02), w - 0.02)                                  # keep inside the view, off the borders
        V = min(max(V * d, 0.02), h - 0.02)
        return (x0 + U) / 2.0, (y0 + V) / 2.0

    new = dict(data)
    new["textures"] = {"particle": "aestheticjobs:item/%s_3d" % name, "p": "aestheticjobs:item/%s_3d" % name}
    new["gui_light"] = "front"                                               # the sprite's shading is already painted in
    new["display"] = dict(data["display"])
    vp = [view((p[0] - centre[0], p[1] - centre[1], p[2] - centre[2])) for p in pts]
    gw = max(p[0] for p in vp) - min(p[0] for p in vp)
    gh = max(p[1] for p in vp) - min(p[1] for p in vp)
    gs = round(max(0.55, min(1.15, 13.0 / max(gw, gh))), 3)
    new["display"]["gui"] = {"rotation": [ang[0], ang[1], 0], "translation": [0, 0, 0], "scale": [gs] * 3}
    new["elements"] = []
    for e in els:
        ne = dict(e)
        faces = {}
        for f, (tl, br) in FACES.items():
            def pick(spec):
                return tuple(e["from"][i] if spec[i] == "f" else e["to"][i] for i in range(3))
            a, b = to_world(e, pick(tl)), to_world(e, pick(br))
            u1, v1 = uvpt(VIEW_OF[f], a)
            u2, v2 = uvpt(VIEW_OF[f], b)
            faces[f] = {"uv": [round(u1, 3), round(v1, 3), round(u2, 3), round(v2, 3)], "texture": "#p"}
        ne["faces"] = faces
        new["elements"].append(ne)
    return new, Image.fromarray(img, "RGBA"), {"iou": round(float(iou), 3), "density": d}
