#!/usr/bin/env python3
"""Hand-painted 32x32 textures + simple geometry for the 3D items listed in PAINTED (gen_3d_models.py).

Unlike bake_3d_textures.py (which projects the 2D sprite onto a model) every face here is painted on purpose, the way a
texture artist would: its own panel in the 32x32 atlas, light from the top left, a lighter lip on the lit edges, darker
edges on the shaded ones, warm hue-shifted shadows. The colours are the ones of the 2D sprites (picked from them), so
the 3D item and its sprite belong together.

Each painter returns   boxes: [{"from","to","color","faces": {face: (x, y, w, h)}}]   (texel rects of the atlas, seen from
outside, so no flips)   and   the PIL image.   The atlas is 2 texels per model unit (a model unit = 1/16 block).
"""
import random

import numpy as np
from PIL import Image

TEX = 32


def hx(s):
    s = s.lstrip("#")
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))


def mix(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


class Atlas:
    def __init__(self):
        self.px = np.zeros((TEX, TEX, 4), np.uint8)
        self.px[:, :, 3] = 255
        self.px[:, :, :3] = (255, 0, 255)                       # unpainted texels would show as magenta (a bug marker)

    def put(self, x, y, c):
        self.px[y, x, :3] = c

    def get(self, x, y):
        return tuple(int(v) for v in self.px[y, x, :3])

    def fill(self, x, y, w, h, c):
        for j in range(h):
            for i in range(w):
                self.put(x + i, y + j, c)

    def image(self):
        return Image.fromarray(self.px, "RGBA")


def edge_light(a, x, y, w, h, left=0.16, right=0.22, bottom=0.18, top=0.0):
    """Lit left edge, shaded right and bottom edges of a side panel (the sprites' soft outline)."""
    for j in range(h):
        if left:
            a.put(x, y + j, mix(a.get(x, y + j), (255, 244, 230), left))
        if right:
            a.put(x + w - 1, y + j, mix(a.get(x + w - 1, y + j), (40, 22, 16), right))
    for i in range(w):
        if bottom:
            a.put(x + i, y + h - 1, mix(a.get(x + i, y + h - 1), (40, 22, 16), bottom))
        if top:
            a.put(x + i, y, mix(a.get(x + i, y), (255, 244, 230), top))


# ======================================================================================================== tiramisu
COCOA, COCOA_L, COCOA_D, OUTLINE = hx("844526"), hx("965833"), hx("63361f"), hx("453024")
SPONGE, SPONGE_D, SPONGE_L = hx("b99070"), hx("9a6e50"), hx("c9a483")
CREAM, CREAM_L, CREAM_D = hx("efcfa4"), hx("f9e0b9"), hx("e0b88a")


def tiramisu():
    a = Atlas()
    rng = random.Random(7)

    # --- the cocoa top, 16x16 at (0,0)
    for y in range(16):
        for x in range(16):
            r = rng.random()
            lit = 1.0 - (x + y) / 30.0                          # lighter to the top left
            c = COCOA
            if r < 0.26 + 0.14 * lit:
                c = COCOA_L
            elif r < 0.36 + 0.14 * lit:
                c = COCOA_D
            if rng.random() < 0.035 + 0.04 * lit:
                c = SPONGE                                      # a few pale grains of dust
            a.put(x, y, c)
    for i in range(16):                                         # a lip: lit on the north and west rim, dark on the south and east
        a.put(i, 0, mix(COCOA_L, CREAM, 0.12))
        a.put(0, i, mix(COCOA_L, CREAM, 0.12))
        a.put(i, 15, mix(COCOA_D, OUTLINE, 0.5))
        a.put(15, i, mix(COCOA_D, OUTLINE, 0.5))
    a.put(0, 15, COCOA_D)
    a.put(15, 0, COCOA)

    # --- the side strips, 16x12: cocoa 2 | cream 3 | sponge 2 | cream 3 | sponge 2 rows
    def side(x0, y0, seed, flip_light):
        r = random.Random(seed)
        for x in range(16):
            # cocoa band
            a.put(x0 + x, y0, mix(COCOA_L, COCOA, 0.5) if r.random() < 0.7 else COCOA)
            a.put(x0 + x, y0 + 1, COCOA_D if r.random() < 0.65 else COCOA)
            for base in (2, 7):                                 # the two cream layers
                a.put(x0 + x, y0 + base, CREAM_L if r.random() < 0.85 else CREAM)
                a.put(x0 + x, y0 + base + 1, CREAM if r.random() < 0.9 else CREAM_L)
                a.put(x0 + x, y0 + base + 2, CREAM_D if r.random() < 0.7 else CREAM)
                if base == 2 and r.random() < 0.22:             # cocoa crumbs sinking into the cream
                    a.put(x0 + x, y0 + base, SPONGE_D)
            for base in (5, 10):                                # the two soaked sponge layers
                a.put(x0 + x, y0 + base, SPONGE_D if r.random() < 0.8 else COCOA_L)
                c = SPONGE
                q = r.random()
                if q < 0.30:
                    c = SPONGE_D
                elif q < 0.38:
                    c = COCOA_L
                elif q < 0.44:
                    c = SPONGE_L
                a.put(x0 + x, y0 + base + 1, c)
        for j in range(12):                                     # soft dark outline on the vertical edges and the bottom, like the sprite's rim
            a.put(x0, y0 + j, mix(a.get(x0, y0 + j), OUTLINE, 0.30 if not flip_light else 0.45))
            a.put(x0 + 15, y0 + j, mix(a.get(x0 + 15, y0 + j), OUTLINE, 0.55 if not flip_light else 0.35))
        for i in range(16):
            a.put(x0 + i, y0 + 11, mix(a.get(x0 + i, y0 + 11), OUTLINE, 0.55))
        # the cream swells a little where the sponge presses on it: a pale dot on the top row of each cream layer's ends
        for base in (2, 7):
            a.put(x0, y0 + base, CREAM_L)
            a.put(x0 + 15, y0 + base, CREAM_D)

    side(16, 0, 11, False)                                      # sideA: north / south (long edge x)
    side(0, 16, 23, True)                                       # sideB: east / west

    # --- small swatches for the thin ledges and the bottom
    a.fill(16, 16, 4, 4, mix(SPONGE_D, COCOA_D, 0.5))           # bottom
    a.fill(20, 16, 2, 2, CREAM_L)                               # cream ledge top
    a.fill(22, 16, 2, 2, CREAM_D)                               # cream underside
    a.fill(24, 16, 2, 2, SPONGE_L)                              # sponge ledge
    a.fill(26, 16, 2, 2, SPONGE_D)                              # sponge underside
    # the rest of the atlas stays unused: paint it with the cocoa colour so nothing magenta ever shows
    for y in range(32):
        for x in range(32):
            if a.get(x, y) == (255, 0, 255):
                a.put(x, y, COCOA)

    # --- geometry: an 8 x 8 x 6 slab, the cream layers bulge 0.15 out of the sponge
    bands = [  # y0, y1, kind, strip rows (top-down, in texels)
        (0.0, 1.0, "sponge", (10, 12)),
        (1.0, 2.5, "cream", (7, 10)),
        (2.5, 3.5, "sponge", (5, 7)),
        (3.5, 5.0, "cream", (2, 5)),
        (5.0, 6.0, "cocoa", (0, 2)),
    ]
    boxes = []
    for i, (y0, y1, kind, (r0, r1)) in enumerate(bands):
        g = 0.15 if kind == "cream" else 0.0
        f = {"north": (16, r0, 16, r1 - r0), "south": (16, r0, 16, r1 - r0),
             "east": (0, 16 + r0, 16, r1 - r0), "west": (0, 16 + r0, 16, r1 - r0)}
        if kind == "cocoa":
            f["up"], f["down"] = (0, 0, 16, 16), (24, 16, 2, 2)
        elif kind == "cream":
            f["up"], f["down"] = (20, 16, 2, 2), (22, 16, 2, 2)
        else:
            f["up"], f["down"] = (24, 16, 2, 2), ((16, 16, 4, 4) if i == 0 else (26, 16, 2, 2))
        boxes.append({"from": [4 - g, y0, 4 - g], "to": [12 + g, y1, 12 + g], "color": {"sponge": "coffee_l", "cream": "cream", "cocoa": "coffee"}[kind], "faces": f})
    return boxes, a.image()


# ======================================================================================================== milk carton
PAPER, PAPER_L, PAPER_S, PAPER_SS = hx("d9c7bd"), hx("efe2d9"), hx("cab5ad"), hx("a18e8d")
INK, INK_L = hx("564a49"), hx("6b625d")

# cow patches: (x, y, rows) on the 12x12 front
COW = [
    (1, 2, [".##", "###", "##."]),
    (5, 4, [".###", "####", "##.#", ".#.."]),
    (2, 8, ["##.", ".##"]),
    (8, 1, ["##", "#."]),
]


def milk_carton():
    a = Atlas()
    rng = random.Random(5)

    def paper(x, y, w, h, base, light, shade, grain=0.07):
        for j in range(h):
            for i in range(w):
                c = base
                if rng.random() < grain:
                    c = mix(base, light, 0.7)
                elif rng.random() < grain:
                    c = mix(base, shade, 0.5)
                a.put(x + i, y + j, c)

    # front 12x12 at (0,0): the cow-patch logo
    paper(0, 0, 12, 12, PAPER, PAPER_L, PAPER_S)
    for j in range(12):                                          # soft vertical gradient, a touch darker towards the bottom
        for i in range(12):
            if j >= 8 and (i + j) % 2 == 0:
                a.put(i, j, mix(a.get(i, j), PAPER_S, 0.35))
    for ox, oy, rows in COW:
        for j, row in enumerate(rows):
            for i, ch in enumerate(row):
                if ch == "#":
                    lit = (i == 0 or rows[j][i - 1] != "#" or j == 0 or rows[j - 1][i] != "#")
                    a.put(ox + i, oy + j, INK_L if lit else INK)         # a lighter rim top left gives the patch some volume
    edge_light(a, 0, 0, 12, 12, left=0.0, right=0.25, bottom=0.3, top=0.25)
    for j in range(12):
        a.put(0, j, mix(a.get(0, j), PAPER_L, 0.6))

    # back 12x12 at (12,0): plain
    paper(12, 0, 12, 12, mix(PAPER, PAPER_S, 0.35), PAPER, PAPER_SS)
    edge_light(a, 12, 0, 12, 12, left=0.1, right=0.25, bottom=0.3, top=0.15)

    # the sides 10x12: east at (0,12) is the shaded one the GUI shows, west at (10,12)
    paper(0, 12, 10, 12, PAPER_S, PAPER, PAPER_SS)
    edge_light(a, 0, 12, 10, 12, left=0.25, right=0.0, bottom=0.3, top=0.2)
    paper(10, 12, 10, 12, mix(PAPER_S, PAPER_SS, 0.35), PAPER_S, PAPER_SS)
    edge_light(a, 10, 12, 10, 12, left=0.1, right=0.2, bottom=0.3, top=0.1)
    for j in range(12):
        a.put(9, 12 + j, mix(a.get(9, 12 + j), PAPER_SS, 0.3))

    # the roof: front/back strips 12x6 at (20,12), side strips 8x6 at (20,18), the top 12x8 at (20,24)
    for k in range(3):                                           # step 1, step 2, the fin: 2 texel rows each
        y = 12 + 2 * k
        paper(20, y, 12, 2, mix(PAPER, PAPER_L, 0.5), PAPER_L, PAPER, grain=0.05)
        a.put(20, y, PAPER_L)
        a.put(20, y + 1, PAPER_L)
        a.put(31, y, mix(a.get(31, y), PAPER_S, 0.5))
        a.put(31, y + 1, mix(a.get(31, y + 1), PAPER_S, 0.5))
        paper(20, 18 + 2 * k, 8, 2, PAPER_S, PAPER, PAPER_SS, grain=0.05)
        a.put(20, 18 + 2 * k, mix(PAPER_S, PAPER_L, 0.3))
        a.put(20, 19 + 2 * k, mix(PAPER_S, PAPER_L, 0.3))
    for i in range(12):                                          # only the very top of the fin is darker: the sealed edge
        a.put(20 + i, 16, mix(a.get(20 + i, 16), PAPER_SS, 0.35))
    paper(20, 24, 12, 8, PAPER_L, PAPER_L, PAPER, grain=0.05)
    for i in range(12):                                          # the glued ridge
        a.put(20 + i, 27, mix(PAPER_L, PAPER_SS, 0.35))
        a.put(20 + i, 28, mix(PAPER_L, PAPER_SS, 0.18))
    for j in range(8):
        a.put(20, 24 + j, PAPER_L)
        a.put(31, 24 + j, mix(a.get(31, 24 + j), PAPER_SS, 0.25))

    a.fill(0, 24, 4, 4, PAPER_SS)                                # the bottom
    for y in range(32):
        for x in range(32):
            if a.get(x, y) == (255, 0, 255):
                a.put(x, y, PAPER_S)

    top = (20, 24, 12, 8)
    bottom = (0, 24, 4, 4)
    boxes = [
        {"from": [0, 0, 0], "to": [6, 6, 5], "color": "white",
         "faces": {"north": (0, 0, 12, 12), "south": (12, 0, 12, 12), "east": (0, 12, 10, 12), "west": (10, 12, 10, 12), "up": top, "down": bottom}},
    ]
    for i, w in enumerate((4.2, 3.4, 2.6, 1.8)):                 # the gable as 4 fine steps (half a unit each, one texel row each)
        boxes.append({"from": [0, 6 + 0.5 * i, 2.5 - w / 2], "to": [6, 6.5 + 0.5 * i, 2.5 + w / 2], "color": "white",
                      "faces": {"north": (20, 12 + i, 12, 1), "south": (20, 12 + i, 12, 1), "east": (20, 18 + i, 8, 1), "west": (20, 18 + i, 8, 1), "up": top, "down": bottom}})
    boxes.append({"from": [0, 8, 2.1], "to": [6, 9, 2.9], "color": "white",                      # the sealed fin
                  "faces": {"north": (20, 16, 12, 2), "south": (20, 16, 12, 2), "east": (20, 22, 8, 2), "west": (20, 22, 8, 2), "up": top, "down": bottom}})
    return boxes, a.image()


PAINTERS = {"tiramisu": tiramisu, "milk_carton": milk_carton}


def uv_of(rect):
    """Texel rect (x, y, w, h) -> Minecraft uv [u1, v1, u2, v2] (texture is 32 px = 16 uv units), a hair inside the rect."""
    x, y, w, h = rect
    e = 0.02
    return [round((x + e) / 2.0, 3), round((y + e) / 2.0, 3), round((x + w - e) / 2.0, 3), round((y + h - e) / 2.0, 3)]
