#!/usr/bin/env python3
"""
Skins of the cafe staff NPCs (same 32x32 UV layout as the customers) and the plate icon:

  (staff skins are made by tools/gen_person_skins.py)
  textures/item/dessert_plate.png     32x32 plate (the dessert is drawn on top of it by the plate models)

Run: python3 tools/gen_staff_textures.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from PIL import Image, ImageDraw  # noqa: E402
import gen_customer_textures as ct  # noqa: E402

ASSETS = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "aestheticjobs", "textures")

WHITE = "#fffaf0"

CHEF = dict(name="Chef", skin="#f6d8bc", hair="#6a4a3a", iris="#6a8fb0", style="beret", top=WHITE, trim=ct.TERRA,
            bottom="#8a6a58", detail="buttons", dress=False, legs="#8a6a58", sock=None, shoes="#6a4a3a", extra=None,
            hat=WHITE)
BARISTA = dict(name="Barista", skin="#eec1a0", hair="#4a3830", iris="#5a3a2a", style="beanie", top=ct.COFFEE, trim=ct.CREAM,
               bottom="#6a4a3a", detail="pocket", dress=False, legs="#6a4a3a", sock=None, shoes="#4a3228", extra=None,
               hat=ct.COFFEE)


def plate():
    im = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.ellipse((2, 15, 29, 29), fill=(214, 204, 190, 255))          # rim shadow
    d.ellipse((2, 14, 29, 27), fill=(255, 250, 240, 255))          # the plate
    d.ellipse((7, 17, 24, 24), fill=(240, 232, 218, 255))          # the well
    d.arc((2, 14, 29, 27), 200, 340, fill=(255, 255, 255, 255))
    d.ellipse((2, 14, 29, 27), outline=(138, 106, 88, 255))
    return im


def main():
    plate().save(os.path.join(ASSETS, "item", "dessert_plate.png"))
    print("ok")


if __name__ == "__main__":
    main()
