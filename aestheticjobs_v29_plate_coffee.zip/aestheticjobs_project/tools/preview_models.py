#!/usr/bin/env python3
"""Software preview of block and item model JSONs (element rotations around y only): isometric view, per-face shading, alpha.

    python3 tools/preview_models.py out.png model1 [item/model2 ...] [--cols N] [--cell PX] [--gui]
"""
import json
import math
import os
import sys

import numpy as np
from PIL import Image

ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "aestheticjobs")


def load(name):
    with open(os.path.join(ASSETS, "models", name if "/" in name else "block/" + name) + ".json") as f:
        m = json.load(f)
    if "elements" not in m:
        base = load(m["parent"].split("/")[-1])
        base["textures"].update(m.get("textures", {}))
        return base
    return m


def corners(f, t, d):
    (x0, y0, z0), (x1, y1, z1) = f, t
    return {
        "north": ((x1, y1, z0), (x0, y1, z0), (x1, y0, z0)),
        "south": ((x0, y1, z1), (x1, y1, z1), (x0, y0, z1)),
        "east": ((x1, y1, z1), (x1, y1, z0), (x1, y0, z1)),
        "west": ((x0, y1, z0), (x0, y1, z1), (x0, y0, z0)),
        "up": ((x0, y1, z0), (x1, y1, z0), (x0, y1, z1)),
        "down": ((x0, y0, z1), (x1, y0, z1), (x0, y0, z0)),
    }[d]


def render(name, size=420, yaw_deg=30.0, pitch_deg=30.0, gui=False):
    model = load(name)
    S = 2
    big = size * S
    scale = big / 25.0
    yaw, pit = math.radians(yaw_deg), math.radians(pitch_deg)
    cy, sy, cp, sp = math.cos(yaw), math.sin(yaw), math.cos(pit), math.sin(pit)

    def proj(p):
        x, y, z = p[0] - 8, p[1] - 8, p[2] - 8
        x2, z2 = x * cy + z * sy, -x * sy + z * cy
        return (big / 2 - x2 * scale, big / 2 - (y * cp + z2 * sp) * scale, -y * sp + z2 * cp)

    if gui:                                           # exactly the "gui" display transform of the model: one inventory slot
        t = model["display"]["gui"]
        a, b = math.radians(t["rotation"][0]), math.radians(t["rotation"][1])

        def proj(p):                                  # noqa: F811
            x, y, z = (p[i] - 8 for i in range(3))
            x, y, z = (v * t["scale"][0] for v in (x, y, z))
            x, z = x * math.cos(b) + z * math.sin(b), -x * math.sin(b) + z * math.cos(b)
            y, z = y * math.cos(a) - z * math.sin(a), y * math.sin(a) + z * math.cos(a)
            k = big / 16.0
            return (big / 2 + (x + t["translation"][0]) * k, big / 2 - (y + t["translation"][1]) * k, -z)
    tex = {}
    shade = {"north": 0.86, "south": 0.86, "east": 0.70, "west": 0.70, "up": 1.0, "down": 0.5}
    todo = []
    for el in model["elements"]:
        for d, face in el["faces"].items():
            pts = corners(el["from"], el["to"], d)
            rot = el.get("rotation")
            if rot:
                ang = math.radians(rot["angle"])
                ox, oz = rot["origin"][0], rot["origin"][2]
                pts = [(ox + (x - ox) * math.cos(ang) + (z - oz) * math.sin(ang), y,
                        oz - (x - ox) * math.sin(ang) + (z - oz) * math.cos(ang)) for x, y, z in pts]
            tl, tr, bl = (proj(c) for c in pts)
            if (tr[0] - tl[0]) * (bl[1] - tl[1]) - (tr[1] - tl[1]) * (bl[0] - tl[0]) <= 0:
                continue
            key = model["textures"][face["texture"][1:]].split(":")[-1]
            if key not in tex:
                tex[key] = Image.open(os.path.join(ASSETS, "textures", key + ".png")).convert("RGBA")
            todo.append((d, face["uv"], tex[key], tl, tr, bl))
    color = np.zeros((big, big, 4), np.float32)
    depth = np.full((big, big), 1e9, np.float32)
    glass = []
    gy, gx = np.mgrid[0:big, 0:big] + 0.5

    def raster(item, blend):
        d, uv, im, tl, tr, bl = item
        a = np.array(im).astype(np.float32)
        th, tw = a.shape[:2]
        ax, ay, bx, by = tr[0] - tl[0], tr[1] - tl[1], bl[0] - tl[0], bl[1] - tl[1]
        det = ax * by - bx * ay
        if abs(det) < 1e-6:
            return
        xs = [tl[0], tr[0], bl[0], tr[0] + bx]
        ys = [tl[1], tr[1], bl[1], tr[1] + by]
        x0, x1 = max(0, int(min(xs))), min(big, int(max(xs)) + 2)
        y0, y1 = max(0, int(min(ys))), min(big, int(max(ys)) + 2)
        X, Y = gx[y0:y1, x0:x1] - tl[0], gy[y0:y1, x0:x1] - tl[1]
        u = (by * X - bx * Y) / det
        v = (-ay * X + ax * Y) / det
        inside = (u >= 0) & (u < 1) & (v >= 0) & (v < 1)
        z = tl[2] + u * (tr[2] - tl[2]) + v * (bl[2] - tl[2])
        px = np.clip(((uv[0] + u * (uv[2] - uv[0])) / 16 * tw).astype(int), 0, tw - 1)
        py = np.clip(((uv[1] + v * (uv[3] - uv[1])) / 16 * th).astype(int), 0, th - 1)
        c = a[py, px].copy()
        c[..., :3] *= shade[d]
        dz = depth[y0:y1, x0:x1]
        m = inside & (z < dz) & (c[..., 3] > 8)
        region = color[y0:y1, x0:x1]
        if blend:
            al = (c[..., 3:4] / 255.0)
            mixed = region.copy()
            mixed[..., :3] = c[..., :3] * al + region[..., :3] * (1 - al)
            mixed[..., 3] = np.maximum(region[..., 3], c[..., 3])
            region[m] = mixed[m]
        else:
            opaque = m & (c[..., 3] >= 250)
            region[opaque] = c[opaque]
            dz[opaque] = z[opaque]

    for item in todo:
        raster(item, False)
    todo.sort(key=lambda i: -(i[3][2] + i[4][2] + i[5][2]))
    for item in todo:
        a = np.array(item[2])
        if a[..., 3][a[..., 3] > 8].size and (a[..., 3][a[..., 3] > 8] < 250).any():
            raster(item, True)
    return Image.fromarray(color.clip(0, 255).astype(np.uint8), "RGBA").resize((size, size), Image.LANCZOS)


def sheet(out, names, cols=4, cell=420, bg=(190, 194, 196), gui=False):
    rows = (len(names) + cols - 1) // cols
    img = Image.new("RGBA", (cols * cell, rows * cell), bg + (255,))
    for i, n in enumerate(names):
        x, y = (i % cols) * cell, (i // cols) * cell
        if gui:
            img.paste((139, 139, 139, 255), (x + 4, y + 4, x + cell - 4, y + cell - 4))
            img.alpha_composite(render(n, cell - 16, gui=True), (x + 8, y + 8))
        else:
            img.alpha_composite(render(n, cell), (x, y))
    img.save(out)


if __name__ == "__main__":
    args = sys.argv[1:]
    opts = {}
    for k in ("--cols", "--cell"):
        if k in args:
            i = args.index(k)
            opts[k[2:]] = int(args[i + 1])
            del args[i:i + 2]
    if "--gui" in args:
        args.remove("--gui")
        opts["gui"] = True
    sheet(args[0], args[1:], **opts)
