#!/usr/bin/env python3
"""Draws how a food item sits in the hands and moves while it is used: repeats the vanilla matrix chain of the first and
third person with the item's "display" transforms and the numbers of client/FoodAnimation, client/FoodArmPose and
cafe/anim/FoodMotion. A software picture, not the game: keep the numbers in step with the Java code.

    python3 tools/preview_hands.py out.png cup_cappuccino donut_pink
"""
import json
import math
import os
import sys

import numpy as np
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import preview_models as P  # noqa: E402

DURATION, RAISE_TICKS = 32, 7.0
DRINKS = ("cup_", )


# ---------------------------------------------------------------- FoodMotion
def clamp(v, a=0.0, b=1.0):
    return max(a, min(b, v))


def raise_(u):
    return 1 - (1 - clamp(u / RAISE_TICKS)) ** 3


def progress(u):
    return clamp((u - RAISE_TICKS) / (DURATION - RAISE_TICKS))


def gulp(u):
    p = progress(u)
    return max(0.0, math.sin(p * 6 * math.pi)) if 0 < p < 1 else 0.0


def bite(u):
    p = progress(u)
    phase = (p * 4) % 1
    return math.sin(phase * 2 * math.pi) if 0 < p < 1 and phase < 0.5 else 0.0


def scale_(u):
    p = progress(u)
    return 1 - 0.09 * (min(4, math.floor(p * 4 + 0.75)) if p > 0 else 0)


# ---------------------------------------------------------------- matrices
def T(x, y, z):
    m = np.eye(4)
    m[:3, 3] = (x, y, z)
    return m


def S(s):
    return np.diag((s, s, s, 1.0))


def R(axis, deg):
    a = math.radians(deg)
    c, s = math.cos(a), math.sin(a)
    m = np.eye(4)
    i, j = {"x": (1, 2), "y": (2, 0), "z": (0, 1)}[axis]
    m[i, i] = m[j, j] = c
    m[i, j], m[j, i] = -s, s
    return m


def item_matrix(model, key):
    t = model["display"][key]
    tr, ro, sc = t["translation"], t["rotation"], t["scale"][0]
    return T(*(v / 16 for v in tr)) @ R("x", ro[0]) @ R("y", ro[1]) @ R("z", ro[2]) @ S(sc) @ T(-0.5, -0.5, -0.5)


# ---------------------------------------------------------------- quads
def item_quads(name, matrix):
    m = P.load("item/" + name)
    im = np.array(Image.open(os.path.join(P.ASSETS, "textures", m["textures"]["t"].split(":")[1] + ".png")).convert("RGBA"))
    shade = {"north": 0.86, "south": 0.86, "east": 0.72, "west": 0.72, "up": 1.0, "down": 0.55}
    out = []
    for e in m["elements"]:
        for d, face in e["faces"].items():
            tl, tr, bl = P.corners(e["from"], e["to"], d)
            br = tuple(tr[i] + bl[i] - tl[i] for i in range(3))
            pts = []
            for p in (tl, tr, br, bl):
                x, y, z = p
                rot = e.get("rotation")
                if rot:
                    a = math.radians(rot["angle"])
                    ox, oz = rot["origin"][0], rot["origin"][2]
                    x, z = ox + (x - ox) * math.cos(a) + (z - oz) * math.sin(a), oz - (x - ox) * math.sin(a) + (z - oz) * math.cos(a)
                pts.append((matrix @ (x / 16, y / 16, z / 16, 1))[:3])
            u0, v0, u1, v1 = (c / 16 for c in face["uv"])
            out.append((pts, [(u0, v0), (u1, v0), (u1, v1), (u0, v1)], im, shade[d]))
    return out


def box_quads(matrix, lo, hi, color):
    tex = np.array([[color + (255,)]], np.uint8)
    out = []
    for d, k in (("north", 0.85), ("south", 0.85), ("east", 0.7), ("west", 0.7), ("up", 0.6), ("down", 1.0)):
        tl, tr, bl = P.corners(lo, hi, d)
        br = tuple(tr[i] + bl[i] - tl[i] for i in range(3))
        pts = [(matrix @ (p[0] / 16, p[1] / 16, p[2] / 16, 1))[:3] for p in (tl, tr, br, bl)]
        out.append((pts, [(0, 0)] * 4, tex, k))
    return out


def draw(quads, project, w, h, bg):
    color = np.zeros((h, w, 3), np.float32)
    color[:] = bg
    depth = np.full((h, w), 1e9)
    for pts, uvs, im, shade in quads:
        proj = [project(p) for p in pts]
        if any(p is None for p in proj):
            continue
        th, tw = im.shape[:2]
        for tri in ((0, 1, 2), (0, 2, 3)):
            (x0, y0, z0), (x1, y1, z1), (x2, y2, z2) = (proj[i] for i in tri)
            det = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0)
            if abs(det) < 1e-9:
                continue
            ax, bx = max(0, int(min(x0, x1, x2))), min(w, int(max(x0, x1, x2)) + 2)
            ay, by = max(0, int(min(y0, y1, y2))), min(h, int(max(y0, y1, y2)) + 2)
            if ax >= bx or ay >= by:
                continue
            Y, X = np.mgrid[ay:by, ax:bx] + 0.5
            l1 = ((X - x0) * (y2 - y0) - (x2 - x0) * (Y - y0)) / det
            l2 = ((x1 - x0) * (Y - y0) - (X - x0) * (y1 - y0)) / det
            l0 = 1 - l1 - l2
            inside = (l0 >= -1e-6) & (l1 >= -1e-6) & (l2 >= -1e-6)
            iz = l0 / z0 + l1 / z1 + l2 / z2
            z = 1 / np.where(iz == 0, 1e-9, iz)
            u = (l0 * uvs[tri[0]][0] / z0 + l1 * uvs[tri[1]][0] / z1 + l2 * uvs[tri[2]][0] / z2) * z
            v = (l0 * uvs[tri[0]][1] / z0 + l1 * uvs[tri[1]][1] / z1 + l2 * uvs[tri[2]][1] / z2) * z
            c = im[np.clip((v * th).astype(int), 0, th - 1), np.clip((u * tw).astype(int), 0, tw - 1)]
            m = inside & (z < depth[ay:by, ax:bx]) & (c[..., 3] > 60)
            color[ay:by, ax:bx][m] = c[..., :3][m] * shade
            depth[ay:by, ax:bx][m] = z[m]
    return Image.fromarray(color.clip(0, 255).astype(np.uint8))


def first_person(name, u, w=640, h=400):
    drink = name.startswith(DRINKS)
    model = P.load("item/" + name)
    if u is None:
        chain = T(0.56, -0.52, -0.72)
    else:
        r = raise_(u)
        if drink:
            g = gulp(u)
            x, y, z = 0.10, -0.38 + 0.012 * g, -0.62 + 0.025 * g
            tip, yaw, roll, s = r * (18 + 34 * progress(u)) + 5 * g, 10, 8, 1
        else:
            b = bite(u)
            x, y, z = 0.08, -0.40 + 0.03 * b, -0.68 + 0.13 * b
            tip, yaw, roll = r * 12 + 10 * b, 6, 6 + 2.5 * math.sin(u * 1.9) * (1 - b)
            s = scale_(u)
        lerp = lambda a, c: a + (c - a) * r
        chain = (T(lerp(0.56, x), lerp(-0.52, y), lerp(-0.72, z)) @ T(0, 0.16, 0) @ R("y", yaw * r) @ R("x", tip) @ R("z", roll * r)
                 @ S(s) @ T(0, -0.16, 0))
    f = h / 2 / math.tan(math.radians(35))

    def project(p):
        if p[2] > -0.05:
            return None
        return (w / 2 + p[0] / -p[2] * f, h / 2 - p[1] / -p[2] * f, -p[2])
    img = draw(item_quads(name, chain @ item_matrix(model, "firstperson_righthand")), project, w, h, (150, 176, 196))
    d = ImageDraw.Draw(img)
    d.line((w / 2 - 6, h / 2, w / 2 + 6, h / 2), fill=(255, 255, 255))
    d.line((w / 2, h / 2 - 6, w / 2, h / 2 + 6), fill=(255, 255, 255))
    return img


def third_person(name, u, view_yaw, w=400, h=400):
    drink = name.startswith(DRINKS)
    model = P.load("item/" + name)
    x_arm, y_arm, head = -18.0, 0.0, 0.0                              # holding an item
    if u is not None:
        r = raise_(u)
        mouth = -math.degrees(1.72)
        if drink:
            mouth -= math.degrees(0.12 * progress(u) + 0.06 * gulp(u))
            head = -math.degrees(0.22 * r * progress(u))
        else:
            mouth += math.degrees(0.16 * bite(u))
        x_arm = -18 + (mouth + 18) * r
        y_arm = -math.degrees(0.50) * r
    arm = T(-5 / 16, 2 / 16, 0) @ R("y", y_arm) @ R("x", x_arm)
    hand = arm @ R("x", -90) @ R("y", 180) @ T(1 / 16, 0.125, -0.625)
    world = np.diag((1.0, -1.0, -1.0, 1.0))
    world[1, 3] = 1.501
    quads = []
    skin, shirt, pants, hair = (224, 176, 140), (120, 150, 130), (80, 84, 110), (110, 74, 50)
    hm = R("x", head)
    quads += box_quads(world @ hm, (-4, -8, -4), (4, 0, 4), skin)
    quads += box_quads(world @ hm, (-4.2, -8.4, -3.4), (4.2, -6, 4.4), hair)
    for ex in (-2.6, 1.2):
        quads += box_quads(world @ hm, (ex, -4.4, -4.25), (ex + 1.4, -3.2, -4.0), (60, 50, 60))
    quads += box_quads(world, (-4, 0, -2), (4, 12, 2), shirt)
    quads += box_quads(world @ arm, (-2, -2, -2), (1, 10, 2), skin)
    quads += box_quads(world @ T(5 / 16, 2 / 16, 0), (-1, -2, -2), (2, 10, 2), skin)
    for lx in (-1.9, 1.9):
        quads += box_quads(world @ T(lx / 16, 12 / 16, 0), (-2, 0, -2), (2, 12, 2), pants)
    quads += item_quads(name, world @ hand @ item_matrix(model, "thirdperson_righthand"))
    view = R("x", 8) @ R("y", view_yaw) @ T(0, -1.25, 0)
    f = w * 2.4

    def project(p):
        q = view @ (p[0], p[1], p[2], 1)
        z = 4.0 - q[2]
        return (w / 2 + q[0] / z * f, h / 2 - q[1] / z * f, z)
    return draw(quads, project, w, h, (170, 188, 170))


def main(out, names):
    rows = []
    for name in names:
        times = [None, 4, 12, 20, 27, 31]
        fp = [first_person(name, t, 480, 300) for t in times]
        tp = [third_person(name, None, -35, 300, 300), third_person(name, None, -90, 300, 300),
              third_person(name, 12, -35, 300, 300), third_person(name, 12, -90, 300, 300),
              third_person(name, 29, -35, 300, 300), third_person(name, 29, -90, 300, 300)]
        for strip, labels in ((fp, ["1st: idle"] + [f"1st: tick {t}" for t in times[1:]]),
                              (tp, ["3rd: idle", "3rd: idle side", "tick 12", "tick 12 side", "tick 29", "tick 29 side"])):
            row = Image.new("RGB", (sum(i.width + 6 for i in strip), strip[0].height + 6), (40, 40, 40))
            x = 0
            for im, label in zip(strip, labels):
                ImageDraw.Draw(im).text((8, 6), label, fill=(0, 0, 0))
                row.paste(im, (x + 3, 3))
                x += im.width + 6
            rows.append(row)
    sheet = Image.new("RGB", (max(r.width for r in rows), sum(r.height for r in rows)), (40, 40, 40))
    y = 0
    for r in rows:
        sheet.paste(r, (0, y))
        y += r.height
    sheet.save(out)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2:])
