package dev.aestheticjobs.job.interview;

import dev.aestheticjobs.cafe.CupData;
import dev.aestheticjobs.entity.JobManagerEntity;
import dev.aestheticjobs.job.Jobs;
import dev.aestheticjobs.job.Profession;
import dev.aestheticjobs.job.ProfessionManager;
import dev.aestheticjobs.job.Shift;
import dev.aestheticjobs.network.InterviewStatePayload;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.registry.ModItems;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The interview on the server (the window is only a picture of the state). The course itself is {@link InterviewFlow};
 * this class connects it with the world: the resume in the hand, the manager nearby, the thing brought for the trial,
 * the records of the player and, at the end, the real job (Jobs.hire, the badge, the start rank).
 * Sessions live in memory. A session that waits for the trial survives a closed window for 20 minutes.
 */
public final class Interview {
    private static final long SESSION_MS = 10 * 60_000L, TRIAL_MS = 20 * 60_000L, FAST_TRIAL_MS = 5 * 60_000L;
    private static final long BLANK_COOLDOWN_MS = 20_000L;
    private static final int BREAD_NEEDED = 8;
    private static final int[] CUP_GRADE = {-6, 0, 6, 10, 14};      // by the stars of the cup
    private static final Random RNG = new Random();

    private static final class Session {
        int managerId;
        final ManagerKind kind;
        final InterviewFlow flow;
        long expires = System.currentTimeMillis() + SESSION_MS;
        long trialStart;

        Session(int managerId, ManagerKind kind, InterviewFlow flow) {
            this.managerId = managerId;
            this.kind = kind;
            this.flow = flow;
        }
    }

    private static final Map<UUID, Session> SESSIONS = new HashMap<>();
    /** player|job -> until when (ms) the manager does not talk to him. */
    private static final Map<String, Long> BANS = new HashMap<>();
    private static final Map<UUID, Long> BLANKS = new HashMap<>();

    private Interview() {}

    // ------------------------------------------------------------------ start

    /** The player right-clicked a manager. */
    public static void begin(ServerPlayer sp, JobManagerEntity mgr) {
        MinecraftServer server = sp.server;
        ManagerKind kind = mgr.kind();
        Optional<Profession> prof = ProfessionManager.get(kind.profession);
        if (prof.isEmpty()) {
            say(sp, mgr, "interview.err.no_profession");
            return;
        }
        Optional<Jobs.Status> cur = Jobs.status(server, sp.getUUID());
        Session waiting = SESSIONS.get(sp.getUUID());
        if (waiting != null && waiting.flow.stage() == InterviewFlow.Stage.TRIAL && waiting.kind == kind
                && cur.isEmpty() && System.currentTimeMillis() <= waiting.expires) {
            waiting.managerId = mgr.getId();
            submitTrial(sp, waiting);
            return;
        }
        if (cur.isPresent()) {
            say(sp, mgr, cur.get().profession().id().equals(kind.profession) ? "interview.err.here" : "interview.err.elsewhere");
            return;
        }
        ItemStack held = heldResume(sp);
        if (held.isEmpty()) {
            if (hasResume(sp)) {
                say(sp, mgr, "interview.err.hold");
            } else {
                giveBlank(sp, mgr);
            }
            return;
        }
        if (!Resumes.isFilled(held)) {
            say(sp, mgr, "interview.err.blank");
            return;
        }
        long left = banLeft(sp.getUUID(), kind);
        if (left > 0) {
            say(sp, mgr, "interview.err.wait", Long.toString(Math.max(1L, (left + 59_999L) / 60_000L)));
            return;
        }
        for (Profession.Requirement r : prof.get().requirements()) {
            if (Jobs.bestRank(server, sp.getUUID(), r.profession()) < r.minRank()) {
                say(sp, mgr, "interview.err.requirements");
                return;
            }
        }
        if (waiting != null) close(sp);                                     // another interview: the old one ends

        Resumes.Data d = Resumes.read(held);
        InterviewFlow flow = new InterviewFlow(
                new InterviewFlow.Boss(kind.ordinal(), kind.id, kind.threshold, kind.valued, kind.likedTrait),
                new InterviewFlow.Claim(d.exp(), d.skills(), d.trait(), d.goal()),
                trueExp(server, sp.getUUID()), Jobs.bestRank(server, sp.getUUID(), prof.get().id()) >= 0,
                prof.get().ranks().size() - 1, RNG);
        Session s = new Session(mgr.getId(), kind, flow);
        SESSIONS.put(sp.getUUID(), s);
        List<String> skills = new ArrayList<>();
        for (int i = 0; i < Resumes.SKILL_COUNT; i++) {
            if ((d.skills() >> i & 1) != 0) skills.add("resume.skill." + i);
        }
        flow.start(sp.getGameProfile().getName(), List.of("t:resume.exp." + d.exp(), "t:resume.trait." + d.trait(),
                skills.isEmpty() ? "t:resume.skill.none" : "T:" + String.join(",", skills)));
        send(sp, s, prof.get());
    }

    // ------------------------------------------------------------------ the answers

    public static void answer(ServerPlayer sp, int choice) {
        Session s = SESSIONS.get(sp.getUUID());
        if (s == null) return;
        if (manager(sp, s) == null || System.currentTimeMillis() > s.expires) {
            // too far away: the window closes, a waiting trial is not lost
            if (s.flow.stage() == InterviewFlow.Stage.TRIAL && System.currentTimeMillis() <= s.expires) shut(sp, s, true);
            else close(sp);
            return;
        }
        InterviewFlow.View before = s.flow.view();
        if (choice < 0 || choice >= before.options().size()) return;
        InterviewFlow.View view = s.flow.answer(choice);
        if (view == before) return;
        Optional<Profession> prof = ProfessionManager.get(s.kind.profession);
        if (prof.isEmpty() || view.stage() == InterviewFlow.Stage.LEFT) {
            close(sp);
            return;
        }
        if (view.stage() == InterviewFlow.Stage.TRIAL) {
            s.trialStart = System.currentTimeMillis();
            s.expires = s.trialStart + TRIAL_MS;
        } else {
            s.expires = System.currentTimeMillis() + SESSION_MS;
        }
        if (view.stage() == InterviewFlow.Stage.HIRED) hire(sp, s, prof.get());
        else send(sp, s, prof.get());
    }

    /** The window was closed by the player. */
    public static void cancel(ServerPlayer sp) {
        Session s = SESSIONS.get(sp.getUUID());
        if (s != null && s.flow.stage() != InterviewFlow.Stage.TRIAL) SESSIONS.remove(sp.getUUID());
    }

    // ------------------------------------------------------------------ the trial

    private static void submitTrial(ServerPlayer sp, Session s) {
        Optional<Profession> prof = ProfessionManager.get(s.kind.profession);
        if (prof.isEmpty()) {
            close(sp);
            return;
        }
        boolean wrong = false;
        for (ItemStack stack : new ItemStack[]{sp.getMainHandItem(), sp.getOffhandItem()}) {
            int grade;
            int count = 1;
            switch (s.kind) {
                case CAFE -> {
                    CupData cup = stack.is(ModItems.COFFEE_CUP.get()) ? stack.get(ModComponents.CUP.get()) : null;
                    if (cup == null) continue;
                    if (cup.drink() != s.flow.trialDrink()) {
                        wrong = true;
                        continue;
                    }
                    grade = CUP_GRADE[Math.max(1, Math.min(5, cup.stars())) - 1];
                }
                case OFFICE -> {
                    if (!stack.is(Items.WRITABLE_BOOK)) continue;
                    grade = 12;
                }
                default -> {
                    if (!stack.is(Items.BREAD) || stack.getCount() < BREAD_NEEDED) continue;
                    count = BREAD_NEEDED;
                    grade = 12;
                }
            }
            if (System.currentTimeMillis() - s.trialStart <= FAST_TRIAL_MS) grade += 4;
            stack.shrink(count);
            s.expires = System.currentTimeMillis() + SESSION_MS;
            s.flow.trialDone(grade);
            send(sp, s, prof.get());
            return;
        }
        s.flow.remind(wrong ? "interview.trial.wrong" : "interview.trial.missing");
        send(sp, s, prof.get());
    }

    // ------------------------------------------------------------------ the result

    private static void hire(ServerPlayer sp, Session s, Profession prof) {
        MinecraftServer server = sp.server;
        Jobs.Result r = Jobs.hire(server, sp.getUUID(), prof.id(), false);
        if (r != Jobs.Result.OK) {
            String why = switch (r) {
                case ALREADY_EMPLOYED -> "interview.err.elsewhere";
                case COOLDOWN -> "interview.err.cooldown";
                case REQUIREMENTS_NOT_MET -> "interview.err.requirements";
                default -> "interview.err.no_profession";
            };
            SESSIONS.remove(sp.getUUID());
            packet(sp, s, InterviewStatePayload.REJECTED, "", List.of(), why, List.of(), List.of("interview.close"), 0);
            return;
        }
        int rank = s.flow.rankOffer();
        if (rank > 0) {
            Jobs.addXp(server, sp.getUUID(), prof.ranks().get(rank).xp());      // the start rank is real: the experience of that rank
        }
        Shift.giveBadgeIfMissing(sp);
        ItemStack resume = findResume(sp);
        if (!resume.isEmpty() && Resumes.isFilled(resume)) resume.shrink(1);                                 // the manager keeps the resume
        send(sp, s, prof);
        sp.sendSystemMessage(Component.translatable("interview.hired.chat", prof.displayName(), prof.rankName(rank)));
        ServerLevel level = sp.serverLevel();
        level.playSound(null, sp.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.6F, 1.3F);
        Entity mgr = level.getEntity(s.managerId);
        if (mgr != null) level.sendParticles(ParticleTypes.HAPPY_VILLAGER, mgr.getX(), mgr.getY() + 1.8D, mgr.getZ(), 12, 0.4D, 0.3D, 0.4D, 0.0D);
    }

    /** Ends the interview and tells the window to close. */
    private static void close(ServerPlayer sp) {
        Session s = SESSIONS.remove(sp.getUUID());
        if (s != null) shut(sp, s, false);
    }

    /** keep: the trial is still waiting (the line "keep" tells the client to go on showing the task). */
    private static void shut(ServerPlayer sp, Session s, boolean keep) {
        packet(sp, s, InterviewStatePayload.CLOSE, "", List.of(), keep ? "keep" : "", List.of(), List.of(), 0);
    }

    // ------------------------------------------------------------------ sending

    /** The current view of the flow goes to the window; a finished interview is forgotten. */
    private static void send(ServerPlayer sp, Session s, Profession prof) {
        InterviewFlow.View v = s.flow.view();
        int phase = switch (v.stage()) {
            case CALL -> InterviewStatePayload.CALL;
            case TRIAL -> InterviewStatePayload.TRIAL;
            case OFFER -> InterviewStatePayload.OFFER;
            case CONTRACT -> InterviewStatePayload.CONTRACT;
            case HIRED -> InterviewStatePayload.HIRED;
            case REJECTED -> InterviewStatePayload.REJECTED;
            default -> InterviewStatePayload.Q;
        };
        int rank = s.flow.rankOffer();
        List<String> args = switch (v.stage()) {
            case OFFER -> List.of("t:" + rankKey(prof, rank), prof.wageText(rank));
            case CONTRACT -> List.of("t:" + professionKey(prof), "t:" + rankKey(prof, rank), prof.wageText(rank));
            case HIRED -> List.of("t:" + rankKey(prof, rank));
            default -> v.lineArgs();
        };
        packet(sp, s, phase, v.react(), v.reactArgs(), v.line(), args, v.options(), v.mood());
        if (v.stage() == InterviewFlow.Stage.REJECTED) {
            if (v.banMinutes() > 0) {
                BANS.put(sp.getUUID() + "|" + s.kind.id, System.currentTimeMillis() + v.banMinutes() * 60_000L);
            }
            sp.serverLevel().playSound(null, sp.blockPosition(), SoundEvents.VILLAGER_NO, SoundSource.NEUTRAL, 0.7F, 1.0F);
        }
        if (v.stage() == InterviewFlow.Stage.REJECTED || v.stage() == InterviewFlow.Stage.HIRED) SESSIONS.remove(sp.getUUID());
    }

    private static void packet(ServerPlayer sp, Session s, int phase, String react, List<String> reactArgs, String line,
                               List<String> lineArgs, List<String> options, int mood) {
        Entity e = sp.serverLevel().getEntity(s.managerId);
        if (e instanceof JobManagerEntity m) m.setMood(mood);
        PacketDistributor.sendToPlayer(sp, new InterviewStatePayload(s.managerId, phase, react, reactArgs, line, lineArgs, options,
                mood, s.flow.impression(), s.flow.takeDelta(), s.flow.progress(), s.flow.sheet(), s.flow.threshold()));
    }

    // ------------------------------------------------------------------ helpers

    private static String professionKey(Profession prof) {
        return "profession." + prof.id().getNamespace() + "." + prof.id().getPath();
    }

    private static String rankKey(Profession prof, int rank) {
        return professionKey(prof) + ".rank." + prof.ranks().get(rank).id();
    }

    private static JobManagerEntity manager(ServerPlayer sp, Session s) {
        Entity e = sp.serverLevel().getEntity(s.managerId);
        return e instanceof JobManagerEntity m && m.isAlive() && m.distanceToSqr(sp) <= 64.0D ? m : null;
    }

    private static long banLeft(UUID player, ManagerKind kind) {
        Long until = BANS.get(player + "|" + kind.id);
        return until == null ? 0L : until - System.currentTimeMillis();
    }

    /** What the applicant really did: 0 nothing, 1 has worked somewhere, 2 reached the second rank, 3 the third. */
    private static int trueExp(MinecraftServer server, UUID player) {
        int best = -1;
        for (net.minecraft.resources.ResourceLocation id : ProfessionManager.ids()) {
            best = Math.max(best, Jobs.bestRank(server, player, id));
        }
        return best < 0 ? 0 : best >= 2 ? 3 : best == 1 ? 2 : 1;
    }

    private static ItemStack heldResume(ServerPlayer sp) {
        if (Resumes.isResume(sp.getMainHandItem())) return sp.getMainHandItem();
        if (Resumes.isResume(sp.getOffhandItem())) return sp.getOffhandItem();
        return ItemStack.EMPTY;
    }

    private static boolean hasResume(ServerPlayer sp) {
        return !findResume(sp).isEmpty();
    }

    /** A filled resume anywhere on the player (empty when he has none). */
    private static ItemStack findResume(ServerPlayer sp) {
        ItemStack held = heldResume(sp);
        if (!held.isEmpty() && Resumes.isFilled(held)) return held;
        ItemStack any = ItemStack.EMPTY;
        for (ItemStack st : sp.getInventory().items) {
            if (!Resumes.isResume(st)) continue;
            if (Resumes.isFilled(st)) return st;
            any = st;
        }
        return any;
    }

    private static void giveBlank(ServerPlayer sp, JobManagerEntity mgr) {
        long now = System.currentTimeMillis();
        Long last = BLANKS.get(sp.getUUID());
        if (last != null && now - last < BLANK_COOLDOWN_MS) {
            say(sp, mgr, "interview.err.hold");
            return;
        }
        BLANKS.put(sp.getUUID(), now);
        sp.getInventory().placeItemBackInInventory(new ItemStack(ModItems.RESUME.get()));
        say(sp, mgr, "interview.give_blank");
    }

    /** The manager says something in the chat (when there is no interview). */
    private static void say(ServerPlayer sp, JobManagerEntity mgr, String key, Object... args) {
        sp.sendSystemMessage(Component.translatable("cafe.customer.says", mgr.getDisplayName(), Component.translatable(key, args)));
    }
}
