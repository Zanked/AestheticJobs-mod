package dev.aestheticjobs.job.interview;

import dev.aestheticjobs.registry.ModItems;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.CustomModelData;

/**
 * The resume: a paper the player fills in himself (experience, skills, character, goal). It lives in the custom data of
 * the item, so nothing new has to be registered. The client only asks the server to write it (SubmitResumePayload);
 * the server checks every number. What is written is a CLAIM: the interview compares it with what the player really did.
 */
public final class Resumes {
    public static final int EXP_COUNT = 4, SKILL_COUNT = 8, TRAIT_COUNT = 4, GOAL_COUNT = 3, MAX_SKILLS = 3;

    /** exp: 0 none, 1 under a year, 2 one to three years, 3 more. trait: 0 calm, 1 energetic, 2 meticulous, 3 friendly. goal: 0 career, 1 money, 2 interest. */
    public record Data(int exp, int skills, int trait, int goal, String name) {}

    private Resumes() {}

    public static boolean isResume(ItemStack stack) {
        return stack.is(ModItems.RESUME.get());
    }

    public static boolean isFilled(ItemStack stack) {
        if (!isResume(stack)) return false;
        CustomData data = stack.get(DataComponents.CUSTOM_DATA);
        return data != null && data.copyTag().getBoolean("Filled");
    }

    public static Data read(ItemStack stack) {
        CustomData data = stack.get(DataComponents.CUSTOM_DATA);
        CompoundTag tag = data == null ? new CompoundTag() : data.copyTag();
        return new Data(clamp(tag.getInt("Exp"), 0, EXP_COUNT - 1), tag.getInt("Skills") & 0xFF,
                clamp(tag.getInt("Trait"), 0, TRAIT_COUNT - 1), clamp(tag.getInt("Goal"), 0, GOAL_COUNT - 1), tag.getString("Name"));
    }

    public static void write(ItemStack stack, Data d) {
        CompoundTag tag = new CompoundTag();
        tag.putBoolean("Filled", true);
        tag.putInt("Exp", d.exp());
        tag.putInt("Skills", d.skills());
        tag.putInt("Trait", d.trait());
        tag.putInt("Goal", d.goal());
        tag.putString("Name", d.name());
        stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
        stack.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(1));          // the filled icon
    }

    public static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** At most MAX_SKILLS skills: extra ones are dropped (lowest first). */
    public static int limitSkills(int mask) {
        mask &= (1 << SKILL_COUNT) - 1;
        while (Integer.bitCount(mask) > MAX_SKILLS) mask &= mask - 1;
        return mask;
    }
}
