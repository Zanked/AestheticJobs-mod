package dev.aestheticjobs.job.interview;

import net.minecraft.resources.ResourceLocation;
import dev.aestheticjobs.AestheticJobs;

/**
 * The managers who interview: one per profession (an NPC of its own, with its own skin and its own taste in people).
 * threshold = the impression (0..100) the applicant needs to be hired; valued = the skills this manager likes in a resume
 * (see Resumes.SKILLS); likedTrait = the character he likes (Resumes.TRAITS).
 */
public enum ManagerKind {
    CAFE("cafe_manager", "cafe_worker", 10, 55, new int[]{7, 2, 3}, 3),
    OFFICE("office_manager", "office_clerk", 11, 65, new int[]{1, 4, 3}, 2),
    SHOP("shop_manager", "shop_assistant", 12, 58, new int[]{2, 4, 0}, 1);

    public final String id;
    public final ResourceLocation profession;
    public final int skin;
    public final int threshold;
    public final int[] valued;
    public final int likedTrait;

    ManagerKind(String id, String profession, int skin, int threshold, int[] valued, int likedTrait) {
        this.id = id;
        this.profession = ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, profession);
        this.skin = skin;
        this.threshold = threshold;
        this.valued = valued;
        this.likedTrait = likedTrait;
    }
}
