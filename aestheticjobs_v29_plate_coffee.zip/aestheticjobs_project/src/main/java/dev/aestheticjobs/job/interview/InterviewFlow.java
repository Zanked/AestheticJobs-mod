package dev.aestheticjobs.job.interview;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * The course of a job interview, plain Java (tested without the game): greeting, questions, a check of the skills the
 * resume claims, a phone call if the experience is a lie, the applicant's own question, a practical trial in the world,
 * the offer and the contract. Every call returns the {@link View} the window shows next; its options are translation
 * keys and the player answers with the index of one of them.
 */
public final class InterviewFlow {
    public enum Stage { GREET, QUESTION, SKILL, CHECK, CALL, ASK, TRIAL_OFFER, TRIAL, OFFER, CONTRACT, HIRED, REJECTED, LEFT }

    /** What the manager of this job is like. kind = ordinal of ManagerKind. */
    public record Boss(int kind, String id, int threshold, int[] valued, int likedTrait) {}

    /** What the resume claims. */
    public record Claim(int exp, int skills, int trait, int goal) {}

    /** react: his answer to the last thing said; line: what he says now. banMinutes only with REJECTED. */
    public record View(Stage stage, String react, List<String> reactArgs, String line, List<String> lineArgs,
                       List<String> options, int mood, int banMinutes) {}

    public static final int SKILL_CHECKS = 2, TRIAL_DRINKS = 4, SKIP_PENALTY = 10, WALKOUT = 15;
    private static final String[] DRINKS = {"espresso", "americano", "latte", "cappuccino"};
    private static final int[][] GREET = {{5, 3, -5}, {6, -2, -6}, {4, 5, -4}};     // [kind][greeting]
    private static final int SKILLS = 8;
    private static final int[] ASK = {6, 4, -6};
    private static final String[] ASK_REPLY = {"learn", "team", "pay"};

    private final Boss boss;
    private final Claim claim;
    private final int truth, maxRank;
    private final Random rng;
    private final List<InterviewScript.Q> questions;
    private final List<Integer> checks = new ArrayList<>();
    private final int trialDrink;

    private Stage stage = Stage.GREET;
    private int impression, delta, question, check, exp, gap, rankOffer, verified, doubted, expState;
    private boolean usedHaggle;
    private List<Integer> codes = List.of();
    private View view;

    public InterviewFlow(Boss boss, Claim claim, int trueExp, boolean workedHere, int maxRank, Random rng) {
        this.boss = boss;
        this.claim = claim;
        this.truth = trueExp;
        this.maxRank = maxRank;
        this.rng = rng;
        this.exp = claim.exp();
        this.questions = InterviewScript.pick(boss.kind(), rng);
        this.trialDrink = rng.nextInt(TRIAL_DRINKS);

        List<Integer> claimed = new ArrayList<>();
        for (int i = 0; i < SKILLS; i++) if ((claim.skills() >> i & 1) != 0) claimed.add(i);
        Collections.shuffle(claimed, rng);
        claimed.sort((a, b) -> Boolean.compare(!valued(a), !valued(b)));            // what matters to him is checked first
        checks.addAll(claimed.subList(0, Math.min(SKILL_CHECKS, claimed.size())));

        int imp = 45;                                                               // the paper alone
        for (int s : boss.valued()) if ((claim.skills() >> s & 1) != 0) imp += 3;
        imp += claim.exp() * 3;
        if (claim.trait() == boss.likedTrait()) imp += 4;
        imp += claim.goal() == 2 ? 2 : claim.goal() == 0 ? (boss.kind() == 1 ? 4 : 2) : 0;
        if (workedHere) imp += 8;
        this.impression = clamp(imp);
    }

    private boolean valued(int skill) {
        for (int v : boss.valued()) if (v == skill) return true;
        return false;
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(100, v));
    }

    private void apply(int by) {
        int before = impression;
        impression = clamp(impression + by);
        delta += impression - before;
    }

    // ------------------------------------------------------------------ what the window needs

    public View view() { return view; }
    public Stage stage() { return stage; }
    public int impression() { return impression; }
    public int rankOffer() { return rankOffer; }
    public int trialDrink() { return trialDrink; }
    public int threshold() { return boss.threshold(); }

    /** How the last step changed the impression; asked once. */
    public int takeDelta() {
        int d = delta;
        delta = 0;
        return d;
    }

    /** The step of the progress line: 0 greeting, 1 questions, 2 checks, 3 trial, 4 contract. */
    public int progress() {
        return switch (stage) {
            case GREET -> 0;
            case QUESTION -> 1;
            case SKILL, CHECK, CALL, ASK -> 2;
            case TRIAL_OFFER, TRIAL -> 3;
            default -> 4;
        };
    }

    /**
     * The resume with the manager's marks, packed: exp (2 bits), trait (2), goal (2), claimed skills (8), confirmed
     * skills (8), doubted skills (8), experience mark (2: 0 unchecked, 1 true, 2 a lie).
     */
    public int sheet() {
        return claim.exp() | claim.trait() << 2 | claim.goal() << 4 | claim.skills() << 6 | verified << 14 | doubted << 22
                | expState << 30;
    }

    // ------------------------------------------------------------------ the course

    public View start(String name, List<String> resumeArgs) {
        List<String> args = new ArrayList<>(List.of(name));
        args.addAll(resumeArgs);
        return ask(Stage.GREET, "", List.of(), "interview.greet." + boss.id(), args, shuffled("interview.greet.a", 3), 0);
    }

    /** The player picked option number index of the current view. */
    public View answer(int index) {
        if (view == null || index < 0 || index >= view.options().size()) return view;
        int code = codes.get(index);
        return switch (stage) {
            case GREET -> {
                int d = GREET[boss.kind()][code];
                apply(d);
                yield nextQuestion("interview.greet.react." + code, d >= 4 ? 1 : d < 0 ? 2 : 0);
            }
            case QUESTION -> onQuestion(code);
            case SKILL -> onSkill(code);
            case CHECK -> onCheck(code);
            case CALL -> onCall();
            case ASK -> {
                apply(ASK[code]);
                yield trialOffer("interview.ask.reply." + ASK_REPLY[code], ASK[code] > 0 ? 1 : 2);
            }
            case TRIAL_OFFER -> {
                if (code == 0) {
                    yield ask(Stage.TRIAL, "", List.of(), "interview.trial.go." + boss.id(), trialArgs(), List.of("interview.close"), 1);
                }
                apply(-SKIP_PENALTY);
                yield verdict("interview.trial.skipped", 2);
            }
            case TRIAL -> {
                if (code == 0) yield view;                                           // "alright": he goes to do it
                apply(-SKIP_PENALTY);
                yield verdict("interview.trial.skipped", 2);
            }
            case OFFER -> onOffer(code);
            case CONTRACT -> code == 0 ? ask(Stage.HIRED, "", List.of(), "interview.hired", List.of(), List.of("interview.close"), 1)
                    : leave();
            default -> leave();
        };
    }

    /** He came back without the thing. */
    public View remind(String why) {
        if (stage != Stage.TRIAL) return view;
        codes = List.of(0, 1);
        view = new View(Stage.TRIAL, why, List.of(), "interview.trial.remind." + boss.id(), trialArgs(),
                List.of("interview.trial.ok", "interview.trial.giveup"), 0, 0);
        return view;
    }

    /** He brought it: the grade is the change of the impression, from -6 to 18. */
    public View trialDone(int grade) {
        if (stage != Stage.TRIAL) return view;
        apply(Math.max(-6, Math.min(18, grade)));
        return verdict(grade >= 12 ? "interview.trial.great" : grade >= 6 ? "interview.trial.good" : "interview.trial.weak",
                grade >= 6 ? 1 : 2);
    }

    private View nextQuestion(String react, int mood) {
        InterviewScript.Q q = questions.get(question);
        return ask(Stage.QUESTION, react, List.of(), "interview.q." + q.id(), List.of(), shuffled("interview.a." + q.id() + ".", 3), mood);
    }

    private View onQuestion(int code) {
        int d = questions.get(question).deltas()[code][boss.kind()];
        apply(d);
        question++;
        String react = (d >= 8 ? "interview.react.good." : d <= -6 ? "interview.react.bad." : "interview.react.ok.") + (1 + rng.nextInt(3));
        int mood = d >= 8 ? 1 : d <= -6 ? 2 : 0;
        if (impression <= WALKOUT) return reject(react, "interview.reject.walkout", 5, 2);
        if (question < questions.size()) return nextQuestion(react, mood);
        return nextSkill(react, mood);
    }

    private View nextSkill(String react, int mood) {
        if (check >= checks.size()) return experienceCheck(react, mood);
        String key = "interview.skill." + checks.get(check);
        return ask(Stage.SKILL, react, List.of(), key + ".q", List.of(), shuffled(key + ".a", 3), mood);
    }

    private View onSkill(int code) {
        int skill = checks.get(check++);
        boolean right = code == 0;
        if (right) verified |= 1 << skill;
        else doubted |= 1 << skill;
        apply(right ? 6 : -7);
        if (impression <= WALKOUT) return reject("interview.skill.bad", "interview.reject.walkout", 5, 2);
        return nextSkill(right ? "interview.skill.good" : "interview.skill.bad", right ? 1 : 2);
    }

    private View experienceCheck(String react, int mood) {
        gap = Math.max(0, exp - truth);
        if (gap > 0) {
            return ask(Stage.CHECK, react, List.of(), "interview.check", List.of(),
                    List.of("interview.check.a0", "interview.check.a1", "interview.check.a2"), mood);
        }
        expState = 1;
        if (exp >= 1) {                                                              // the records agree with the resume
            apply(4);
            return askQuestions("interview.verified", 1);
        }
        return askQuestions(react, mood);
    }

    private View onCheck(int code) {
        if (code == 1) {                                                             // a bluff: the phone call decides
            return ask(Stage.CALL, "", List.of(), "interview.calling", List.of(), List.of(""), 0);
        }
        expState = 2;
        exp = truth;
        apply(code == 0 ? 3 : -10);
        return askQuestions(code == 0 ? "interview.confess.react" : "interview.evade.react", code == 0 ? 1 : 0);
    }

    private View onCall() {
        double caught = Math.min(0.9D, 0.3D + 0.25D * gap + (boss.kind() == 1 ? 0.1D : 0.0D));
        if (rng.nextDouble() < caught) {
            expState = 2;
            return reject("", "interview.caught", 10, 2);
        }
        expState = 1;
        apply(6);
        return askQuestions("interview.call.ok", 1);
    }

    private View askQuestions(String react, int mood) {
        if (impression <= WALKOUT) return reject(react, "interview.reject.walkout", 5, 2);
        return ask(Stage.ASK, react, List.of(), "interview.ask", List.of(), shuffled("interview.ask.a", 3), mood);
    }

    private View trialOffer(String react, int mood) {
        // so far below the line that no trial can help: say no now and do not waste the applicant's time
        if (impression + 18 < boss.threshold()) return reject(react, "interview.reject.low", 5, 2);
        return ask(Stage.TRIAL_OFFER, react, List.of(), "interview.trial." + boss.id(), trialArgs(),
                List.of("interview.trial.accept", "interview.trial.skip"), mood);
    }

    private List<String> trialArgs() {
        return boss.kind() == 0 ? List.of("t:drink.aestheticjobs." + DRINKS[trialDrink]) : List.of();
    }

    private View verdict(String react, int mood) {
        if (impression < boss.threshold()) {
            return reject(react, "interview.reject.low", 5, impression < boss.threshold() - 15 ? 2 : 0);
        }
        rankOffer = impression >= 85 && exp >= 2 ? Math.min(1, maxRank) : 0;
        return offer(react, mood);
    }

    private View offer(String react, int mood) {
        List<String> options = new ArrayList<>(List.of("interview.offer.a0"));
        List<Integer> what = new ArrayList<>(List.of(0));
        boolean mayHaggle = !usedHaggle && rankOffer + 1 <= maxRank && impression >= boss.threshold() + 8;
        if (mayHaggle) {
            options.add("interview.offer.a1");
            what.add(1);
        }
        options.add("interview.offer.a2");
        what.add(2);
        View v = ask(Stage.OFFER, react, List.of(), "interview.offer", List.of(), options, mood);
        codes = what;
        return v;
    }

    private View onOffer(int code) {
        if (code == 0) {
            return ask(Stage.CONTRACT, "", List.of(), "interview.contract", List.of(),
                    List.of("interview.contract.sign", "interview.contract.later"), 1);
        }
        if (code != 1) return leave();                                              // "I will think": nothing is lost
        usedHaggle = true;
        double chance = Math.max(0.15D, Math.min(0.7D, 0.2D + (impression - 50) / 100.0D));
        if (rng.nextDouble() < chance) {
            rankOffer++;
            return offer("interview.haggle.ok", 1);
        }
        if (rng.nextDouble() < 0.35D) return reject("", "interview.haggle.withdrawn", 3, 2);
        return offer("interview.haggle.no", 2);
    }

    private View reject(String react, String line, int minutes, int mood) {
        View v = ask(Stage.REJECTED, react, List.of(), line,
                line.equals("interview.reject.low") ? List.of(Integer.toString(minutes)) : List.of(), List.of("interview.close"), mood);
        view = new View(v.stage(), v.react(), v.reactArgs(), v.line(), v.lineArgs(), v.options(), v.mood(), minutes);
        return view;
    }

    private View leave() {
        return ask(Stage.LEFT, "", List.of(), "", List.of(), List.of(), 0);
    }

    // ------------------------------------------------------------------ helpers

    /** The keys prefix0..prefix(n-1) in random order; the codes remember which is which (0 is the best answer). */
    private List<String> shuffled(String prefix, int n) {
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < n; i++) order.add(i);
        Collections.shuffle(order, rng);
        pending = order;
        List<String> keys = new ArrayList<>();
        for (int i : order) keys.add(prefix + i);
        return keys;
    }

    private List<Integer> pending;

    private View ask(Stage next, String react, List<String> reactArgs, String line, List<String> lineArgs, List<String> options, int mood) {
        stage = next;
        if (pending != null) {
            codes = pending;
            pending = null;
        } else {
            List<Integer> plain = new ArrayList<>();
            for (int i = 0; i < options.size(); i++) plain.add(i);
            codes = plain;
        }
        view = new View(next, react, reactArgs, line, lineArgs, options, mood, 0);
        return view;
    }
}
