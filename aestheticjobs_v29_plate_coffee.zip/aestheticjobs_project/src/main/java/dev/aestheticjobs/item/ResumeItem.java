package dev.aestheticjobs.item;

import dev.aestheticjobs.client.ClientHooks;
import dev.aestheticjobs.job.interview.Resumes;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** The resume. Right-click: the form opens (fill it in, or change it); a filled one is handed to the manager of the job. */
public class ResumeItem extends Item {
    public ResumeItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) {
            ClientHooks.openResume(hand == InteractionHand.OFF_HAND ? 1 : 0, stack);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        if (!Resumes.isFilled(stack)) {
            tooltip.add(Component.translatable("item.aestheticjobs.resume.blank").withStyle(ChatFormatting.GRAY));
            return;
        }
        Resumes.Data d = Resumes.read(stack);
        tooltip.add(Component.literal(d.name()).withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable("resume.form.exp").append(": ").append(Component.translatable("resume.exp." + d.exp())).withStyle(ChatFormatting.GRAY));
        List<Component> skills = new ArrayList<>();
        for (int i = 0; i < Resumes.SKILL_COUNT; i++) {
            if ((d.skills() >> i & 1) != 0) skills.add(Component.translatable("resume.skill." + i));
        }
        Component joined = Component.empty();
        for (int i = 0; i < skills.size(); i++) joined = Component.empty().append(joined).append(i == 0 ? "" : ", ").append(skills.get(i));
        tooltip.add(Component.translatable("resume.form.skills").append(": ").append(skills.isEmpty() ? Component.translatable("resume.skill.none") : joined).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("resume.form.trait").append(": ").append(Component.translatable("resume.trait." + d.trait())).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("resume.form.goal").append(": ").append(Component.translatable("resume.goal." + d.goal())).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("item.aestheticjobs.resume.hint").withStyle(ChatFormatting.DARK_GRAY));
    }
}
