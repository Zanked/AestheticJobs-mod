package dev.aestheticjobs.item;

import dev.aestheticjobs.cafe.CupData;
import dev.aestheticjobs.cafe.Plate;
import dev.aestheticjobs.registry.ModComponents;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/**
 * A plate with a dessert from the chef. It is not food: the barista hands it to the customer together with the cup.
 * It gets cold (the plate disappears) after a few minutes, see {@link Plate}.
 */
public class DessertPlateItem extends Item {
    public DessertPlateItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public Component getName(ItemStack stack) {
        Plate plate = stack.get(ModComponents.PLATE.get());
        Dessert dessert = plate == null ? null : Dessert.byIndex(plate.dessert());
        return dessert == null ? super.getName(stack)
                : Component.translatable("item.aestheticjobs.dessert_plate.named", dessert.displayName());
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        Plate plate = stack.get(ModComponents.PLATE.get());
        Level level = context.level();
        if (plate != null && level != null) {
            long left = (plate.expires() - level.getGameTime()) / 20L;
            if (left < 100_000L) {
                tooltip.add(Component.translatable("item.aestheticjobs.dessert_plate.cools", Math.max(0L, left))
                        .withStyle(ChatFormatting.GRAY));
            }
        }
        if (plate != null && plate.stars() > 0) {
            tooltip.add(Component.translatable("item.aestheticjobs.dessert_plate.handmade", CupData.starText(plate.stars()))
                    .withStyle(ChatFormatting.GOLD));
        }
        tooltip.add(Component.translatable("item.aestheticjobs.dessert_plate.hint").withStyle(ChatFormatting.DARK_GRAY));
    }

    /** A cold plate is thrown away. */
    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide) return;
        Plate plate = stack.get(ModComponents.PLATE.get());
        if (plate != null && !plate.fresh(level.getGameTime())) {
            stack.shrink(1);
        }
    }
}
