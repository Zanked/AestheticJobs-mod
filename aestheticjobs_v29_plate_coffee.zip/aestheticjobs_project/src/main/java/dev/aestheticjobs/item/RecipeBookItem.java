package dev.aestheticjobs.item;

import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.KitchenData;
import dev.aestheticjobs.cafe.Order;
import dev.aestheticjobs.cafe.kitchen.Knowledge;
import dev.aestheticjobs.cafe.kitchen.Menu;
import dev.aestheticjobs.network.OpenBookPayload;
import dev.aestheticjobs.registry.ModComponents;
import java.util.Arrays;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.network.PacketDistributor;

/** The recipe book of the cafe: how every drink and dessert is made, and what the player has found out. */
public class RecipeBookItem extends Item {
    public RecipeBookItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (player instanceof ServerPlayer server) open(server, null);
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }

    /** @param bowl the mixing bowl a dessert is being chosen for, or null to only read */
    public static void open(ServerPlayer player, @Nullable BlockPos bowl) {
        Knowledge knowledge = KitchenData.get(player.server).of(player.getUUID());
        List<Integer> tried = Arrays.stream(knowledge.triedCopy()).boxed().toList();
        ItemStack ticket = CafeLogic.findTicket(player);
        Order order = ticket.isEmpty() ? null : ticket.get(ModComponents.ORDER.get());
        int drink = order == null ? -1 : order.drink();
        int dessert = order == null || order.dessert() < 0 ? -1 : Menu.dessertIndex(order.dessert());
        PacketDistributor.sendToPlayer(player, new OpenBookPayload(bowl != null, bowl == null ? BlockPos.ZERO : bowl,
                tried, knowledge.foundBits(), drink, dessert));
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.aestheticjobs.recipe_book.hint").withStyle(ChatFormatting.GRAY));
    }
}
