package dev.aestheticjobs.item;

import dev.aestheticjobs.registry.ModComponents;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomModelData;

/** The handle of the espresso machine: filled at the grinder, emptied into the machine. */
public class PortafilterItem extends Item {
    public PortafilterItem(Item.Properties properties) {
        super(properties);
    }

    public static boolean filled(ItemStack stack) {
        return stack.getOrDefault(ModComponents.GROUND.get(), false);
    }

    /** custom_model_data 1 shows the coffee in it. */
    public static void fill(ItemStack stack, boolean full) {
        if (full) {
            stack.set(ModComponents.GROUND.get(), true);
            stack.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(1));
        } else {
            stack.remove(ModComponents.GROUND.get());
            stack.remove(DataComponents.CUSTOM_MODEL_DATA);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        String key = "item.aestheticjobs.portafilter." + (filled(stack) ? "full" : "empty");
        tooltip.add(Component.translatable(key).withStyle(ChatFormatting.GRAY));
    }
}
