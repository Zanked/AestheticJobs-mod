package dev.aestheticjobs.item;

import dev.aestheticjobs.block.StationBlockEntity;
import dev.aestheticjobs.cafe.kitchen.Menu;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.registry.ModItems;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

/** Whisked dough from the mixing bowl, ready for the pastry oven. */
public class DoughItem extends Item {
    public DoughItem(Item.Properties properties) {
        super(properties);
    }

    public static ItemStack of(int base) {
        ItemStack stack = new ItemStack(ModItems.DOUGH.get());
        stack.set(ModComponents.DOUGH.get(), base);
        return stack;
    }

    /** The dessert (index in the menu) it becomes, -1 for dough without one. */
    public static int recipe(ItemStack stack) {
        int base = stack.getOrDefault(ModComponents.DOUGH.get(), -1);
        Menu.Base b = Menu.get(base);
        return b == null || b.isDrink() ? -1 : base;
    }

    @Override
    public Component getName(ItemStack stack) {
        int base = recipe(stack);
        return base < 0 ? super.getName(stack)
                : Component.translatable("item.aestheticjobs.dough.of", StationBlockEntity.recipeName(base, 0));
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.aestheticjobs.dough.hint").withStyle(ChatFormatting.GRAY));
    }
}
