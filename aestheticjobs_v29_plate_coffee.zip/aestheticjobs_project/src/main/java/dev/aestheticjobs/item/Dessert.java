package dev.aestheticjobs.item;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.registry.ModItems;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;

/**
 * Cafe desserts: one edible item per entry (texture tools/gen_desserts.py, lang item.aestheticjobs.<id>).
 * Customers of the cafe may order one together with their drink (see cafe/Order, cafe/CafeLogic).
 */
public enum Dessert {
    CROISSANT("croissant", 4, 0.5f, 300),
    DONUT_PINK("donut_pink", 4, 0.4f, 250),
    DONUT_CHOC("donut_choc", 4, 0.4f, 250),
    CUPCAKE_PINK("cupcake_pink", 4, 0.4f, 300),
    CUPCAKE_CHOC("cupcake_choc", 4, 0.4f, 300),
    MUFFIN_BLUEBERRY("muffin_blueberry", 5, 0.5f, 320),
    CREAM_PUFF("cream_puff", 3, 0.4f, 350),
    ECLAIR("eclair", 4, 0.5f, 350),
    CINNAMON_ROLL("cinnamon_roll", 6, 0.6f, 380),
    COOKIE_CHOC("cookie_choc", 2, 0.3f, 200),
    COOKIE_HEART("cookie_heart", 2, 0.3f, 220),
    GINGERBREAD_MAN("gingerbread_man", 3, 0.4f, 250),
    MACARON_PINK("macaron_pink", 2, 0.3f, 280),
    MACARON_MINT("macaron_mint", 2, 0.3f, 280),
    MACARON_LEMON("macaron_lemon", 2, 0.3f, 280),
    CAKE_POP("cake_pop", 3, 0.4f, 300),
    CHEESECAKE("cheesecake", 6, 0.6f, 500),
    CAKE_STRAWBERRY("cake_strawberry", 6, 0.6f, 520),
    CAKE_CHOC("cake_choc", 6, 0.6f, 520),
    TIRAMISU("tiramisu", 6, 0.6f, 550),
    APPLE_PIE("apple_pie", 6, 0.6f, 480),
    MEDOVIK("medovik", 6, 0.6f, 500),
    BROWNIE("brownie", 4, 0.5f, 350),
    WAFFLE("waffle", 5, 0.5f, 450),
    PANCAKES("pancakes", 6, 0.6f, 480),
    ICE_CREAM_CONE("ice_cream_cone", 5, 0.5f, 350),
    SUNDAE("sundae", 7, 0.6f, 600),
    CREME_BRULEE("creme_brulee", 6, 0.6f, 580),
    PANNA_COTTA("panna_cotta", 5, 0.6f, 520),
    FLAN("flan", 5, 0.6f, 450),
    FRUIT_TART("fruit_tart", 5, 0.6f, 520),
    BAKLAVA("baklava", 5, 0.6f, 400);

    private final String id;
    private final int nutrition;
    private final float saturation;
    private final long priceCents;

    Dessert(String id, int nutrition, float saturation, long priceCents) {
        this.id = id;
        this.nutrition = nutrition;
        this.saturation = saturation;
        this.priceCents = priceCents;
    }

    public String id() {
        return id;
    }

    public long priceCents() {
        return priceCents;
    }

    public FoodProperties food() {
        return new FoodProperties.Builder().nutrition(nutrition).saturationModifier(saturation).build();
    }

    public Item item() {
        return ModItems.DESSERTS.get(this).get();
    }

    public Component displayName() {
        return Component.translatable("item." + AestheticJobs.MODID + "." + id);
    }

    /** The 32x32 item picture, also drawn in the customer's thought bubble. */
    public ResourceLocation iconTexture() {
        return ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "textures/item/" + id + ".png");
    }

    /** The dessert an item is, null for any other item. */
    public static Dessert ofItem(Item item) {
        for (Dessert d : values()) {
            if (d.item() == item) return d;
        }
        return null;
    }

    public static Dessert byIndex(int i) {
        Dessert[] all = values();
        return i >= 0 && i < all.length ? all[i] : null;
    }
}
