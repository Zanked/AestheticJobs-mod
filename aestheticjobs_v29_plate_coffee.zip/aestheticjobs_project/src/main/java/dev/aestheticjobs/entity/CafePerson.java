package dev.aestheticjobs.entity;

import dev.aestheticjobs.cafe.anim.PoseInput;

/** An NPC of the cafe that is drawn with the player-like model (CafePersonModel): tells the animation what it is doing. */
public interface CafePerson {
    /** Client: fills what the animation needs (mode, time in the mode, ...). The walk values are set by the model. */
    void fillPose(PoseInput in, float ageInTicks);

    /** Which of the skins (textures/entity/person_N_face.png) this person wears. */
    int personSkin();

    /** Face of the skin now: 0 neutral, 1 blink, 2 happy, 3 angry. */
    int faceIndex(float ageInTicks);

    /** The chef wears the tall hat. */
    boolean wearsToque();
}
