package dev.aestheticjobs.entity;

import dev.aestheticjobs.cafe.anim.PersonRig;
import dev.aestheticjobs.cafe.anim.PoseInput;
import dev.aestheticjobs.cafe.anim.Poses;
import dev.aestheticjobs.cafe.anim.StaffAction;
import dev.aestheticjobs.job.interview.Interview;
import dev.aestheticjobs.job.interview.ManagerKind;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * The manager of a job (one entity type per job): he stands at the workplace, takes the resume and interviews the
 * applicant (see {@link Interview}). The face shows his mood during the interview (the screen draws this very entity).
 */
public class JobManagerEntity extends PathfinderMob implements CafePerson {
    private static final EntityDataAccessor<Integer> DATA_MOOD = SynchedEntityData.defineId(JobManagerEntity.class, EntityDataSerializers.INT);

    private final ManagerKind kind;
    /** Server tick when the face goes back to neutral. */
    private int moodUntil;

    public JobManagerEntity(EntityType<? extends JobManagerEntity> type, Level level, ManagerKind kind) {
        super(type, level);
        this.kind = kind;
        setInvulnerable(true);
        setPersistenceRequired();
        setCustomName(Component.translatable("manager.aestheticjobs." + kind.id));
        setCustomNameVisible(true);
    }

    public ManagerKind kind() {
        return kind;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_MOOD, 0);
    }

    /** 0 neutral, 1 happy, 2 angry. The face goes back to neutral after a while. */
    public void setMood(int mood) {
        entityData.set(DATA_MOOD, mood);
        moodUntil = mood == 0 ? 0 : tickCount + 160;
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && moodUntil > 0 && tickCount > moodUntil && entityData.get(DATA_MOOD) != 0) {
            setMood(0);
        }
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!level().isClientSide && player instanceof ServerPlayer sp) {
            Interview.begin(sp, this);
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 10.0D).add(Attributes.MOVEMENT_SPEED, 0.2D);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 8.0F));
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    // ------------------------------------------------------------------ the player-like model

    @Override
    public void fillPose(PoseInput in, float ageInTicks) {
        in.age = ageInTicks;
        in.seed = getId();
        in.mode = StaffAction.IDLE;
        in.t = ageInTicks;
    }

    @Override
    public int personSkin() {
        return kind.skin;
    }

    @Override
    public int faceIndex(float ageInTicks) {
        int m = entityData.get(DATA_MOOD);
        int mood = m == 1 ? PersonRig.MOOD_HAPPY : m == 2 ? PersonRig.MOOD_ANGRY : PersonRig.MOOD_NEUTRAL;
        return Poses.face(mood, Poses.blink(ageInTicks, getId()));
    }

    @Override
    public boolean wearsToque() {
        return false;
    }
}
