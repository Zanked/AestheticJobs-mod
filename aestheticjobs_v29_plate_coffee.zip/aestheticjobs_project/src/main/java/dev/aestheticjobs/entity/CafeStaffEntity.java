package dev.aestheticjobs.entity;

import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.CafeOrders;
import dev.aestheticjobs.cafe.CafeRegisters;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.Pairing;
import dev.aestheticjobs.cafe.Personality;
import dev.aestheticjobs.cafe.Plate;
import dev.aestheticjobs.cafe.anim.PoseInput;
import dev.aestheticjobs.cafe.anim.Poses;
import dev.aestheticjobs.cafe.anim.StaffAction;
import dev.aestheticjobs.cafe.Order;
import dev.aestheticjobs.economy.Bank;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.economy.Transaction;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.registry.ModBlocks;
import dev.aestheticjobs.registry.ModItems;
import dev.aestheticjobs.registry.ModSounds;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.OpenDoorGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.navigation.GroundPathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.AbstractFurnaceBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * The staff of the cafe, two roles (two entity types, the same class). Nobody gives them orders: they work by themselves.
 *
 * CHEF: a pastry chef, no menu. He decides what to bake: first what the baristas asked for (the queue), otherwise he keeps
 * a small stock of desserts that sell (what customers order most, see {@link #pickProactive}). He bakes in a regular
 * furnace next to him (it lights up), and every ready plate he carries himself to the NPC barista, hands it over and goes
 * back to the furnace. Without an NPC barista the plates wait on his tray (a player barista takes them at the register).
 *
 * BARISTA: an NPC barista. He works through a list of jobs: the paid orders of real players and the NPC customers at his
 * register. He makes one drink at a time, never waits idle while there is a job, never lets a missing dessert block the
 * rest (the cup waits aside, the chef is asked again, after a while the cup goes out without the dessert), and takes over
 * jobs that nobody is working on any more (after a reload, or when another barista disappeared).
 */
public class CafeStaffEntity extends PathfinderMob implements CafePerson {
    public enum Role { CHEF, BARISTA }

    /** Plates on the chef's tray that nobody took yet (he carries them to the barista as soon as there is room). */
    public static final int TRAY = 3;
    /** Plates on the barista's shelf, brought by the chef. */
    public static final int SHELF = 6;
    /** The chef bakes ahead until this many plates are ready (on his tray and on the shelves), then he rests. */
    public static final int STOCK_TARGET = 2;
    public static final long PLATE_LIFE = 6000L;          // 5 minutes
    public static final int BAKE_TICKS = 600;             // 30 seconds a plate
    public static final int MAX_CHEFS = 4;
    public static final int MAX_BARISTAS = 2;
    public static final int MAX_QUEUE = 6;
    /** A paid order waits this long for a player barista before the NPC barista takes it (when nobody takes it earlier). */
    public static final long NPC_TAKES_AFTER = 800L;
    /** A ready order is kept this long for the buyer. */
    public static final long READY_LIFE = 6000L;
    /** A made cup waits this long for its dessert, then it goes out without it (and the dessert is refunded). */
    private static final long PLATE_WAIT_TICKS = 2400L;
    private static final int TRIP_TIMEOUT = 500;

    private static final int C_BAKE = 0, C_DELIVER = 1, C_RETURN = 2;

    private static final net.minecraft.network.syncher.EntityDataAccessor<Integer> DATA_ACTION =
            net.minecraft.network.syncher.SynchedEntityData.defineId(CafeStaffEntity.class,
                    net.minecraft.network.syncher.EntityDataSerializers.INT);

    private final Role role;
    /** Server: what the staff does (synced to the client animation) and the timers that drive it. */
    private boolean working;
    private int oneShotUntil = -1;
    private int oneShotAction;
    private int wipeAt = 400;
    /** Client: tick when the current action started. */
    private int clientActionStart;

    // ---- chef ----
    private final List<Plate> tray = new ArrayList<>();
    /** Desserts the baristas asked this chef to bake (in order); they are baked before anything he plans himself. */
    private final java.util.ArrayDeque<Integer> queue = new java.util.ArrayDeque<>();
    /** The dessert in the furnace now (-1 = nothing), and whether somebody asked for it (an asked one is never dropped for another). */
    private int baking = -1;
    private boolean bakingAsked;
    private int bake;
    /** How often every dessert was ordered near this chef lately (halves every 5 minutes): what he plans to bake ahead. */
    private final int[] demand = new int[Dessert.values().length];
    private int chefState = C_BAKE;
    private int stateTicks;
    @Nullable private BlockPos home;
    @Nullable private UUID deliverTo;
    /** The plate a barista player waits for (-1 = the chef brings everything he has, to the NPC barista). */
    private int deliverDessert = -1;
    @Nullable private BlockPos faceTarget;
    @Nullable private BlockPos furnace;
    @Nullable private BlockPos lit;
    private static int[] baseline;

    // ---- barista ----
    private static final class Job {
        @Nullable final UUID customer;
        @Nullable final CafeOrders.Entry order;
        final int drink;
        final int dessert;
        boolean plated;
        long doneAt;
        long waitSince;
        long lastAsk;

        Job(@Nullable UUID customer, @Nullable CafeOrders.Entry order, int drink, int dessert, boolean plated, long doneAt) {
            this.customer = customer;
            this.order = order;
            this.drink = drink;
            this.dessert = dessert;
            this.plated = plated || dessert < 0;
            this.doneAt = doneAt;
        }
    }

    @Nullable private BlockPos register;
    /** Plates the chef brought. */
    private final List<Plate> shelf = new ArrayList<>();
    /** The cup in the machine now, and the cups that are ready but wait for their plate. */
    @Nullable private Job making;
    private final List<Job> waiting = new ArrayList<>();

    private boolean limitChecked;
    private String shownName = "";

    public CafeStaffEntity(EntityType<? extends CafeStaffEntity> type, Level level, Role role) {
        super(type, level);
        this.role = role;
        setInvulnerable(true);
        setPersistenceRequired();
        setCustomNameVisible(true);
        if (getNavigation() instanceof GroundPathNavigation nav) {
            nav.setCanOpenDoors(true);
        }
    }

    @Override
    protected void defineSynchedData(net.minecraft.network.syncher.SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_ACTION, StaffAction.IDLE);
    }

    public int action() {
        return entityData.get(DATA_ACTION);
    }

    @Override
    public void onSyncedDataUpdated(net.minecraft.network.syncher.EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);
        if (DATA_ACTION.equals(key) && level().isClientSide) clientActionStart = tickCount;
    }

    /** Server: plays a one-shot animation (serve a cup, present a plate) with something in the hand. */
    private void playOnce(int action, int ticks, ItemStack held) {
        oneShotAction = action;
        oneShotUntil = tickCount + ticks;
        setItemSlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND, held);
        setDropChance(net.minecraft.world.entity.EquipmentSlot.MAINHAND, 0.0F);
    }

    private void setHeld(ItemStack held) {
        if (!ItemStack.matches(getMainHandItem(), held)) {
            setItemSlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND, held);
            setDropChance(net.minecraft.world.entity.EquipmentSlot.MAINHAND, 0.0F);
        }
    }

    private void faceBlock(@Nullable BlockPos p) {
        if (p == null) return;
        double dx = p.getX() + 0.5D - getX(), dz = p.getZ() + 0.5D - getZ();
        if (dx * dx + dz * dz < 0.04D) return;
        float yaw = (float) (net.minecraft.util.Mth.atan2(dz, dx) * 57.29578D) - 90.0F;
        float turned = net.minecraft.util.Mth.approachDegrees(yBodyRot, yaw, 14.0F);
        setYRot(turned);
        setYBodyRot(turned);
        setYHeadRot(turned);
    }

    /** Server, every tick: decides which animation plays (barista: machine / serve / wipe; chef: knead / oven / watch / present / walk). */
    private void updateAction() {
        int a = StaffAction.IDLE;
        ItemStack held = ItemStack.EMPTY;
        BlockPos target = null;
        if (oneShotUntil > tickCount) {
            a = oneShotAction;
            held = getMainHandItem();
            target = role == Role.CHEF ? (faceTarget != null ? faceTarget : furnace) : register;
        } else if (role == Role.BARISTA) {
            if (working) {
                a = StaffAction.MACHINE;
                held = new ItemStack(ModItems.EMPTY_CUP.get());
                target = register;
            } else if (wipeAt <= tickCount && wipeAt + StaffAction.WIPE_TICKS > tickCount && register != null) {
                a = StaffAction.WIPE;
                target = register;
            } else if (wipeAt + StaffAction.WIPE_TICKS <= tickCount) {
                wipeAt = tickCount + 500 + random.nextInt(900);
            }
        } else if (chefState != C_BAKE) {
            if (chefState == C_DELIVER && !tray.isEmpty()) {            // walks with the plate in his hands
                Plate p = tray.get(0);
                held = CafeLogic.makePlate(p.dessert(), p.expires());
            }
        } else if (baking >= 0 && furnace != null) {
            target = furnace;
            if (bake < 330) a = StaffAction.KNEAD;
            else if (bake < 520) a = StaffAction.WATCH;
            else {
                a = StaffAction.OVEN;
                held = new ItemStack(ModItems.DESSERT_PLATE.get());
            }
        }
        if (a != action()) entityData.set(DATA_ACTION, a);
        setHeld(held);
        if (target != null) faceBlock(target);
    }

    // ------------------------------------------------------------------ the player-like model (client)

    @Override
    public void fillPose(PoseInput in, float ageInTicks) {
        in.age = ageInTicks;
        in.seed = getId();
        in.mode = action();
        in.t = ageInTicks - clientActionStart;
    }

    @Override
    public int personSkin() {
        return role == Role.CHEF ? 8 : 9;
    }

    @Override
    public int faceIndex(float ageInTicks) {
        int mood = StaffAction.mood(action());
        return Poses.face(mood, Poses.blink(ageInTicks, getId()));
    }

    @Override
    public boolean wearsToque() {
        return role == Role.CHEF;
    }

    public Role role() {
        return role;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new OpenDoorGoal(this, true));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    // ------------------------------------------------------------------ helpers for the register (chefs and baristas near it)

    private static List<CafeStaffEntity> staffNear(ServerLevel level, BlockPos at, Role role) {
        return staffAround(level, at, role, CafeLogic.STAFF_RADIUS);
    }

    private static List<CafeStaffEntity> staffAround(ServerLevel level, BlockPos at, Role role, double r) {
        return level.getEntitiesOfClass(CafeStaffEntity.class, new AABB(at).inflate(r), e -> e.role == role && e.isAlive());
    }

    /** The desserts that are ready near the register (on a barista's shelf or a chef's tray, without repeats). */
    public static List<Integer> availableDesserts(ServerLevel level, BlockPos register) {
        long now = level.getGameTime();
        Set<Integer> set = new LinkedHashSet<>();
        for (CafeStaffEntity b : staffNear(level, register, Role.BARISTA)) {
            for (Plate p : b.shelf) if (p.fresh(now)) set.add(p.dessert());
        }
        for (CafeStaffEntity chef : staffNear(level, register, Role.CHEF)) {
            for (Plate p : chef.tray) if (p.fresh(now)) set.add(p.dessert());
        }
        return new ArrayList<>(set);
    }

    /** Is there a chef near the register at all? (Then every dessert can be ordered: he bakes it on demand.) */
    public static boolean hasChef(ServerLevel level, BlockPos register) {
        return !staffNear(level, register, Role.CHEF).isEmpty();
    }

    /** Does a chef near the register have room in the queue for one more dessert? */
    public static boolean canRequest(ServerLevel level, BlockPos register) {
        for (CafeStaffEntity chef : staffNear(level, register, Role.CHEF)) {
            if (chef.queue.size() < MAX_QUEUE) return true;
        }
        return false;
    }

    /** The barista tells a chef (the least busy one) to bake this dessert. False if there is no chef or all have a full queue. */
    public static boolean request(ServerLevel level, BlockPos register, int dessert) {
        if (Dessert.byIndex(dessert) == null) return false;
        CafeStaffEntity best = null;
        for (CafeStaffEntity chef : staffNear(level, register, Role.CHEF)) {
            if (chef.queue.size() >= MAX_QUEUE) continue;
            if (best == null || chef.queue.size() + chef.tray.size() < best.queue.size() + best.tray.size()) best = chef;
        }
        if (best == null) return false;
        best.queue.addLast(dessert);
        return true;
    }

    /** Is somebody already baking this dessert or has it in the queue? (Then asking again would only bake it twice.) */
    private static boolean isQueued(ServerLevel level, BlockPos register, int dessert) {
        for (CafeStaffEntity chef : staffNear(level, register, Role.CHEF)) {
            if (chef.queue.contains(dessert) || chef.baking == dessert) return true;
        }
        return false;
    }

    /** Makes sure this dessert is on its way: there is a ready plate, or somebody bakes it, or it is asked now (nothing happens without a chef). */
    public static void ensureBaked(ServerLevel level, BlockPos register, int dessert) {
        if (hasPlate(level, register, dessert) || isQueued(level, register, dessert)) return;
        request(level, register, dessert);
    }

    private static boolean removeFresh(List<Plate> list, int dessert, long now) {
        for (int i = 0; i < list.size(); i++) {
            Plate p = list.get(i);
            if (p.dessert() == dessert && p.fresh(now)) {
                list.remove(i);
                return true;
            }
        }
        return false;
    }

    private static boolean hasFresh(List<Plate> list, int dessert, long now) {
        for (Plate p : list) if (p.dessert() == dessert && p.fresh(now)) return true;
        return false;
    }

    /** Takes one plate of this dessert near the register: first from a barista's shelf, then from a chef's tray. False if there is none. */
    public static boolean takePlate(ServerLevel level, BlockPos register, int dessert) {
        long now = level.getGameTime();
        for (CafeStaffEntity b : staffNear(level, register, Role.BARISTA)) {
            if (removeFresh(b.shelf, dessert, now)) return true;
        }
        for (CafeStaffEntity chef : staffNear(level, register, Role.CHEF)) {
            if (removeFresh(chef.tray, dessert, now)) return true;
        }
        return false;
    }

    /** Is there a ready plate of this dessert near the register? (It is not taken.) */
    public static boolean hasPlate(ServerLevel level, BlockPos register, int dessert) {
        long now = level.getGameTime();
        for (CafeStaffEntity b : staffNear(level, register, Role.BARISTA)) {
            if (hasFresh(b.shelf, dessert, now)) return true;
        }
        for (CafeStaffEntity chef : staffNear(level, register, Role.CHEF)) {
            if (hasFresh(chef.tray, dessert, now)) return true;
        }
        return false;
    }

    /** Somebody ordered this dessert at the register: the chefs near it learn what sells. */
    public static void noteDemand(ServerLevel level, BlockPos register, int dessert) {
        if (Dessert.byIndex(dessert) == null) return;
        for (CafeStaffEntity chef : staffNear(level, register, Role.CHEF)) {
            chef.demand[dessert] = Math.min(60, chef.demand[dessert] + 1);
        }
    }

    @Nullable
    public static CafeStaffEntity baristaNear(ServerLevel level, BlockPos register) {
        List<CafeStaffEntity> list = staffNear(level, register, Role.BARISTA);
        return list.isEmpty() ? null : list.get(0);
    }

    // ------------------------------------------------------------------ interaction

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!level().isClientSide && player instanceof ServerPlayer sp) {
            if (role == Role.CHEF) {
                findFurnace();
                sp.displayClientMessage(furnace == null ? Component.translatable("staff.chef.need_furnace")
                        : Component.translatable("staff.chef.talk"), true);
            } else {
                baristaInteract(sp);
            }
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    private void baristaInteract(ServerPlayer player) {
        CafeOrders orders = CafeOrders.get(player.server);
        CafeOrders.Entry e = orders.ofBuyer(player.getUUID());
        if (e == null) {
            player.displayClientMessage(Component.translatable("staff.barista.hint"), true);
            return;
        }
        if (e.status != CafeOrders.READY) {
            player.displayClientMessage(Component.translatable("staff.barista.not_ready"), true);
            return;
        }
        Drink drink = Drink.byIndex(e.drink);
        if (drink == null) {
            orders.remove(e);
            return;
        }
        for (ItemStack out : CafeLogic.purchaseItems(e, CafeLogic.npcCup(drink))) {
            player.getInventory().placeItemBackInInventory(out);
        }
        orders.remove(e);
        level().playSound(null, blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.NEUTRAL, 0.9F, 1.3F);
        player.sendSystemMessage(Component.translatable("cafe.order.received", getDisplayName()));
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (!limitChecked && tickCount > 2) {
            limitChecked = true;
            if (overLimit()) return;
        }
        if (role == Role.CHEF) {
            tickChef();
        } else {
            tickBarista();
        }
        updateAction();
        if (tickCount % 20 == 0) refreshName();
    }

    /** Too many staff of this role around: the newest one is taken back as a spawn egg. */
    private boolean overLimit() {
        ServerLevel sl = (ServerLevel) level();
        int limit = role == Role.CHEF ? MAX_CHEFS : MAX_BARISTAS;
        int older = 0;
        for (CafeStaffEntity e : sl.getEntitiesOfClass(CafeStaffEntity.class, getBoundingBox().inflate(CafeLogic.STAFF_RADIUS),
                x -> x != this && x.role == role && x.tickCount > tickCount)) {
            older++;
        }
        if (older < limit) return false;
        ItemStack egg = new ItemStack(role == Role.CHEF ? ModItems.CAFE_CHEF_SPAWN_EGG.get() : ModItems.CAFE_BARISTA_SPAWN_EGG.get());
        spawnAtLocation(egg);
        Player p = sl.getNearestPlayer(this, 8.0D);
        if (p != null) {
            p.displayClientMessage(Component.translatable("staff.limit", limit), true);
        }
        discard();
        return true;
    }

    private void refreshName() {
        Component name;
        if (role == Role.CHEF) {
            Dessert d = Dessert.byIndex(baking);
            if (furnace == null && d != null) {
                name = Component.translatable("staff.chef.no_furnace");
            } else if (chefState == C_DELIVER) {
                name = Component.translatable("staff.chef.delivering");
            } else if (d == null) {
                name = Component.translatable("staff.chef.idle");
            } else {
                name = Component.translatable("staff.chef.baking", d.displayName(), Math.min(100, bake * 100 / BAKE_TICKS));
            }
        } else {
            name = Component.translatable("staff.barista.name");
        }
        String key = name.getString();
        if (!key.equals(shownName)) {
            shownName = key;
            setCustomName(name);
        }
    }

    // ------------------------------------------------------------------ chef

    private void findFurnace() {
        if (furnace != null && level().getBlockState(furnace).is(Blocks.FURNACE)) return;
        furnace = null;
        BlockPos c = home != null ? home : blockPosition();
        double best = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-4, -2, -4), c.offset(4, 2, 4))) {
            if (!level().getBlockState(p).is(Blocks.FURNACE)) continue;
            double d = p.distSqr(c);
            if (d < best) {
                best = d;
                furnace = p.immutable();
            }
        }
    }

    private void light(boolean on) {
        if (on) {
            if (furnace == null) return;
            BlockState st = level().getBlockState(furnace);
            if (st.is(Blocks.FURNACE) && !st.getValue(AbstractFurnaceBlock.LIT)) {
                level().setBlock(furnace, st.setValue(AbstractFurnaceBlock.LIT, true), 3);
            }
            lit = furnace;
        } else if (lit != null) {
            BlockState st = level().getBlockState(lit);
            if (st.is(Blocks.FURNACE) && st.getValue(AbstractFurnaceBlock.LIT)) {
                level().setBlock(lit, st.setValue(AbstractFurnaceBlock.LIT, false), 3);
            }
            lit = null;
        }
    }

    /** What sells in general: how often a dessert is chosen by all the customers over all the drinks (the biggest one = 10). */
    private static int baseline(int dessert) {
        if (baseline == null) {
            Dessert[] all = Dessert.values();
            long[] sum = new long[all.length];
            long max = 1;
            for (int i = 0; i < all.length; i++) {
                for (Personality who : Personality.values()) {
                    for (Drink drink : Drink.values()) sum[i] += Pairing.dessertWeight(who, drink.id(), all[i].id());
                }
                max = Math.max(max, sum[i]);
            }
            int[] b = new int[all.length];
            for (int i = 0; i < all.length; i++) b[i] = (int) Math.max(1L, sum[i] * 10L / max);
            baseline = b;
        }
        return baseline[dessert];
    }

    private int stock(ServerLevel sl, @Nullable boolean[] have) {
        long now = sl.getGameTime();
        int n = 0;
        for (Plate p : tray) {
            if (!p.fresh(now)) continue;
            n++;
            if (have != null && p.dessert() < have.length) have[p.dessert()] = true;
        }
        for (CafeStaffEntity b : staffAround(sl, blockPosition(), Role.BARISTA, 24.0D)) {
            for (Plate p : b.shelf) {
                if (!p.fresh(now)) continue;
                n++;
                if (have != null && p.dessert() < have.length) have[p.dessert()] = true;
            }
        }
        return n;
    }

    /** What to bake ahead: what is not in stock yet, the more likely the more it sells (customers in general + what was ordered near him lately). */
    private int pickProactive(ServerLevel sl) {
        int n = Dessert.values().length;
        boolean[] have = new boolean[n];
        stock(sl, have);
        int[] w = new int[n];
        for (int i = 0; i < n; i++) w[i] = have[i] ? 0 : baseline(i) + demand[i] * 6;
        return Personality.weightedPick(w, random::nextInt);
    }

    /** Decides what is in the furnace: an asked dessert first, otherwise (if somebody is around) a dessert to keep the stock up. */
    private void planBake(ServerLevel sl) {
        if (!queue.isEmpty()) {
            int want = queue.peekFirst();
            if (baking == want) {
                bakingAsked = true;
            } else if (baking < 0 || !bakingAsked || bake < BAKE_TICKS / 3) {    // a half-baked asked one is not dropped
                baking = want;
                bakingAsked = true;
                bake = 0;
            }
            return;
        }
        if (baking >= 0 || furnace == null) return;
        if (sl.getNearestPlayer(this, 48.0D) == null) return;                    // nobody to bake for
        if (stock(sl, null) >= STOCK_TARGET) return;
        baking = pickProactive(sl);
        bakingAsked = false;
        bake = 0;
    }

    private void tickChef() {
        ServerLevel sl = (ServerLevel) level();
        long now = sl.getGameTime();
        if (home == null) home = blockPosition();
        tray.removeIf(p -> !p.fresh(now));
        if (tickCount % 40 == 1) findFurnace();
        if (tickCount % 6000 == 0) {
            for (int i = 0; i < demand.length; i++) demand[i] /= 2;
        }
        planBake(sl);

        // the furnace works while the dough is in it, also while the chef is away with a plate
        boolean canBake = baking >= 0 && furnace != null;
        if (!canBake) {
            if (lit != null) light(false);
        } else {
            if (lit == null || !lit.equals(furnace)) {
                light(false);
                light(true);
            }
            if (bake < BAKE_TICKS) bake++;
            if (chefState == C_BAKE && bake < BAKE_TICKS && bake % 30 == 0) {
                sl.sendParticles(ParticleTypes.SMOKE, furnace.getX() + 0.5D, furnace.getY() + 1.1D, furnace.getZ() + 0.5D, 2, 0.15D, 0.05D, 0.15D, 0.01D);
            }
        }

        stateTicks++;
        switch (chefState) {
            case C_DELIVER -> tickDeliver(sl);
            case C_RETURN -> tickReturn();
            default -> {
                if (canBake && bake >= BAKE_TICKS) {
                    finishPlate(sl, now);
                } else if (!tray.isEmpty() && oneShotUntil <= tickCount) {
                    ServerPlayer needy = playerNeedingPlate(sl, now);
                    CafeStaffEntity barista = needy == null ? baristaWithRoom(sl) : null;
                    if (needy != null || barista != null) {
                        chefState = C_DELIVER;
                        deliverTo = needy != null ? needy.getUUID() : barista.getUUID();
                        deliverDessert = needy != null ? playerNeed(needy, now) : -1;
                        stateTicks = 0;
                    }
                }
            }
        }
    }

    private void finishPlate(ServerLevel sl, long now) {
        while (tray.size() >= TRAY) tray.remove(0);                              // an old plate makes room for the asked one
        tray.add(new Plate(baking, now + PLATE_LIFE));
        queue.removeFirstOccurrence(baking);
        baking = -1;
        bakingAsked = false;
        bake = 0;
        playOnce(StaffAction.PRESENT, StaffAction.PRESENT_TICKS, new ItemStack(ModItems.DESSERT_PLATE.get()));
        sl.playSound(null, blockPosition(), SoundEvents.NOTE_BLOCK_CHIME.value(), SoundSource.NEUTRAL, 0.8F, 1.5F);
        sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 2.0D, getZ(), 4, 0.25D, 0.2D, 0.25D, 0.0D);
    }

    /** The nearest NPC barista with room on his shelf (null if there is none: then the plates wait on the tray). */
    @Nullable
    private CafeStaffEntity baristaWithRoom(ServerLevel sl) {
        return staffAround(sl, blockPosition(), Role.BARISTA, 24.0D).stream()
                .filter(b -> b.shelf.size() < SHELF)
                .min(Comparator.comparingDouble(this::distanceToSqr)).orElse(null);
    }

    /** The dessert on the order ticket of this barista player, if he is at work and has no fresh plate of it yet (-1 otherwise). */
    private static int playerNeed(ServerPlayer p, long now) {
        if (!CafeLogic.isWorking(p)) return -1;
        ItemStack ticket = CafeLogic.findTicket(p);
        Order order = ticket.isEmpty() ? null : ticket.get(dev.aestheticjobs.registry.ModComponents.ORDER.get());
        Dessert dessert = order == null ? null : Dessert.byIndex(order.dessert());
        if (dessert == null || !CafeLogic.findPlate(p, dessert, now).isEmpty()) return -1;
        return dessert.ordinal();
    }

    /** A barista player near the chef who waits for a plate that is on the tray right now. */
    @Nullable
    private ServerPlayer playerNeedingPlate(ServerLevel sl, long now) {
        for (ServerPlayer p : sl.players()) {
            if (p.distanceToSqr(this) > 24.0D * 24.0D) continue;
            int need = playerNeed(p, now);
            if (need >= 0 && hasFresh(tray, need, now)) return p;
        }
        return null;
    }

    private void tickDeliver(ServerLevel sl) {
        long now = sl.getGameTime();
        Entity target = deliverTo == null ? null : sl.getEntity(deliverTo);
        boolean ok;
        if (target instanceof CafeStaffEntity b) {
            ok = b.isAlive() && b.shelf.size() < SHELF && !tray.isEmpty();
        } else if (target instanceof ServerPlayer p) {
            ok = !p.isRemoved() && deliverDessert >= 0 && playerNeed(p, now) == deliverDessert && hasFresh(tray, deliverDessert, now);
        } else {
            ok = false;
        }
        if (!ok) {
            endTrip();
            return;
        }
        if (distanceToSqr(target) < 4.0D || stateTicks > TRIP_TIMEOUT) {          // arrived (or stuck: hand it over from here)
            getNavigation().stop();
            Plate first = tray.get(0);
            if (target instanceof CafeStaffEntity b) {
                while (!tray.isEmpty() && b.shelf.size() < SHELF) b.shelf.add(tray.remove(0));
            } else if (target instanceof ServerPlayer p) {
                removeFresh(tray, deliverDessert, now);
                first = new Plate(deliverDessert, now + PLATE_LIFE);
                p.getInventory().placeItemBackInInventory(CafeLogic.makePlate(deliverDessert, first.expires()));
                p.displayClientMessage(Component.translatable("staff.chef.gave_plate", Dessert.values()[deliverDessert].displayName()), true);
            }
            faceTarget = target.blockPosition();
            playOnce(StaffAction.PRESENT, StaffAction.PRESENT_TICKS, CafeLogic.makePlate(first.dessert(), first.expires()));
            sl.playSound(null, blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.NEUTRAL, 0.7F, 1.1F);
            endTrip();
            return;
        }
        if (stateTicks % 10 == 1) getNavigation().moveTo(target.getX(), target.getY(), target.getZ(), 1.0D);
    }

    private void endTrip() {
        chefState = C_RETURN;
        deliverTo = null;
        deliverDessert = -1;
        stateTicks = 0;
        getNavigation().stop();
    }

    private void tickReturn() {
        if (oneShotUntil > tickCount) {                                          // finishing the handover
            getNavigation().stop();
            return;
        }
        faceTarget = null;
        Vec3 h = home == null ? position() : Vec3.atBottomCenterOf(home);
        double dx = h.x - getX(), dz = h.z - getZ();
        if (dx * dx + dz * dz < 0.5D) {
            getNavigation().stop();
            chefState = C_BAKE;
            stateTicks = 0;
            return;
        }
        if (stateTicks > TRIP_TIMEOUT) {                                         // cannot find the way: back to the furnace at once
            moveTo(h.x, h.y, h.z, getYRot(), 0.0F);
            getNavigation().stop();
            chefState = C_BAKE;
            stateTicks = 0;
            return;
        }
        if (stateTicks % 10 == 1) getNavigation().moveTo(h.x, h.y, h.z, 1.0D);
    }

    @Override
    public void remove(RemovalReason reason) {
        if (!level().isClientSide && lit != null) light(false);       // do not leave a furnace burning for nothing
        super.remove(reason);
    }

    // ------------------------------------------------------------------ barista

    private void findRegister() {
        if (register != null && level().getBlockState(register).is(ModBlocks.CAFE_REGISTER.get())) return;
        register = null;
        BlockPos c = blockPosition();
        double best = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-12, -4, -12), c.offset(12, 4, 12))) {
            if (!level().getBlockState(p).is(ModBlocks.CAFE_REGISTER.get())) continue;
            double d = p.distSqr(c);
            if (d < best) {
                best = d;
                register = p.immutable();
            }
        }
        if (register != null && level() instanceof ServerLevel sl) {                // customers come to a known register by themselves
            CafeRegisters.get(sl.getServer()).add(sl.dimension().location().toString(), register.asLong());
        }
    }

    private void tickBarista() {
        ServerLevel sl = (ServerLevel) level();
        long now = sl.getGameTime();
        shelf.removeIf(p -> !p.fresh(now));
        if (tickCount % 20 != 0) return;
        baristaWork(sl, now);
        working = making != null;
        if (working && register != null) machineEffects(sl);
    }

    /** While he makes a drink: a puff of steam by the machine, and now and then the sound of it. */
    private void machineEffects(ServerLevel sl) {
        Vec3 to = Vec3.atCenterOf(register).subtract(position());
        Vec3 dir = to.lengthSqr() < 1.0E-4D ? Vec3.ZERO : to.normalize();
        sl.sendParticles(ParticleTypes.CLOUD, getX() + dir.x * 0.6D, getY() + 1.2D, getZ() + dir.z * 0.6D, 2, 0.08D, 0.05D, 0.08D, 0.01D);
        if ((tickCount / 20) % 3 == 0) {
            sl.playSound(null, blockPosition(), SoundEvents.BREWING_STAND_BREW, SoundSource.NEUTRAL, 0.35F, 1.3F);
        }
    }

    /** Once a second: finish what is done, hand over what has its plate, take the next job at once, call a customer when it is quiet. */
    private void baristaWork(ServerLevel sl, long now) {
        if (tickCount % 100 == 0 || register == null) findRegister();
        if (register == null) {
            if (tickCount % 200 == 0) {                                          // say why nothing happens
                Player p = sl.getNearestPlayer(this, 8.0D);
                if (p != null) p.displayClientMessage(Component.translatable("staff.barista.no_register"), true);
            }
            making = null;
            waiting.clear();
            return;
        }
        CafeOrders orders = CafeOrders.get(sl.getServer());
        adoptOrphans(sl, orders);

        // cups that are made and wait for their dessert: out as soon as the plate is there, or without it after a long wait
        for (Iterator<Job> it = waiting.iterator(); it.hasNext(); ) {
            Job j = it.next();
            if (!valid(j, sl, orders)) {
                dropJob(j, sl, now);
                it.remove();
            } else if (plateFor(sl, j)) {
                it.remove();
                handOver(sl, j, now, orders, true);
            } else if (now - j.waitSince > PLATE_WAIT_TICKS) {
                it.remove();
                handOver(sl, j, now, orders, false);
            } else {
                askChef(sl, j, now);
            }
        }

        // the drink in the machine
        if (making != null && !valid(making, sl, orders)) {
            dropJob(making, sl, now);
            making = null;
        }
        if (making != null) {
            if (now < making.doneAt) return;                                     // still at work
            if (making.customer != null && sl.getEntity(making.customer) instanceof CafeCustomerEntity wc
                    && wc.getState() == CafeCustomerEntity.STATE_WALKING) return;      // the customer is stepping up in the line: wait a moment
            Job done = making;
            making = null;
            if (plateFor(sl, done)) {
                handOver(sl, done, now, orders, true);
            } else {                                                             // the cup waits aside, the next job is not blocked
                done.waitSince = now;
                waiting.add(done);
                askChef(sl, done, now);
            }
        }

        // the next job, right away
        making = nextJob(sl, now, orders);
    }

    /** Jobs of a barista that is gone (replaced, removed): the customers and the paid orders nobody is working on are taken over. */
    private void adoptOrphans(ServerLevel sl, CafeOrders orders) {
        if (tickCount % 100 != 0 || register == null) return;
        BlockPos reg = register;
        for (CafeOrders.Entry e : orders.all()) {
            if (e.status != CafeOrders.COOKING || e.worker == null || getUUID().equals(e.worker)) continue;
            if (!e.dim.equals(sl.dimension().location().toString())) continue;
            if (BlockPos.of(e.register).distSqr(reg) > CafeLogic.STAFF_RADIUS * CafeLogic.STAFF_RADIUS) continue;
            if (sl.getEntity(e.worker) == null) {
                e.worker = getUUID();
                orders.changed();
            }
        }
        for (CafeCustomerEntity c : sl.getEntitiesOfClass(CafeCustomerEntity.class, new AABB(reg).inflate(CafeLogic.STAFF_RADIUS),
                x -> x.isNpcServed() && x.getWorker() != null && !getUUID().equals(x.getWorker()))) {
            if (sl.getEntity(c.getWorker()) == null) c.adoptBy(getUUID());
        }
    }

    private boolean valid(Job j, ServerLevel sl, CafeOrders orders) {
        if (j.order != null) {
            return orders.all().contains(j.order) && j.order.status == CafeOrders.COOKING && getUUID().equals(j.order.worker);
        }
        return j.customer != null && sl.getEntity(j.customer) instanceof CafeCustomerEntity c && c.isAlive()
                && (c.getState() == CafeCustomerEntity.STATE_WAITING || c.getState() == CafeCustomerEntity.STATE_WALKING)
                && getUUID().equals(c.getWorker());
    }

    /** The job is gone (the customer left, the order was refunded): a plate that was already taken goes back on the shelf. */
    private void dropJob(Job j, ServerLevel sl, long now) {
        if (j.dessert >= 0 && j.plated && shelf.size() < SHELF) {
            shelf.add(new Plate(j.dessert, now + PLATE_LIFE / 2));
        }
    }

    /** Takes the plate of the job (from the shelf or a tray) unless it already has it. */
    private boolean plateFor(ServerLevel sl, Job j) {
        if (j.plated) return true;
        if (register != null && takePlate(sl, register, j.dessert)) {
            j.plated = true;
            if (j.order != null) j.order.plated = true;
            return true;
        }
        return false;
    }

    /** Makes sure a chef is going to bake what the waiting cup needs (every 10 seconds: the queue may have been lost). */
    private void askChef(ServerLevel sl, Job j, long now) {
        if (j.dessert < 0 || j.plated || register == null) return;
        if (j.lastAsk != 0L && now - j.lastAsk < 200L) return;
        j.lastAsk = now;
        if (!hasPlate(sl, register, j.dessert) && !isQueued(sl, register, j.dessert)) {
            request(sl, register, j.dessert);
        }
    }

    private boolean hasJobFor(@Nullable UUID customer, @Nullable CafeOrders.Entry order) {
        if (making != null && ((customer != null && customer.equals(making.customer)) || (order != null && order == making.order))) return true;
        for (Job j : waiting) {
            if ((customer != null && customer.equals(j.customer)) || (order != null && order == j.order)) return true;
        }
        return false;
    }

    /** How long this drink takes the NPC barista (a simple drink is quick, a layered one takes its time). */
    private static long workTicks(Drink drink) {
        return Math.max(400L, Math.round(drink.fastTicks() * 0.36));
    }

    private boolean playerBaristaNear(ServerLevel sl) {
        if (register == null) return false;
        for (ServerPlayer p : sl.getServer().getPlayerList().getPlayers()) {
            if (p.level() == sl && CafeLogic.isWorking(p) && p.blockPosition().distSqr(register) < 48.0D * 48.0D) return true;
        }
        return false;
    }

    /** The next thing to make: a paid order of a player first (also one that was already started), then the customer who has waited longest. */
    @Nullable
    private Job nextJob(ServerLevel sl, long now, CafeOrders orders) {
        for (CafeOrders.Entry e : orders.all()) {                                // an order that I am making (after a reload nothing is lost)
            if (e.status != CafeOrders.COOKING || !getUUID().equals(e.worker) || hasJobFor(null, e)) continue;
            Drink drink = Drink.byIndex(e.drink);
            if (drink == null) continue;
            return new Job(null, e, e.drink, e.dessert, e.plated, Math.max(now, e.readyAt));
        }
        CafeOrders.Entry open = orders.nextPending(sl.dimension().location().toString(), register, CafeLogic.STAFF_RADIUS);
        if (open != null && Drink.byIndex(open.drink) != null && (now - open.created >= NPC_TAKES_AFTER || !playerBaristaNear(sl))) {
            open.status = CafeOrders.COOKING;
            open.worker = getUUID();
            open.readyAt = now + workTicks(Drink.byIndex(open.drink));
            orders.changed();
            return new Job(null, open, open.drink, open.dessert, open.plated, open.readyAt);
        }
        CafeCustomerEntity best = null;
        for (CafeCustomerEntity c : customersOfMine(sl, true)) {                  // the first in the line first (then the most impatient)
            if (hasJobFor(c.getUUID(), null) || Drink.byIndex(c.getDrink()) == null) continue;
            if (best == null || c.getLineIndex() < best.getLineIndex()
                    || (c.getLineIndex() == best.getLineIndex() && c.getPatience() < best.getPatience())) {
                best = c;
            }
        }
        if (best == null) {                                                       // nobody of mine: the first who waits and has nobody yet
            for (CafeCustomerEntity c : sl.getEntitiesOfClass(CafeCustomerEntity.class, new AABB(register).inflate(CafeLogic.STAFF_RADIUS + 8.0D),
                    x -> x.isUnclaimed() && register.equals(x.getRegisterPos()))) {
                if (playerBaristaNear(sl) && now - c.getOrderTime() < NPC_TAKES_AFTER) continue;       // a barista at work has the first turn
                if (Drink.byIndex(c.getDrink()) == null) continue;
                if (best == null || c.getLineIndex() < best.getLineIndex()) best = c;
            }
            if (best != null) best.claimByNpc(getUUID());
        }
        if (best != null) {
            Drink drink = Drink.byIndex(best.getDrink());
            return new Job(best.getUUID(), null, best.getDrink(), best.getDessert(), false, now + workTicks(drink));
        }
        return null;
    }

    /** My NPC customers near the register: only the ones that already wait at the counter, or also the ones still walking up. */
    private List<CafeCustomerEntity> customersOfMine(ServerLevel sl, boolean waitingOnly) {
        if (register == null) return List.of();
        return sl.getEntitiesOfClass(CafeCustomerEntity.class, new AABB(register).inflate(CafeLogic.STAFF_RADIUS + 8.0D),
                c -> c.isAlive() && getUUID().equals(c.getWorker()) && c.isNpcServed()
                        && (c.getState() == CafeCustomerEntity.STATE_WAITING
                        || (!waitingOnly && c.getState() == CafeCustomerEntity.STATE_WALKING)));
    }

    /** The cup (and the plate, if it has one) goes out: to the customer, or onto the counter for the buyer. */
    private void handOver(ServerLevel sl, Job j, long now, CafeOrders orders, boolean withDessert) {
        Drink made = Drink.byIndex(j.drink);
        if (made != null) playOnce(StaffAction.SERVE, StaffAction.SERVE_TICKS, CafeLogic.npcCup(made));
        if (j.order != null) {
            CafeOrders.Entry e = j.order;
            Dessert dessert = Dessert.byIndex(j.dessert);
            ServerPlayer buyer = sl.getServer().getPlayerList().getPlayer(e.buyer);
            if (dessert != null && !withDessert) {                               // the chef did not make it in time: the dessert is refunded
                e.dessertDropped = true;
                e.price -= dessert.priceCents();
                Bank.deposit(sl.getServer(), e.buyer, dessert.priceCents(), Transaction.Type.REFUND, "cafe");
                if (buyer != null) {
                    buyer.sendSystemMessage(Component.translatable("cafe.order.dessert_refunded", dessert.displayName(), Money.format(dessert.priceCents())));
                }
            }
            e.status = CafeOrders.READY;
            e.readyAt = now;
            orders.changed();
            sl.playSound(null, blockPosition(), ModSounds.BARISTA_DING.get(), SoundSource.NEUTRAL, 1.0F, 1.0F);
            sl.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 1.6D, getZ(), 6, 0.2D, 0.1D, 0.2D, 0.01D);
            if (buyer != null) buyer.sendSystemMessage(Component.translatable("cafe.order.ready"));
        } else if (j.customer != null && sl.getEntity(j.customer) instanceof CafeCustomerEntity c && c.isAlive()) {
            c.receiveByNpc(position());
            sl.playSound(null, blockPosition(), ModSounds.BARISTA_DING.get(), SoundSource.NEUTRAL, 0.8F, 1.1F);
        }
    }

    // ------------------------------------------------------------------ save / load

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Bake", bake);
        tag.putInt("Baking", baking);
        tag.putBoolean("BakingAsked", bakingAsked);
        int[] q = new int[queue.size()];
        int qi = 0;
        for (int x : queue) q[qi++] = x;
        tag.putIntArray("Queue", q);
        tag.putIntArray("Demand", demand);
        tag.put("Tray", plates(tray));
        tag.put("Shelf", plates(shelf));
        if (home != null) tag.putLong("Home", home.asLong());
        if (lit != null) tag.putLong("Lit", lit.asLong());
    }

    private static ListTag plates(List<Plate> list) {
        ListTag out = new ListTag();
        for (Plate p : list) {
            CompoundTag t = new CompoundTag();
            t.putInt("d", p.dessert());
            t.putLong("e", p.expires());
            out.add(t);
        }
        return out;
    }

    private static void readPlates(CompoundTag tag, String key, int max, List<Plate> into) {
        into.clear();
        ListTag list = tag.getList(key, Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size() && i < max; i++) {
            CompoundTag t = list.getCompound(i);
            into.add(new Plate(t.getInt("d"), t.getLong("e")));
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        baking = tag.contains("Baking") ? tag.getInt("Baking") : -1;
        bakingAsked = tag.getBoolean("BakingAsked");
        bake = baking >= 0 ? tag.getInt("Bake") : 0;
        queue.clear();
        for (int x : tag.getIntArray("Queue")) queue.addLast(x);
        int[] d = tag.getIntArray("Demand");
        for (int i = 0; i < demand.length && i < d.length; i++) demand[i] = d[i];
        readPlates(tag, "Tray", TRAY, tray);
        readPlates(tag, "Shelf", SHELF, shelf);
        home = tag.contains("Home") ? BlockPos.of(tag.getLong("Home")) : null;
        lit = tag.contains("Lit") ? BlockPos.of(tag.getLong("Lit")) : null;     // put out on the first tick if nothing is baking
    }
}
