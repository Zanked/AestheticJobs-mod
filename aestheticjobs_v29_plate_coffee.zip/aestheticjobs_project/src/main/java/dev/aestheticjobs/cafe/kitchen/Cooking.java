package dev.aestheticjobs.cafe.kitchen;

import java.util.ArrayList;
import java.util.List;

/** The rules: how good a recipe is. No luck and no timing, the result depends only on what goes in. Pure Java. */
public final class Cooking {
    public static final int MAX_EXTRAS = 3;
    public static final int PLAIN = 65, LIKED = 14, NEUTRAL = 3, DISLIKED = -16, BEST_WITHOUT_SIGNATURE = 96;
    public static final int ALL_EXTRAS = (1 << Extra.values().length) - 1;

    private Cooking() {}

    public static boolean valid(int base, int mask) {
        return Menu.get(base) != null && (mask & ~ALL_EXTRAS) == 0 && Integer.bitCount(mask) <= MAX_EXTRAS;
    }

    /** +1 suits the base, -1 spoils it, 0 neither. */
    public static int match(int base, Extra extra) {
        Menu.Base b = Menu.get(base);
        if (b == null) return 0;
        return extra.in(b.likes()) ? 1 : extra.in(b.dislikes()) ? -1 : 0;
    }

    public static int quality(int base, int mask) {
        if (!valid(base, mask)) return 0;
        if (Signature.of(base, mask) != null) return 100;
        int q = PLAIN;
        for (Extra e : Extra.values()) {
            if (!e.in(mask)) continue;
            int m = match(base, e);
            q += m > 0 ? LIKED : m < 0 ? DISLIKED : NEUTRAL;
        }
        return Math.max(0, Math.min(BEST_WITHOUT_SIGNATURE, q));
    }

    public static int stars(int quality) {
        return quality >= 90 ? 5 : quality >= 75 ? 4 : quality >= 60 ? 3 : quality >= 40 ? 2 : 1;
    }

    /** How strong a taste is in the finished recipe. */
    public static int taste(int base, int mask, Flavor flavor) {
        Menu.Base b = Menu.get(base);
        if (b == null) return 0;
        int v = b.taste(flavor);
        for (Extra e : Extra.values()) {
            if (e.in(mask)) v += e.taste(flavor);
        }
        return v;
    }

    /** Everything it takes: the ingredients of the base, then one item for every addition (an item may repeat). */
    public static List<String> shopping(int base, int mask) {
        List<String> out = new ArrayList<>();
        Menu.Base b = Menu.get(base);
        if (b == null) return out;
        out.addAll(b.ingredients());
        for (Extra e : Extra.values()) {
            if (e.in(mask)) out.add(e.item());
        }
        return out;
    }

    /** Extra tip (percent) for serving a plate somebody baked by hand. */
    public static int handmadeBonus(int stars) {
        return stars >= 5 ? 20 : stars == 4 ? 10 : 0;
    }
}
