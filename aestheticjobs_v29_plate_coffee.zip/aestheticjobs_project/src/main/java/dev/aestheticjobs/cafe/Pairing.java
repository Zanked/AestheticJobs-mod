package dev.aestheticjobs.cafe;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Which desserts go well with which drink. A classic pair earns a better tip and a better opinion of the customer;
 * customers also order such pairs more often. Drinks and desserts are referred to by id (no Minecraft classes here).
 * Every dessert belongs to at least one drink.
 */
public final class Pairing {
    /** How much more often a classic pair is chosen when a customer picks a dessert for its drink. */
    public static final int PAIR_WEIGHT = 3;

    private static final Map<String, String[]> PAIRS = new HashMap<>();

    static {
        PAIRS.put("espresso", new String[]{"croissant", "cookie_choc", "macaron_pink", "macaron_mint", "macaron_lemon", "baklava", "eclair"});
        PAIRS.put("americano", new String[]{"apple_pie", "cinnamon_roll", "brownie", "croissant", "medovik", "cookie_choc", "gingerbread_man"});
        PAIRS.put("latte", new String[]{"cupcake_pink", "cupcake_choc", "muffin_blueberry", "cake_pop", "cheesecake", "donut_pink", "cookie_heart"});
        PAIRS.put("cappuccino", new String[]{"cinnamon_roll", "donut_choc", "waffle", "pancakes", "croissant", "gingerbread_man", "cream_puff"});
        PAIRS.put("flat_white", new String[]{"tiramisu", "creme_brulee", "panna_cotta", "flan", "eclair", "macaron_lemon", "fruit_tart"});
        PAIRS.put("raf", new String[]{"cake_strawberry", "cream_puff", "cheesecake", "panna_cotta", "fruit_tart", "donut_pink", "muffin_blueberry"});
        PAIRS.put("mocha", new String[]{"brownie", "cake_choc", "donut_choc", "cupcake_choc", "cookie_choc", "sundae", "waffle"});
        PAIRS.put("macchiato", new String[]{"tiramisu", "medovik", "baklava", "creme_brulee", "flan", "ice_cream_cone", "cake_strawberry"});
    }

    private Pairing() {}

    public static boolean isPair(String drinkId, String dessertId) {
        String[] list = PAIRS.get(drinkId);
        return list != null && Arrays.asList(list).contains(dessertId);
    }

    /** The classic desserts of a drink (empty for an unknown drink). */
    public static String[] pairsOf(String drinkId) {
        String[] list = PAIRS.get(drinkId);
        return list == null ? new String[0] : list.clone();
    }

    /** Weight of a dessert when a customer who wants this drink picks one: pairs and its own favourites come up more often. */
    public static int dessertWeight(Personality who, String drinkId, String dessertId) {
        return who.dessertWeight(dessertId) * (isPair(drinkId, dessertId) ? PAIR_WEIGHT : 1);
    }
}
