package dev.aestheticjobs.cafe.career;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Everything a barista has achieved: the streak of great cups, the mastery of every drink and the tasks of the day.
 * Plain Java (saved by cafe/CafeCareer).
 */
public final class Career {
    public static final int MAX_DRINKS = 16;
    /** Cups (3 stars or more) needed for bronze, silver and gold. */
    public static final int[] MASTERY = {5, 15, 40};
    public static final int COMFORT_PER_DECOR = 3, COMFORT_MAX = 21;
    public static final int DAILY_BONUS = 40, WISH_BONUS = 30;

    public int streak, bestStreak, served;
    public long tips;
    public final int[] cups = new int[MAX_DRINKS];
    public long questDay = Long.MIN_VALUE;
    public final int[] progress = new int[Quest.PER_DAY];
    public final boolean[] done = new boolean[Quest.PER_DAY];

    /** What happened when a cup was served. */
    public record Serve(int drink, int stars, boolean dessert, boolean pair, boolean wishDone) {}

    /** What it brought. completed = indices of the tasks finished just now; masteryUp = new level 1..3 or 0. */
    public record Result(int streak, long streakPrize, int masteryUp, List<Integer> completed) {}

    public static int masteryLevel(int cups) {
        int level = 0;
        for (int need : MASTERY) if (cups >= need) level++;
        return level;
    }

    /** Extra tip in percent for the mastery of a drink. */
    public static int masteryBonus(int cups) { return masteryLevel(cups) * 5; }

    /** Extra tip in percent for a streak of great cups: 5 per cup, at most 50. */
    public static int streakBonus(int streak) { return Math.min(Math.max(streak, 0), 10) * 5; }

    public static long streakPrize(int streak) {
        if (streak == 3) return 200;
        if (streak == 5) return 500;
        return streak > 0 && streak % 10 == 0 ? 1500 : 0;
    }

    public static int comfortBonus(int kinds) { return Math.min(Math.max(kinds, 0) * COMFORT_PER_DECOR, COMFORT_MAX); }

    /** The drink of the day. */
    public static int dailyDrink(long day, int drinks) {
        return (int) Math.floorMod(day * 5 + 3, (long) drinks);
    }

    /** The streak this cup leads to: 4-5 stars go on, 3 keep it, 1-2 break it. */
    public int nextStreak(int stars) {
        return stars >= 4 ? streak + 1 : stars == 3 ? streak : 0;
    }

    /** A new day brings new tasks. */
    public void rollDay(long day) {
        if (day == questDay) return;
        questDay = day;
        Arrays.fill(progress, 0);
        Arrays.fill(done, false);
    }

    public Result serve(Serve s, long day, List<Quest> quests, long tip) {
        rollDay(day);
        int before = streak;
        streak = nextStreak(s.stars());
        bestStreak = Math.max(bestStreak, streak);
        served++;
        tips += tip;
        int up = 0;
        if (s.stars() >= 3 && s.drink() >= 0 && s.drink() < MAX_DRINKS) {
            int old = masteryLevel(cups[s.drink()]);
            cups[s.drink()]++;
            int now = masteryLevel(cups[s.drink()]);
            if (now > old) up = now;
        }
        List<Integer> completed = new ArrayList<>();
        for (int i = 0; i < Math.min(quests.size(), Quest.PER_DAY); i++) {
            if (done[i]) continue;
            Quest q = quests.get(i);
            int add = switch (q.type()) {
                case DRINK -> s.drink() == q.drink() && s.stars() >= 3 ? 1 : 0;
                case GREAT -> s.stars() >= 4 ? 1 : 0;
                case DESSERT -> s.dessert() ? 1 : 0;
                case WISH -> s.wishDone() ? 1 : 0;
                case PAIR -> s.pair() ? 1 : 0;
                case STREAK -> 0;
            };
            progress[i] = q.type() == Quest.Type.STREAK ? Math.max(progress[i], streak) : progress[i] + add;
            if (progress[i] >= q.target()) {
                progress[i] = q.target();
                done[i] = true;
                completed.add(i);
            }
        }
        long prize = streak > before ? streakPrize(streak) : 0;
        return new Result(streak, prize, up, completed);
    }

    /** A guest walked out. */
    public void breakStreak() { streak = 0; }
}
