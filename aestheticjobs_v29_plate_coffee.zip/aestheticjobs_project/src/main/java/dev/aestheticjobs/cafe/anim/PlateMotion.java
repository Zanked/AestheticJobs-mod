package dev.aestheticjobs.cafe.anim;

/**
 * Eating from a plate (pure Java, tested by tools/tests/PlateMotionTest). One click is one bite: a little fork dips into
 * the dessert, carries a piece to the mouth of the eater, and the dessert on the plate gets smaller. "t" is the number
 * of ticks since the bite began (with the partial tick).
 */
public final class PlateMotion {
    /** Bites of one dessert; the last one feeds the player. */
    public static final int BITES = 4;
    /** Ticks between two bites (a held button keeps eating at this pace). */
    public static final int BITE_TICKS = 16;
    /** A dessert that was just put down is not bitten at once by the same held button. */
    public static final int PUT_TICKS = 12;
    /** The fork reaches into the dessert; from here on the piece is missing from it. */
    public static final float DIP = 4.0F;
    /** The fork is at the mouth: the eater chews, crumbs fall. */
    public static final int ARRIVE = 12;
    /** The fork is gone. */
    public static final float END = 15.0F;

    private static final float[] SIZES = {1.0F, 0.86F, 0.72F, 0.56F, 0.0F};

    private PlateMotion() {}

    private static float smooth(float v) {
        float c = v < 0.0F ? 0.0F : Math.min(v, 1.0F);
        return c * c * (3.0F - 2.0F * c);
    }

    /** The size of the dessert after so many bites, 0 = eaten. */
    public static float size(int bites) {
        return SIZES[Math.max(0, Math.min(BITES, bites))];
    }

    /** How high above the dessert the fork still is, 1 at the start and 0 when it is in. */
    public static float above(float t) {
        return 1.0F - smooth(t / DIP);
    }

    /** The way from the plate (0) to the mouth (1). */
    public static float travel(float t) {
        return smooth((t - DIP) / (ARRIVE - DIP));
    }

    /** The arc of the way, 0 at both ends. */
    public static float arc(float t) {
        float p = travel(t);
        return 4.0F * p * (1.0F - p);
    }

    /** The fork and its piece shrink away at the mouth. */
    public static float forkSize(float t) {
        return 1.0F - smooth((t - (ARRIVE - 1)) / (END - ARRIVE + 1));
    }

    public static boolean showsFork(float t) {
        return t >= 0.0F && t < END;
    }
}
