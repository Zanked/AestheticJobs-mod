package dev.aestheticjobs.cafe.kitchen;

import static dev.aestheticjobs.cafe.kitchen.Extra.*;

/**
 * The signature recipes: one base with exactly these two additions. Unknown ones show a hint in the recipe book (the
 * base and one of the two). The ordinal is a bit in the saved knowledge: only add new ones at the end.
 */
public enum Signature {
    HONEY_LATTE("honey_latte", "latte", HONEY, VANILLA),
    VIENNA("vienna", "espresso", CREAM, CHOCOLATE),
    ORCHARD("orchard", "americano", APPLE, HONEY),
    VELVET("velvet", "cappuccino", COCOA, VANILLA),
    AMBER("amber", "flat_white", CARAMEL, HONEY),
    FOREST_RAF("forest_raf", "raf", BERRY, HONEY),
    BLACK_FOREST("black_forest", "mocha", BERRY, CREAM),
    PRALINE("praline", "macchiato", CHOCOLATE, CREAM),
    PARIS("paris", "croissant", HONEY, CREAM),
    PINK_CLOUD("pink_cloud", "donut_pink", BERRY, CREAM),
    NORTHERN("northern", "cinnamon_roll", APPLE, CARAMEL),
    FIRESIDE("fireside", "gingerbread_man", HONEY, CHOCOLATE),
    ROSE_GARDEN("rose_garden", "macaron_pink", BERRY, VANILLA),
    SUNSET("sunset", "cheesecake", CARAMEL, BERRY),
    SUMMER("summer", "cake_strawberry", CREAM, VANILLA),
    MIDNIGHT("midnight", "cake_choc", COCOA, BERRY),
    GRANDMA("grandma", "apple_pie", CARAMEL, VANILLA),
    BRUNCH("brunch", "pancakes", BERRY, HONEY),
    DOUBLE("double", "brownie", CHOCOLATE, CREAM),
    CRYSTAL("crystal", "creme_brulee", VANILLA, BERRY),
    FESTIVAL("festival", "sundae", CHOCOLATE, APPLE),
    MILK_MOON("milk_moon", "panna_cotta", HONEY, BERRY);

    private final String id, base;
    private final Extra first, second;

    Signature(String id, String base, Extra first, Extra second) {
        this.id = id;
        this.base = base;
        this.first = first;
        this.second = second;
    }

    public String id() { return id; }
    public int base() { return Menu.indexOf(base); }
    /** The addition shown as a hint. */
    public Extra hint() { return first; }
    public int mask() { return first.bit() | second.bit(); }
    public long bit() { return 1L << ordinal(); }
    public boolean isDrink() { return base() < Menu.DRINKS; }

    public static Signature of(int base, int mask) {
        for (Signature s : values()) {
            if (s.mask() == mask && s.base() == base) return s;
        }
        return null;
    }
}
