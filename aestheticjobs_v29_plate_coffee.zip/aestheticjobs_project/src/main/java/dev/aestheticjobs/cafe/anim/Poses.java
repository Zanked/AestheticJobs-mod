package dev.aestheticjobs.cafe.anim;

import dev.aestheticjobs.cafe.Personality;

/**
 * All the animations of the people in the cafe as pure functions: Poses.apply(rig, input) fills a PersonRig.
 * No Minecraft classes, so everything here can be unit-tested; client/CafePersonModel only copies the result.
 */
public final class Poses {
    // customer modes = CafeCustomerEntity.STATE_*
    public static final int C_IDLE = 0, C_WALKING = 1, C_WAITING = 2, C_DRINKING = 3, C_LEAVING = 4;
    /** Ticks of the sip animation: reaching, drinking, and the tick of the pixel burst (CafeCustomerEntity.BURST_TICK). */
    public static final int BURST_TICK = 72;

    private static final float PI = (float) Math.PI;

    private Poses() {}

    // ------------------------------------------------------------------ small maths

    public static float ease(float x) {
        x = x < 0.0F ? 0.0F : Math.min(x, 1.0F);
        return x * x * (3.0F - 2.0F * x);
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** 0 -> 1 -> 0 envelope: rises on [a, a+ramp], falls on [b-ramp, b]. */
    public static float window(float x, float a, float b, float ramp) {
        return Math.min(ease((x - a) / ramp), ease((b - x) / ramp));
    }

    private static float sin(float x) {
        return (float) Math.sin(x);
    }

    private static float cos(float x) {
        return (float) Math.cos(x);
    }

    private static int hash(int n) {
        n ^= n >>> 16;
        n *= 0x45d9f3b;
        n ^= n >>> 16;
        n *= 0x45d9f3b;
        n ^= n >>> 16;
        return n & 0x7fffffff;
    }

    // ------------------------------------------------------------------ faces

    /** True for the few ticks of a blink; every person blinks at its own pace (about every 3-5 seconds). */
    public static boolean blink(float age, int seed) {
        int period = 60 + hash(seed * 31 + 7) % 50;
        int offset = hash(seed) % period;
        int phase = (int) Math.floor(age + offset) % period;
        return phase < 3;
    }

    /** Mood of a customer: angry when out of patience (hasty and grumpy people earlier), happy after a good review. */
    public static int customerMood(PoseInput in) {
        if (in.mode == C_DRINKING) {
            float t = in.t;
            if (t >= BURST_TICK) return in.stars >= 4 ? PersonRig.MOOD_HAPPY : in.stars <= 2 ? PersonRig.MOOD_ANGRY : PersonRig.MOOD_NEUTRAL;
            return t >= 18 && t < 36 ? PersonRig.MOOD_HAPPY : PersonRig.MOOD_NEUTRAL;
        }
        if (in.mode == C_LEAVING) {
            return in.stars >= 3 ? PersonRig.MOOD_HAPPY : in.stars >= 1 ? PersonRig.MOOD_ANGRY : PersonRig.MOOD_NEUTRAL;
        }
        if (in.mode == C_WAITING) {
            int limit = in.style == Personality.Style.HASTY || in.style == Personality.Style.GRUMPY ? 45 : 25;
            if (in.patience < limit) return PersonRig.MOOD_ANGRY;
            if (in.style == Personality.Style.GRUMPY) return PersonRig.MOOD_NEUTRAL;
            if (in.patience >= 85) return PersonRig.MOOD_HAPPY;
        }
        return PersonRig.MOOD_NEUTRAL;
    }

    /** Skin face index 0 neutral, 1 blink, 2 happy, 3 angry. */
    public static int face(int mood, boolean blink) {
        if (blink) return 1;
        return mood == PersonRig.MOOD_HAPPY ? 2 : mood == PersonRig.MOOD_ANGRY ? 3 : 0;
    }

    // ------------------------------------------------------------------ keyframes

    /** A pose of the upper body: lean, head pitch/yaw, right arm (rx, ry, rz, elbow), left arm. */
    static final class Key {
        final float lean, hx, hy;
        final float[] r, l;

        Key(float lean, float hx, float hy, float[] r, float[] l) {
            this.lean = lean;
            this.hx = hx;
            this.hy = hy;
            this.r = r;
            this.l = l;
        }
    }

    static float[] arm(float rx, float ry, float rz, float elbow) {
        return new float[]{rx, ry, rz, elbow};
    }

    static Key key(float lean, float hx, float hy, float[] r, float[] l) {
        return new Key(lean, hx, hy, r, l);
    }

    /** Smoothly goes through keys[i] at times[i] (times ascending, the last key is held). */
    static Key sample(Key[] keys, float[] times, float t) {
        if (t <= times[0]) return keys[0];
        for (int i = 1; i < keys.length; i++) {
            if (t < times[i]) {
                float k = ease((t - times[i - 1]) / (times[i] - times[i - 1]));
                return mix(keys[i - 1], keys[i], k);
            }
        }
        return keys[keys.length - 1];
    }

    static Key mix(Key a, Key b, float k) {
        float[] r = new float[4], l = new float[4];
        for (int i = 0; i < 4; i++) {
            r[i] = lerp(a.r[i], b.r[i], k);
            l[i] = lerp(a.l[i], b.l[i], k);
        }
        return new Key(lerp(a.lean, b.lean, k), lerp(a.hx, b.hx, k), lerp(a.hy, b.hy, k), r, l);
    }

    /** Applies a key on top of the base pose with the given strength 0..1. */
    static void put(PersonRig rig, Key k, float w) {
        rig.lean(k.lean * w);
        rig.head.rx += k.hx * w;
        rig.head.ry += k.hy * w;
        blendArm(rig.rightArm, k.r, w);
        blendArm(rig.leftArm, k.l, w);
    }

    private static void blendArm(PersonRig.Part p, float[] v, float w) {
        p.rx = lerp(p.rx, v[0], w);
        p.ry = lerp(p.ry, v[1], w);
        p.rz = lerp(p.rz, v[2], w);
        p.elbow = lerp(p.elbow, v[3], w);
    }

    // ------------------------------------------------------------------ the base: standing, walking, breathing, glancing

    static void base(PersonRig rig, PoseInput in) {
        rig.reset();
        float w = in.walk;
        float sw = in.limbSwing * 0.6662F;
        rig.rightLeg.rx = cos(sw) * 1.2F * w;
        rig.leftLeg.rx = cos(sw + PI) * 1.2F * w;
        rig.rightArm.rx = cos(sw + PI) * 0.9F * w;
        rig.leftArm.rx = cos(sw) * 0.9F * w;
        rig.rightArm.elbow = 0.12F + 0.55F * w * Math.max(0.0F, -cos(sw + PI));
        rig.leftArm.elbow = 0.12F + 0.55F * w * Math.max(0.0F, -cos(sw));
        // the body turns a bit against the legs
        rig.body.ry = cos(sw) * 0.12F * w;
        rig.head.ry = -rig.body.ry * 0.5F;
        rig.lean(0.05F * w);

        // breathing: the shoulders rise and fall, the arms hang a little away from the body
        float breath = sin(in.age * 0.09F + in.seed);
        rig.rightArm.rz = 0.05F + breath * 0.025F;
        rig.leftArm.rz = -0.05F - breath * 0.025F;
        rig.head.rx += breath * 0.015F;
        rig.rightArm.y -= breath * 0.12F * (1.0F - w);
        rig.leftArm.y -= breath * 0.12F * (1.0F - w);

        // the person looks around now and then (not while walking)
        int slot = (int) Math.floor((in.age + hash(in.seed) % 97) / 70.0F);
        int h = hash(slot * 13 + in.seed);
        if (h % 3 != 0) {
            float within = (in.age + hash(in.seed) % 97) / 70.0F - slot;
            float dir = (h >> 4 & 1) == 0 ? -1.0F : 1.0F;
            float amount = 0.35F + (h >> 8 & 7) * 0.05F;
            rig.head.ry += dir * amount * window(within, 0.1F, 0.9F, 0.25F) * (1.0F - w);
            rig.head.rx += (h >> 12 & 1) * 0.08F * window(within, 0.1F, 0.9F, 0.25F);
        }
        rig.head.rx += in.headPitch * 0.0174533F;
        rig.head.ry += in.headYaw * 0.0174533F;
    }

    // ------------------------------------------------------------------ customers

    public static void customer(PersonRig rig, PoseInput in) {
        base(rig, in);
        switch (in.mode) {
            case C_WAITING -> waiting(rig, in);
            case C_DRINKING -> drinking(rig, in);
            case C_LEAVING -> leaving(rig, in);
            default -> { }
        }
    }

    static final Key CROSSED = key(0.0F, 0.0F, 0.0F, arm(-0.85F, -0.62F, 0.0F, 1.95F), arm(-0.85F, 0.62F, 0.0F, 1.95F));
    static final Key CLASPED = key(0.0F, 0.0F, 0.0F, arm(-0.45F, -0.3F, 0.0F, 0.9F), arm(-0.45F, 0.3F, 0.0F, 0.9F));
    static final Key HIPS = key(0.0F, 0.0F, 0.0F, arm(0.2F, 0.0F, 0.45F, 1.25F), arm(0.2F, 0.0F, -0.45F, 1.25F));
    static final Key WATCH_LOOK = key(0.0F, 0.0F, 0.0F, arm(0.04F, 0.0F, 0.05F, 0.12F), arm(-0.55F, 0.35F, -0.1F, 1.75F));
    static final Key PHONE = key(0.0F, 0.0F, 0.0F, arm(0.04F, 0.0F, 0.05F, 0.12F), arm(-0.8F, 0.1F, -0.05F, 1.5F));

    static void waiting(PersonRig rig, PoseInput in) {
        int period;
        switch (in.style) {
            case HASTY -> period = 130;
            case PICKY -> period = 210;
            case GRUMPY -> period = 170;
            default -> period = 250;
        }
        float cycle = (in.age + hash(in.seed) % period) % period / period;
        boolean angry = customerMood(in) == PersonRig.MOOD_ANGRY;
        float weight = in.walk > 0.2F ? 0.0F : 1.0F;

        // 1) looks at the watch (the head follows the left wrist), hasty people more often
        float watch = window(cycle, 0.22F, 0.42F, 0.06F);
        // 2) the waiting posture: sweet people fold the hands, picky ones fold the arms, grumpy ones put the hands on the hips
        float posture = window(cycle, 0.50F, 0.98F, 0.08F) * (in.patience < 85 ? 1.0F : 0.4F);
        Key idle = switch (in.style) {
            case SWEET -> CLASPED;
            case HASTY -> PHONE;
            case PICKY -> CROSSED;
            case GRUMPY -> HIPS;
        };
        if (in.patience < 60) idle = in.style == Personality.Style.SWEET ? CROSSED : idle;
        if (angry && in.style != Personality.Style.GRUMPY) idle = CROSSED;
        put(rig, idle, posture * weight);
        put(rig, WATCH_LOOK, watch * weight);
        rig.head.rx += 0.25F * watch * weight;
        rig.head.ry += 0.3F * watch * weight;

        // 3) the weight moves from foot to foot, impatient people tap a foot
        float shift = sin(in.age * 0.05F + in.seed) * weight;
        rig.body.rz += shift * 0.03F;
        rig.rightLeg.rz += shift * 0.03F;
        rig.leftLeg.rz += shift * 0.03F;
        if (angry) {
            float tap = Math.max(0.0F, sin(in.age * (in.style == Personality.Style.HASTY ? 0.9F : 0.65F)));
            rig.rightLeg.rx = -0.45F * tap * weight;
            rig.head.ry += sin(in.age * 0.2F) * 0.05F;
        }
        // 4) the bubble pops up: one little surprised hop of the head at the start
        float pop = window(in.t, 0.0F, 12.0F, 5.0F);
        rig.head.rx -= 0.12F * pop * weight;
    }

    static void drinking(PersonRig rig, PoseInput in) {
        float t = in.t;
        // 0 -> 1: how far the cup is lifted to the mouth
        float up;
        if (t < 10.0F) up = 0.55F * ease(t / 10.0F);
        else if (t < 18.0F) up = 0.55F + 0.45F * ease((t - 10.0F) / 8.0F);
        else if (t < 36.0F) up = 1.0F;
        else up = 1.0F - ease((t - 36.0F) / 16.0F);
        rig.rightArm.rx = lerp(rig.rightArm.rx, -1.1F, up);
        rig.rightArm.ry = lerp(rig.rightArm.ry, -0.2F, up);
        rig.rightArm.rz = lerp(rig.rightArm.rz, 0.0F, up);
        rig.rightArm.elbow = lerp(rig.rightArm.elbow, 2.0F, ease(Math.max(0.0F, up * 1.4F - 0.4F)));
        // the other hand holds the saucer / rests in front
        rig.leftArm.rx = lerp(rig.leftArm.rx, -0.5F, up);
        rig.leftArm.ry = lerp(rig.leftArm.ry, 0.3F, up);
        rig.leftArm.elbow = lerp(rig.leftArm.elbow, 1.1F, up);
        if (t >= 14.0F && t < 38.0F) {
            float k = window(t, 14.0F, 38.0F, 4.0F);
            rig.head.rx -= 0.25F * k;                     // the head goes back to drink
            rig.lean(-0.05F * k);
            rig.head.rz += sin((t - 14.0F) * 0.3F) * 0.015F;
        }
        if (t >= BURST_TICK) {
            float k = t - BURST_TICK;
            float s = ease(k / 4.0F);
            if (in.stars >= 4) {                           // cheers: both arms up, waving
                float wave = sin(k * 0.9F) * 0.2F * s;
                rig.rightArm.rx = lerp(rig.rightArm.rx, -3.0F + wave, s);
                rig.leftArm.rx = lerp(rig.leftArm.rx, -3.0F - wave, s);
                rig.rightArm.ry = lerp(rig.rightArm.ry, 0.0F, s);
                rig.leftArm.ry = lerp(rig.leftArm.ry, 0.0F, s);
                rig.rightArm.rz = lerp(rig.rightArm.rz, 0.35F, s);
                rig.leftArm.rz = lerp(rig.leftArm.rz, -0.35F, s);
                rig.rightArm.elbow = lerp(rig.rightArm.elbow, 0.1F, s);
                rig.leftArm.elbow = lerp(rig.leftArm.elbow, 0.1F, s);
                rig.head.rx -= 0.15F * s;
            } else if (in.stars <= 2) {                    // disappointed: shakes the head, arms folded
                put(rig, CROSSED, s);
                rig.head.ry += sin(k * 1.3F) * 0.35F * window(k, 0.0F, 30.0F, 6.0F);
                rig.head.rx += 0.1F * s;
            } else {                                       // 3 stars: a satisfied nod
                rig.head.rx += sin(k * 0.45F) * 0.18F * window(k, 0.0F, 24.0F, 6.0F);
            }
        }
    }

    static void leaving(PersonRig rig, PoseInput in) {
        if (in.stars >= 3 && in.walk < 0.25F && in.t < 36.0F) {            // waves goodbye
            float k = window(in.t, 0.0F, 36.0F, 6.0F);
            rig.rightArm.rx = lerp(rig.rightArm.rx, -2.6F, k);
            rig.rightArm.rz = lerp(rig.rightArm.rz, 0.5F + sin(in.t * 0.9F) * 0.25F, k);
            rig.rightArm.elbow = lerp(rig.rightArm.elbow, 0.9F, k);
            rig.head.rz += 0.06F * k;
        } else if (in.stars >= 1 && in.stars <= 2) {                         // stomps off, arms stiff
            float k = ease(in.walk * 2.0F);
            rig.rightArm.elbow = lerp(rig.rightArm.elbow, 0.5F, k);
            rig.leftArm.elbow = lerp(rig.leftArm.elbow, 0.5F, k);
            rig.leftArm.rx *= 1.3F;
            rig.rightArm.rx *= 1.3F;
        }
    }

    // ------------------------------------------------------------------ staff

    private static final Key REST = key(0.0F, 0.0F, 0.0F, arm(0, 0, 0.05F, 0.12F), arm(0, 0, -0.05F, 0.12F));

    // barista, the coffee machine, one loop of MACHINE_LOOP ticks
    public static final int MACHINE_LOOP = 130;
    private static final float[] MT = {0, 14, 26, 44, 58, 76, 96, 112, 130};
    private static final Key[] MK = {
            key(0.10F, 0.18F, 0.0F, arm(-1.0F, -0.05F, 0.08F, 0.30F), arm(-0.85F, 0.10F, -0.10F, 0.35F)),     // hands on the machine
            key(0.14F, 0.20F, 0.0F, arm(-1.30F, 0.0F, 0.08F, 0.20F), arm(-0.85F, 0.10F, -0.10F, 0.35F)),      // pulls the lever
            key(0.10F, 0.18F, 0.0F, arm(-0.95F, 0.0F, 0.08F, 0.30F), arm(-0.85F, 0.10F, -0.10F, 0.35F)),
            key(0.18F, 0.30F, 0.0F, arm(-0.80F, -0.22F, 0.0F, 1.05F), arm(-0.90F, 0.22F, 0.0F, 0.95F)),       // tamps
            key(0.22F, 0.34F, 0.0F, arm(-0.70F, -0.22F, 0.0F, 0.80F), arm(-0.85F, 0.22F, 0.0F, 0.80F)),       // presses
            key(0.06F, 0.28F, -0.1F, arm(-1.15F, -0.30F, 0.15F, 1.40F), arm(-0.60F, 0.30F, 0.0F, 1.40F)),      // pours the milk
            key(0.10F, 0.38F, 0.0F, arm(-1.05F, -0.20F, 0.10F, 1.45F), arm(-0.65F, 0.25F, 0.0F, 1.35F)),      // draws the art
            key(0.05F, 0.10F, 0.0F, arm(-1.0F, -0.1F, 0.08F, 0.8F), arm(-0.8F, 0.1F, -0.1F, 0.5F)),           // tidies up
            key(0.10F, 0.18F, 0.0F, arm(-1.0F, -0.05F, 0.08F, 0.30F), arm(-0.85F, 0.10F, -0.10F, 0.35F)),
    };

    private static final float[] ST = {0, 10, 25, 40};
    private static final Key[] SK = {
            key(0.0F, 0.0F, 0.0F, arm(-0.9F, -0.1F, 0.05F, 0.9F), arm(-0.2F, 0.0F, -0.05F, 0.2F)),            // takes the cup
            key(0.05F, -0.12F, 0.0F, arm(-1.35F, 0.2F, 0.12F, 0.35F), arm(-0.15F, 0.0F, -0.05F, 0.2F)),       // holds it out, smiles
            key(0.04F, -0.10F, 0.0F, arm(-1.35F, 0.2F, 0.12F, 0.35F), arm(-0.15F, 0.0F, -0.05F, 0.2F)),
            REST,
    };

    private static final float[] PT = {0, 12, 38, 50};
    private static final Key[] PK = {
            key(0.0F, 0.0F, 0.0F, arm(-1.0F, -0.35F, 0.0F, 1.1F), arm(-1.0F, 0.35F, 0.0F, 1.1F)),            // lifts the plate
            key(0.14F, -0.1F, 0.0F, arm(-1.40F, -0.12F, 0.0F, 0.12F), arm(-1.40F, 0.12F, 0.0F, 0.12F)),      // bows, holds it out
            key(0.12F, -0.1F, 0.0F, arm(-1.40F, -0.12F, 0.0F, 0.12F), arm(-1.40F, 0.12F, 0.0F, 0.12F)),
            REST,
    };

    private static final Key OVEN_IN = key(0.30F, 0.25F, 0.0F, arm(-1.25F, -0.12F, 0.0F, 0.15F), arm(-1.25F, 0.12F, 0.0F, 0.15F));
    private static final Key OVEN_OUT = key(0.20F, 0.30F, 0.0F, arm(-0.85F, -0.12F, 0.0F, 0.9F), arm(-0.85F, 0.12F, 0.0F, 0.9F));
    private static final Key KNEAD_A = key(0.22F, 0.30F, 0.0F, arm(-1.05F, -0.15F, 0.0F, 0.55F), arm(-1.05F, 0.15F, 0.0F, 0.55F));

    private static final float[] WT = {0, 20, 90, 108, 124, 160};
    private static final Key[] WK = {
            CROSSED_ARMS(), CROSSED_ARMS(),
            key(0.0F, 0.0F, 0.0F, arm(-0.85F, -0.62F, 0.0F, 1.95F), arm(-0.85F, 0.62F, 0.0F, 1.95F)),
            key(0.0F, -0.15F, 0.0F, arm(-2.55F, 0.0F, -0.1F, 2.3F), arm(-0.85F, 0.62F, 0.0F, 1.95F)),        // wipes the brow
            key(0.0F, 0.0F, 0.0F, arm(-0.85F, -0.62F, 0.0F, 1.95F), arm(-0.85F, 0.62F, 0.0F, 1.95F)),
            CROSSED_ARMS(),
    };

    private static Key CROSSED_ARMS() {
        return key(0.0F, 0.0F, 0.0F, arm(-0.85F, -0.62F, 0.0F, 1.95F), arm(-0.85F, 0.62F, 0.0F, 1.95F));
    }

    public static void staff(PersonRig rig, PoseInput in) {
        base(rig, in);
        float t = in.t;
        float stand = in.walk > 0.2F ? 0.0F : 1.0F;
        switch (in.mode) {
            case StaffAction.MACHINE -> {
                float loop = t % MACHINE_LOOP;
                put(rig, sample(MK, MT, loop), stand);
                if (loop >= 76 && loop < 112) {          // the latte art: the pitcher draws small waves
                    float k = window(loop, 76, 112, 8) * stand;
                    rig.rightArm.ry += sin(loop * 0.55F) * 0.16F * k;
                    rig.rightArm.rz += sin(loop * 0.55F + 1.2F) * 0.06F * k;
                    rig.head.ry += sin(loop * 0.55F) * 0.04F * k;
                }
                if (loop >= 26 && loop < 60) {            // the tamper presses twice
                    rig.rightArm.rx += Math.max(0.0F, sin((loop - 26) * 0.37F)) * 0.12F * stand;
                }
            }
            case StaffAction.SERVE -> put(rig, sample(SK, ST, t), stand);
            case StaffAction.WIPE -> {
                float k = window(t, 0.0F, StaffAction.WIPE_TICKS, 10.0F) * stand;
                float sweep = sin(t * 0.38F);
                put(rig, key(0.20F, 0.30F, sweep * 0.20F, arm(-0.95F, -0.35F + sweep * 0.4F, 0.0F, 0.45F + sweep * 0.1F),
                        arm(-0.55F, 0.25F, -0.05F, 0.8F)), k);
                rig.body.ry += sweep * 0.12F * k;
            }
            case StaffAction.KNEAD -> {
                float k = window(Math.min(t, 1000.0F), 0.0F, 100000.0F, 12.0F) * stand;
                float push = sin(in.age * 0.42F);
                put(rig, KNEAD_A, k);
                // the dough is pushed away and folded back: the arms go forward and down, the body follows
                rig.rightArm.rx += push * 0.32F * k;
                rig.leftArm.rx += sin(in.age * 0.42F + 1.0F) * 0.32F * k;
                rig.rightArm.elbow += (1.0F - push) * 0.22F * k;
                rig.leftArm.elbow += (1.0F - sin(in.age * 0.42F + 1.0F)) * 0.22F * k;
                rig.body.rx += push * 0.05F * k;
                rig.head.ry += sin(in.age * 0.21F) * 0.05F * k;
            }
            case StaffAction.OVEN -> {
                float loop = t % 70;
                float in1 = window(loop, 8, 40, 12);
                put(rig, mix(OVEN_OUT, OVEN_IN, in1), stand);
                rig.rightArm.rx += sin(loop * 0.09F) * 0.03F;
            }
            case StaffAction.WATCH -> put(rig, sample(WK, WT, t % 160), stand);
            case StaffAction.PRESENT -> put(rig, sample(PK, PT, t), stand);
            default -> {
                // idle: the barista leans on the counter with the elbow, the chef stands with the hands behind the back
                put(rig, REST, 0.0F);
            }
        }
    }
}
