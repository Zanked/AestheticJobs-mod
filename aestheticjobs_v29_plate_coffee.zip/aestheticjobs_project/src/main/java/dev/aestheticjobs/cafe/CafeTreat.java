package dev.aestheticjobs.cafe;

import dev.aestheticjobs.cafe.kitchen.Menu;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.registry.ModComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent;

/** A little joy: hearts over the head of a player who finished a cafe drink or dessert, an effect from a masterpiece. */
public final class CafeTreat {
    private CafeTreat() {}

    public static void onUseFinish(LivingEntityUseItemEvent.Finish event) {
        if (event.getEntity() instanceof ServerPlayer player) enjoy(player, event.getItem());
    }

    /** A finished drink or dessert: the effect of a masterpiece and the hearts. */
    public static void enjoy(ServerPlayer player, ItemStack stack) {
        if (stack.get(ModComponents.CUP.get()) == null && Dessert.ofItem(stack.getItem()) == null) return;
        Integer family = stack.get(ModComponents.MASTERPIECE.get());
        if (family != null && family > 0 && family < Menu.Kind.values().length) {
            player.addEffect(switch (Menu.Kind.values()[family]) {
                case DRINK, BUNS -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 600);
                case COOKIES -> new MobEffectInstance(MobEffects.DIG_SPEED, 600);
                case CAKES -> new MobEffectInstance(MobEffects.REGENERATION, 100);
                case PIES -> new MobEffectInstance(MobEffects.ABSORPTION, 900);
                case CREAMS -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 400);
            });
        }
        player.serverLevel().sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + player.getBbHeight() + 0.3,
                player.getZ(), 3, 0.3, 0.12, 0.3, 0.0);
    }
}
