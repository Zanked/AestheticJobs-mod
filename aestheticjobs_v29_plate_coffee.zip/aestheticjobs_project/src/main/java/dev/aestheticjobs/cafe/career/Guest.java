package dev.aestheticjobs.cafe.career;

import java.util.Random;

/** Sometimes a guest is special: it changes what a good service is worth. Plain Java. */
public enum Guest {
    REGULAR("regular"),
    /** A food critic: a great cup doubles the tip, the review counts three times (good or bad). */
    CRITIC("critic"),
    /** A big tipper. */
    GENEROUS("generous"),
    /** In a hurry: a big bonus, but only inside the speed window. */
    HURRY("hurry"),
    /** A birthday: extra tip, double experience, confetti. */
    BIRTHDAY("birthday");

    private final String id;

    Guest(String id) {
        this.id = id;
    }

    public String id() { return id; }

    /** Extra tip in percent. */
    public int tipBonus(int stars, boolean fast) {
        return switch (this) {
            case REGULAR -> 0;
            case CRITIC -> stars >= 4 ? 100 : 0;
            case GENEROUS -> 80;
            case HURRY -> fast ? 90 : 0;
            case BIRTHDAY -> 30;
        };
    }

    public int reviewCount() { return this == CRITIC ? 3 : 1; }

    public int xpFactor() { return this == BIRTHDAY ? 2 : 1; }

    public static Guest byIndex(int i) {
        return i >= 0 && i < values().length ? values()[i] : REGULAR;
    }

    public static Guest pickSpecial(Random random) {
        return values()[1 + random.nextInt(values().length - 1)];
    }
}
