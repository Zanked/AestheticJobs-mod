package dev.aestheticjobs.cafe.kitchen;

/** What one cook has found out: which additions he has tried on which base, and the signature recipes he knows. */
public final class Knowledge {
    private final int[] tried = new int[Menu.size()];
    private long found;

    public boolean tried(int base, Extra e) {
        return base >= 0 && base < tried.length && e.in(tried[base]);
    }

    /** Every addition of this recipe is known, so its stars can be foretold. */
    public boolean knows(int base, int mask) {
        if (base < 0 || base >= tried.length) return false;
        Signature s = Signature.of(base, mask);
        if (s != null) return knows(s);
        return (mask & ~tried[base]) == 0;
    }

    public boolean knows(Signature s) {
        return (found & s.bit()) != 0;
    }

    public int foundCount() {
        return Long.bitCount(found);
    }

    /** Remembers a cooked recipe; returns the signature recipe if it was found just now, otherwise null. */
    public Signature learn(int base, int mask) {
        if (!Cooking.valid(base, mask)) return null;
        tried[base] |= mask;
        Signature s = Signature.of(base, mask);
        if (s == null || knows(s)) return null;
        found |= s.bit();
        return s;
    }

    public int[] triedCopy() { return tried.clone(); }
    public long foundBits() { return found; }

    public void load(int[] savedTried, long savedFound) {
        for (int i = 0; i < tried.length; i++) tried[i] = i < savedTried.length ? savedTried[i] & Cooking.ALL_EXTRAS : 0;
        found = savedFound & ((1L << Signature.values().length) - 1);
    }
}
