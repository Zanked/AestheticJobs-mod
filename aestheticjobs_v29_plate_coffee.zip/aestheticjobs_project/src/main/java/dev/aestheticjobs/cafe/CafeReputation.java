package dev.aestheticjobs.cafe;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** The reviews of every barista (world/data/aestheticjobs_reputation.dat). Server side only. */
public class CafeReputation extends SavedData {
    public static final String NAME = "aestheticjobs_reputation";

    private final Map<UUID, ReviewLog> logs = new HashMap<>();

    public static CafeReputation get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(factory(), NAME);
    }

    public static SavedData.Factory<CafeReputation> factory() {
        return new SavedData.Factory<>(CafeReputation::new, CafeReputation::load, null);
    }

    /** The reviews of a barista, null if nobody has reviewed them yet. */
    @Nullable
    public ReviewLog peek(UUID barista) {
        return logs.get(barista);
    }

    public void add(UUID barista, ReviewLog.Review review) {
        logs.computeIfAbsent(barista, k -> new ReviewLog()).add(review);
        setDirty();
    }

    /** The tip multiplier the reputation of this barista earns (1.0 without reviews). */
    public double tipMultiplier(UUID barista) {
        ReviewLog log = logs.get(barista);
        return log == null ? 1.0 : log.tipMultiplier();
    }

    public static CafeReputation load(CompoundTag tag, HolderLookup.Provider registries) {
        CafeReputation data = new CafeReputation();
        ListTag list = tag.getList("logs", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            ReviewLog log = new ReviewLog();
            ListTag rs = t.getList("reviews", Tag.TAG_COMPOUND);
            for (int j = 0; j < rs.size(); j++) {
                CompoundTag r = rs.getCompound(j);
                log.add(new ReviewLog.Review(r.getInt("c"), r.getInt("s"), r.getInt("d"), r.getLong("t")));
            }
            log.setTotal(t.getInt("total"));
            data.logs.put(t.getUUID("id"), log);
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        for (Map.Entry<UUID, ReviewLog> e : logs.entrySet()) {
            CompoundTag t = new CompoundTag();
            t.putUUID("id", e.getKey());
            t.putInt("total", e.getValue().total());
            ListTag rs = new ListTag();
            for (ReviewLog.Review r : e.getValue().reviews()) {
                CompoundTag c = new CompoundTag();
                c.putInt("c", r.customer());
                c.putInt("s", r.stars());
                c.putInt("d", r.drink());
                c.putLong("t", r.time());
                rs.add(c);
            }
            t.put("reviews", rs);
            list.add(t);
        }
        tag.put("logs", list);
        return tag;
    }
}
