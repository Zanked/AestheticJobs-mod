package dev.aestheticjobs.cafe.kitchen;

/**
 * The coffee machine: a cup under the spout, ground coffee in the group, the lever, then milk and the rest into the cup.
 * Every method says whether it did something; the block entity takes the items and plays the sounds.
 */
public final class BrewState {
    public static final int SHOT_TICKS = 60;

    private boolean cup, grounds;
    private int shots, art;
    private long shotEnd;
    private final int[] counts = new int[Pantry.values().length];

    public boolean cup() { return cup; }
    public boolean grounds() { return grounds; }
    public int shots() { return shots; }
    public int art() { return art; }
    public int count(Pantry p) { return counts[p.ordinal()]; }
    public long shotEnd() { return shotEnd; }
    public boolean pulling(long now) { return now < shotEnd; }
    public boolean empty() { return !cup && !grounds; }

    public boolean putCup() {
        if (cup) return false;
        cup = true;
        return true;
    }

    public boolean putGrounds(long now) {
        if (grounds || pulling(now) || shots >= CupRecipe.MAX_SHOTS) return false;
        grounds = true;
        return true;
    }

    /** The lever: one shot of espresso runs into the cup. */
    public boolean pull(long now) {
        if (!cup || !grounds || pulling(now)) return false;
        grounds = false;
        shots++;
        shotEnd = now + SHOT_TICKS;
        return true;
    }

    /** Whether this may be poured in now (needs coffee in the cup and must still be some drink afterwards). */
    public boolean canPour(Pantry p, long now) {
        if (!cup || shots == 0 || pulling(now)) return false;
        int[] next = counts.clone();
        next[p.ordinal()]++;
        // the second shot of a flat white may come after the milk, so one shot more is allowed to complete the drink
        return CupRecipe.match(shots, next) != null || shots < 2 && CupRecipe.match(2, next) != null;
    }

    public boolean pour(Pantry p, long now) {
        if (!canPour(p, now)) return false;
        counts[p.ordinal()]++;
        return true;
    }

    /** The drink in the cup now, or null. */
    public CupRecipe.Result drink() {
        return shots == 0 ? null : CupRecipe.match(shots, counts);
    }

    public void nextArt() {
        art = (art + 1) % LatteArt.STYLES.length;
    }

    /** After the cup was taken: the ground coffee that was not used stays. */
    public void takeCup() {
        cup = false;
        shots = 0;
        shotEnd = 0;
        java.util.Arrays.fill(counts, 0);
    }

    public void clear() {
        takeCup();
        grounds = false;
    }

    public long[] save() {
        long[] out = new long[5 + counts.length];
        out[0] = cup ? 1 : 0;
        out[1] = grounds ? 1 : 0;
        out[2] = shots;
        out[3] = art;
        out[4] = shotEnd;
        for (int i = 0; i < counts.length; i++) out[5 + i] = counts[i];
        return out;
    }

    public void load(long[] in) {
        clear();
        art = 0;
        if (in.length < 5) return;
        cup = in[0] != 0;
        grounds = in[1] != 0;
        shots = (int) Math.max(0, Math.min(CupRecipe.MAX_SHOTS, in[2]));
        art = (int) Math.floorMod(in[3], (long) LatteArt.STYLES.length);
        shotEnd = in[4];
        for (int i = 0; i < counts.length && 5 + i < in.length; i++) counts[i] = (int) Math.max(0, Math.min(2, in[5 + i]));
    }
}
