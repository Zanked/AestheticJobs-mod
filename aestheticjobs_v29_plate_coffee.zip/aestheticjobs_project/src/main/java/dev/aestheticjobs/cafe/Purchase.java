package dev.aestheticjobs.cafe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

/**
 * Put on a cup or a dessert that a customer paid for: who ordered it (uuid string) and what it cost (cents).
 * A barista on shift who eats or drinks something that is not his own purchase is fined (CafeFraud).
 */
public record Purchase(String buyer, long price) {
    public static final Codec<Purchase> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.STRING.fieldOf("buyer").forGetter(Purchase::buyer),
            Codec.LONG.fieldOf("price").forGetter(Purchase::price)
    ).apply(instance, Purchase::new));

    public static final StreamCodec<ByteBuf, Purchase> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.STRING_UTF8, Purchase::buyer,
            ByteBufCodecs.VAR_LONG, Purchase::price,
            Purchase::new);
}
