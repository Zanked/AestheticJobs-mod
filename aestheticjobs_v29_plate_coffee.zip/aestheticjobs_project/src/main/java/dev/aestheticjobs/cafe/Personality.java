package dev.aestheticjobs.cafe;

import java.util.function.IntUnaryOperator;

/**
 * Who a customer is. The 8 skins (Order.CUSTOMERS) are 8 different people: they like different drinks and desserts,
 * wait for different times, tip differently and judge the cup differently. The personality is derived from the skin
 * number only, so the client knows it too (patience bars on the ticket) and nothing has to be saved.
 *
 * No Minecraft classes in here on purpose: drinks and desserts are referred to by their id strings.
 */
public enum Personality {
    //      style           patience tip  bias hasty dessert  favourite drinks             favourite desserts
    EMMA(Style.SWEET, 1.25F, 1.15F, +1, false, 0.55F,
            new String[]{"latte", "cappuccino"},
            new String[]{"cupcake_pink", "macaron_pink", "cake_strawberry", "cookie_heart"}),
    LIAM(Style.HASTY, 0.70F, 1.00F, 0, true, 0.15F,
            new String[]{"espresso", "americano"},
            new String[]{"croissant", "cookie_choc"}),
    SOFIA(Style.PICKY, 1.00F, 1.30F, -1, false, 0.50F,
            new String[]{"flat_white", "macchiato"},
            new String[]{"tiramisu", "creme_brulee", "panna_cotta", "fruit_tart"}),
    NOAH(Style.SWEET, 1.30F, 0.60F, 0, false, 0.50F,
            new String[]{"raf", "mocha"},
            new String[]{"cookie_choc", "donut_choc", "pancakes", "waffle"}),
    MIA(Style.SWEET, 1.10F, 1.10F, 0, false, 0.85F,
            new String[]{"mocha", "macchiato"},
            new String[]{"macaron_mint", "macaron_lemon", "sundae", "ice_cream_cone", "cake_pop"}),
    OLIVER(Style.GRUMPY, 1.00F, 0.90F, 0, false, 0.30F,
            new String[]{"americano", "cappuccino"},
            new String[]{"apple_pie", "medovik", "baklava"}),
    LILY(Style.PICKY, 1.00F, 1.10F, 0, false, 0.45F,
            new String[]{"latte", "raf"},
            new String[]{"fruit_tart", "cheesecake", "macaron_pink", "eclair"}),
    MAX(Style.GRUMPY, 0.80F, 0.80F, -1, true, 0.30F,
            new String[]{"espresso", "flat_white"},
            new String[]{"brownie", "cinnamon_roll"});

    /** How the customer talks: the lines are translation keys customer.say.<style>.<event>. */
    public enum Style {
        SWEET("sweet"), HASTY("hasty"), PICKY("picky"), GRUMPY("grumpy");

        private final String id;

        Style(String id) {
            this.id = id;
        }

        public String id() {
            return id;
        }
    }

    /** The moments a customer says something. */
    public enum Say {
        GREET("greet"),        // arrives at the counter
        FAVOURITE("fav"),      // arrives and the order is its favourite
        WAIT("wait"),          // the patience is half gone
        HURRY("hurry"),        // the patience is nearly gone
        LEAVE("leave"),        // lost patience
        WRONG("wrong"),        // got the wrong cup / the dessert is missing
        LOW("low"),            // the verdict on the cup: 1-2 stars
        MID("mid"),            // 3 stars
        HIGH("high"),          // 4-5 stars
        FRIEND("friend"),      // a company: speaks to the friend at the counter
        REPLY("reply"),        // a company: the friend answers
        FOLLOW("follow"),
        CROWD("crowd");        // arrives and sees a long line      // a company: the friend lost patience and left, so this one leaves too

        private final String id;

        Say(String id) {
            this.id = id;
        }

        public String id() {
            return id;
        }

        /** The verdict for a reaction of 1..5 stars. */
        public static Say verdict(int reaction) {
            return reaction <= 2 ? LOW : reaction == 3 ? MID : HIGH;
        }
    }

    /** Weight of a favourite in the random order (every other item weighs 1). */
    public static final int FAVOURITE_WEIGHT = 5;

    private final Style style;
    private final float patience;
    private final float tip;
    private final int bias;
    private final boolean hasty;
    private final float dessertChance;
    private final String[] drinks;
    private final String[] desserts;

    Personality(Style style, float patience, float tip, int bias, boolean hasty, float dessertChance,
                String[] drinks, String[] desserts) {
        this.style = style;
        this.patience = patience;
        this.tip = tip;
        this.bias = bias;
        this.hasty = hasty;
        this.dessertChance = dessertChance;
        this.drinks = drinks;
        this.desserts = desserts;
    }

    public static Personality of(int customer) {
        Personality[] all = values();
        return all[Math.floorMod(customer, all.length)];
    }

    public Style style() { return style; }
    /** Multiplier of how long the customer waits (and of the speed-bonus window). */
    public float patience() { return patience; }
    /** Multiplier of the tip. */
    public float tip() { return tip; }
    /** Added to the star rating when the customer judges the cup: -1 strict, +1 kind. */
    public int bias() { return bias; }
    /** A hurried customer is disappointed if it did not get the cup in the speed-bonus time. */
    public boolean hasty() { return hasty; }
    /** Chance to order a dessert with the drink. */
    public float dessertChance() { return dessertChance; }

    /**
     * Whether the customer takes another dessert when the ordered one is missing (it must still be a classic pair of its
     * drink, see Pairing). Kind and hurried customers do, picky and grumpy ones want exactly what they ordered.
     */
    public boolean acceptsSubstitute() {
        return style == Style.SWEET || style == Style.HASTY;
    }

    public boolean likesDrink(String drinkId) {
        for (String d : drinks) if (d.equals(drinkId)) return true;
        return false;
    }

    public boolean likesDessert(String dessertId) {
        for (String d : desserts) if (d.equals(dessertId)) return true;
        return false;
    }

    public int drinkWeight(String drinkId) {
        return likesDrink(drinkId) ? FAVOURITE_WEIGHT : 1;
    }

    public int dessertWeight(String dessertId) {
        return likesDessert(dessertId) ? FAVOURITE_WEIGHT : 1;
    }

    /** The translation key of a line of this customer. */
    public String lineKey(Say say) {
        return "customer.say." + style.id() + "." + say.id();
    }

    /**
     * What the customer thinks of the cup, 1..5 (this is the "review"). The barista is paid by the real quality
     * (stars); the personality only colours the reaction: a strict one is harder to please, a kind one is easier,
     * a favourite drink made well makes the day, a hurried one hates to wait.
     */
    public int reaction(int stars, boolean favourite, boolean slow) {
        int r = stars + bias;
        if (favourite && stars >= 3) r++;
        if (hasty && slow) r--;
        return Math.max(1, Math.min(5, r));
    }

    /** A random index 0..weights.length-1, an item chosen with the probability proportional to its weight. */
    public static int weightedPick(int[] weights, IntUnaryOperator nextInt) {
        int total = 0;
        for (int w : weights) total += Math.max(0, w);
        if (total <= 0) return 0;
        int roll = nextInt.applyAsInt(total);
        for (int i = 0; i < weights.length; i++) {
            roll -= Math.max(0, weights[i]);
            if (roll < 0) return i;
        }
        return weights.length - 1;
    }
}
