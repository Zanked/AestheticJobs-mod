package dev.aestheticjobs.cafe.kitchen;

/** What can be added to any drink or dessert. A recipe stores its additions as a bit mask of the ordinals. */
public enum Extra {
    //        id          item                              sweet creamy fruity choco
    SUGAR("sugar", "minecraft:sugar", 2, 0, 0, 0),
    VANILLA("vanilla", "aestheticjobs:syrup_vanilla", 1, 1, 0, 0),
    CARAMEL("caramel", "aestheticjobs:syrup_caramel", 2, 1, 0, 0),
    CHOCOLATE("chocolate", "aestheticjobs:chocolate", 1, 0, 0, 2),
    COCOA("cocoa", "minecraft:cocoa_beans", 0, 0, 0, 2),
    BERRY("berry", "minecraft:sweet_berries", 1, 0, 2, 0),
    HONEY("honey", "minecraft:honey_bottle", 2, 0, 1, 0),
    CREAM("cream", "aestheticjobs:cream_carton", 0, 2, 0, 0),
    APPLE("apple", "minecraft:apple", 0, 0, 2, 0);

    private final String id, item;
    private final int[] taste;

    Extra(String id, String item, int sweet, int creamy, int fruity, int choco) {
        this.id = id;
        this.item = item;
        this.taste = new int[]{sweet, creamy, fruity, choco};
    }

    public String id() { return id; }
    /** Registry id of the item it takes. */
    public String item() { return item; }
    public int taste(Flavor f) { return taste[f.ordinal()]; }
    public int bit() { return 1 << ordinal(); }

    public boolean in(int mask) {
        return (mask & bit()) != 0;
    }

    public static int mask(Extra... list) {
        int m = 0;
        for (Extra e : list) m |= e.bit();
        return m;
    }
}
