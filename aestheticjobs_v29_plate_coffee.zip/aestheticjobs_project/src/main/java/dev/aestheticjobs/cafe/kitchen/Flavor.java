package dev.aestheticjobs.cafe.kitchen;

/** The four tastes a drink or dessert can have; guests wish for them. */
public enum Flavor {
    SWEET("sweet", 0xFFE88AA0), CREAMY("creamy", 0xFFE8C98A), FRUITY("fruity", 0xFFD9605A), CHOCO("choco", 0xFF8A5A44);

    private final String id;
    private final int color;

    Flavor(String id, int color) {
        this.id = id;
        this.color = color;
    }

    public String id() { return id; }
    public int color() { return color; }
}
