package dev.aestheticjobs.cafe;

import dev.aestheticjobs.block.CafeDecorBlock;
import dev.aestheticjobs.cafe.career.Career;
import dev.aestheticjobs.cafe.career.Quest;
import dev.aestheticjobs.network.JournalPayload;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.saveddata.SavedData;
import net.neoforged.neoforge.network.PacketDistributor;

/** The careers of the baristas (world/data/aestheticjobs_career.dat). Server side only. */
public class CafeCareer extends SavedData {
    public static final String NAME = "aestheticjobs_career";
    private static final int COMFORT_RADIUS = 6;

    private final Map<UUID, Career> careers = new HashMap<>();

    public static CafeCareer get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(new SavedData.Factory<>(CafeCareer::new, CafeCareer::load, null), NAME);
    }

    /** The career of a barista with the tasks of today. Call setDirty() after changing it. */
    public Career of(UUID barista) {
        return careers.computeIfAbsent(barista, k -> new Career());
    }

    public static long day(MinecraftServer server) {
        return server.overworld().getDayTime() / 24000L;
    }

    public static List<Quest> quests(UUID barista, long day) {
        return Quest.ofDay(day, barista.getMostSignificantBits() ^ barista.getLeastSignificantBits(), Drink.values().length);
    }

    /** A guest walked out: the streak is over. */
    public static void guestLeft(MinecraftServer server, UUID barista) {
        CafeCareer data = get(server);
        data.of(barista).breakStreak();
        data.setDirty();
    }

    /** How many different decorations stand around this place: a cosy cafe gets better tips. */
    public static int decorKinds(ServerLevel level, BlockPos center) {
        EnumSet<CafeDecorBlock.Kind> found = EnumSet.noneOf(CafeDecorBlock.Kind.class);
        for (BlockPos p : BlockPos.betweenClosed(center.offset(-COMFORT_RADIUS, -2, -COMFORT_RADIUS),
                center.offset(COMFORT_RADIUS, 4, COMFORT_RADIUS))) {
            if (!level.isLoaded(p)) continue;
            Block block = level.getBlockState(p).getBlock();
            if (block instanceof CafeDecorBlock decor) found.add(decor.kind());
        }
        return found.size();
    }

    /** Opens the journal of the barista (at a register or by /cafe journal). */
    public static void openJournal(ServerPlayer player, BlockPos near) {
        MinecraftServer server = player.server;
        CafeCareer data = get(server);
        long day = day(server);
        Career c = data.of(player.getUUID());
        c.rollDay(day);
        data.setDirty();
        List<Quest> quests = quests(player.getUUID(), day);
        List<JournalPayload.Task> tasks = new ArrayList<>();
        for (int i = 0; i < quests.size(); i++) {
            Quest q = quests.get(i);
            tasks.add(new JournalPayload.Task(q.type().ordinal(), q.drink(), q.target(), c.progress[i], q.rewardCents(), c.done[i]));
        }
        List<Integer> cups = new ArrayList<>();
        for (int i = 0; i < Drink.values().length; i++) cups.add(c.cups[i]);
        ReviewLog log = CafeReputation.get(server).peek(player.getUUID());
        int rating = log == null || log.reviews().isEmpty() ? 0 : (int) Math.round(log.average() * 10.0);
        PacketDistributor.sendToPlayer(player, new JournalPayload(Career.dailyDrink(day, Drink.values().length), c.streak, c.bestStreak,
                c.served, c.tips, rating, decorKinds(player.serverLevel(), near), cups, tasks));
    }

    private static CafeCareer load(CompoundTag tag, HolderLookup.Provider registries) {
        CafeCareer data = new CafeCareer();
        ListTag list = tag.getList("careers", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            Career c = new Career();
            c.streak = t.getInt("streak");
            c.bestStreak = t.getInt("best");
            c.served = t.getInt("served");
            c.tips = t.getLong("tips");
            c.questDay = t.getLong("day");
            int[] cups = t.getIntArray("cups");
            System.arraycopy(cups, 0, c.cups, 0, Math.min(cups.length, c.cups.length));
            int[] progress = t.getIntArray("progress");
            System.arraycopy(progress, 0, c.progress, 0, Math.min(progress.length, c.progress.length));
            int done = t.getInt("done");
            for (int k = 0; k < c.done.length; k++) c.done[k] = (done & 1 << k) != 0;
            data.careers.put(t.getUUID("id"), c);
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        for (Map.Entry<UUID, Career> e : careers.entrySet()) {
            Career c = e.getValue();
            CompoundTag t = new CompoundTag();
            t.putUUID("id", e.getKey());
            t.putInt("streak", c.streak);
            t.putInt("best", c.bestStreak);
            t.putInt("served", c.served);
            t.putLong("tips", c.tips);
            t.putLong("day", c.questDay);
            t.putIntArray("cups", c.cups.clone());
            t.putIntArray("progress", c.progress.clone());
            int done = 0;
            for (int k = 0; k < c.done.length; k++) if (c.done[k]) done |= 1 << k;
            t.putInt("done", done);
            list.add(t);
        }
        tag.put("careers", list);
        return tag;
    }
}
