package dev.aestheticjobs.cafe.career;

import dev.aestheticjobs.cafe.kitchen.Cooking;
import dev.aestheticjobs.cafe.kitchen.Flavor;
import java.util.Random;

/**
 * A special wish of a guest about the taste of the drink; it is fulfilled by choosing the right additions.
 * The ordinal is saved on tickets. Plain Java, no Minecraft classes.
 */
public enum Wish {
    NONE("none", null, 0),
    SWEETER("sweeter", Flavor.SWEET, 3),
    CREAMIER("creamier", Flavor.CREAMY, 3),
    FRUITY("fruity", Flavor.FRUITY, 2),
    CHOCO("choco", Flavor.CHOCO, 2),
    PLAIN("plain", null, 0);

    private final String id;
    private final Flavor flavor;
    private final int need;

    Wish(String id, Flavor flavor, int need) {
        this.id = id;
        this.flavor = flavor;
        this.need = need;
    }

    public String id() { return id; }
    /** The taste it asks for (null for NONE and PLAIN). */
    public Flavor flavor() { return flavor; }
    public int need() { return need; }

    /** Does a drink with these additions (made from this base) grant the wish? */
    public boolean granted(int base, int mask) {
        return switch (this) {
            case NONE -> false;
            case PLAIN -> mask == 0;
            default -> Cooking.taste(base, mask, flavor) >= need;
        };
    }

    public static Wish byIndex(int i) {
        return i >= 0 && i < values().length ? values()[i] : NONE;
    }

    /** A random wish that asks for a change: the plain recipe of this base does not grant it already (PLAIN aside). */
    public static Wish pick(Random random, int base) {
        Wish[] all = values();
        for (int tries = 0; tries < 20; tries++) {
            Wish w = all[1 + random.nextInt(all.length - 1)];
            if (w == PLAIN || !w.granted(base, 0)) return w;
        }
        return PLAIN;
    }
}
