package dev.aestheticjobs.cafe.kitchen;

import java.util.ArrayList;
import java.util.List;

/** The mixing bowl: choose a dessert from the book, put its ingredients in (any order), whisk, take the dough. */
public final class BowlState {
    public static final int WHISKS = 4;

    private int recipe = -1, put, whisks;

    public int recipe() { return recipe; }
    public int whisks() { return whisks; }
    /** Bit i: the ingredient i of the recipe is in the bowl. */
    public int put() { return put; }
    public boolean empty() { return put == 0; }

    private List<String> list() {
        return recipe < 0 ? List.of() : Menu.get(recipe).ingredients();
    }

    /** Choosing another dessert is possible only while nothing is in the bowl. */
    public boolean choose(int base) {
        Menu.Base b = Menu.get(base);
        if (b == null || b.isDrink() || put != 0) return false;
        recipe = base;
        whisks = 0;
        return true;
    }

    public boolean add(String item) {
        List<String> need = list();
        for (int i = 0; i < need.size(); i++) {
            if ((put >> i & 1) == 0 && need.get(i).equals(item)) {
                put |= 1 << i;
                return true;
            }
        }
        return false;
    }

    public List<String> missing() {
        List<String> out = new ArrayList<>();
        List<String> need = list();
        for (int i = 0; i < need.size(); i++) if ((put >> i & 1) == 0) out.add(need.get(i));
        return out;
    }

    public List<String> inside() {
        List<String> out = new ArrayList<>();
        List<String> need = list();
        for (int i = 0; i < need.size(); i++) if ((put >> i & 1) != 0) out.add(need.get(i));
        return out;
    }

    public boolean full() { return recipe >= 0 && missing().isEmpty(); }

    public boolean mixed() { return full() && whisks >= WHISKS; }

    public boolean whisk() {
        if (!full() || mixed()) return false;
        whisks++;
        return true;
    }

    /** The dough is taken (or the bowl emptied); the chosen dessert stays for the next portion. */
    public void pourOut() { put = whisks = 0; }

    public long[] save() { return new long[]{recipe, put, whisks}; }

    public void load(long[] in) {
        recipe = -1;
        put = whisks = 0;
        if (in.length < 3) return;
        Menu.Base b = Menu.get((int) in[0]);
        if (b == null || b.isDrink()) return;
        recipe = (int) in[0];
        put = (int) in[1] & (1 << list().size()) - 1;
        whisks = (int) Math.max(0, Math.min(WHISKS, in[2]));
    }
}
