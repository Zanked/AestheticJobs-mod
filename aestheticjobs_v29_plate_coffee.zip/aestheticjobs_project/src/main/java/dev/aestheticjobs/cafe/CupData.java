package dev.aestheticjobs.cafe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.aestheticjobs.cafe.kitchen.Cooking;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

/**
 * A finished cup: the picture on the surface (256 chars, see Art), the drink (index in Drink), the quality 0..100 and
 * the additions that went in (bit mask of cafe/kitchen/Extra).
 */
public record CupData(String art, int drink, int quality, int extras) {
    public static final Codec<CupData> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.STRING.fieldOf("art").forGetter(CupData::art),
            Codec.INT.fieldOf("drink").forGetter(CupData::drink),
            Codec.INT.fieldOf("quality").forGetter(CupData::quality),
            Codec.INT.optionalFieldOf("extras", 0).forGetter(CupData::extras)
    ).apply(instance, CupData::new));

    public static final StreamCodec<ByteBuf, CupData> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.STRING_UTF8, CupData::art,
            ByteBufCodecs.VAR_INT, CupData::drink,
            ByteBufCodecs.VAR_INT, CupData::quality,
            ByteBufCodecs.VAR_INT, CupData::extras,
            CupData::new);

    public int stars() {
        return Cooking.stars(quality);
    }

    public static String starText(int stars) {
        return "\u2605".repeat(stars) + "\u2606".repeat(5 - stars);
    }
}
