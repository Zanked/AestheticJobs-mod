package dev.aestheticjobs.cafe.anim;

/**
 * What a staff NPC (chef, NPC barista) is doing: the server writes it into the synced data of the entity, the client
 * model plays the matching animation (Poses). Plain ints on purpose: no Minecraft classes in this package.
 */
public final class StaffAction {
    public static final int IDLE = 0;
    /** Barista: works at the coffee machine (grind, tamp, pour, latte art in a loop). */
    public static final int MACHINE = 1;
    /** Barista: hands a cup over (one shot, SERVE_TICKS). */
    public static final int SERVE = 2;
    /** Barista: wipes the counter (one shot, WIPE_TICKS). */
    public static final int WIPE = 3;
    /** Chef: kneads the dough. */
    public static final int KNEAD = 4;
    /** Chef: puts the tray into the furnace / takes it out. */
    public static final int OVEN = 5;
    /** Chef: waits at the furnace, folds the arms, wipes the brow. */
    public static final int WATCH = 6;
    /** Chef: presents a plate that is ready (one shot, PRESENT_TICKS). */
    public static final int PRESENT = 7;

    public static final int SERVE_TICKS = 40;
    public static final int WIPE_TICKS = 100;
    public static final int PRESENT_TICKS = 50;

    /** Faces: 0 neutral, 2 happy (see PersonRig.MOOD_*). */
    public static int mood(int action) {
        return action == SERVE || action == PRESENT ? PersonRig.MOOD_HAPPY : PersonRig.MOOD_NEUTRAL;
    }

    private StaffAction() {}
}
