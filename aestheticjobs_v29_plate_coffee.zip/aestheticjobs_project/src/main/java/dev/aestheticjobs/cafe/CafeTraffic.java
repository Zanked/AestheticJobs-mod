package dev.aestheticjobs.cafe;

import dev.aestheticjobs.entity.CafeCustomerEntity;
import dev.aestheticjobs.entity.CafeStaffEntity;
import dev.aestheticjobs.registry.ModBlocks;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * The customers come to the cafe by themselves. Nobody calls them: not a player (the register only takes the order of
 * the customer who already stands there) and not an NPC barista. Every register that is "open" (a barista at work or an
 * NPC barista near it) and has somebody around to see it gets visits: a person, two friends or sometimes a big group
 * who walk up from afar, stand in the line, and wait for whoever serves first.
 *
 * The shift has a rhythm: a calm flow, then a rush hour (a few minutes with twice the people, a longer line and more
 * groups), then calm again. The players near the register are told when it starts and ends.
 */
public final class CafeTraffic {
    /** At most this many customers in the line of one register (a company of two counts as two); in a rush hour more. */
    public static final int MAX_CUSTOMERS = 5, MAX_CUSTOMERS_RUSH = 7;
    /** Chance of a company of two / of a big group (3-4 people) per visit: calm, and in a rush hour. */
    private static final float COMPANY_CHANCE = 0.4F, COMPANY_CHANCE_RUSH = 0.5F;
    private static final float GROUP_CHANCE = 0.08F, GROUP_CHANCE_RUSH = 0.25F;
    /** The next visit comes after BASE + random(SPREAD) ticks, and EXTRA more for everybody who already stands in the line (20 ticks = 1 second). */
    private static final int VISIT_BASE_TICKS = 300, VISIT_SPREAD_TICKS = 300, VISIT_EXTRA_PER_PERSON = 200;
    /** In a rush hour the visits come this much faster (a factor on the wait). */
    private static final float RUSH_WAIT_FACTOR = 0.4F;
    /** Calm lasts CALM_BASE + random(CALM_SPREAD) ticks, a rush hour RUSH_BASE + random(RUSH_SPREAD) (20 ticks = 1 second). */
    private static final int CALM_BASE_TICKS = 4800, CALM_SPREAD_TICKS = 4800, RUSH_BASE_TICKS = 2400, RUSH_SPREAD_TICKS = 1800;
    private static final double ANNOUNCE_RANGE = 48.0D;

    /** What is going on at a register (only in memory: after a restart the rhythm starts anew with a calm). */
    private static final class Rhythm {
        int cooldown = 100;
        boolean rush;
        long phaseEnds;
    }

    private static final Map<String, Rhythm> RHYTHM = new HashMap<>();

    private CafeTraffic() {}

    /** Called every server tick, works once a second. */
    public static void tick(MinecraftServer server) {
        if (server.getTickCount() % 20 != 7) return;
        CafeRegisters registers = CafeRegisters.get(server);
        for (CafeRegisters.Spot spot : registers.all()) {
            ServerLevel level = null;
            for (ServerLevel l : server.getAllLevels()) {
                if (l.dimension().location().toString().equals(spot.dim())) {
                    level = l;
                    break;
                }
            }
            if (level == null) continue;
            BlockPos pos = BlockPos.of(spot.pos());
            if (!level.isLoaded(pos)) continue;
            BlockState state = level.getBlockState(pos);
            if (!state.is(ModBlocks.CAFE_REGISTER.get())) {
                registers.remove(spot.dim(), spot.pos());
                continue;
            }
            Direction facing = state.hasProperty(HorizontalDirectionalBlock.FACING) ? state.getValue(HorizontalDirectionalBlock.FACING) : Direction.NORTH;
            tickRegister(level, spot.dim() + "@" + spot.pos(), pos, facing);
        }
    }

    /** Is a rush hour going on at this register? (The barista and the customers may react to it.) */
    public static boolean isRush(ServerLevel level, BlockPos register) {
        Rhythm r = RHYTHM.get(level.dimension().location() + "@" + register.asLong());
        return r != null && r.rush;
    }

    private static void tickRegister(ServerLevel level, String key, BlockPos pos, Direction facing) {
        Rhythm r = RHYTHM.computeIfAbsent(key, k -> new Rhythm());
        long now = level.getGameTime();
        if (r.phaseEnds == 0L) r.phaseEnds = now + CALM_BASE_TICKS / 2 + level.random.nextInt(CALM_SPREAD_TICKS);   // the first rush comes after a few minutes

        r.cooldown -= 20;
        if (!CafeLogic.isOpen(level, pos)) {                                     // nobody to serve: the cafe is closed
            r.cooldown = Math.max(r.cooldown, 0);
            return;
        }
        if (level.getNearestPlayer(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, ANNOUNCE_RANGE, false) == null) {      // nobody around to see it
            r.cooldown = Math.max(r.cooldown, 200);
            return;
        }

        // calm <-> rush hour
        if (now >= r.phaseEnds) {
            r.rush = !r.rush;
            r.phaseEnds = now + (r.rush ? RUSH_BASE_TICKS + level.random.nextInt(RUSH_SPREAD_TICKS)
                    : CALM_BASE_TICKS + level.random.nextInt(CALM_SPREAD_TICKS));
            tell(level, pos, r.rush ? "cafe.rush.start" : "cafe.rush.end");
            if (r.rush) r.cooldown = Math.min(r.cooldown, 0);                    // the first ones come at once
        }

        if (r.cooldown > 0) return;
        int cap = r.rush ? MAX_CUSTOMERS_RUSH : MAX_CUSTOMERS;
        int inLine = CafeCustomerEntity.lineSize(level, pos);
        if (inLine >= cap) {
            r.cooldown = 100;
            return;
        }

        // who comes: one, two friends, or a big group
        int room = cap - inLine;
        float group = r.rush ? GROUP_CHANCE_RUSH : GROUP_CHANCE;
        float company = r.rush ? COMPANY_CHANCE_RUSH : COMPANY_CHANCE;
        float roll = level.random.nextFloat();
        int size = roll < group ? 3 + level.random.nextInt(2) : roll < group + company ? 2 : 1;
        size = Math.min(size, room);

        List<Integer> variants = new ArrayList<>();
        for (int i = 0; i < Order.CUSTOMERS; i++) variants.add(i);
        Collections.shuffle(variants, new java.util.Random(level.random.nextLong()));      // different people

        List<CafeCustomerEntity> made = new ArrayList<>();
        CafeCustomerEntity prev = null;
        for (int i = 0; i < size; i++) {
            CafeCustomerEntity c = visitor(level, pos, facing, variants.get(i), prev);
            if (c == null) break;
            made.add(c);
            prev = c;
        }
        for (int i = 0; i + 1 < made.size(); i += 2) {                           // friends in pairs
            made.get(i).setCompanion(made.get(i + 1).getUUID());
            made.get(i + 1).setCompanion(made.get(i).getUUID());
        }
        if (made.size() >= 3) tell(level, pos, "cafe.rush.group", made.size());

        int people = inLine + made.size();
        int wait = VISIT_BASE_TICKS + level.random.nextInt(VISIT_SPREAD_TICKS) + people * VISIT_EXTRA_PER_PERSON + (made.size() >= 2 ? 150 * made.size() : 0);
        r.cooldown = made.isEmpty() ? 200 : r.rush ? Math.round(wait * RUSH_WAIT_FACTOR) : wait;
    }

    /** A line to everybody near the register (a rush hour starts, a big group arrives). */
    private static void tell(ServerLevel level, BlockPos pos, String key, Object... args) {
        Component msg = Component.translatable(key, args).withStyle(net.minecraft.ChatFormatting.GOLD);
        for (ServerPlayer p : level.players()) {
            if (p.distanceToSqr(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D) <= ANNOUNCE_RANGE * ANNOUNCE_RANGE) p.sendSystemMessage(msg);
        }
    }

    /** One customer arrives: picks a drink (and maybe a dessert) in its own taste; the chef is asked to bake the dessert. near = the friend it comes with. */
    @Nullable
    private static CafeCustomerEntity visitor(ServerLevel level, BlockPos register, Direction facing, int variant, @Nullable CafeCustomerEntity near) {
        Personality person = Personality.of(variant);
        Drink drink = CafeLogic.pickDrink(person, level.random);
        int dessert = -1;
        if (level.random.nextFloat() < person.dessertChance() && CafeStaffEntity.hasChef(level, register)) {   // any dessert: the chef bakes it on request
            int pick = CafeLogic.pickDessert(person, drink, level.random);
            if (pick >= 0) {
                CafeStaffEntity.noteDemand(level, register, pick);
                if (CafeStaffEntity.hasPlate(level, register, pick) || CafeStaffEntity.request(level, register, pick)) dessert = pick;
            }
        }
        return CafeCustomerEntity.spawnFor(level, register, facing, null, variant, drink.ordinal(), dessert, level.getGameTime(), false, near);
    }
}
