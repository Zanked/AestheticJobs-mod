package dev.aestheticjobs.cafe.kitchen;

/** What can go into a cup. Plain Java: item ids are strings, so the rules are tested without the game. */
public enum Pantry {
    WATER("minecraft:water_bucket", null),
    MILK("aestheticjobs:milk_carton", null),
    SUGAR(Extra.SUGAR), VANILLA(Extra.VANILLA), CARAMEL(Extra.CARAMEL), CHOCOLATE(Extra.CHOCOLATE), COCOA(Extra.COCOA),
    BERRY(Extra.BERRY), HONEY(Extra.HONEY), CREAM(Extra.CREAM), APPLE(Extra.APPLE);

    private final String item;
    private final Extra extra;

    Pantry(String item, Extra extra) {
        this.item = item;
        this.extra = extra;
    }

    Pantry(Extra extra) {
        this(extra.item(), extra);
    }

    public String item() {
        return item;
    }

    /** The addition this is when the drink does not need it as a part of itself; null for water and milk. */
    public Extra extra() {
        return extra;
    }

    public static Pantry byItem(String id) {
        for (Pantry p : values()) if (p.item.equals(id)) return p;
        return null;
    }
}
