package dev.aestheticjobs.cafe.career;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** A task of the day. Every barista gets three different ones each Minecraft day. Plain Java. */
public record Quest(Type type, int drink, int target, long rewardCents, int xp) {
    public static final int PER_DAY = 3;

    public enum Type {
        DRINK("drink", 3, 600),
        GREAT("great", 4, 900),
        DESSERT("dessert", 3, 600),
        WISH("wish", 2, 800),
        STREAK("streak", 5, 1000),
        PAIR("pair", 2, 700);

        private final String id;
        private final int target;
        private final long reward;

        Type(String id, int target, long reward) {
            this.id = id;
            this.target = target;
            this.reward = reward;
        }

        public String id() { return id; }
    }

    /** The same day and barista always give the same three tasks. */
    public static List<Quest> ofDay(long day, long seed, int drinks) {
        Random r = new Random(day * 0x9E3779B97F4A7C15L ^ seed);
        r.nextInt();
        List<Type> types = new ArrayList<>(List.of(Type.values()));
        Collections.shuffle(types, r);
        List<Quest> out = new ArrayList<>();
        for (int i = 0; i < PER_DAY; i++) {
            Type t = types.get(i);
            int drink = t == Type.DRINK ? r.nextInt(drinks) : -1;
            out.add(new Quest(t, drink, t.target, t.reward, 15));
        }
        return out;
    }
}
