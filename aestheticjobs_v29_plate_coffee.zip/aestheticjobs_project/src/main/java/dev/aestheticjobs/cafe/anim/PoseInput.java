package dev.aestheticjobs.cafe.anim;

import dev.aestheticjobs.cafe.Personality;

/** Everything the animations need to know about a person at one frame (filled by the model from the entity). */
public final class PoseInput {
    /** Walk cycle position and strength (vanilla limbSwing / limbSwingAmount). */
    public float limbSwing, walk;
    /** Entity age in ticks with the partial tick. */
    public float age;
    /** Head turn relative to the body (degrees) and pitch (degrees). */
    public float headYaw, headPitch;
    /** Ticks since the state / action started (with the partial tick). */
    public float t;
    /** A number per person (entity id), so that two people do not move in step. */
    public int seed;
    /** Customer: state (Poses.C_*); staff: StaffAction. */
    public int mode;
    /** Customer: patience 0..100, stars of the reaction (0 = none), speech style. */
    public int patience = 100;
    public int stars;
    public Personality.Style style = Personality.Style.SWEET;
}
