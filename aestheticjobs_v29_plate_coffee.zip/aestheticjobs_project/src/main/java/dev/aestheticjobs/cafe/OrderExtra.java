package dev.aestheticjobs.cafe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.aestheticjobs.cafe.career.Guest;
import dev.aestheticjobs.cafe.career.Wish;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

/** The second part of an order ticket: the special wish (index in Wish) and the kind of guest (index in Guest). */
public record OrderExtra(int wish, int guest) {
    public static final OrderExtra PLAIN = new OrderExtra(0, 0);

    public static final Codec<OrderExtra> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.INT.optionalFieldOf("wish", 0).forGetter(OrderExtra::wish),
            Codec.INT.optionalFieldOf("guest", 0).forGetter(OrderExtra::guest)
    ).apply(instance, OrderExtra::new));

    public static final StreamCodec<ByteBuf, OrderExtra> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, OrderExtra::wish,
            ByteBufCodecs.VAR_INT, OrderExtra::guest,
            OrderExtra::new);

    public Wish wishType() { return Wish.byIndex(wish); }

    public Guest guestType() { return Guest.byIndex(guest); }
}
