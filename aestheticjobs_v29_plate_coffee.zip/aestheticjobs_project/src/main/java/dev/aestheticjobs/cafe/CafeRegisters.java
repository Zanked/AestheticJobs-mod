package dev.aestheticjobs.cafe;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * Where the cafe registers stand (world/data/aestheticjobs_registers.dat): the customers come to a register by themselves
 * (see CafeTraffic), so the server has to know the registers. A register is added when it is placed, when somebody uses it
 * and when an NPC barista finds it (so registers placed before this list existed join it on first use).
 */
public class CafeRegisters extends SavedData {
    public static final String NAME = "aestheticjobs_registers";

    public record Spot(String dim, long pos) {}

    private final Set<Spot> spots = new LinkedHashSet<>();

    public static CafeRegisters get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(factory(), NAME);
    }

    public static SavedData.Factory<CafeRegisters> factory() {
        return new SavedData.Factory<>(CafeRegisters::new, CafeRegisters::load, null);
    }

    public void add(String dim, long pos) {
        if (spots.add(new Spot(dim, pos))) setDirty();
    }

    public void remove(String dim, long pos) {
        if (spots.remove(new Spot(dim, pos))) setDirty();
    }

    /** A copy: the caller may remove registers while it goes through the list. */
    public List<Spot> all() {
        return new ArrayList<>(spots);
    }

    public static CafeRegisters load(CompoundTag tag, HolderLookup.Provider registries) {
        CafeRegisters data = new CafeRegisters();
        ListTag list = tag.getList("registers", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            data.spots.add(new Spot(t.getString("dim"), t.getLong("pos")));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        for (Spot s : spots) {
            CompoundTag t = new CompoundTag();
            t.putString("dim", s.dim());
            t.putLong("pos", s.pos());
            list.add(t);
        }
        tag.put("registers", list);
        return tag;
    }
}
