package dev.aestheticjobs.cafe;

import java.util.ArrayList;
import java.util.List;

/**
 * The reviews customers left for one barista: the last MAX of them, the average is the "rating" of the cafe.
 * Pure data and maths (no Minecraft classes); CafeReputation stores it.
 */
public final class ReviewLog {
    public static final int MAX = 20;
    /** A rating means something only after this many reviews; before it the tip multiplier stays neutral. */
    public static final int MIN_FOR_EFFECT = 3;

    /** customer = skin 0..7, stars = 1..5, drink = index in Drink (-1 unknown), time = game time of the review. */
    public record Review(int customer, int stars, int drink, long time) {}

    private final List<Review> reviews = new ArrayList<>();
    /** All reviews ever left (the list above keeps only the last MAX). */
    private int total;

    public void add(Review r) {
        reviews.add(r);
        total++;
        while (reviews.size() > MAX) reviews.remove(0);
    }

    public List<Review> reviews() {
        return reviews;
    }

    public int total() {
        return total;
    }

    public void setTotal(int total) {
        this.total = Math.max(total, reviews.size());
    }

    /** Average of the kept reviews, 0 if there are none. */
    public double average() {
        if (reviews.isEmpty()) return 0.0;
        int sum = 0;
        for (Review r : reviews) sum += r.stars();
        return sum / (double) reviews.size();
    }

    /** Good reputation tips more: 3 stars on average = x1.0, 5 stars = x1.2, 1 star = x0.8. */
    public double tipMultiplier() {
        if (reviews.size() < MIN_FOR_EFFECT) return 1.0;
        return 1.0 + (average() - 3.0) * 0.1;
    }
}
