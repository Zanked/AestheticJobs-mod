package dev.aestheticjobs.cafe.anim;

/**
 * The timing of drinking and eating (pure Java, no Minecraft types; tested by tools/tests/FoodMotionTest).
 * "used" is the number of ticks the item has been in use (with the partial tick), "duration" the full use time (32).
 */
public final class FoodMotion {
    /** Ticks it takes to bring the food to the mouth. */
    public static final float RAISE_TICKS = 7.0F;
    public static final int GULPS = 3, BITES = 4;
    /** Every bite makes the food this much smaller. */
    public static final float BITE_SHRINK = 0.09F;

    private FoodMotion() {}

    private static float clamp(float v) {
        return v < 0.0F ? 0.0F : Math.min(v, 1.0F);
    }

    /** 0 = still at the hip, 1 = at the mouth; starts fast and lands softly. */
    public static float raise(float used) {
        float t = 1.0F - clamp(used / RAISE_TICKS);
        return 1.0F - t * t * t;
    }

    /** How far the drinking or eating itself has got, 0..1 (starts when the food reaches the mouth). */
    public static float progress(float used, int duration) {
        float span = Math.max(1.0F, duration - RAISE_TICKS);
        return clamp((used - RAISE_TICKS) / span);
    }

    /** One swallow: rises and falls GULPS times, 0..1. */
    public static float gulp(float used, int duration) {
        float p = progress(used, duration);
        if (p <= 0.0F || p >= 1.0F) return 0.0F;
        return (float) Math.max(0.0, Math.sin(p * GULPS * 2.0 * Math.PI));
    }

    /** The lunge toward the mouth of one bite, 0..1: the first half of every bite period, then chewing. */
    public static float bite(float used, int duration) {
        float p = progress(used, duration);
        if (p <= 0.0F || p >= 1.0F) return 0.0F;
        float phase = (p * BITES) % 1.0F;
        return phase < 0.5F ? (float) Math.sin(phase * 2.0 * Math.PI) : 0.0F;
    }

    /** How many bites are already missing: a bite is gone at the top of its lunge. */
    public static int bitesTaken(float used, int duration) {
        float p = progress(used, duration);
        if (p <= 0.0F) return 0;
        return Math.min(BITES, (int) Math.floor(p * BITES + 0.75F));
    }

    public static float foodScale(float used, int duration) {
        return 1.0F - BITE_SHRINK * bitesTaken(used, duration);
    }

    /** A small quick wobble while chewing, -1..1; silent during the lunge. */
    public static float chew(float used, int duration) {
        if (progress(used, duration) <= 0.0F) return 0.0F;
        return (float) Math.sin(used * 1.9) * (1.0F - bite(used, duration));
    }
}
