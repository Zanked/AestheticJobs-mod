package dev.aestheticjobs.cafe;

import dev.aestheticjobs.AestheticJobs;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/**
 * The menu of drinks: price, how long a guest waits and the colour of the surface. What goes into a drink and which
 * additions suit it is in cafe/kitchen/Menu (same order). This class also carries the helpers of the 16x16 "art" of a
 * cup (the picture on the surface, see Art).
 */
public enum Drink {
    ESPRESSO("espresso", 350, 40, 0xFF5A3A2A),
    AMERICANO("americano", 400, 55, 0xFF7A5238),
    LATTE("latte", 450, 80, 0xFF8A5E40),
    CAPPUCCINO("cappuccino", 450, 95, 0xFF8A5E40),
    FLAT_WHITE("flat_white", 500, 80, 0xFF8A5E40),
    RAF("raf", 550, 105, 0xFFD8C08A),
    MOCHA("mocha", 600, 120, 0xFF6E4638),
    MACCHIATO("macchiato", 650, 110, 0xFFE9D9B0);

    public static final int SIZE = 16;
    public static final int CELLS = SIZE * SIZE;

    private final String id;
    private final long priceCents;
    private final int baseSeconds;
    private final int baseColor;

    Drink(String id, long priceCents, int baseSeconds, int baseColor) {
        this.id = id;
        this.priceCents = priceCents;
        this.baseSeconds = baseSeconds;
        this.baseColor = baseColor;
    }

    public String id() { return id; }
    public long priceCents() { return priceCents; }
    /** The colour of an empty ('0') art cell: the liquid or crema under the foam. */
    public int baseColor() { return baseColor; }

    public Component displayName() {
        return Component.translatable("drink." + AestheticJobs.MODID + "." + id);
    }

    /** The detailed 32x32 picture of the drink (item texture), also drawn in the customer's thought bubble. */
    public ResourceLocation iconTexture() {
        return ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "textures/item/cup_" + id + ".png");
    }

    /** custom_model_data of the filled cup: 1..8 selects the model of this drink. */
    public int modelData() {
        return ordinal() + 1;
    }

    /** Service within this time gets the speed bonus (about 1.4x the time an expert needs). */
    public long fastTicks() { return Math.round(baseSeconds * 1.4 * 20); }

    /** The customer waits this long. */
    public long okTicks() { return Math.round(baseSeconds * 3.5 * 20); }

    public static Drink byIndex(int i) {
        Drink[] all = values();
        return i >= 0 && i < all.length ? all[i] : null;
    }

    // ------------------------------------------------------------------ the 16x16 art of the surface

    /** The cup is round: only cells inside the circle exist. */
    public static boolean inCup(int x, int y) {
        double dx = x - 7.5, dy = y - 7.5;
        return dx * dx + dy * dy <= 57.8;
    }

    /** Keeps only valid art: exactly 256 chars of '0'..'6', nothing outside the cup. Returns null if broken. */
    public static String sanitize(String art) {
        if (art == null || art.length() != CELLS) return null;
        StringBuilder sb = new StringBuilder(CELLS);
        for (int i = 0; i < CELLS; i++) {
            char c = art.charAt(i);
            if (c < '0' || c > '6') return null;
            sb.append(inCup(i % SIZE, i / SIZE) ? c : '0');
        }
        return sb.toString();
    }
}
