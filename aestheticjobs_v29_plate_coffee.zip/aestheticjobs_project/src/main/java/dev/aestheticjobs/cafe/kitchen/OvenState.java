package dev.aestheticjobs.cafe.kitchen;

/**
 * The pastry oven: the dough goes in and bakes; take it out while it is golden (half a minute), later it gets too dark
 * and in the end burns. Then it stands on top of the oven, where additions decorate it, until somebody takes it.
 */
public final class OvenState {
    public static final int GOLDEN_TICKS = 600, DARK_TICKS = 600, DARK_PENALTY = 20;

    public enum Stage { FREE, BAKING, GOLDEN, DARK, BURNT, PLATE }

    private int recipe = -1, mask;
    private long start, ready;
    private boolean plate, dark;

    public int recipe() { return recipe; }
    public int mask() { return mask; }
    public long ready() { return ready; }
    public boolean wasDark() { return dark; }

    public Stage stage(long now) {
        if (recipe < 0) return Stage.FREE;
        if (plate) return Stage.PLATE;
        if (now < ready) return Stage.BAKING;
        if (now < ready + GOLDEN_TICKS) return Stage.GOLDEN;
        return now < ready + GOLDEN_TICKS + DARK_TICKS ? Stage.DARK : Stage.BURNT;
    }

    public float progress(long now) {
        return ready <= start ? 1.0F : Math.max(0.0F, Math.min(1.0F, (now - start) / (float) (ready - start)));
    }

    public boolean put(int base, long now) {
        Menu.Base b = Menu.get(base);
        if (b == null || b.isDrink() || recipe >= 0) return false;
        recipe = base;
        mask = 0;
        start = now;
        ready = now + b.ticks();
        plate = dark = false;
        return true;
    }

    /** Takes the baked dessert out of the oven onto the plate on top. False while it bakes or when it is burnt. */
    public boolean takeOut(long now) {
        Stage s = stage(now);
        if (s != Stage.GOLDEN && s != Stage.DARK) return false;
        plate = true;
        dark = s == Stage.DARK;
        return true;
    }

    public boolean decorate(Extra e, long now) {
        if (stage(now) != Stage.PLATE || e.in(mask) || Integer.bitCount(mask) >= Cooking.MAX_EXTRAS) return false;
        mask |= e.bit();
        return true;
    }

    public int quality() {
        return Math.max(0, Cooking.quality(recipe, mask) - (dark ? DARK_PENALTY : 0));
    }

    public void clear() {
        recipe = -1;
        mask = 0;
        start = ready = 0;
        plate = dark = false;
    }

    public long[] save() { return new long[]{recipe, mask, start, ready, plate ? 1 : 0, dark ? 1 : 0}; }

    public void load(long[] in) {
        clear();
        if (in.length < 6) return;
        Menu.Base b = Menu.get((int) in[0]);
        if (b == null || b.isDrink()) return;
        recipe = (int) in[0];
        mask = Cooking.valid(recipe, (int) in[1]) ? (int) in[1] : 0;
        start = in[2];
        ready = in[3];
        plate = in[4] != 0;
        dark = in[5] != 0;
    }
}
