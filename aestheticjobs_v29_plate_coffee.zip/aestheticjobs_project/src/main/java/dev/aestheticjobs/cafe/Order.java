package dev.aestheticjobs.cafe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

/**
 * An order ticket: which drink the customer wants, who the customer is, when the order was taken (game ticks)
 * and an optional dessert (index in item/Dessert, -1 = none). An order of a real player (placed at the register and
 * paid from the bank account) also carries the buyer: uuid string and name ("" for the NPC customers).
 */
public record Order(int drink, int customer, long created, int dessert, String buyer, String buyerName) {
    public static final int CUSTOMERS = 8;

    public Order(int drink, int customer, long created, int dessert) {
        this(drink, customer, created, dessert, "", "");
    }

    public boolean isPlayerOrder() {
        return !buyer.isEmpty();
    }

    public static final Codec<Order> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.INT.fieldOf("drink").forGetter(Order::drink),
            Codec.INT.fieldOf("customer").forGetter(Order::customer),
            Codec.LONG.fieldOf("created").forGetter(Order::created),
            Codec.INT.optionalFieldOf("dessert", -1).forGetter(Order::dessert),
            Codec.STRING.optionalFieldOf("buyer", "").forGetter(Order::buyer),
            Codec.STRING.optionalFieldOf("buyer_name", "").forGetter(Order::buyerName)
    ).apply(instance, Order::new));

    public static final StreamCodec<ByteBuf, Order> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, Order::drink,
            ByteBufCodecs.VAR_INT, Order::customer,
            ByteBufCodecs.VAR_LONG, Order::created,
            ByteBufCodecs.INT, Order::dessert,
            ByteBufCodecs.STRING_UTF8, Order::buyer,
            ByteBufCodecs.STRING_UTF8, Order::buyerName,
            Order::new);
}
