package dev.aestheticjobs.cafe;

import dev.aestheticjobs.cafe.kitchen.Knowledge;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** What every player has found out in the kitchen (world/data/aestheticjobs_kitchen.dat). Server side only. */
public class KitchenData extends SavedData {
    public static final String NAME = "aestheticjobs_kitchen";

    private final Map<UUID, Knowledge> cooks = new HashMap<>();

    public static KitchenData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(new SavedData.Factory<>(KitchenData::new, KitchenData::load, null), NAME);
    }

    /** Call setDirty() after changing it. */
    public Knowledge of(UUID player) {
        return cooks.computeIfAbsent(player, k -> new Knowledge());
    }

    private static KitchenData load(CompoundTag tag, HolderLookup.Provider registries) {
        KitchenData data = new KitchenData();
        ListTag list = tag.getList("cooks", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            data.of(t.getUUID("id")).load(t.getIntArray("tried"), t.getLong("found"));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        for (Map.Entry<UUID, Knowledge> e : cooks.entrySet()) {
            CompoundTag t = new CompoundTag();
            t.putUUID("id", e.getKey());
            t.putIntArray("tried", e.getValue().triedCopy());
            t.putLong("found", e.getValue().foundBits());
            list.add(t);
        }
        tag.put("cooks", list);
        return tag;
    }
}
