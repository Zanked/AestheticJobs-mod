package dev.aestheticjobs.cafe.kitchen;

/**
 * The picture on the surface of a cup (16x16 chars, see cafe/Art): one of a few latte art patterns for the milk drinks,
 * crema for the black ones, and what the additions leave on top. Pure Java.
 */
public final class LatteArt {
    public static final int SIZE = 16;
    public static final String[] STYLES = {"heart", "tulip", "rosetta", "swirl", "star", "dots"};

    private LatteArt() {}

    /** Drinks with a milk surface to draw on. */
    public static boolean paintable(int base) {
        Menu.Base b = Menu.get(base);
        return b != null && b.isDrink() && base != Menu.indexOf("espresso") && base != Menu.indexOf("americano");
    }

    private static boolean ellipse(double x, double y, double cx, double cy, double rx, double ry) {
        double dx = (x - cx) / rx, dy = (y - cy) / ry;
        return dx * dx + dy * dy <= 1.0;
    }

    /** Is there milk foam at this point of a pattern? */
    static boolean foam(int style, int ix, int iy) {
        double x = ix - 7.5, y = iy - 7.5, r = Math.sqrt(x * x + y * y);
        return switch (style) {
            case 0 -> ellipse(x, y, -2.1, -1.6, 2.9, 2.7) || ellipse(x, y, 2.1, -1.6, 2.9, 2.7)
                    || (y >= -1.0 && y <= 5.0 && Math.abs(x) <= (5.0 - y) * 0.82);
            case 1 -> ellipse(x, y, 0, -3.8, 2.0, 1.7)
                    || (ellipse(x, y, 0, -0.2, 4.0, 2.2) && !ellipse(x, y, 0, -1.8, 3.0, 1.7))
                    || (ellipse(x, y, 0, 3.0, 4.8, 2.6) && !ellipse(x, y, 0, 1.2, 4.0, 2.0)) || (Math.abs(x) < 1 && y > 3);
            case 2 -> {
                double width = 5.2 - Math.abs(y - 0.5) * 0.55;
                int band = Math.floorMod((int) Math.floor(y + Math.abs(x) * 0.7), 2);
                yield (y >= -5.5 && y <= 4.5 && Math.abs(x) <= width && band == 0) || (Math.abs(x) < 1 && y > -4 && y < 6.5);
            }
            case 3 -> {
                double turn = Math.atan2(y, x) / (Math.PI * 2.0);
                yield r < 6.2 && Math.floorMod((int) Math.floor(r / 1.5 - turn * 2.0), 2) == 0;
            }
            case 4 -> {
                double angle = Math.atan2(y, x) + Math.PI / 2.0;
                double wave = Math.abs((angle / (Math.PI * 2.0 / 5.0) % 1.0 + 1.0) % 1.0 - 0.5) * 2.0;
                yield r <= 2.6 + 3.6 * wave * wave;
            }
            default -> r < 1.8 || ellipse(x, y, 0, -4.4, 1.2, 1.2) || ellipse(x, y, 0, 4.4, 1.2, 1.2)
                    || ellipse(x, y, -4.4, 0, 1.2, 1.2) || ellipse(x, y, 4.4, 0, 1.2, 1.2)
                    || ellipse(x, y, -3.1, -3.1, 0.8, 0.8) || ellipse(x, y, 3.1, 3.1, 0.8, 0.8)
                    || ellipse(x, y, -3.1, 3.1, 0.8, 0.8) || ellipse(x, y, 3.1, -3.1, 0.8, 0.8);
        };
    }

    public static String picture(int base, int mask, int style) {
        boolean milk = paintable(base);
        int s = Math.floorMod(style, STYLES.length);
        StringBuilder out = new StringBuilder(SIZE * SIZE);
        for (int y = 0; y < SIZE; y++) {
            for (int x = 0; x < SIZE; x++) {
                double dx = x - 7.5, dy = y - 7.5, r2 = dx * dx + dy * dy;
                char c = '0';
                if (r2 <= 57.8) {
                    if (milk) c = foam(s, x, y) ? '1' : r2 > 36 ? '5' : '0';
                    else c = r2 > 40 ? '6' : (x * 7 + y * 5) % 11 == 0 ? '6' : '5';
                    if (Extra.CREAM.in(mask) && r2 < 10) c = '4';
                    if (Extra.CARAMEL.in(mask) && ((x + y) % 5 == 0) && r2 < 40) c = '3';
                    if ((Extra.CHOCOLATE.in(mask) || Extra.COCOA.in(mask)) && (x * 13 + y * 29) % 7 == 0 && r2 < 46) c = '2';
                }
                out.append(c);
            }
        }
        return out.toString();
    }
}
