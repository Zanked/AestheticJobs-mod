package dev.aestheticjobs.cafe.kitchen;

/** The hand grinder: pour beans into it, turn the crank, take the ground coffee with the portafilter. */
public final class GrinderState {
    public static final int MAX_BEANS = 4, TURNS = 3;

    private int beans, turns, ground;

    public int beans() { return beans; }
    public int turns() { return turns; }
    public int ground() { return ground; }

    public boolean addBean() {
        if (beans + ground >= MAX_BEANS) return false;
        beans++;
        return true;
    }

    /** One turn of the crank; the third makes one portion of ground coffee. */
    public boolean turn() {
        if (beans == 0) return false;
        if (++turns >= TURNS) {
            turns = 0;
            beans--;
            ground++;
        }
        return true;
    }

    public boolean takeGround() {
        if (ground == 0) return false;
        ground--;
        return true;
    }

    public void clear() { beans = turns = ground = 0; }

    public long[] save() { return new long[]{beans, turns, ground}; }

    public void load(long[] in) {
        clear();
        if (in.length < 3) return;
        beans = (int) Math.max(0, Math.min(MAX_BEANS, in[0]));
        turns = (int) Math.max(0, Math.min(TURNS - 1, in[1]));
        ground = (int) Math.max(0, Math.min(MAX_BEANS - beans, in[2]));
    }
}
