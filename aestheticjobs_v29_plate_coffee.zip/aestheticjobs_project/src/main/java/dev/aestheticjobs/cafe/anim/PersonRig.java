package dev.aestheticjobs.cafe.anim;

/**
 * The pose of a person: the six movable parts of a player-like body. Pure numbers (no Minecraft classes), so the
 * animations can be written, tested and previewed outside the game; client/CafePersonModel copies the result into the
 * ModelParts. Model space like Minecraft's: x to the character's left, y DOWN, z to the back (the face looks to -z);
 * lengths in 1/16 block, angles in radians. A negative xRot of an arm raises it forward. The elbow is the bend of
 * the forearm (>= 0 lifts the hand forward/up).
 */
public final class PersonRig {
    public static final int MOOD_NEUTRAL = 0;
    public static final int MOOD_HAPPY = 2;
    public static final int MOOD_ANGRY = 3;

    /** Height of the hip (pivot of the legs) above the feet in model units; bending the body turns around it. */
    public static final float HIP = 12.0F;

    public static final class Part {
        public final float baseX, baseY, baseZ;
        public float x, y, z, rx, ry, rz;
        /** Arms only: the bend of the forearm. */
        public float elbow;

        Part(float x, float y, float z) {
            this.baseX = x;
            this.baseY = y;
            this.baseZ = z;
        }

        void reset() {
            x = baseX;
            y = baseY;
            z = baseZ;
            rx = 0.0F;
            ry = 0.0F;
            rz = 0.0F;
            elbow = 0.0F;
        }
    }

    public final Part head = new Part(0.0F, 0.0F, 0.0F);
    public final Part body = new Part(0.0F, 0.0F, 0.0F);
    public final Part rightArm = new Part(-5.0F, 2.0F, 0.0F);
    public final Part leftArm = new Part(5.0F, 2.0F, 0.0F);
    public final Part rightLeg = new Part(-1.9F, 12.0F, 0.0F);
    public final Part leftLeg = new Part(1.9F, 12.0F, 0.0F);

    public PersonRig() {
        reset();
    }

    public void reset() {
        head.reset();
        body.reset();
        rightArm.reset();
        leftArm.reset();
        rightLeg.reset();
        leftLeg.reset();
    }

    /**
     * Leans the upper body forward (angle > 0) or back around the hips: the body turns, the head and the shoulders
     * move with it and the arms and the head get the same extra rotation.
     */
    public void lean(float a) {
        if (a == 0.0F) return;
        float c = (float) Math.cos(a), s = (float) Math.sin(a);
        body.rx += a;
        head.rx += a;
        rightArm.rx += a;
        leftArm.rx += a;
        for (Part p : new Part[]{head, rightArm, leftArm}) {
            float dy = p.y - HIP;
            float dz = p.z;
            p.y = HIP + dy * c - dz * s;
            p.z = dy * s + dz * c;
        }
        // the body itself turns around the hip: its pivot is at the shoulder line
        float dy = body.y - HIP;
        body.y = HIP + dy * c;
        body.z = dy * s;
    }
}
