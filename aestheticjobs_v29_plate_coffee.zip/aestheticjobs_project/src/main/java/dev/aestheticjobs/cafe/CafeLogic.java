package dev.aestheticjobs.cafe;

import dev.aestheticjobs.cafe.career.Career;
import dev.aestheticjobs.cafe.career.Guest;
import dev.aestheticjobs.cafe.career.Quest;
import dev.aestheticjobs.cafe.career.Wish;
import dev.aestheticjobs.network.ReceiptPayload;
import net.minecraft.ChatFormatting;
import dev.aestheticjobs.economy.Bank;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.economy.Transaction;
import dev.aestheticjobs.entity.CafeCustomerEntity;
import dev.aestheticjobs.entity.CafeStaffEntity;
import dev.aestheticjobs.network.OpenOrderPayload;
import dev.aestheticjobs.job.Jobs;
import dev.aestheticjobs.job.Profession;
import dev.aestheticjobs.cafe.kitchen.Cooking;
import dev.aestheticjobs.cafe.kitchen.LatteArt;
import dev.aestheticjobs.cafe.kitchen.Signature;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.job.Shift;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.registry.ModItems;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomModelData;
import net.neoforged.neoforge.network.PacketDistributor;

public final class CafeLogic {
    public static final String CAFE_JOB = "cafe_worker";
    /** The average chance that a customer orders a dessert (every customer has its own, see Personality), and the extra patience / speed-bonus time a dessert gives. */
    public static final float DESSERT_CHANCE = 0.45F;
    public static final long DESSERT_EXTRA_TICKS = 600L;
    /** Extra tip (percent) for a signature recipe. */
    public static final int SIGNATURE_BONUS = 15;
    /** Staff (chef, NPC barista) work for a register when they stand within this many blocks of it. */
    public static final double STAFF_RADIUS = 16.0D;
    /** A player's order is cancelled and refunded when it is still open after this long (the plate of a claimed order lasts as long). */
    public static final long ORDER_LIFE_TICKS = 36000L;
    /** What a barista earns from a player's order (share of the price; the rest stays in the register, out of the economy). */
    public static final double PLAYER_ORDER_SHARE = 0.6;

    /** The chance that an order comes with a special wish / that the guest is special. */
    public static final float WISH_CHANCE = 0.35F;
    public static final float GUEST_CHANCE = 0.16F;

    private CafeLogic() {}

    public static int count(Player player, Item item) {
        int n = 0;
        for (ItemStack s : player.getInventory().items) {
            if (s.is(item)) n += s.getCount();
        }
        return n;
    }

    public static boolean takeOne(Player player, Item item) {
        for (ItemStack s : player.getInventory().items) {
            if (s.is(item)) {
                s.shrink(1);
                return true;
            }
        }
        return false;
    }

    public static ItemStack findTicket(Player player) {
        for (ItemStack s : player.getInventory().items) {
            if (s.get(ModComponents.ORDER.get()) != null) return s;
        }
        return ItemStack.EMPTY;
    }

    /** Removes the ticket of an order that was never served (the customer lost patience). */
    public static void voidTicket(ServerPlayer player, long created) {
        for (ItemStack s : player.getInventory().items) {
            Order o = s.get(ModComponents.ORDER.get());
            if (o != null && o.created() == created) {
                s.shrink(1);
                return;
            }
        }
    }

    /** Speed-bonus window of a drink, longer when a dessert has to be fetched too. */
    public static long fastTicks(Drink drink, int dessert) {
        return drink.fastTicks() + (Dessert.byIndex(dessert) != null ? DESSERT_EXTRA_TICKS : 0L);
    }

    /** How long the customer waits in total. */
    public static long okTicks(Drink drink, int dessert) {
        return drink.okTicks() + (Dessert.byIndex(dessert) != null ? DESSERT_EXTRA_TICKS : 0L);
    }

    /** The same windows for a particular customer: a patient one waits longer, a hasty one shorter (see Personality). */
    public static long fastTicks(Drink drink, int dessert, int customer) {
        return Math.round(fastTicks(drink, dessert) * Personality.of(customer).patience());
    }

    public static long okTicks(Drink drink, int dessert, int customer) {
        return Math.round(okTicks(drink, dessert) * Personality.of(customer).patience());
    }

    /** A random drink for this customer: its favourites are ordered much more often than the rest. */
    public static Drink pickDrink(Personality who, RandomSource random) {
        Drink[] all = Drink.values();
        int[] w = new int[all.length];
        for (int i = 0; i < all.length; i++) w[i] = who.drinkWeight(all[i].id());
        return all[Personality.weightedPick(w, random::nextInt)];
    }

    /** Index of a random dessert for this customer and drink: its favourites and the classic pairs of the drink come up more often. */
    public static int pickDessert(Personality who, Drink drink, RandomSource random) {
        Dessert[] all = Dessert.values();
        int[] w = new int[all.length];
        for (int i = 0; i < all.length; i++) w[i] = Pairing.dessertWeight(who, drink.id(), all[i].id());
        return Personality.weightedPick(w, random::nextInt);
    }

    /** The best fresh plate of this dessert from the inventory, hand-made ones first (EMPTY if there is none). */
    public static ItemStack findPlate(Player player, Dessert dessert, long now) {
        ItemStack best = ItemStack.EMPTY;
        int stars = -1;
        for (ItemStack s : player.getInventory().items) {
            Plate plate = s.get(ModComponents.PLATE.get());
            if (plate != null && plate.dessert() == dessert.ordinal() && plate.fresh(now) && plate.stars() > stars) {
                best = s;
                stars = plate.stars();
            }
        }
        return best;
    }

    /** A new plate with a dessert on it. */
    public static ItemStack makePlate(int dessert, long expires) {
        return makePlate(new Plate(dessert, expires));
    }

    public static ItemStack makePlate(Plate data) {
        int dessert = data.dessert();
        ItemStack plate = new ItemStack(ModItems.DESSERT_PLATE.get());
        plate.set(ModComponents.PLATE.get(), data);
        plate.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(dessert + 1));
        return plate;
    }

    /** A plate in the inventory with a classic pair of the drink can stand in for the missing ordered dessert (liked ones first). */
    @Nullable
    public static Dessert findSubstitute(Player player, Drink drink, Personality who, long now) {
        Dessert found = null;
        for (Dessert d : Dessert.values()) {
            if (!Pairing.isPair(drink.id(), d.id()) || findPlate(player, d, now).isEmpty()) continue;
            if (who.likesDessert(d.id())) return d;
            if (found == null) found = d;
        }
        return found;
    }

    /** Quality 0..100 from the art score and the espresso shot. */
    public static int quality(int artScore, int extraction) {
        return (int) Math.round(0.7 * artScore + 0.3 * extraction);
    }

    public static boolean isCafeWorker(ServerPlayer player) {
        Optional<Profession> job = Jobs.currentProfession(player.server, player.getUUID());
        return job.isPresent() && job.get().id().getPath().equals(CAFE_JOB);
    }

    /** A barista who is at work now: at the register he takes orders, everybody else orders as a customer. */
    public static boolean isWorking(ServerPlayer player) {
        return isCafeWorker(player) && (!Jobs.REQUIRE_SHIFT_FOR_WORK || Shift.isOnShift(player.server, player.getUUID()));
    }

    /** Somebody who can make a drink for a customer: a barista at work not too far away, or an NPC barista at this register. */
    public static boolean isOpen(ServerLevel level, BlockPos register) {
        return someoneServes(level, register);
    }

    private static boolean someoneServes(ServerLevel level, BlockPos register) {
        for (ServerPlayer p : level.getServer().getPlayerList().getPlayers()) {
            if (p.level() == level && isWorking(p) && p.blockPosition().distSqr(register) < 64.0D * 64.0D) return true;
        }
        return CafeStaffEntity.baristaNear(level, register) != null;
    }

    // ------------------------------------------------------------------ orders of real players

    /** The customer's menu at the register: the drinks and the desserts the chefs have on their trays right now. */
    public static void openOrderMenu(ServerPlayer player, ServerLevel level, BlockPos register) {
        List<Integer> available = new java.util.ArrayList<>();                        // every dessert while there is a chef
        if (CafeStaffEntity.hasChef(level, register)) {
            for (int i = 0; i < Dessert.values().length; i++) available.add(i);
        }
        PacketDistributor.sendToPlayer(player, new OpenOrderPayload(register, available, Bank.balance(player.server, player.getUUID())));
    }

    /** A player orders at the register: the price goes from his account into the register, a plate is taken from a chef's tray. */
    public static void placeOrder(ServerPlayer buyer, ServerLevel level, BlockPos register, int drinkIdx, int dessertIdx) {
        Drink drink = Drink.byIndex(drinkIdx);
        Dessert dessert = Dessert.byIndex(dessertIdx);
        if (drink == null || (dessertIdx >= 0 && dessert == null)) return;
        CafeOrders orders = CafeOrders.get(buyer.server);
        if (orders.ofBuyer(buyer.getUUID()) != null) {
            buyer.displayClientMessage(Component.translatable("cafe.order.have_order"), true);
            return;
        }
        if (!someoneServes(level, register)) {
            buyer.displayClientMessage(Component.translatable("cafe.order.nobody"), true);
            return;
        }
        long price = drink.priceCents() + (dessert != null ? dessert.priceCents() : 0L);
        if (Bank.balance(buyer.server, buyer.getUUID()) < price) {
            buyer.displayClientMessage(Component.translatable("cafe.order.no_money", Money.format(price)), true);
            return;
        }
        if (dessert != null && !CafeStaffEntity.hasChef(level, register)) {
            buyer.displayClientMessage(Component.translatable("cafe.order.no_dessert", dessert.displayName()), true);
            return;
        }
        if (dessert != null && !CafeStaffEntity.canRequest(level, register)) {                 // all chefs have a full queue
            buyer.displayClientMessage(Component.translatable("cafe.order.chef_busy"), true);
            return;
        }
        if (Bank.withdraw(buyer.server, buyer.getUUID(), price, Transaction.Type.PURCHASE, "cafe") != Bank.Result.OK) {
            buyer.displayClientMessage(Component.translatable("cafe.order.no_money", Money.format(price)), true);
            return;
        }
        CafeOrders.Entry entry = new CafeOrders.Entry(buyer.getUUID(), buyer.getGameProfile().getName(),
                level.dimension().location().toString(), register.asLong(), drinkIdx, dessertIdx, price, level.getGameTime());
        if (dessert != null) CafeStaffEntity.noteDemand(level, register, dessertIdx);            // the chef learns what sells
        if (dessert != null && !CafeStaffEntity.takePlate(level, register, dessertIdx)) {      // not on a tray: the barista asks the chef
            entry.plated = false;
            CafeStaffEntity.request(level, register, dessertIdx);
            buyer.sendSystemMessage(Component.translatable("cafe.order.dessert_baking", dessert.displayName()));
        }
        orders.add(entry);
        level.playSound(null, register, SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.BLOCKS, 1.0F, 1.4F);
        Component what = dessert == null ? drink.displayName()
                : Component.empty().append(drink.displayName()).append(" + ").append(dessert.displayName());
        buyer.sendSystemMessage(Component.translatable("cafe.order.placed", what, Money.format(price)));
    }

    /** A barista at the register takes the oldest paid order of a real player, with its plate. Returns false if there is none. */
    private static boolean claimPlayerOrder(ServerPlayer player, ServerLevel level, BlockPos register) {
        CafeOrders orders = CafeOrders.get(player.server);
        CafeOrders.Entry e = orders.nextPending(level.dimension().location().toString(), register, STAFF_RADIUS);
        if (e == null) return false;
        e.status = CafeOrders.CLAIMED;
        e.worker = player.getUUID();
        orders.changed();

        ItemStack ticket = new ItemStack(ModItems.ORDER_TICKET.get());
        ticket.set(ModComponents.ORDER.get(), new Order(e.drink, Math.floorMod(e.buyer.hashCode(), Order.CUSTOMERS), e.created,
                e.dessert, e.buyer.toString(), e.buyerName));
        player.getInventory().placeItemBackInInventory(ticket);
        if (e.dessert >= 0 && (e.plated || CafeStaffEntity.takePlate(level, register, e.dessert))) {
            e.plated = true;
            player.getInventory().placeItemBackInInventory(makePlate(e.dessert, e.created + ORDER_LIFE_TICKS));
        } else if (e.dessert >= 0) {
            player.sendSystemMessage(Component.translatable("cafe.register.dessert_from_chef"));     // the chef is still baking it
        }
        level.playSound(null, register, SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.BLOCKS, 1.0F, 1.2F);
        Drink drink = Drink.byIndex(e.drink);
        Dessert dessert = Dessert.byIndex(e.dessert);
        Component what = dessert == null ? drink.displayName()
                : Component.empty().append(drink.displayName()).append(" + ").append(dessert.displayName());
        player.sendSystemMessage(Component.translatable("cafe.register.player_order", e.buyerName, what));
        return true;
    }

    /** The cup and the dessert of a paid order as the items the buyer takes away: both remember who bought them. */
    public static List<ItemStack> purchaseItems(CafeOrders.Entry e, ItemStack cup) {
        Drink drink = Drink.byIndex(e.drink);
        Dessert dessert = Dessert.byIndex(e.dessert);
        List<ItemStack> out = new java.util.ArrayList<>();
        ItemStack drinkOut = cup.copyWithCount(1);
        drinkOut.set(ModComponents.PURCHASE.get(), new Purchase(e.buyer.toString(), drink == null ? 0L : drink.priceCents()));
        out.add(drinkOut);
        if (dessert != null && !e.dessertDropped) {
            ItemStack food = new ItemStack(dessert.item());
            food.set(ModComponents.PURCHASE.get(), new Purchase(e.buyer.toString(), dessert.priceCents()));
            out.add(food);
        }
        return out;
    }

    /** The plain 3-star cup an NPC barista makes (no drawing). */
    public static ItemStack npcCup(Drink drink) {
        ItemStack cup = new ItemStack(ModItems.COFFEE_CUP.get());
        cup.set(ModComponents.CUP.get(), new CupData(LatteArt.picture(drink.ordinal(), 0, 0), drink.ordinal(), 70, 0));
        cup.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(drink.modelData()));
        return cup;
    }

    /**
     * The barista right-clicks the buyer with the finished cup: the buyer gets the cup and the dessert in his inventory,
     * the barista earns his share. Called from the interaction event (CafeEvents).
     */
    public static void servePlayer(ServerPlayer barista, ServerPlayer buyer, ItemStack cupStack, CupData cup) {
        ServerLevel level = barista.serverLevel();
        Shift.touch(barista);
        ItemStack ticket = findTicket(barista);
        Order order = ticket.isEmpty() ? null : ticket.get(ModComponents.ORDER.get());
        if (order == null || !order.buyer().equals(buyer.getUUID().toString())) {
            barista.displayClientMessage(Component.translatable("cafe.register.not_his", buyer.getDisplayName()), true);
            return;
        }
        CafeOrders orders = CafeOrders.get(barista.server);
        CafeOrders.Entry e = orders.find(buyer.getUUID(), order.created());
        if (e == null || e.status != CafeOrders.CLAIMED || !barista.getUUID().equals(e.worker)) {
            ticket.shrink(1);
            barista.displayClientMessage(Component.translatable("cafe.register.order_gone"), true);
            return;
        }
        Drink wanted = Drink.byIndex(e.drink);
        if (wanted == null || e.drink != cup.drink()) {
            barista.displayClientMessage(Component.translatable("cafe.register.wrong", wanted == null ? Component.empty() : wanted.displayName()), true);
            return;
        }
        Dessert dessert = Dessert.byIndex(e.dessert);
        ItemStack plate = dessert == null ? ItemStack.EMPTY : findPlate(barista, dessert, level.getGameTime());
        if (dessert != null && plate.isEmpty()) {
            barista.displayClientMessage(Component.translatable("cafe.register.need_dessert", dessert.displayName()), true);
            return;
        }
        long pay = Math.round(e.price * PLAYER_ORDER_SHARE);
        if (Bank.deposit(barista.server, barista.getUUID(), pay, Transaction.Type.WAGE, "cafe") != Bank.Result.OK) {
            barista.displayClientMessage(Component.translatable("cafe.register.bank_full"), true);
            return;
        }
        for (ItemStack out : purchaseItems(e, cupStack)) buyer.getInventory().placeItemBackInInventory(out);
        cupStack.shrink(1);
        plate.shrink(1);
        ticket.shrink(1);
        orders.remove(e);

        int stars = cup.stars();
        CafeReputation.get(barista.server).add(barista.getUUID(),
                new ReviewLog.Review(Math.floorMod(e.buyer.hashCode(), Order.CUSTOMERS), stars, e.drink, level.getGameTime()));
        Jobs.XpResult xp = Jobs.addXp(barista.server, barista.getUUID(), 4L + stars * 2L);
        level.playSound(null, buyer.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.9F, 1.3F);
        barista.sendSystemMessage(Component.translatable("cafe.register.served_player", buyer.getDisplayName(), CupData.starText(stars), Money.format(pay)));
        buyer.sendSystemMessage(Component.translatable("cafe.order.received", barista.getDisplayName()));
        if (xp.employed() && xp.newRank() > xp.oldRank() && xp.profession() != null) {
            barista.sendSystemMessage(Component.translatable("cafe.rank_up", xp.profession().rankName(xp.newRank())));
        }
    }

    /**
     * A barista takes an order. Customers come by themselves and wait in the line: at the register (or on the customer
     * itself) the barista takes the order of the first one who waits and has nobody yet; the drink and the dessert are
     * what the customer chose when it arrived. A spawn-egg customer (STATE_IDLE) chooses now. Without anybody waiting
     * there is nothing to take.
     */
    public static void issueOrder(ServerPlayer player, ServerLevel level, BlockPos soundPos,
                                  @Nullable BlockPos registerPos, @Nullable Direction registerFacing,
                                  @Nullable CafeCustomerEntity npc) {
        if (!isCafeWorker(player)) {
            player.displayClientMessage(Component.translatable("cafe.register.need_job"), true);
            return;
        }
        if (Jobs.REQUIRE_SHIFT_FOR_WORK && !Shift.isOnShift(player.server, player.getUUID())) {
            player.displayClientMessage(Component.translatable("cafe.register.need_shift"), true);
            return;
        }
        if (!findTicket(player).isEmpty()) {
            player.displayClientMessage(Component.translatable("cafe.register.have_ticket"), true);
            return;
        }
        Shift.touch(player);
        if (npc == null && registerPos != null && claimPlayerOrder(player, level, registerPos)) {
            return;                                                           // a customer who already paid comes first
        }
        long now = level.getGameTime();
        CafeCustomerEntity who = npc != null ? npc : (registerPos == null ? null : CafeCustomerEntity.firstUnclaimed(level, registerPos));
        int customer, dessert;
        Drink drink;
        if (who != null && who.isUnclaimed()) {                               // a customer who came by himself and waits
            drink = Drink.byIndex(who.getDrink());
            if (drink == null) return;
            customer = Math.floorMod(who.getVariant(), Order.CUSTOMERS);
            dessert = who.getDessert();
            who.claimByPlayer(player.getUUID(), now);
            registerPos = who.getRegisterPos() != null ? who.getRegisterPos() : registerPos;
        } else if (npc != null && npc.getState() == CafeCustomerEntity.STATE_IDLE) {    // a spawn-egg customer orders right here
            customer = Math.floorMod(npc.getVariant(), Order.CUSTOMERS);
            Personality person = Personality.of(customer);
            drink = pickDrink(person, level.random);
            dessert = level.random.nextFloat() < person.dessertChance() ? pickDessert(person, drink, level.random) : -1;
            npc.beginOrder(player.getUUID(), drink.ordinal(), dessert, now, null, null, false);
        } else {
            player.displayClientMessage(Component.translatable("cafe.register.no_customers"), true);
            return;
        }

        Dessert extra = Dessert.byIndex(dessert);
        if (extra != null && registerPos != null) {                           // the plate: the chef's if it is ready, otherwise he is asked
            if (findPlate(player, extra, now).isEmpty()) {
                if (CafeStaffEntity.takePlate(level, registerPos, dessert)) {
                    player.getInventory().placeItemBackInInventory(makePlate(dessert, now + CafeStaffEntity.PLATE_LIFE / 2));
                } else {
                    CafeStaffEntity.ensureBaked(level, registerPos, dessert);
                }
            }
        }

        ItemStack ticket = new ItemStack(ModItems.ORDER_TICKET.get());
        ticket.set(ModComponents.ORDER.get(), new Order(drink.ordinal(), customer, now, dessert));
        OrderExtra special = rollExtra(drink, level.random);
        if (special.wish() > 0 || special.guest() > 0) ticket.set(ModComponents.ORDER_EXTRA.get(), special);
        player.getInventory().placeItemBackInInventory(ticket);
        level.playSound(null, soundPos, SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.BLOCKS, 1.0F, 1.2F);
        Component name = Component.translatable("customer.aestheticjobs." + customer);
        if (extra != null) {
            player.sendSystemMessage(Component.translatable("cafe.register.new_order_dessert", name, drink.displayName(), extra.displayName()));
        } else {
            player.sendSystemMessage(Component.translatable("cafe.register.new_order", name, drink.displayName()));
        }
        if (special.wishType() != Wish.NONE) {
            player.sendSystemMessage(Component.translatable("cafe.wish.say", name,
                    Component.translatable("wish.aestheticjobs." + special.wishType().id())).withStyle(ChatFormatting.AQUA));
        }
        if (special.guestType() != Guest.REGULAR) {
            player.sendSystemMessage(Component.translatable("cafe.guest." + special.guestType().id(), name).withStyle(ChatFormatting.GOLD));
            level.playSound(null, soundPos, SoundEvents.PLAYER_LEVELUP, SoundSource.BLOCKS, 0.5F, 1.6F);
        }
    }

    /** About every third order has a wish, about every sixth guest is special. */
    private static OrderExtra rollExtra(Drink drink, RandomSource random) {
        java.util.Random r = new java.util.Random(random.nextLong());
        int wish = r.nextFloat() < WISH_CHANCE ? Wish.pick(r, drink.ordinal()).ordinal() : 0;
        int guest = r.nextFloat() < GUEST_CHANCE ? Guest.pickSpecial(r).ordinal() : 0;
        return new OrderExtra(wish, guest);
    }

    private static void addBonus(List<ReceiptPayload.Bonus> list, int kind, int percent) {
        if (percent > 0) list.add(new ReceiptPayload.Bonus(kind, percent));
    }

    /** Fireworks of particles for the big moments. */
    private static void celebrate(ServerLevel level, BlockPos pos, Guest guest, Career.Result result, int stars) {
        double x = pos.getX() + 0.5, y = pos.getY() + 1.4, z = pos.getZ() + 0.5;
        boolean birthday = guest == Guest.BIRTHDAY && stars >= 3;
        if (birthday || result.streakPrize() > 0) {
            level.sendParticles(ParticleTypes.FIREWORK, x, y + 0.6, z, birthday ? 60 : 35, 0.2, 0.3, 0.2, 0.12);
            level.playSound(null, pos, SoundEvents.FIREWORK_ROCKET_TWINKLE, SoundSource.BLOCKS, 0.8F, 1.2F);
        }
        if (!result.completed().isEmpty() || result.masteryUp() > 0) {
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, x, y, z, 20, 0.6, 0.4, 0.6, 0.0);
            level.playSound(null, pos, SoundEvents.PLAYER_LEVELUP, SoundSource.BLOCKS, 0.6F, 1.3F);
        }
    }

    /**
     * Hands a finished cup over: checks the ticket, pays (commission + tips), gives xp.
     * If the customer NPC is there, it takes the cup and shows the drawing (see CafeCustomerEntity).
     */
    public static void serve(ServerPlayer player, ServerLevel level, BlockPos pos, ItemStack cupStack, CupData cup,
                             @Nullable CafeCustomerEntity npc) {
        Shift.touch(player);
        ItemStack ticket = findTicket(player);
        if (ticket.isEmpty()) {
            player.displayClientMessage(Component.translatable("cafe.register.no_order"), true);
            return;
        }
        Order order = ticket.get(ModComponents.ORDER.get());
        if (order.isPlayerOrder()) {                                          // a paying player gets the cup from the barista's hands
            player.displayClientMessage(Component.translatable("cafe.register.hand_to_player", order.buyerName()), true);
            return;
        }
        Drink wanted = Drink.byIndex(order.drink());
        if (wanted == null || order.drink() != cup.drink()) {
            Component name = wanted == null ? Component.empty() : wanted.displayName();
            player.displayClientMessage(Component.translatable("cafe.register.wrong", name), true);
            if (npc != null) npc.say(Personality.Say.WRONG);
            return;
        }

        Personality who = Personality.of(order.customer());
        Dessert ordered = Dessert.byIndex(order.dessert());
        Dessert dessert = ordered;                                            // the dessert that is really served
        boolean substituted = false;
        long now = level.getGameTime();
        if (ordered != null && findPlate(player, ordered, now).isEmpty()) {   // the barista hands the plate over from the inventory (from the chef)
            Dessert stand = findSubstitute(player, wanted, who, now);         // a plate with a classic pair of the drink can stand in for it
            if (stand == null) {
                player.displayClientMessage(Component.translatable("cafe.register.need_dessert", ordered.displayName()), true);
                if (npc != null) npc.say(Personality.Say.WRONG);
                return;
            }
            if (!who.acceptsSubstitute()) {                                   // picky and grumpy customers want exactly what they ordered
                player.displayClientMessage(Component.translatable("cafe.register.no_substitute", ordered.displayName()), true);
                if (npc != null) npc.say(Personality.Say.WRONG);
                return;
            }
            dessert = stand;
            substituted = true;
        }
        boolean pair = dessert != null && Pairing.isPair(wanted.id(), dessert.id());
        boolean favourite = who.likesDrink(wanted.id());
        long elapsed = level.getGameTime() - order.created();
        long fast = fastTicks(wanted, order.dessert(), order.customer());
        long ok = okTicks(wanted, order.dessert(), order.customer());
        double speed = elapsed <= fast ? 0.15 : elapsed <= ok ? 0.05 : 0.0;
        int stars = cup.stars();
        long price = wanted.priceCents() + (dessert != null ? dessert.priceCents() : 0L);
        long base = Math.round(price * 0.6);
        // the tip: quality and speed as before, then the generosity of this customer, the cafe's reputation and a favourite drink
        double reputation = CafeReputation.get(player.server).tipMultiplier(player.getUUID());
        long tip = Math.round(price * (stars * 0.05 + speed) * who.tip() * reputation * (favourite ? 1.1 : 1.0) * (pair ? 1.1 : 1.0));
        tip = Math.min(tip, Math.round(price * 0.6));                          // the plain tip: at most 60% of the price

        // the bonuses on top of the tip: streak, mastery, drink of the day, special guest, wish, a cosy cafe
        OrderExtra special = ticket.getOrDefault(ModComponents.ORDER_EXTRA.get(), OrderExtra.PLAIN);
        Guest guest = special.guestType();
        boolean wishDone = special.wishType().granted(wanted.ordinal(), cup.extras());
        boolean wishFailed = special.wishType() != Wish.NONE && !wishDone;
        CafeCareer careers = CafeCareer.get(player.server);
        Career career = careers.of(player.getUUID());
        long day = CafeCareer.day(player.server);
        List<ReceiptPayload.Bonus> bonuses = new java.util.ArrayList<>();
        if (stars >= 3) {
            addBonus(bonuses, ReceiptPayload.STREAK, Career.streakBonus(career.nextStreak(stars)));
            addBonus(bonuses, ReceiptPayload.MASTERY, Career.masteryBonus(career.cups[wanted.ordinal()]));
            addBonus(bonuses, ReceiptPayload.DAILY,
                    Career.dailyDrink(day, Drink.values().length) == wanted.ordinal() ? Career.DAILY_BONUS : 0);
            addBonus(bonuses, ReceiptPayload.GUEST, guest.tipBonus(stars, elapsed <= fast));
            addBonus(bonuses, ReceiptPayload.WISH, wishDone ? Career.WISH_BONUS : 0);
            addBonus(bonuses, ReceiptPayload.SIGNATURE,
                    Signature.of(cup.drink(), cup.extras()) != null ? SIGNATURE_BONUS : 0);
            addBonus(bonuses, ReceiptPayload.COMFORT, Career.comfortBonus(CafeCareer.decorKinds(level, pos)));
            if (dessert != null) {                                          // baked by hand in the pastry oven
                Plate handed = findPlate(player, dessert, now).get(ModComponents.PLATE.get());
                if (handed != null) addBonus(bonuses, ReceiptPayload.HANDMADE, Cooking.handmadeBonus(handed.stars()));
            }
        }
        int percent = 100;
        for (ReceiptPayload.Bonus b : bonuses) percent += b.percent();
        tip = Math.min(tip * percent / 100, price * 2);
        long total = base + tip;

        Bank.Result paid = Bank.deposit(player.server, player.getUUID(), total, Transaction.Type.WAGE, "cafe");
        if (paid != Bank.Result.OK) {
            player.displayClientMessage(Component.translatable("cafe.register.bank_full"), true);
            return;
        }
        cupStack.shrink(1);
        if (dessert != null) findPlate(player, dessert, now).shrink(1);
        ticket.shrink(1);

        // the review: what this particular customer thinks of the cup (counts towards the cafe's rating, /cafe rating)
        int reaction = who.reaction(stars, favourite, elapsed > fast);
        if (pair && stars >= 3) reaction++;                                   // a good pair made the day
        if (substituted && !who.likesDessert(dessert.id())) reaction--;       // "this is not what I wanted"
        if (wishFailed) reaction--;                                           // "I asked for something else"
        reaction = Math.max(1, Math.min(5, reaction));
        for (int i = 0; i < guest.reviewCount(); i++) {                       // a critic's word weighs three times
            CafeReputation.get(player.server).add(player.getUUID(),
                    new ReviewLog.Review(Math.floorMod(order.customer(), Order.CUSTOMERS), reaction, order.drink(), level.getGameTime()));
        }

        // the career: streak, mastery, tasks of the day
        List<Quest> quests = CafeCareer.quests(player.getUUID(), day);
        Career.Result result = career.serve(new Career.Serve(wanted.ordinal(), stars, dessert != null, pair, wishDone), day, quests, tip);
        careers.setDirty();
        long prize = result.streakPrize();
        long questXp = 0;
        for (int i : result.completed()) {
            prize += quests.get(i).rewardCents();
            questXp += quests.get(i).xp();
        }
        if (prize > 0 && Bank.deposit(player.server, player.getUUID(), prize, Transaction.Type.WAGE, "cafe") != Bank.Result.OK) {
            player.displayClientMessage(Component.translatable("cafe.register.bank_full"), true);
            prize = 0;
        }

        Jobs.XpResult xp = Jobs.addXp(player.server, player.getUUID(), (4L + stars * 2L) * guest.xpFactor() + questXp);
        celebrate(level, pos, guest, result, stars);
        PacketDistributor.sendToPlayer(player, new ReceiptPayload(Math.floorMod(order.customer(), Order.CUSTOMERS), order.drink(),
                stars, total, tip, prize, result.streak(), result.masteryUp(), guest.ordinal(), bonuses, result.completed()));
        if (npc != null) {
            npc.receiveCup(player, cup, reaction);
        } else {
            level.playSound(null, pos, SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.BLOCKS, 0.9F, 1.3F);
            level.sendParticles(ParticleTypes.HEART, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 4, 0.25, 0.1, 0.25, 0.0);
        }
        player.sendSystemMessage(Component.translatable("cafe.register.paid",
                Component.translatable("customer.aestheticjobs." + Math.floorMod(order.customer(), Order.CUSTOMERS)),
                CupData.starText(stars), Money.format(total), Money.format(tip)));
        if (substituted) {
            player.sendSystemMessage(Component.translatable("cafe.register.substituted", dessert.displayName(), ordered.displayName()));
        } else if (pair) {
            player.sendSystemMessage(Component.translatable("cafe.register.pairing", wanted.displayName(), dessert.displayName()));
        }
        if (xp.employed() && xp.newRank() > xp.oldRank() && xp.profession() != null) {
            player.sendSystemMessage(Component.translatable("cafe.rank_up", xp.profession().rankName(xp.newRank())));
        }
    }
}
