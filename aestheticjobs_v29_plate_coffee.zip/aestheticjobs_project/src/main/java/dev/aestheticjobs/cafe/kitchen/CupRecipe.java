package dev.aestheticjobs.cafe.kitchen;

import java.util.ArrayList;
import java.util.List;

/**
 * Which drink is in the cup: it follows from what was poured in, in any order. A drink needs some number of espresso
 * shots and some things; whatever is left over counts as additions (each at most once, at most Cooking.MAX_EXTRAS).
 */
public final class CupRecipe {
    /** drink = ordinal of cafe/Drink, mask = the additions. */
    public record Result(int drink, int mask) {}

    private record Rule(int shots, Pantry... parts) {}

    /** In the order of cafe/Drink. */
    private static final Rule[] RULES = {
            new Rule(1),                                                                     // espresso
            new Rule(1, Pantry.WATER),                                                       // americano
            new Rule(1, Pantry.MILK),                                                        // latte
            new Rule(1, Pantry.MILK, Pantry.MILK),                                           // cappuccino
            new Rule(2, Pantry.MILK),                                                        // flat white
            new Rule(1, Pantry.CREAM, Pantry.VANILLA),                                       // raf
            new Rule(1, Pantry.MILK, Pantry.CHOCOLATE),                                      // mocha
            new Rule(1, Pantry.MILK, Pantry.VANILLA, Pantry.CARAMEL),                        // macchiato
    };

    public static final int MAX_SHOTS = 2;

    private CupRecipe() {}

    public static int shots(int drink) {
        return RULES[drink].shots();
    }

    /** What has to be poured in (besides the coffee). */
    public static List<Pantry> parts(int drink) {
        return List.of(RULES[drink].parts());
    }

    /** The drink for this content, or null when it is no drink. counts = how many of every Pantry value. */
    public static Result match(int shots, int[] counts) {
        Result best = null;
        int size = -1;
        for (int d = 0; d < RULES.length; d++) {
            Rule rule = RULES[d];
            if (rule.shots() != shots || rule.parts().length <= size) continue;
            int[] left = counts.clone();
            boolean ok = true;
            for (Pantry p : rule.parts()) ok &= --left[p.ordinal()] >= 0;
            if (!ok) continue;
            int mask = 0;
            for (Pantry p : Pantry.values()) {
                int n = left[p.ordinal()];
                if (n == 0) continue;
                if (n > 1 || p.extra() == null) ok = false;
                else mask |= p.extra().bit();
            }
            if (ok && Integer.bitCount(mask) <= Cooking.MAX_EXTRAS) {
                best = new Result(d, mask);
                size = rule.parts().length;
            }
        }
        return best;
    }

    /** Everything that has to go in to get this drink with these additions (without the coffee). */
    public static List<Pantry> contents(int drink, int mask) {
        List<Pantry> out = new ArrayList<>(parts(drink));
        for (Pantry p : Pantry.values()) if (p.extra() != null && p.extra().in(mask)) out.add(p);
        return out;
    }
}
