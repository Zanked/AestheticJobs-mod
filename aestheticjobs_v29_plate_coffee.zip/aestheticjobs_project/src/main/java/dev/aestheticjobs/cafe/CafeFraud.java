package dev.aestheticjobs.cafe;

import dev.aestheticjobs.economy.Bank;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.economy.Transaction;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.job.Shift;
import dev.aestheticjobs.registry.ModComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent;

/**
 * A barista on shift who drinks or eats a cafe item that is not his own purchase (a cup or a dessert of a customer,
 * or one he made himself) is fined: FINE_FACTOR x the price is taken from his account, and the cafe gets a bad review.
 */
public final class CafeFraud {
    public static final long FINE_FACTOR = 2L;

    private CafeFraud() {}

    public static void onUseFinish(LivingEntityUseItemEvent.Finish event) {
        if (event.getEntity() instanceof ServerPlayer player) consumed(player, event.getItem());
    }

    /** The player drank a cup (from the hand) or finished a dessert (from a plate). */
    public static void consumed(ServerPlayer player, ItemStack stack) {
        CupData cup = stack.get(ModComponents.CUP.get());
        Dessert dessert = Dessert.ofItem(stack.getItem());
        if (cup == null && dessert == null) return;
        if (!CafeLogic.isCafeWorker(player) || !Shift.isOnShift(player.server, player.getUUID())) return;

        Purchase bought = stack.get(ModComponents.PURCHASE.get());
        if (bought != null && bought.buyer().equals(player.getUUID().toString())) return;   // his own purchase: fine

        long price;
        if (bought != null) {
            price = bought.price();
        } else if (cup != null) {
            Drink d = Drink.byIndex(cup.drink());
            price = d == null ? 0L : d.priceCents();
        } else {
            price = dessert.priceCents();
        }
        long fine = Math.min(price * FINE_FACTOR, Bank.balance(player.server, player.getUUID()));
        if (fine > 0L) {
            Bank.withdraw(player.server, player.getUUID(), fine, Transaction.Type.FINE, "cafe");
        }
        CafeReputation.get(player.server).add(player.getUUID(),
                new ReviewLog.Review(-1, 1, cup != null ? cup.drink() : -1, player.serverLevel().getGameTime()));
        player.sendSystemMessage(Component.translatable("cafe.fraud.fined", Money.format(fine)));
    }
}
