package dev.aestheticjobs.client;

import dev.aestheticjobs.entity.CafeStaffEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

/** The pastry chef (with the tall hat) and the NPC barista: player-like models with their own animations. */
public class CafeStaffRenderer extends CafePersonRenderer<CafeStaffEntity> {
    private CafeStaffRenderer(EntityRendererProvider.Context context, boolean chef) {
        super(context, chef ? CafePersonModel.CHEF_LAYER : CafePersonModel.LAYER);
    }

    public static CafeStaffRenderer chef(EntityRendererProvider.Context context) {
        return new CafeStaffRenderer(context, true);
    }

    public static CafeStaffRenderer barista(EntityRendererProvider.Context context) {
        return new CafeStaffRenderer(context, false);
    }
}
