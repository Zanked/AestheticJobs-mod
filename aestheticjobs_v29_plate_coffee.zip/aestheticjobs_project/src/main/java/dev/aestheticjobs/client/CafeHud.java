package dev.aestheticjobs.client;

import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.career.Guest;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.network.ReceiptPayload;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.Util;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;

/**
 * The receipt that slides in from the right after a cup was served: the stars pop up one by one, the bonuses are printed
 * line by line, the money counts up, a streak burns at the bottom and confetti rains after a great cup.
 */
public final class CafeHud {
    private static final int W = 142;
    private static final float LIFE = 8.5F, SLIDE = 0.45F, STAR_AT = 0.55F, STAR_GAP = 0.16F, LINE_GAP = 0.22F;
    private static final int[] CONFETTI = {0xFFF2A8B8, 0xFFB4E2CC, 0xFFF4D88C, 0xFFA9D0F0, 0xFFE3A08C, 0xFFD9C2F0};

    private static ReceiptPayload receipt;
    private static long shownAt;
    private static int sounds;

    private CafeHud() {}

    public static void show(ReceiptPayload payload) {
        receipt = payload;
        shownAt = Util.getNanos();
        sounds = 0;
    }

    public static void render(GuiGraphics g, DeltaTracker delta) {
        ReceiptPayload r = receipt;
        if (r == null) return;
        Minecraft mc = Minecraft.getInstance();
        float t = (Util.getNanos() - shownAt) / 1.0E9F;
        if (t > LIFE) {
            receipt = null;
            return;
        }
        if (mc.options.hideGui) return;
        // a chime for every star
        while (sounds < r.stars() && t >= STAR_AT + sounds * STAR_GAP) {
            Ui.sound(SoundEvents.NOTE_BLOCK_CHIME.value(), 0.9F + sounds * 0.16F, 0.5F);
            sounds++;
        }
        draw(g, mc.font, r, t, g.guiWidth(), g.guiHeight());
    }

    private static float ease(float x) {
        x = Math.max(0.0F, Math.min(1.0F, x));
        float inv = 1.0F - x;
        return 1.0F - inv * inv * inv;
    }

    /** One printed line of the receipt. */
    private record Line(Component left, String right, int color) {
        List<String> lines(Font font) {
            return Ui.lines(font, left, W - 22 - font.width(right), 2);
        }
    }

    static void draw(GuiGraphics g, Font font, ReceiptPayload r, float t, int sw, int sh) {
        Drink drink = Drink.byIndex(r.drink());
        if (drink == null) return;

        List<Line> lines = new ArrayList<>();
        for (ReceiptPayload.Bonus b : r.bonuses()) {
            Component name = b.kind() == ReceiptPayload.GUEST
                    ? Component.translatable("guest.aestheticjobs." + Guest.byIndex(r.guest()).id())
                    : Component.translatable("hud.aestheticjobs.bonus." + b.kind());
            lines.add(new Line(name, "+" + b.percent() + "%", Ui.GOOD_D));
        }
        List<Component> badges = new ArrayList<>();
        if (r.prize() > 0) badges.add(Component.translatable("hud.aestheticjobs.prize", Money.format(r.prize())));
        if (!r.tasks().isEmpty()) badges.add(Component.translatable("hud.aestheticjobs.task_done", r.tasks().size()));
        if (r.masteryUp() > 0) badges.add(Component.translatable("hud.aestheticjobs.mastery." + r.masteryUp()));

        List<List<String>> badgeLines = new ArrayList<>();
        int badgesH = 0;
        for (Component badge : badges) {
            List<String> wrapped = Ui.lines(font, badge, W - 22, 2);
            badgeLines.add(wrapped);
            badgesH += wrapped.size() * Ui.LINE + 5;
        }
        int linesH = 0;
        for (Line l : lines) linesH += l.lines(font).size() * Ui.LINE;
        int h = 78 + linesH + 39 + (r.streak() >= 2 ? 18 : 0) + badgesH;
        float in = ease(t / SLIDE), out = ease((t - (LIFE - SLIDE)) / SLIDE);
        int x = sw - Math.round((W + 8) * in * (1.0F - out)) + (out >= 1.0F ? W : 0);
        int y = Math.max(6, (sh - h) / 2 - 10);

        // the paper with its torn edges
        g.fill(x + 3, y + 5, x + W + 3, y + h + 5, 0x55000000);
        g.fill(x, y, x + W, y + h, 0xFFFFF8E8);
        for (int i = 0; i < W; i += 6) {
            g.fill(x + i + 1, y - 2, x + i + 5, y, 0xFFFFF8E8);
            g.fill(x + i + 2, y - 3, x + i + 4, y - 2, 0xFFFFF8E8);
            g.fill(x + i + 1, y + h, x + i + 5, y + h + 2, 0xFFFFF8E8);
            g.fill(x + i + 2, y + h + 2, x + i + 4, y + h + 3, 0xFFFFF8E8);
        }
        g.fill(x + 4, y + 4, x + W - 4, y + 17, 0xFF6A4A3A);
        g.fill(x + 5, y + 5, x + W - 5, y + 16, 0xFF8A6450);
        Ui.label(g, font, Component.translatable("customer.aestheticjobs." + r.customer()), x + W / 2, y + 7, W - 12, 0xFFFFF6E2);

        Ui.icon(g, drink.iconTexture(), x + W / 2 - 16, y + 20, 32);
        Ui.label(g, font, drink.displayName(), x + W / 2, y + 52, W - 12, Ui.INK);

        // the stars, one after another, each with a little bounce
        for (int i = 0; i < 5; i++) {
            float k = (t - (STAR_AT + i * STAR_GAP)) / 0.25F;
            int sx = x + W / 2 + (i - 2) * 16, sy = y + 68;
            if (i >= r.stars() || k < 0) {
                star(g, sx, sy, 1.0F, 0xFFD8CBB0);
                continue;
            }
            float size = k < 0.6F ? k / 0.6F * 1.5F : k < 1.0F ? 1.5F - (k - 0.6F) / 0.4F * 0.5F : 1.0F;
            star(g, sx, sy, size, 0xFFF2B632);
        }

        int ly = y + 78;
        float printAt = STAR_AT + 5 * STAR_GAP + 0.1F;
        dashes(g, x + 8, ly - 1, W - 16);
        ly += 3;
        for (int i = 0; i < lines.size(); ly += lines.get(i).lines(font).size() * Ui.LINE, i++) {
            if (t < printAt + i * LINE_GAP) continue;
            Line l = lines.get(i);
            Ui.paragraph(g, font, l.left(), x + 9, ly, W - 22 - font.width(l.right()), 2, Ui.LABEL);
            Ui.text(g, font, Component.literal(l.right()), x + W - 9 - font.width(l.right()), ly, l.color());
        }

        // the money counts up
        float totalAt = printAt + lines.size() * LINE_GAP;
        float count = ease((t - totalAt) / 0.8F);
        dashes(g, x + 8, ly + 1, W - 16);
        ly += 5;
        Ui.paragraph(g, font, Component.translatable("hud.aestheticjobs.tip", Money.format(Math.round(r.tip() * count))), x + 9, ly, W - 18, 1, Ui.LABEL);
        String total = Money.format(Math.round(r.total() * count));
        var pose = g.pose();
        pose.pushPose();
        pose.translate(x + W / 2.0F, ly + 11.0F, 0.0F);
        pose.scale(1.5F, 1.5F, 1.0F);
        g.drawString(font, total, -font.width(total) / 2, 0, 0xFF4F7A45, false);
        pose.popPose();
        ly += 27;

        if (r.streak() >= 2) {
            int fw = Math.min(W - 12, font.width(Component.translatable("hud.aestheticjobs.streak", r.streak())) + 14);
            int fx = x + (W - fw) / 2;
            flame(g, fx + 4, ly + 11, t, Math.min(1.0F, r.streak() / 10.0F));
            Ui.paragraph(g, font, Component.translatable("hud.aestheticjobs.streak", r.streak()), fx + 13, ly + 3, W - 26, 1, 0xFFD2622A);
            ly += 18;
        }
        for (int i = 0; i < badgeLines.size(); ly += badgeLines.get(i).size() * Ui.LINE + 5, i++) {
            float k = ease((t - totalAt - 0.6F - i * 0.35F) / 0.25F);
            if (k <= 0.0F) continue;
            int bw = Math.round((W - 14) * k);
            int bx = x + (W - bw) / 2;
            List<String> wrapped = badgeLines.get(i);
            Ui.box(g, bx, ly, bw, wrapped.size() * Ui.LINE + 3, Ui.WARN_D, 0xFFFFE9A8);
            if (k >= 1.0F) {
                for (int j = 0; j < wrapped.size(); j++) {
                    g.drawString(font, wrapped.get(j), x + (W - font.width(wrapped.get(j))) / 2, ly + 3 + j * Ui.LINE, Ui.INK, false);
                }
            }
        }

        // confetti for a great cup
        if (r.stars() >= 5 || !badges.isEmpty()) {
            for (int i = 0; i < 40; i++) {
                float age = t - 0.9F - (i % 10) * 0.05F;
                if (age < 0 || age > 2.6F) continue;
                int cx = x + (i * 37) % (W + 30) - 15 + (int) (Math.sin(age * 4.0F + i) * 6.0F);
                int cy = y - 24 + (int) (age * (40 + i % 5 * 14));
                int s = 1 + i % 3;
                g.fill(cx, cy, cx + s, cy + s + 1, CONFETTI[i % CONFETTI.length]);
            }
        }
    }

    private static void dashes(GuiGraphics g, int x, int y, int w) {
        for (int i = 0; i < w; i += 5) g.fill(x + i, y, x + Math.min(i + 3, w), y + 1, 0xFFCDBB98);
    }

    /** A pixel star around (cx, cy). */
    static void star(GuiGraphics g, int cx, int cy, float size, int color) {
        String[] shape = {"....#....", "...###...", "...###...", "#########", ".#######.", "..#####..", "..#####..", ".###.###.", ".#.....#."};
        var pose = g.pose();
        pose.pushPose();
        pose.translate(cx, cy, 0.0F);
        pose.scale(size, size, 1.0F);
        for (int r = 0; r < shape.length; r++) {
            for (int c = 0; c < shape[r].length(); c++) {
                if (shape[r].charAt(c) == '#') g.fill(c - 4, r - 4, c - 3, r - 3, color);
            }
        }
        pose.popPose();
    }

    /** A flickering pixel flame standing on (cx, bottom); heat 0..1 makes it taller. */
    static void flame(GuiGraphics g, int cx, int bottom, float t, float heat) {
        int tall = 8 + Math.round(heat * 6.0F);
        for (int row = 0; row < tall; row++) {
            double p = row / (double) tall;
            int half = (int) Math.round(Math.sin(Math.PI * Math.min(1.0, p * 0.75 + 0.2)) * 4.0);
            int sway = (int) Math.round(Math.sin(t * 11.0F + row * 0.8F) * p * 2.0);
            int y = bottom - row;
            g.fill(cx - half + sway, y - 1, cx + half + sway + 1, y, 0xFFE8672C);
            if (p < 0.6 && half > 1) g.fill(cx - half + 2 + sway, y - 1, cx + half - 1 + sway, y, 0xFFFFC440);
        }
    }
}
