package dev.aestheticjobs.client;

import dev.aestheticjobs.entity.JobManagerEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

/** The managers who interview: the player-like model, the skin of the manager (see JobManagerEntity). */
public class JobManagerRenderer extends CafePersonRenderer<JobManagerEntity> {
    public JobManagerRenderer(EntityRendererProvider.Context context) {
        super(context, CafePersonModel.LAYER);
    }
}
