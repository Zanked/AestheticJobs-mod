package dev.aestheticjobs.client;

import static dev.aestheticjobs.client.Boxes.box;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.aestheticjobs.block.CafeDecorBlock;
import dev.aestheticjobs.block.MixingBowlBlockEntity;
import dev.aestheticjobs.block.PastryOvenBlockEntity;
import dev.aestheticjobs.block.StationBlockEntity;
import dev.aestheticjobs.cafe.kitchen.BowlState;
import dev.aestheticjobs.item.Dessert;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * What is going on in the mixing bowl: the ingredients lie in it as they come, every stroke of the whisk turns them into
 * smoother dough. A small picture of the chosen dessert floats above, so everybody sees what is being made.
 */
public class MixingBowlRenderer implements BlockEntityRenderer<MixingBowlBlockEntity> {
    private static final int DOUGH = 0xFFF2D89C, DOUGH_L = 0xFFFAE8BC, CHOC = 0xFF8A5C40, CHOC_L = 0xFFA87656,
            STEEL = 0xFFC8D0D6, WOOD = 0xFFB98A5C;
    private static final float STROKE_TICKS = 8.0F;

    private final ItemRenderer items;
    private final Map<String, ItemStack> stacks = new HashMap<>();

    public MixingBowlRenderer(BlockEntityRendererProvider.Context context) {
        this.items = context.getItemRenderer();
    }

    @Override
    public void render(MixingBowlBlockEntity be, float pt, PoseStack ps, MultiBufferSource buffers, int light, int overlay) {
        Level level = be.getLevel();
        if (level == null) return;
        BowlState bowl = be.bowl();
        if (bowl.recipe() < 0) return;
        long now = level.getGameTime();
        float time = (now % 24000L) + pt;
        Boxes.face(ps, be.getBlockState().getValue(CafeDecorBlock.FACING));

        Dessert dessert = PastryOvenBlockEntity.dessert(bowl.recipe());
        if (dessert != null) {
            double bob = Math.sin(time * 0.09F) * 0.35;
            Boxes.item(items, level, ps, buffers, stacks.computeIfAbsent(dessert.id(), k -> new ItemStack(dessert.item())),
                    8.0, 13.0 + bob, 8.0, 0.32F, time * 1.8F, false, light, overlay);
        }

        int whisks = bowl.whisks();
        List<String> inside = bowl.inside();
        for (int i = 0; i < inside.size() && whisks < 2; i++) {                    // the first strokes still show them
            String id = inside.get(i);
            float angle = i * 360.0F / Math.max(1, inside.size()) + whisks * 70.0F;
            double r = inside.size() == 1 ? 0.0 : 2.4;
            double x = 8.0 + Math.cos(Math.toRadians(angle)) * r, z = 8.0 + Math.sin(Math.toRadians(angle)) * r;
            Boxes.item(items, level, ps, buffers, stacks.computeIfAbsent(id, k -> new ItemStack(StationBlockEntity.item(k))),
                    x, 2.5 + i * 0.12, z, 0.28F, angle, true, light, overlay);
        }

        VertexConsumer vc = Boxes.buffer(buffers);
        if (whisks > 0) {                                                          // the dough, higher with every stroke
            boolean choc = dessert != null && (dessert.id().contains("choc") || dessert.id().equals("brownie"));
            double top = 2.6 + whisks * 0.65;
            box(ps, vc, 3.0, 2.0, 3.0, 13.0, top, 13.0, choc ? CHOC : DOUGH, light, overlay);
            float swirl = whisks * 47.0F;
            ps.pushPose();
            ps.translate(0.5, 0.0, 0.5);
            ps.mulPose(Axis.YP.rotationDegrees(swirl));
            box(ps, vc, -3.2, top, -0.8, 1.2, top + 0.25, 0.8, choc ? CHOC_L : DOUGH_L, light, overlay);
            box(ps, vc, 0.4, top, -2.6, 1.8, top + 0.25, 0.4, choc ? CHOC_L : DOUGH_L, light, overlay);
            ps.popPose();
        }

        float since = now - be.acted() + pt;
        if (whisks > 0 && since >= 0.0F && since < STROKE_TICKS) {                  // the whisk goes round once
            ps.pushPose();
            ps.translate(0.5, 0.0, 0.5);
            ps.mulPose(Axis.YP.rotationDegrees(360.0F * since / STROKE_TICKS));
            ps.translate(2.4 / 16.0, 3.0 / 16.0, 0.0);
            ps.mulPose(Axis.ZP.rotationDegrees(-22.0F));
            for (double x : new double[]{-1.0, -0.15, 0.7}) box(ps, vc, x, 0.0, -0.15, x + 0.3, 3.6, 0.15, STEEL, light, overlay);
            box(ps, vc, -1.0, 0.0, -0.15, 1.0, 0.3, 0.15, STEEL, light, overlay);
            box(ps, vc, -0.35, 3.6, -0.35, 0.35, 8.5, 0.35, WOOD, light, overlay);
            ps.popPose();
        }
        ps.popPose();
    }

    @Override
    public int getViewDistance() {
        return 32;
    }
}
