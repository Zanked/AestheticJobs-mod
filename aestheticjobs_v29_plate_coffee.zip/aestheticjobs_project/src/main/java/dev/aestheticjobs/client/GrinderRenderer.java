package dev.aestheticjobs.client;

import static dev.aestheticjobs.client.Boxes.box;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.aestheticjobs.block.CafeDecorBlock;
import dev.aestheticjobs.block.GrinderBlockEntity;
import dev.aestheticjobs.cafe.kitchen.GrinderState;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.world.level.Level;

/** The crank that turns with every click, the beans in the hopper and the ground coffee in front. */
public class GrinderRenderer implements BlockEntityRenderer<GrinderBlockEntity> {
    private static final int IRON = 0xFF9AA4AA, WOOD = 0xFFB98A5C, BEAN = 0xFF5A3A2A, BEAN_L = 0xFF7A5240, GROUND = 0xFF3C261A,
            TRAY = 0xFFC9A05A;
    private static final float SPIN_TICKS = 7.0F;

    public GrinderRenderer(BlockEntityRendererProvider.Context context) {}

    @Override
    public void render(GrinderBlockEntity be, float pt, PoseStack ps, MultiBufferSource buffers, int light, int overlay) {
        Level level = be.getLevel();
        if (level == null) return;
        GrinderState state = be.grinder();
        VertexConsumer vc = Boxes.buffer(buffers);
        Boxes.face(ps, be.getBlockState().getValue(CafeDecorBlock.FACING));

        // one full turn per click that ground something
        float since = level.getGameTime() - be.acted() + pt;
        float turn = since >= 0.0F && since < SPIN_TICKS && (state.beans() > 0 || state.turns() == 0 && state.ground() > 0)
                ? 360.0F * since / SPIN_TICKS : 0.0F;
        ps.pushPose();
        ps.translate(0.5, 0.0, 0.5);
        ps.mulPose(Axis.YP.rotationDegrees(-turn));
        box(ps, vc, -0.4, 13.0, -0.3, 4.6, 13.6, 0.3, IRON, light, overlay);          // arm
        box(ps, vc, 3.8, 13.6, -0.3, 4.4, 14.2, 0.3, IRON, light, overlay);           // pin
        box(ps, vc, 3.4, 14.2, -0.7, 4.8, 15.4, 0.7, WOOD, light, overlay);           // knob
        ps.popPose();

        for (int i = 0; i < state.beans(); i++) {                                     // beans on top of the heap
            double x = 6.2 + (i % 2) * 2.5, z = 6.2 + (i / 2) * 2.5;
            box(ps, vc, x, 11.2, z, x + 1.1, 11.75, z + 0.8, i % 2 == 0 ? BEAN : BEAN_L, light, overlay);
        }
        if (state.ground() > 0) {                                                     // the tray in front fills up
            double h = 0.45 * state.ground();
            box(ps, vc, 5.5, 0.0, 1.6, 10.5, 0.35, 4.4, TRAY, light, overlay);
            box(ps, vc, 6.2, 0.35, 2.1, 9.8, 0.35 + h * 0.6, 3.9, GROUND, light, overlay);
            box(ps, vc, 6.9, 0.35 + h * 0.6, 2.5, 9.1, 0.35 + h, 3.5, GROUND, light, overlay);
        }
        ps.popPose();
    }

    @Override
    public int getViewDistance() {
        return 32;
    }
}
