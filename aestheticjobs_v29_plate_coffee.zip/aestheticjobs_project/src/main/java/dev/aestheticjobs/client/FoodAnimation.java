package dev.aestheticjobs.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.aestheticjobs.cafe.anim.FoodMotion;
import dev.aestheticjobs.registry.ModItems;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;

/**
 * Drinking a cafe drink (desserts are eaten from a plate, see PlateRenderer). First person: the cup comes to the mouth
 * and tips back with every gulp; the branch for food stays for any item with the EAT animation. Third person: the arm goes to the mouth (see {@link FoodArmPose}).
 * Sounds and crumbs stay vanilla, because the items keep their DRINK / EAT use animation.
 */
public final class FoodAnimation implements IClientItemExtensions {
    private static final FoodAnimation INSTANCE = new FoodAnimation();

    private FoodAnimation() {}

    public static void register(RegisterClientExtensionsEvent event) {
        event.registerItem(INSTANCE, ModItems.COFFEE_CUP.get());
    }

    private static boolean using(LivingEntity entity, InteractionHand hand) {
        return entity.isUsingItem() && entity.getUseItemRemainingTicks() > 0 && entity.getUsedItemHand() == hand;
    }

    static float partialTick() {
        return Minecraft.getInstance().getTimer().getGameTimeDeltaPartialTick(false);
    }

    @Override
    public HumanoidModel.ArmPose getArmPose(LivingEntity entity, InteractionHand hand, ItemStack stack) {
        return using(entity, hand) ? FoodArmPose.PARAMS.getValue() : null;     // null: the usual way of holding an item
    }

    @Override
    public boolean applyForgeHandTransform(PoseStack pose, LocalPlayer player, HumanoidArm arm, ItemStack stack,
                                           float partialTick, float equipProcess, float swingProcess) {
        InteractionHand hand = arm == player.getMainArm() ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND;
        if (!using(player, hand)) return false;                                 // idle and swinging: vanilla

        int side = arm == HumanoidArm.RIGHT ? 1 : -1;
        int duration = player.getUseItem().getUseDuration(player);
        float used = duration - player.getUseItemRemainingTicks() + partialTick;
        float raise = FoodMotion.raise(used);
        boolean drink = player.getUseItem().getUseAnimation() == UseAnim.DRINK;

        float x, y, z, tipX, turnY, rollZ, scale = 1.0F;
        if (drink) {
            float gulp = FoodMotion.gulp(used, duration);
            x = side * 0.10F;
            y = -0.38F + 0.012F * gulp;
            z = -0.62F + 0.025F * gulp;
            tipX = raise * (18.0F + 34.0F * FoodMotion.progress(used, duration)) + 5.0F * gulp;   // the rim comes toward the face
            turnY = side * 10.0F;
            rollZ = side * 8.0F;
        } else {
            float bite = FoodMotion.bite(used, duration);
            x = side * 0.08F;
            y = -0.40F + 0.03F * bite;
            z = -0.68F + 0.13F * bite;
            tipX = raise * 12.0F + 10.0F * bite;
            turnY = side * 6.0F;
            rollZ = side * 6.0F + 2.5F * FoodMotion.chew(used, duration);
            scale = FoodMotion.foodScale(used, duration);
        }
        pose.translate(Mth.lerp(raise, side * 0.56F, x), Mth.lerp(raise, -0.52F, y) - 0.6F * equipProcess,
                Mth.lerp(raise, -0.72F, z));
        pose.translate(0.0F, 0.16F, 0.0F);                                      // turn and shrink around the middle of the food
        pose.mulPose(Axis.YP.rotationDegrees(turnY * raise));
        pose.mulPose(Axis.XP.rotationDegrees(tipX));
        pose.mulPose(Axis.ZP.rotationDegrees(rollZ * raise));
        pose.scale(scale, scale, scale);
        pose.translate(0.0F, -0.16F, 0.0F);
        return true;
    }
}
