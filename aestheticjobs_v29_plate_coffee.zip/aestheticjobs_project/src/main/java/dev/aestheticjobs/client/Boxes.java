package dev.aestheticjobs.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.aestheticjobs.AestheticJobs;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * What the live parts of the stations are drawn with: coloured boxes on one white texel, in block pixels (1/16) of a
 * north-facing block, and small items lying or standing on it.
 */
final class Boxes {
    private static final ResourceLocation WHITE =
            ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "textures/block/fx_white.png");

    private Boxes() {}

    /** Ask for it again after an item was drawn: the item uses another buffer. */
    static VertexConsumer buffer(MultiBufferSource buffers) {
        return buffers.getBuffer(RenderType.entityCutoutNoCull(WHITE));
    }

    /** Pushes the pose and turns it with the block; the caller pops it. */
    static void face(PoseStack ps, Direction facing) {
        ps.pushPose();
        ps.translate(0.5, 0.0, 0.5);
        ps.mulPose(Axis.YP.rotationDegrees(180.0F - facing.toYRot()));
        ps.translate(-0.5, 0.0, -0.5);
    }

    /** An item with its middle at (x, y, z) in block pixels; flat = lying on its back. */
    static void item(ItemRenderer items, Level level, PoseStack ps, MultiBufferSource buffers, ItemStack stack,
                     double x, double y, double z, float scale, float turn, boolean flat, int light, int overlay) {
        ps.pushPose();
        ps.translate(x / 16.0, y / 16.0, z / 16.0);
        ps.mulPose(Axis.YP.rotationDegrees(turn));
        if (flat) ps.mulPose(Axis.XP.rotationDegrees(90.0F));
        ps.scale(scale, scale, scale);
        items.renderStatic(stack, ItemDisplayContext.NONE, light, overlay, ps, buffers, level, 0);
        ps.popPose();
    }

    static void box(PoseStack ps, VertexConsumer vc, double ax, double ay, double az, double bx, double by, double bz,
                            int argb, int light, int overlay) {
        PoseStack.Pose p = ps.last();
        float x0 = (float) (ax / 16.0), y0 = (float) (ay / 16.0), z0 = (float) (az / 16.0);
        float x1 = (float) (bx / 16.0), y1 = (float) (by / 16.0), z1 = (float) (bz / 16.0);
        int r = argb >> 16 & 255, g = argb >> 8 & 255, b = argb & 255;
        // up
        v(vc, p, x0, y1, z0, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x0, y1, z1, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x1, y1, z1, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x1, y1, z0, r, g, b, light, overlay, 0, 1, 0);
        // down
        v(vc, p, x0, y0, z0, r, g, b, light, overlay, 0, -1, 0);
        v(vc, p, x1, y0, z0, r, g, b, light, overlay, 0, -1, 0);
        v(vc, p, x1, y0, z1, r, g, b, light, overlay, 0, -1, 0);
        v(vc, p, x0, y0, z1, r, g, b, light, overlay, 0, -1, 0);
        // north (-z)
        v(vc, p, x1, y1, z0, r, g, b, light, overlay, 0, 0, -1);
        v(vc, p, x1, y0, z0, r, g, b, light, overlay, 0, 0, -1);
        v(vc, p, x0, y0, z0, r, g, b, light, overlay, 0, 0, -1);
        v(vc, p, x0, y1, z0, r, g, b, light, overlay, 0, 0, -1);
        // south (+z)
        v(vc, p, x0, y1, z1, r, g, b, light, overlay, 0, 0, 1);
        v(vc, p, x0, y0, z1, r, g, b, light, overlay, 0, 0, 1);
        v(vc, p, x1, y0, z1, r, g, b, light, overlay, 0, 0, 1);
        v(vc, p, x1, y1, z1, r, g, b, light, overlay, 0, 0, 1);
        // west (-x)
        v(vc, p, x0, y1, z0, r, g, b, light, overlay, -1, 0, 0);
        v(vc, p, x0, y0, z0, r, g, b, light, overlay, -1, 0, 0);
        v(vc, p, x0, y0, z1, r, g, b, light, overlay, -1, 0, 0);
        v(vc, p, x0, y1, z1, r, g, b, light, overlay, -1, 0, 0);
        // east (+x)
        v(vc, p, x1, y1, z1, r, g, b, light, overlay, 1, 0, 0);
        v(vc, p, x1, y0, z1, r, g, b, light, overlay, 1, 0, 0);
        v(vc, p, x1, y0, z0, r, g, b, light, overlay, 1, 0, 0);
        v(vc, p, x1, y1, z0, r, g, b, light, overlay, 1, 0, 0);
    }

    /** Only the top face (the surface of a liquid). */
    static void quadUp(PoseStack ps, VertexConsumer vc, double ax, double az, double bx, double bz, double y,
                               int argb, int light, int overlay) {
        PoseStack.Pose p = ps.last();
        float x0 = (float) (ax / 16.0), z0 = (float) (az / 16.0), x1 = (float) (bx / 16.0), z1 = (float) (bz / 16.0);
        float yy = (float) (y / 16.0);
        int r = argb >> 16 & 255, g = argb >> 8 & 255, b = argb & 255;
        v(vc, p, x0, yy, z0, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x0, yy, z1, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x1, yy, z1, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x1, yy, z0, r, g, b, light, overlay, 0, 1, 0);
    }

    static void v(VertexConsumer vc, PoseStack.Pose p, float x, float y, float z, int r, int g, int b,
                          int light, int overlay, float nx, float ny, float nz) {
        vc.addVertex(p, x, y, z).setColor(r, g, b, 255).setUv(0.5F, 0.5F).setOverlay(overlay).setLight(light).setNormal(p, nx, ny, nz);
    }

}
