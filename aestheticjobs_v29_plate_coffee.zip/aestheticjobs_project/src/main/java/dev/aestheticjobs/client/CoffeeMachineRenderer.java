package dev.aestheticjobs.client;

import static dev.aestheticjobs.client.Boxes.box;
import static dev.aestheticjobs.client.Boxes.quadUp;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.aestheticjobs.block.CoffeeMachineBlock;
import dev.aestheticjobs.block.CoffeeMachineBlockEntity;
import dev.aestheticjobs.cafe.Art;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.kitchen.BrewState;
import dev.aestheticjobs.cafe.kitchen.CupRecipe;
import dev.aestheticjobs.cafe.kitchen.LatteArt;
import dev.aestheticjobs.cafe.kitchen.Pantry;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * The live parts of the espresso machine on top of its static model: the gauge, the status lamp, the portafilter with
 * the ground coffee and the cup. The cup shows what really is in it: the coffee runs in, water or milk change its
 * colour, additions appear on top and a finished milk drink gets its latte art.
 */
public class CoffeeMachineRenderer implements BlockEntityRenderer<CoffeeMachineBlockEntity> {
    private static final int DARK = 0xFF4A3228, PORCELAIN = 0xFFF4EEE2, STREAM = 0xFF8A5A30, CHROME = 0xFFC8D0D6,
            CHROME_D = 0xFF8C98A0, WOOD = 0xFF5E3E2E, GROUND = 0xFF3C261A;
    /** Colour of each addition on the surface, in the order of Pantry (null parts have none). */
    private static final int[] DOTS = {0, 0, 0xFFFFFFFF, 0xFFF7E6B0, 0xFFD99032, 0xFF5A3424, 0xFF8A5638, 0xFFC8344A,
            0xFFF2B632, 0xFFFFF4DC, 0xFF9CC25A};

    // cup (outer box and wall) and its inside
    private static final double CUP_X0 = 6.6, CUP_X1 = 9.4, CUP_Z0 = 1.2, CUP_Z1 = 3.95, CUP_Y0 = 2.02, CUP_Y1 = 4.0, WALL = 0.3;
    private static final double IN_X0 = CUP_X0 + WALL, IN_X1 = CUP_X1 - WALL, IN_Z0 = CUP_Z0 + WALL, IN_Z1 = CUP_Z1 - WALL;
    private static final double IN_Y0 = CUP_Y0 + 0.3, IN_Y1 = CUP_Y1 - 0.15;

    /** The finished picture, built once per recipe and not every frame. */
    private int artKey = -1;
    private String art = "";

    public CoffeeMachineRenderer(BlockEntityRendererProvider.Context context) {}

    @Override
    public void render(CoffeeMachineBlockEntity be, float pt, PoseStack ps, MultiBufferSource buffers, int light, int overlay) {
        Level level = be.getLevel();
        if (level == null) return;
        BlockState state = be.getBlockState();
        // the idle model has its own cup and portafilter: draw nothing over them
        if (!state.hasProperty(CoffeeMachineBlock.BREWING)) return;
        Direction facing = state.getValue(CoffeeMachineBlock.FACING);
        BrewState brew = be.brew();
        long now = level.getGameTime();
        boolean pulling = brew.pulling(now);
        double clock = ((now % 24000L) + pt) / 20.0;
        VertexConsumer vc = Boxes.buffer(buffers);

        Boxes.face(ps, facing);
        gauge(ps, vc, pulling ? 0.66 + 0.035 * Math.sin(clock * 9.0) : brew.grounds() ? 0.3 : 0.10, light, overlay);
        lamp(ps, vc, pulling, brew.drink() != null, clock, light, overlay);

        if (state.getValue(CoffeeMachineBlock.BREWING)) {
            if (brew.grounds() || pulling) portafilter(ps, vc, brew.grounds(), light, overlay);
            if (brew.cup()) cup(ps, vc, brew, now, pt, light, overlay);
            if (pulling) stream(ps, vc, fill(brew, now, pt), clock, overlay);
        }
        ps.popPose();
    }

    @Override
    public int getViewDistance() {
        return 40;
    }

    /** Pressure gauge on the front: rests low, trembles while the machine works. */
    private static void gauge(PoseStack ps, VertexConsumer vc, double value, int light, int overlay) {
        double angle = -115.0 + 230.0 * value;                              // clockwise from 12 o'clock, seen from the front
        box(ps, vc, 10.8, 7.4, 3.8, 13.2, 9.8, 4.0, DARK, light, overlay);          // rim
        box(ps, vc, 11.0, 7.6, 3.72, 13.0, 9.6, 3.8, 0xFFFFF6E2, light, overlay);   // face
        box(ps, vc, 11.2, 7.7, 3.69, 11.45, 8.0, 3.72, 0xFF7FA070, light, overlay);  // green zone marks
        box(ps, vc, 12.55, 7.7, 3.69, 12.8, 8.0, 3.72, 0xFFC98468, light, overlay);  // red zone mark
        ps.pushPose();
        ps.translate(12.0 / 16.0, 8.6 / 16.0, 0.0);   // dial centre
        ps.mulPose(Axis.ZP.rotationDegrees((float) angle));
        box(ps, vc, -0.09, -0.25, 3.62, 0.09, 0.8, 3.69, 0xFFC03A2A, light, overlay);   // needle (pivot at the origin)
        ps.popPose();
        box(ps, vc, 11.85, 8.45, 3.58, 12.15, 8.75, 3.69, DARK, light, overlay);     // hub
    }

    private static void lamp(PoseStack ps, VertexConsumer vc, boolean pulling, boolean drink, double clock, int light, int overlay) {
        int color = 0xFF3E6A44;
        if (pulling) {
            color = Ui.lerp(0xFFFF9A20, 0xFFFFD070, 0.5 + 0.5 * Math.sin(clock * 6.0));
            light = LightTexture.FULL_BRIGHT;
        } else if (drink) {
            color = 0xFF5CFF72;
            light = LightTexture.FULL_BRIGHT;
        }
        box(ps, vc, 3.2, 9.4, 3.82, 4.4, 10.3, 4.0, 0xFF2E2420, light, overlay);
        box(ps, vc, 3.35, 9.55, 3.78, 4.25, 10.15, 3.82, color, light, overlay);
    }

    private static void portafilter(PoseStack ps, VertexConsumer vc, boolean full, int light, int overlay) {
        box(ps, vc, 6.4, 4.2, 2.5, 9.6, 5.0, 4.0, CHROME, light, overlay);
        box(ps, vc, 7.55, 4.35, 0.7, 8.45, 4.95, 2.5, WOOD, light, overlay);
        box(ps, vc, 7.55, 4.35, 0.5, 8.45, 4.95, 0.7, CHROME_D, light, overlay);
        if (full) box(ps, vc, 6.7, 5.0, 2.7, 9.3, 5.05, 3.8, GROUND, light, overlay);
    }

    /** How full the cup is: coffee runs in during a shot, everything else adds a portion. */
    private static double fill(BrewState brew, long now, float pt) {
        double shots = brew.shots();
        if (brew.pulling(now)) shots -= Math.max(0.0, Math.min(1.0, (brew.shotEnd() - now - pt) / BrewState.SHOT_TICKS));
        int poured = brew.count(Pantry.WATER) * 3 + brew.count(Pantry.MILK) * 2 + brew.count(Pantry.CREAM) * 2;
        return Math.min(1.0, shots * 0.28 + poured * 0.2);
    }

    private static int liquid(BrewState brew) {
        int color = Ui.ESPRESSO;
        if (brew.count(Pantry.WATER) > 0) color = 0xFF6E4630;
        int milk = brew.count(Pantry.MILK) + brew.count(Pantry.CREAM);
        if (milk > 0) color = Ui.lerp(0xFFB07C52, 0xFFE0B88A, Math.min(1.0, (milk - 1) * 0.6));
        if (brew.count(Pantry.CHOCOLATE) + brew.count(Pantry.COCOA) > 0) color = Ui.lerp(color, 0xFF4A2A1C, 0.35);
        if (brew.count(Pantry.BERRY) > 0) color = Ui.lerp(color, 0xFFB04A60, 0.3);
        return color;
    }

    private void cup(PoseStack ps, VertexConsumer vc, BrewState brew, long now, float pt, int light, int overlay) {
        vessel(ps, vc, CUP_X0, CUP_Y0, CUP_Z0, CUP_X1, CUP_Y1, CUP_Z1, WALL, PORCELAIN, light, overlay);
        box(ps, vc, CUP_X0 - 0.5, CUP_Y0, CUP_Z0 - 0.3, CUP_X1 + 0.5, CUP_Y0 + 0.12, CUP_Z1 - 0.1, 0xFFE6D9BA, light, overlay);

        double lv = fill(brew, now, pt);
        if (lv <= 0.01) return;
        double top = IN_Y0 + (IN_Y1 - IN_Y0) * lv;
        int color = liquid(brew);
        box(ps, vc, IN_X0, IN_Y0, IN_Z0, IN_X1, top - 0.02, IN_Z1, color, light, overlay);
        CupRecipe.Result drink = brew.drink();
        boolean milk = brew.count(Pantry.MILK) + brew.count(Pantry.CREAM) > 0;
        if (drink != null && milk && !brew.pulling(now)) {
            int key = (drink.drink() * 512 + drink.mask()) * 8 + brew.art();
            if (key != artKey) {
                artKey = key;
                art = LatteArt.picture(drink.drink(), drink.mask(), brew.art());
            }
            artTop(ps, vc, art, Drink.byIndex(drink.drink()), top, light, overlay);
        } else {
            quadUp(ps, vc, IN_X0, IN_Z0, IN_X1, IN_Z1, top, brew.count(Pantry.WATER) > 0 || milk ? color : Ui.CREMA, light, overlay);
        }
        // a small piece of every addition floats on top
        int n = 0;
        for (Pantry p : Pantry.values()) {
            if (p.extra() == null || brew.count(p) == 0) continue;
            double x = IN_X0 + 0.15 + (n % 3) * 0.68, z = IN_Z0 + 0.15 + (n / 3 % 3) * 0.68;
            box(ps, vc, x, top, z, x + 0.4, top + 0.18, z + 0.4, DOTS[p.ordinal()], light, overlay);
            n++;
        }
    }

    /** Two thin streams from the spouts into the cup. */
    private static void stream(PoseStack ps, VertexConsumer vc, double lv, double clock, int overlay) {
        double bottom = IN_Y0 + (IN_Y1 - IN_Y0) * lv;
        double half = 0.17 * (0.85 + 0.15 * Math.sin(clock * 31.0));
        for (double x : new double[]{7.45, 8.55}) {
            box(ps, vc, x - half, bottom, 2.9 - half, x + half, 4.2, 2.9 + half, STREAM, LightTexture.FULL_BRIGHT, overlay);
        }
    }

    private static void artTop(PoseStack ps, VertexConsumer vc, String art, Drink drink, double y, int light, int overlay) {
        double cw = (IN_X1 - IN_X0) / Drink.SIZE, cd = (IN_Z1 - IN_Z0) / Drink.SIZE;
        for (int row = 0; row < Drink.SIZE; row++) {
            for (int col = 0; col < Drink.SIZE; col++) {
                if (!Drink.inCup(col, row)) continue;
                int rgb = Art.rgb(art.charAt(row * Drink.SIZE + col), drink);
                double x1 = IN_X1 - col * cw, x0 = x1 - cw;
                double z1 = IN_Z1 - row * cd, z0 = z1 - cd;
                quadUp(ps, vc, x0, z0, x1, z1, y, rgb, light, overlay);
            }
        }
    }

    private static void vessel(PoseStack ps, VertexConsumer vc, double x0, double y0, double z0, double x1, double y1, double z1,
                               double wall, int color, int light, int overlay) {
        box(ps, vc, x0, y0, z0, x1, y0 + wall, z1, color, light, overlay);
        box(ps, vc, x0, y0 + wall, z0, x0 + wall, y1, z1, color, light, overlay);
        box(ps, vc, x1 - wall, y0 + wall, z0, x1, y1, z1, color, light, overlay);
        box(ps, vc, x0 + wall, y0 + wall, z0, x1 - wall, y1, z0 + wall, color, light, overlay);
        box(ps, vc, x0 + wall, y0 + wall, z1 - wall, x1 - wall, y1, z1, color, light, overlay);
    }
}
