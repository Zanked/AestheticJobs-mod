package dev.aestheticjobs.client;

import dev.aestheticjobs.cafe.anim.FoodMotion;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.UseAnim;
import net.neoforged.fml.common.asm.enumextension.EnumProxy;
import net.neoforged.neoforge.client.IArmPoseTransformer;

/**
 * The third person pose of drinking and eating: an extra HumanoidModel.ArmPose, added through
 * META-INF/enumextensions.json (AESTHETICJOBS_FOOD).
 */
public final class FoodArmPose {
    /** Referenced by enumextensions.json: the constructor arguments (two handed, transformer) of the new pose. */
    public static final EnumProxy<HumanoidModel.ArmPose> PARAMS = new EnumProxy<>(
            HumanoidModel.ArmPose.class, false, (IArmPoseTransformer) FoodArmPose::apply);

    private FoodArmPose() {}

    private static void apply(HumanoidModel<?> model, LivingEntity entity, HumanoidArm arm) {
        if (!entity.isUsingItem()) return;
        int side = arm == HumanoidArm.RIGHT ? 1 : -1;
        int duration = entity.getUseItem().getUseDuration(entity);
        float used = entity.getTicksUsingItem() + FoodAnimation.partialTick();
        float raise = FoodMotion.raise(used);
        float progress = FoodMotion.progress(used, duration);
        boolean drink = entity.getUseItem().getUseAnimation() == UseAnim.DRINK;

        var limb = arm == HumanoidArm.RIGHT ? model.rightArm : model.leftArm;
        float holding = limb.xRot * 0.5F - Mth.PI / 10.0F;                      // the usual pose with an item
        float look = Mth.clamp(model.head.xRot, -0.6F, 0.6F);
        float mouth = look - 1.72F;
        if (drink) {
            mouth -= 0.12F * progress + 0.06F * FoodMotion.gulp(used, duration);
            model.head.xRot -= 0.22F * raise * progress;                         // the head tips back with the cup
        } else {
            mouth += 0.16F * FoodMotion.bite(used, duration);
            model.head.xRot += raise * (0.10F * FoodMotion.bite(used, duration) + 0.025F * FoodMotion.chew(used, duration));
        }
        limb.xRot = Mth.lerp(raise, holding, mouth);
        limb.yRot = Mth.lerp(raise, 0.0F, model.head.yRot - side * 0.50F);       // inward, in front of the face
    }
}
