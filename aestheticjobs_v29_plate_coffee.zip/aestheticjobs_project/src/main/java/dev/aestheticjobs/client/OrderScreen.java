package dev.aestheticjobs.client;

import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.network.OpenOrderPayload;
import dev.aestheticjobs.network.PlaceOrderPayload;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The customer's menu of a register: pick a drink, optionally one of the desserts the chefs have ready, and pay from the
 * bank account. A barista then makes it (or the NPC barista) and the order is handed over / collected.
 */
public class OrderScreen extends ScaledScreen {
    private static final int W = 326, H = 280;
    /** Desserts are shown in pages: 8 in a row, 2 rows. */
    private static final int COLS = 8, ROWS = 2, PER_PAGE = COLS * ROWS;

    private final BlockPos pos;
    private final List<Integer> desserts;
    private final long balance;
    private int drink = -1;
    private int dessert = -1;
    private int page;
    /** The panel on the canvas: a 3 pixel frame around it. */
    private final int left = 3, top = 3;
    private Component tooltip;

    public OrderScreen(OpenOrderPayload p) {
        super(Component.translatable("gui.aestheticjobs.order.title"));
        this.pos = p.pos();
        this.desserts = p.desserts();
        this.balance = p.balance();
    }

    @Override
    protected int vw() {
        return W + 6;
    }

    @Override
    protected int vh() {
        return H + 6;
    }

    private int drinkX(int i) { return left + 12 + (i % 4) * 76; }
    private int drinkY(int i) { return top + 36 + (i / 4) * 60; }
    /** k = the place on the current page (0..PER_PAGE-1). */
    private int dessX(int k) { return left + 12 + (k % COLS) * 38; }
    private int dessY(int k) { return top + 178 + (k / COLS) * 32; }
    private int buyX() { return left + W - 100; }
    private int buyY() { return top + H - 28; }
    private int prevX() { return left + W - 12 - 58; }
    private int nextX() { return prevX() + 44; }
    private int arrowY() { return top + 161; }

    private int pages() {
        return Math.max(1, (desserts.size() + PER_PAGE - 1) / PER_PAGE);
    }

    private void turn(int delta) {
        int np = Math.max(0, Math.min(pages() - 1, page + delta));
        if (np != page) {
            page = np;
            Ui.sound(net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK.value(), 1.3F, 0.5F);
        }
    }

    private long total() {
        Drink d = Drink.byIndex(drink);
        Dessert s = Dessert.byIndex(dessert);
        return (d == null ? 0L : d.priceCents()) + (s == null ? 0L : s.priceCents());
    }

    private boolean canBuy() {
        return drink >= 0 && total() <= balance;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        tooltip = null;
        super.render(g, mouseX, mouseY, partial);
        if (tooltip != null) g.renderTooltip(font, tooltip, mouseX, mouseY);      // on top, unscaled
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my, float partial) {
        Ui.box(g, left - 3, top - 3, W + 6, H + 6, Ui.BORDER, Ui.BORDER);
        Ui.box(g, left, top, W, H, Ui.KHAKI, Ui.BG);
        g.renderOutline(left + 3, top + 3, W - 6, H - 6, 0x66FFFFFF);

        Ui.paragraph(g, font, Component.translatable("gui.aestheticjobs.order.title"), left + 12, top + 10, W - 24, 1, Ui.INK);
        Ui.paragraph(g, font, Component.translatable("gui.aestheticjobs.order.balance", Money.format(balance)), left + 12, top + 22, W - 24, 1, Ui.LABEL);

        Drink[] all = Drink.values();
        Component tip = null;
        for (int i = 0; i < all.length; i++) {
            int x = drinkX(i), y = drinkY(i);
            boolean hov = Ui.in(mx, my, x, y, 74, 58);
            boolean sel = i == drink;
            Ui.box(g, x, y, 74, 58, sel ? Ui.GOOD_D : Ui.KHAKI, sel ? 0xFFF2F8EC : hov ? 0xFFFFFBEE : Ui.INNER);
            Ui.icon(g, all[i].iconTexture(), x + 21, y + 1, 32);
            List<String> name = Ui.lines(font, all[i].displayName(), 72, 2);
            int ny = y + (name.size() > 1 ? 32 : 36);
            for (String line : name) {
                g.drawString(font, line, x + 37 - font.width(line) / 2, ny, Ui.INK, false);
                ny += 9;
            }
            Ui.centered(g, font, Component.literal(Money.format(all[i].priceCents())), x + 37, y + 49, Ui.LABEL);
        }

        // the dessert shelf: a divider, the title with the chosen dessert, the page arrows and two rows of cells
        g.fill(left + 12, top + 158, left + W - 12, top + 159, Ui.KHAKI);
        Component head = Component.translatable("gui.aestheticjobs.order.dessert");
        Dessert chosen = Dessert.byIndex(dessert);
        if (chosen != null) head = Component.empty().append(head).append(": ").append(chosen.displayName());
        int headW = pages() > 1 ? prevX() - left - 18 : W - 24;
        Ui.paragraph(g, font, head, left + 12, top + 165, headW, 1, chosen != null ? Ui.INK : Ui.LABEL);
        if (Ui.in(mx, my, left + 12, top + 163, headW, 12) && Ui.cut(font, head, headW, 1)) tip = head;

        if (desserts.isEmpty()) {
            Ui.paragraph(g, font, Component.translatable("gui.aestheticjobs.order.no_desserts"), left + 12, top + 182, W - 24, 3, Ui.LABEL);
        } else {
            int pages = pages();
            if (pages > 1) {
                Ui.button(g, font, prevX(), arrowY(), 14, 14, Component.literal("<"), Ui.in(mx, my, prevX(), arrowY(), 14, 14), page > 0, 0);
                Ui.centered(g, font, Component.literal((page + 1) + " / " + pages), prevX() + 29, arrowY() + 3, Ui.LABEL);
                Ui.button(g, font, nextX(), arrowY(), 14, 14, Component.literal(">"), Ui.in(mx, my, nextX(), arrowY(), 14, 14), page < pages - 1, 0);
            }
            for (int k = 0; k < PER_PAGE; k++) {
                int idx = page * PER_PAGE + k;
                if (idx >= desserts.size()) break;
                Dessert d = Dessert.byIndex(desserts.get(idx));
                if (d == null) continue;
                int x = dessX(k), y = dessY(k);
                boolean hov = Ui.in(mx, my, x, y, 36, 30);
                boolean sel = desserts.get(idx) == dessert;
                Ui.box(g, x, y, 36, 30, sel ? Ui.GOOD_D : Ui.KHAKI, sel ? 0xFFF2F8EC : hov ? 0xFFFFFBEE : Ui.INNER);
                Ui.icon(g, d.iconTexture(), x + 6, y + 3, 24);
                if (hov) tip = Component.empty().append(d.displayName()).append("  " + Money.format(d.priceCents()));
            }
        }

        long total = total();
        int footW = buyX() - left - 18;
        Ui.paragraph(g, font, Component.translatable("gui.aestheticjobs.order.total", Money.format(total)), left + 12, buyY() + 2, footW, 1, Ui.INK);
        if (drink >= 0 && total > balance) {
            Ui.paragraph(g, font, Component.translatable("gui.aestheticjobs.order.too_expensive"), left + 12, buyY() + 12, footW, 1, 0xFFB5543A);
        }
        Ui.button(g, font, buyX(), buyY(), 88, 22, Component.translatable("gui.aestheticjobs.order.buy"),
                Ui.in(mx, my, buyX(), buyY(), 88, 22), canBuy(), 1);
        tooltip = tip;
    }

    @Override
    protected boolean click(int mx, int my, int button) {
        if (button != 0) return false;
        Drink[] all = Drink.values();
        for (int i = 0; i < all.length; i++) {
            if (Ui.in(mx, my, drinkX(i), drinkY(i), 74, 58)) {
                drink = i;
                return true;
            }
        }
        if (pages() > 1) {
            if (Ui.in(mx, my, prevX(), arrowY(), 14, 14)) {
                turn(-1);
                return true;
            }
            if (Ui.in(mx, my, nextX(), arrowY(), 14, 14)) {
                turn(1);
                return true;
            }
        }
        for (int k = 0; k < PER_PAGE; k++) {
            int idx = page * PER_PAGE + k;
            if (idx >= desserts.size()) break;
            if (Ui.in(mx, my, dessX(k), dessY(k), 36, 30)) {
                dessert = desserts.get(idx) == dessert ? -1 : desserts.get(idx);       // click again: no dessert
                return true;
            }
        }
        if (Ui.in(mx, my, buyX(), buyY(), 88, 22) && canBuy()) {
            PacketDistributor.sendToServer(new PlaceOrderPayload(pos, drink, dessert));
            onClose();
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        if (scrollY != 0 && pages() > 1 && vy(my) >= top + 158) {
            turn(scrollY < 0 ? 1 : -1);
            return true;
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (key == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT || key == org.lwjgl.glfw.GLFW.GLFW_KEY_PAGE_DOWN) {
            turn(1);
            return true;
        }
        if (key == org.lwjgl.glfw.GLFW.GLFW_KEY_LEFT || key == org.lwjgl.glfw.GLFW.GLFW_KEY_PAGE_UP) {
            turn(-1);
            return true;
        }
        return super.keyPressed(key, scanCode, modifiers);
    }
}
