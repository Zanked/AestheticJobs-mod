package dev.aestheticjobs.client;

import dev.aestheticjobs.cafe.Art;
import dev.aestheticjobs.cafe.Drink;
import net.minecraft.client.gui.GuiGraphics;

/** Draws the round cup top with the picture on its surface. Used by the brewing screen and by item tooltips. */
public final class CupRenderer {
    private CupRenderer() {}

    public static void draw(GuiGraphics g, int x, int y, int cell, String art, Drink drink) {
        g.drawManaged(() -> {                                     // one draw call for the whole picture
            for (int cy = 0; cy < Drink.SIZE; cy++) {
                for (int cx = 0; cx < Drink.SIZE; cx++) {
                    if (!Drink.inCup(cx, cy)) continue;
                    int x0 = x + cx * cell, y0 = y + cy * cell;
                    g.fill(x0, y0, x0 + cell, y0 + cell, Art.rgb(art.charAt(cy * Drink.SIZE + cx), drink));
                }
            }
        });
    }
}
