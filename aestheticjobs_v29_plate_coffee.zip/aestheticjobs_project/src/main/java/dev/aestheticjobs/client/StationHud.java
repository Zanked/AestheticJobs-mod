package dev.aestheticjobs.client;

import dev.aestheticjobs.block.StationBlockEntity;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/**
 * The card next to the crosshair while the player looks at a station: what is in it and what to do next. It sits under
 * the crosshair; on a low window it moves to the right of it, so it never covers the hotbar.
 */
public final class StationHud {
    private static final int W = 190, PAD = 7, MAX_ICONS = 8;

    // the texts are built once per tick, not every frame
    private static BlockPos pos;
    private static long time = Long.MIN_VALUE;
    private static List<Component> guide = List.of();
    private static List<ItemStack> icons = List.of();

    private StationHud() {}

    public static void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.screen != null || mc.player == null || mc.level == null || mc.player.isSpectator()) return;
        if (!(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        if (!(mc.level.getBlockEntity(hit.getBlockPos()) instanceof StationBlockEntity station)) return;
        long now = mc.level.getGameTime();
        if (now != time || !hit.getBlockPos().equals(pos)) {
            time = now;
            pos = hit.getBlockPos().immutable();
            guide = station.guide(mc.player);
            icons = station.guideItems(mc.player);
        }
        draw(g, mc.font, guide, icons, g.guiWidth(), g.guiHeight());
    }

    /** guide: the title, then information lines, the last one is the next step. */
    static void draw(GuiGraphics g, Font font, List<Component> guide, List<ItemStack> icons, int sw, int sh) {
        if (guide.size() < 2) return;
        int w = Math.min(W, sw - 16), tw = w - PAD * 2;
        List<List<String>> info = new ArrayList<>();
        int h = 20;
        for (int i = 1; i < guide.size() - 1; i++) {
            List<String> lines = Ui.lines(font, guide.get(i), tw, 4);
            info.add(lines);
            h += lines.size() * Ui.LINE + 2;
        }
        if (!icons.isEmpty()) h += 20;
        List<String> next = Ui.lines(font, guide.get(guide.size() - 1), tw - 8, 5);
        int nh = next.size() * Ui.LINE + 6;
        h += nh + 7;

        int x = (sw - w) / 2, y = sh / 2 + 12;
        if (y + h > sh - 46) {                                              // no room below: beside the crosshair
            x = Math.min(sw - w - 6, sw / 2 + 14);
            y = Math.max(4, Math.min(sh - h - 46, sh / 2 - h / 2));
        }
        Ui.card(g, x, y, w, h);
        Ui.header(g, font, guide.get(0), x, y, w);
        int line = y + 20;
        for (List<String> lines : info) {
            for (String s : lines) {
                g.drawString(font, s, x + PAD, line, Ui.INK, false);
                line += Ui.LINE;
            }
            line += 2;
        }
        if (!icons.isEmpty()) {
            int n = Math.min(MAX_ICONS, icons.size());
            int ix = x + w / 2 - n * 10;
            for (int i = 0; i < n; i++) {
                g.fill(ix + i * 20 + 1, line - 1, ix + i * 20 + 19, line + 17, Ui.TAN);
                g.renderItem(icons.get(i), ix + i * 20 + 2, line);
            }
            line += 20;
        }
        g.fill(x + 4, line, x + w - 4, line + nh, 0xFFE3F0D8);
        g.fill(x + 4, line, x + 6, line + nh, Ui.GOOD_D);
        for (int i = 0; i < next.size(); i++) {
            g.drawString(font, next.get(i), x + PAD + 4, line + 4 + i * Ui.LINE, 0xFF35552F, false);
        }
    }
}
