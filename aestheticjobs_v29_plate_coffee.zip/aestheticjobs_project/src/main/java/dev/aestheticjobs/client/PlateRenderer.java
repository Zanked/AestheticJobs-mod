package dev.aestheticjobs.client;

import static dev.aestheticjobs.client.Boxes.box;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.aestheticjobs.block.PlateBlock;
import dev.aestheticjobs.block.PlateBlockEntity;
import dev.aestheticjobs.cafe.anim.PlateMotion;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * The dessert standing on a plate (its own 3D model, smaller after every bite) and the little fork that carries each
 * bite to the mouth of whoever is eating: seen by the eater and by everybody around.
 */
public class PlateRenderer implements BlockEntityRenderer<PlateBlockEntity> {
    private static final int STEEL = 0xFFDDE3E8, STEEL_D = 0xFFB4BEC8, HANDLE = 0xFFF2A9BC, HANDLE_L = 0xFFFAC6D4;
    /** The top of the plate, in blocks. */
    private static final double TOP = 1.0 / 16.0;

    private final ItemRenderer items;

    public PlateRenderer(BlockEntityRendererProvider.Context context) {
        this.items = context.getItemRenderer();
    }

    @Override
    public void render(PlateBlockEntity be, float pt, PoseStack ps, MultiBufferSource buffers, int light, int overlay) {
        Level level = be.getLevel();
        if (level == null) return;
        float t = (float) (level.getGameTime() - be.bittenAt()) + pt;
        if (t < 0.0F && t > -10.0F) t = 0.0F;                                  // the client clock may be a little behind
        boolean eating = !be.piece().isEmpty() && PlateMotion.showsFork(t);

        ItemStack stack = be.food();
        int bites = be.bites();
        if (eating && t < PlateMotion.DIP) {                                   // the fork is not in yet: still whole
            stack = be.piece();
            bites--;
        }
        float size = PlateMotion.size(bites);
        if (!stack.isEmpty() && size > 0.0F) {
            Boxes.face(ps, be.getBlockState().getValue(PlateBlock.FACING));
            ps.translate(0.5, TOP + 0.5 * size, 0.5);                          // the model stands on its lowest level
            ps.scale(size, size, size);
            items.renderStatic(stack, ItemDisplayContext.NONE, light, overlay, ps, buffers, level, 0);
            ps.popPose();
        }
        if (eating) fork(be, level, t, pt, ps, buffers, light, overlay);
    }

    private void fork(PlateBlockEntity be, Level level, float t, float pt, PoseStack ps, MultiBufferSource buffers,
                      int light, int overlay) {
        float shrink = PlateMotion.forkSize(t);
        if (shrink <= 0.01F) return;
        BlockPos pos = be.getBlockPos();
        Entity eater = level.getEntity(be.eater());
        Vec3 mouth = new Vec3(0.5, 1.0, 0.5);
        Vec3 toward = new Vec3(0.0, 0.0, 1.0);
        if (eater != null) {
            Vec3 eye = eater.getEyePosition(pt), look = eater.getViewVector(pt);
            Vec3 at = eye.add(look.scale(0.42)).add(0.0, -0.2, 0.0).subtract(pos.getX(), pos.getY(), pos.getZ());
            if (at.distanceToSqr(0.5, 0.5, 0.5) < 64.0) mouth = at;
            Vec3 flat = new Vec3(eye.x - pos.getX() - 0.5, 0.0, eye.z - pos.getZ() - 0.5);
            if (flat.lengthSqr() > 1.0E-4) toward = flat.normalize();
        }
        // the fork starts above the side of the dessert that faces the eater
        double size = PlateMotion.size(be.bites() - 1);
        double sx = 0.5 + toward.x * 0.16 * size, sz = 0.5 + toward.z * 0.16 * size;
        double sy = TOP + 0.24 * size + 0.35 * PlateMotion.above(t);
        double p = PlateMotion.travel(t);
        double x = Mth.lerp(p, sx, mouth.x), z = Mth.lerp(p, sz, mouth.z);
        double y = Mth.lerp(p, sy, mouth.y) + 0.22 * PlateMotion.arc(t);

        ps.pushPose();
        ps.translate(x, y, z);
        ps.mulPose(Axis.YP.rotation((float) Math.atan2(toward.x, toward.z)));   // +z of the fork looks at the eater
        ps.scale(shrink, shrink, shrink);
        ps.pushPose();
        ps.mulPose(Axis.XP.rotationDegrees(-28.0F * (1.0F - (float) p * 0.7F)));   // the handle points up
        VertexConsumer vc = Boxes.buffer(buffers);
        for (double tine : new double[]{-0.8, -0.15, 0.5}) box(ps, vc, tine, -0.15, -0.4, tine + 0.3, 0.15, 1.2, STEEL, light, overlay);
        box(ps, vc, -0.8, -0.15, 1.2, 0.8, 0.15, 1.8, STEEL, light, overlay);
        box(ps, vc, -0.25, -0.18, 1.8, 0.25, 0.18, 3.4, STEEL_D, light, overlay);
        box(ps, vc, -0.45, -0.3, 3.4, 0.45, 0.3, 6.2, HANDLE, light, overlay);
        box(ps, vc, -0.3, 0.3, 3.8, 0.3, 0.42, 5.8, HANDLE_L, light, overlay);
        ps.popPose();
        if (t >= PlateMotion.DIP * 0.75F) {                                     // the piece on the tines
            ps.translate(0.0, 0.07, 0.0);
            ps.scale(0.2F, 0.2F, 0.2F);
            ps.translate(0.0, 0.3, 0.0);
            items.renderStatic(be.piece(), ItemDisplayContext.NONE, light, overlay, ps, buffers, level, 0);
        }
        ps.popPose();
    }

    /** The fork flies out of the block of the plate: keep it visible while the plate itself is out of sight. */
    public AABB getRenderBoundingBox(PlateBlockEntity be) {
        return new AABB(be.getBlockPos()).inflate(4.0);
    }

    @Override
    public int getViewDistance() {
        return 32;
    }
}
