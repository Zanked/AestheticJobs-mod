package dev.aestheticjobs.client;

import dev.aestheticjobs.job.interview.Resumes;
import dev.aestheticjobs.network.SubmitResumePayload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The resume form: the player fills it in himself with chips (experience, up to three skills, character, goal) and signs.
 * What he writes is a claim: in the interview the manager may check it.
 */
public class ResumeScreen extends ScaledScreen {
    private static final int VW = 300, VH = 268, X0 = 18, W = 264, CHIP_H = 16;

    private record Chip(int section, int index, int x, int y, int w) {}

    private static final int EXP = 0, SKILL = 1, TRAIT = 2, GOAL = 3;

    private final int hand;
    private final String name;
    private int exp, skills, trait, goal = 2;
    /** Ticks since "sign" was pressed (-1 = not pressed): the signature is drawn, then the form is sent. */
    private int signT = -1;
    private final java.util.List<Chip> chips = new java.util.ArrayList<>();

    public ResumeScreen(int hand, ItemStack stack) {
        super(Component.translatable("resume.form.title"));
        this.hand = hand;
        this.name = Minecraft.getInstance().player == null ? "" : Minecraft.getInstance().player.getGameProfile().getName();
        if (Resumes.isFilled(stack)) {
            Resumes.Data d = Resumes.read(stack);
            exp = d.exp();
            skills = d.skills();
            trait = d.trait();
            goal = d.goal();
        }
        buildChips();
    }

    @Override
    protected int vw() {
        return VW;
    }

    @Override
    protected int vh() {
        return VH;
    }

    private void buildChips() {
        chips.clear();
        row(EXP, Resumes.EXP_COUNT, 4, 53);
        row(SKILL, 4, 4, 89);
        for (int i = 4; i < Resumes.SKILL_COUNT; i++) chips.add(new Chip(SKILL, i, X0 + (i - 4) * 67, 109, 63));
        row(TRAIT, Resumes.TRAIT_COUNT, 4, 145);
        row(GOAL, Resumes.GOAL_COUNT, 3, 181);
    }

    private void row(int section, int count, int perRow, int y) {
        int w = (W - (perRow - 1) * 4) / perRow;
        for (int i = 0; i < count; i++) chips.add(new Chip(section, i, X0 + i * (w + 4), y, w));
    }

    private boolean selected(Chip c) {
        return switch (c.section()) {
            case EXP -> exp == c.index();
            case SKILL -> (skills >> c.index() & 1) != 0;
            case TRAIT -> trait == c.index();
            default -> goal == c.index();
        };
    }

    private Component label(Chip c) {
        String key = switch (c.section()) {
            case EXP -> "resume.exp.";
            case SKILL -> "resume.skill.";
            case TRAIT -> "resume.trait.";
            default -> "resume.goal.";
        };
        return Component.translatable(key + c.index());
    }

    private boolean skillLocked(Chip c) {
        return c.section() == SKILL && (skills >> c.index() & 1) == 0 && Integer.bitCount(skills) >= Resumes.MAX_SKILLS;
    }

    @Override
    public void tick() {
        if (signT >= 0 && ++signT >= 24) {
            PacketDistributor.sendToServer(new SubmitResumePayload(hand, exp, skills, trait, goal));
            onClose();
        }
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my, float partial) {
        // the paper
        Ui.card(g, 0, 0, VW, VH);
        Ui.box(g, 8, 10, VW - 16, VH - 18, Ui.KHAKI, Ui.CREAM);
        Ui.box(g, VW / 2 - 18, 3, 36, 12, Ui.BORDER, 0xFFD49C68);                    // the clip
        Ui.centered(g, font, Component.translatable("resume.form.title"), VW / 2, 20, Ui.INK);
        Ui.centered(g, font, fit(font, Component.translatable("resume.form.name", name), W), VW / 2, 31, Ui.LABEL);

        label(g, "resume.form.exp", 43);
        label(g, "resume.form.skills.pick", 79);
        label(g, "resume.form.trait", 135);
        label(g, "resume.form.goal", 171);
        for (Chip c : chips) {
            boolean sel = selected(c);
            boolean locked = skillLocked(c);
            boolean hover = signT < 0 && !locked && Ui.in(mx, my, c.x(), c.y(), c.w(), CHIP_H);
            Ui.button(g, font, c.x(), c.y(), c.w(), CHIP_H, fit(font, label(c), c.w() - 6), hover, !locked, sel ? 2 : 0);
        }

        // the signature is drawn when "sign" is pressed
        if (signT >= 0) {
            double p = Math.min(1.0D, (signT + partial) / 20.0D);
            int[][] pts = {{150, 207}, {158, 198}, {164, 209}, {172, 199}, {179, 209}, {187, 200}, {194, 208}, {204, 202}, {214, 207}, {232, 203}, {262, 206}};
            double len = p * (pts.length - 1);
            for (int i = 0; i < pts.length - 1 && i < len; i++) {
                double f = Math.min(1.0D, len - i);
                Ui.line(g, pts[i][0], pts[i][1], pts[i][0] + (pts[i + 1][0] - pts[i][0]) * f, pts[i][1] + (pts[i + 1][1] - pts[i][1]) * f, 1, 0xFF5070AA);
            }
        }
        boolean idle = signT < 0;
        Ui.button(g, font, X0, 214, 130, 20, Component.translatable("resume.form.sign"), idle && Ui.in(mx, my, X0, 214, 130, 20), idle, 1);
        Ui.button(g, font, X0 + 134, 214, 130, 20, Component.translatable("resume.form.cancel"), idle && Ui.in(mx, my, X0 + 134, 214, 130, 20), idle, 0);
        int hy = 237;
        for (String line : Ui.lines(font, Component.translatable("resume.form.hint"), W, 2)) {
            g.drawString(font, line, (VW - font.width(line)) / 2, hy, Ui.LABEL, false);
            hy += Ui.LINE;
        }
    }

    private void label(GuiGraphics g, String key, int y) {
        Ui.text(g, font, fit(font, Component.translatable(key), W), X0, y, Ui.INK);
    }

    @Override
    protected boolean click(int mx, int my, int button) {
        if (button != 0 || signT >= 0) return false;
        for (Chip c : chips) {
            if (!Ui.in(mx, my, c.x(), c.y(), c.w(), CHIP_H) || skillLocked(c)) continue;
            switch (c.section()) {
                case EXP -> exp = c.index();
                case SKILL -> skills ^= 1 << c.index();
                case TRAIT -> trait = c.index();
                default -> goal = c.index();
            }
            Ui.sound(SoundEvents.UI_BUTTON_CLICK.value(), 1.2F, 0.4F);
            return true;
        }
        if (Ui.in(mx, my, X0, 214, 130, 20)) {
            signT = 0;
            Ui.sound(SoundEvents.UI_BUTTON_CLICK.value(), 0.9F, 0.5F);
            return true;
        }
        if (Ui.in(mx, my, X0 + 134, 214, 130, 20)) {
            onClose();
            return true;
        }
        return false;
    }
}
