package dev.aestheticjobs.client;

import dev.aestheticjobs.block.PastryOvenBlock;
import dev.aestheticjobs.block.PastryOvenBlockEntity;
import dev.aestheticjobs.block.StationBlockEntity;
import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.kitchen.Extra;
import dev.aestheticjobs.cafe.kitchen.OvenState;
import dev.aestheticjobs.item.Dessert;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Shows the real 3D dessert: inside the window while it is in the oven and on its plate on the counter afterwards, with
 * the additions around it. The places are the ones of tools/gen_oven.py.
 */
public class PastryOvenRenderer implements BlockEntityRenderer<PastryOvenBlockEntity> {
    private final ItemRenderer items;
    private final ItemStack[] desserts = new ItemStack[Dessert.values().length];
    private final ItemStack[] plates = new ItemStack[Dessert.values().length];
    private final ItemStack[] extras = new ItemStack[Extra.values().length];

    public PastryOvenRenderer(BlockEntityRendererProvider.Context context) {
        this.items = context.getItemRenderer();
    }

    @Override
    public void render(PastryOvenBlockEntity be, float pt, PoseStack ps, MultiBufferSource buffers, int light, int overlay) {
        Level level = be.getLevel();
        OvenState oven = be.oven();
        Dessert dessert = PastryOvenBlockEntity.dessert(oven.recipe());
        if (dessert == null || level == null) return;                       // a free oven draws nothing
        long now = level.getGameTime();
        float time = (now % 24000L) + pt;
        OvenState.Stage stage = oven.stage(now);

        Boxes.face(ps, be.getBlockState().getValue(PastryOvenBlock.FACING));
        if (stage == OvenState.Stage.PLATE) {
            ItemStack plate = plate(dessert);
            Boxes.item(items, level, ps, buffers, plate, 8.0, 16.4, 7.0, 0.55F, 180.0F, false, light, overlay);
            int n = 0;
            for (Extra e : Extra.values()) {
                if (!e.in(oven.mask())) continue;
                double bob = Math.sin(time * 0.12F + n * 2.0F) * 0.3;
                Boxes.item(items, level, ps, buffers, extra(e), 4.0 + n * 4.0, 21.0 + bob, 7.0, 0.24F, time * 2.0F, false, light, overlay);
                n++;
            }
        } else {                                                            // it rises in the window
            float grow = stage == OvenState.Stage.BAKING ? 0.6F + 0.4F * oven.progress(now) : 1.0F;
            double bob = stage == OvenState.Stage.BAKING ? 0.0 : Math.abs(Math.sin(time * 0.15F)) * 0.4;
            int glow = stage == OvenState.Stage.BURNT ? LightTexture.pack(3, 2) : LightTexture.pack(13, 10);
            Boxes.item(items, level, ps, buffers, stack(dessert), 8.0, 2.0 + 8.0 * 0.38 * grow + bob, 3.7, 0.38F * grow, 180.0F, false,
                    glow, overlay);
        }
        ps.popPose();
    }

    private ItemStack stack(Dessert d) {
        ItemStack s = desserts[d.ordinal()];
        if (s == null) desserts[d.ordinal()] = s = new ItemStack(d.item());
        return s;
    }

    private ItemStack plate(Dessert d) {
        ItemStack s = plates[d.ordinal()];
        if (s == null) plates[d.ordinal()] = s = CafeLogic.makePlate(d.ordinal(), Long.MAX_VALUE);
        return s;
    }

    private ItemStack extra(Extra e) {
        ItemStack s = extras[e.ordinal()];
        if (s == null) extras[e.ordinal()] = s = new ItemStack(StationBlockEntity.item(e.item()));
        return s;
    }

    @Override
    public int getViewDistance() {
        return 32;
    }
}
