package dev.aestheticjobs.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.FormattedText;
import net.minecraft.network.chat.Style;

/**
 * A screen drawn on its own canvas of a fixed size (vw x vh) that is scaled down as a whole to fit the window. So the
 * layout is the same on every GUI scale and window size: nothing sticks out, and every text has the same size
 * (the font is never scaled separately). Mouse positions are given to the subclass in canvas coordinates.
 */
public abstract class ScaledScreen extends Screen {
    protected float scale = 1.0F;
    protected int ox, oy;

    protected ScaledScreen(Component title) {
        super(title);
    }

    /** Canvas size (may change between frames). */
    protected abstract int vw();

    protected abstract int vh();

    /** Called before the size is asked: compute the layout here. */
    protected void prepare() {}

    protected abstract void draw(GuiGraphics g, int mx, int my, float partial);

    protected boolean click(int mx, int my, int button) {
        return false;
    }

    private void fit() {
        prepare();
        float w = vw(), h = vh();
        scale = Math.max(0.3F, Math.min(1.0F, Math.min((width - 6.0F) / w, (height - 6.0F) / h)));
        ox = Math.round((width - w * scale) / 2.0F);
        oy = Math.round((height - h * scale) / 2.0F);
    }

    protected int vx(double x) {
        return (int) Math.floor((x - ox) / scale);
    }

    protected int vy(double y) {
        return (int) Math.floor((y - oy) / scale);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        fit();
        renderBackground(g, mouseX, mouseY, partial);
        g.pose().pushPose();
        g.pose().translate(ox, oy, 0.0F);
        g.pose().scale(scale, scale, 1.0F);
        draw(g, vx(mouseX), vy(mouseY), partial);
        g.pose().popPose();
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        fit();
        return click(vx(mx), vy(my), button) || super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ------------------------------------------------------------------ text that always fits

    /** The text cut into lines no wider than w (the font size is never changed). */
    public static List<String> wrap(Font font, Component text, int w) {
        List<String> out = new ArrayList<>();
        for (FormattedText line : font.getSplitter().splitLines(text, w, Style.EMPTY)) out.add(line.getString());
        return out;
    }

    /** One line: the text, or its beginning with "..." if it is wider than w. */
    public static Component fit(Font font, Component text, int w) {
        if (font.width(text) <= w) return text;
        return Component.literal(font.plainSubstrByWidth(text.getString(), Math.max(0, w - font.width("..."))) + "...");
    }
}
