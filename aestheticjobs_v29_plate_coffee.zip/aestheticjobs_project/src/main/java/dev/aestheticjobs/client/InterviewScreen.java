package dev.aestheticjobs.client;

import com.mojang.math.Axis;
import dev.aestheticjobs.network.InterviewAnswerPayload;
import dev.aestheticjobs.network.InterviewCancelPayload;
import dev.aestheticjobs.network.InterviewStatePayload;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

/**
 * The interview window. Left: the real manager of the world and under him the applicant's resume, on which the
 * manager's marks appear. Right: the steps of the interview, the impression bar, his words typed into a speech bubble and
 * the answers. A phone rings to check a bluff, the trial shows its task, the contract is signed on paper, and at the end
 * a stamp lands. The text has one size everywhere (see Ui); the canvas grows with it and is scaled to the window.
 */
public class InterviewScreen extends ScaledScreen {
    private static final int VW = 420, MARGIN = 10, SIDE_W = 134, RX = MARGIN + SIDE_W + 8, RW = VW - RX - MARGIN;
    private static final int BUBBLE_W = RW - 20, OPT_W = RW - 34, LINE = Ui.LINE, BAR_Y = 45, BUBBLE_Y = 62;
    private static final int PORTRAIT_H = 114, MIN_H = 250, SIGN_TICKS = 34;
    private static final int STEPS = 5;

    private int managerId;
    private InterviewStatePayload state;

    private List<String> reactLines = List.of(), lineLines = List.of();
    private final List<List<String>> optionLines = new ArrayList<>();
    private int totalChars;
    private float typed;
    private boolean ready, answered;
    private int readyT, callT, stampT, signT = -1;
    private float shownImpression;
    private int popT = -1, popDelta;

    // the layout of the current frame
    private int bubbleH, midY, canvasH = MIN_H;
    /** Where the room of the portrait ends (above the name plate), on the canvas. */
    private int portraitBottom;
    private final List<int[]> optBoxes = new ArrayList<>();       // x, y, w, h
    private final List<SheetLine> sheet = new ArrayList<>();
    private int sheetH;

    /** mark: 0 none, 1 confirmed, 2 doubted, 3 a claim not yet checked. */
    private record SheetLine(String text, int color, int mark) {}

    private final int[] confettiX = new int[40], confettiV = new int[40], confettiC = new int[40];

    public InterviewScreen(InterviewStatePayload payload) {
        super(Component.translatable("interview.title"));
        this.state = payload;
        this.managerId = payload.manager();
        this.shownImpression = payload.impression();
        java.util.Random r = new java.util.Random(payload.manager() * 31L + 7L);
        int[] palette = {0xFFE3A08C, 0xFFF6D58A, 0xFFA9C79A, 0xFFB8C8E8, 0xFFF0B8D8};
        for (int i = 0; i < confettiX.length; i++) {
            confettiX[i] = r.nextInt(RW - 8);
            confettiV[i] = 6 + r.nextInt(10);
            confettiC[i] = palette[r.nextInt(palette.length)];
        }
    }

    public int manager() {
        return managerId;
    }

    /** A new state from the server (the answer was taken): the manager answers. */
    public void update(InterviewStatePayload payload) {
        this.state = payload;
        this.managerId = payload.manager();
        rebuildText();
        Ui.sound(SoundEvents.UI_BUTTON_CLICK.value(), 1.5F, 0.3F);
    }

    @Override
    protected void init() {
        // also called when the window is resized: the text stays as far as it was typed
        if (totalChars == 0 && lineLines.isEmpty()) rebuildText();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private static Component arg(String s) {
        if (s.startsWith("t:")) return Component.translatable(s.substring(2));
        if (s.startsWith("T:")) {
            var out = Component.empty();
            String[] keys = s.substring(2).split(",");
            for (int i = 0; i < keys.length; i++) {
                if (i > 0) out.append(", ");
                out.append(Component.translatable(keys[i]));
            }
            return out;
        }
        return Component.literal(s);
    }

    private static Component tr(String key, List<String> args) {
        Object[] a = new Object[args.size()];
        for (int i = 0; i < a.length; i++) a[i] = arg(args.get(i));
        return Component.translatable(key, a);
    }

    private void rebuildText() {
        if (font == null) return;
        reactLines = state.reactKey().isEmpty() ? List.of() : wrap(font, tr(state.reactKey(), state.reactArgs()), BUBBLE_W);
        // the contract has its own paper: its figures are not repeated in the bubble
        lineLines = state.lineKey().isEmpty() ? List.of()
                : wrap(font, tr(state.lineKey(), phase(InterviewStatePayload.CONTRACT) ? List.of() : state.lineArgs()), BUBBLE_W);
        optionLines.clear();
        for (String key : state.options()) optionLines.add(key.isEmpty() ? List.of() : wrap(font, Component.translatable(key), OPT_W));
        totalChars = 0;
        for (String s : reactLines) totalChars += s.length();
        for (String s : lineLines) totalChars += s.length();
        typed = 0.0F;
        ready = totalChars == 0;
        readyT = 0;
        answered = false;
        callT = 0;
        stampT = 0;
        signT = -1;
        if (state.delta() != 0) {
            popT = 0;
            popDelta = state.delta();
        }
    }

    private boolean phase(int p) {
        return state.phase() == p;
    }

    private boolean finalPhase() {
        return phase(InterviewStatePayload.HIRED) || phase(InterviewStatePayload.REJECTED);
    }

    @Override
    protected int vw() {
        return VW;
    }

    @Override
    protected int vh() {
        return canvasH;
    }

    /** The height of what stands between the bubble and the answers. */
    private int middle() {
        if (phase(InterviewStatePayload.CALL)) return 66;
        if (phase(InterviewStatePayload.TRIAL)) return 36;
        if (phase(InterviewStatePayload.CONTRACT)) return 92;
        if (finalPhase()) return 52;                                        // room for the stamp
        return 0;
    }

    @Override
    protected void prepare() {
        int lines = reactLines.size() + lineLines.size();
        int gap = reactLines.isEmpty() || lineLines.isEmpty() ? 0 : 4;
        bubbleH = Math.max(36, lines * LINE + gap + 14);
        midY = BUBBLE_Y + bubbleH + 6;
        optBoxes.clear();
        int y = midY + middle();
        if (!phase(InterviewStatePayload.CALL)) {
            for (List<String> ol : optionLines) {
                int h = Math.max(20, ol.size() * LINE + 9);
                optBoxes.add(new int[]{RX, y, RW, h});
                y += h + 4;
            }
        }
        buildSheet();
        canvasH = Math.max(Math.max(MIN_H, y + 8), MARGIN + PORTRAIT_H + 6 + sheetH + MARGIN);
    }

    private void buildSheet() {
        sheet.clear();
        int bits = state.sheet();
        int exp = bits & 3, trait = bits >> 2 & 3, goal = bits >> 4 & 3, skills = bits >> 6 & 255;
        int ok = bits >> 14 & 255, bad = bits >> 22 & 255, expMark = bits >>> 30;
        add(Component.translatable("interview.sheet.exp", Component.translatable("resume.exp." + exp)), Ui.INK,
                expMark == 1 ? 1 : expMark == 2 ? 2 : 0);
        add(Component.translatable("interview.sheet.trait", Component.translatable("resume.trait." + trait)), Ui.LABEL, 0);
        add(Component.translatable("interview.sheet.goal", Component.translatable("resume.goal." + goal)), Ui.LABEL, 0);
        for (int i = 0; i < 8; i++) {
            if ((skills >> i & 1) == 0) continue;
            add(Component.translatable("resume.skill." + i), Ui.INK, (ok >> i & 1) != 0 ? 1 : (bad >> i & 1) != 0 ? 2 : 3);
        }
        sheetH = 20 + sheet.size() * LINE + 5;
    }

    private void add(Component text, int color, int mark) {
        List<String> lines = Ui.lines(font, text, SIDE_W - 26, 2);
        for (int i = 0; i < lines.size(); i++) sheet.add(new SheetLine(lines.get(i), color, i == 0 ? mark : 0));
    }

    @Override
    public void tick() {
        if (typed < totalChars) {
            typed += 3.0F;
            if (typed >= totalChars) {
                typed = totalChars;
                ready = true;
            }
        } else if (!ready) {
            ready = true;
        }
        if (ready) {
            readyT++;
            if (finalPhase()) stampT++;
        }
        shownImpression += (state.impression() - shownImpression) * 0.12F;
        if (Math.abs(state.impression() - shownImpression) < 0.2F) shownImpression = state.impression();
        if (popT >= 0 && ++popT > 44) popT = -1;
        if (phase(InterviewStatePayload.CALL) && !answered) {
            if (++callT >= 50) {
                answered = true;
                PacketDistributor.sendToServer(new InterviewAnswerPayload(0));
            }
        }
        if (signT >= 0 && signT < SIGN_TICKS) {                              // the pen runs, then the paper is handed over
            signT++;
            if (signT % 6 == 1) Ui.sound(SoundEvents.BOOK_PAGE_TURN, 1.8F, 0.25F);
            if (signT == SIGN_TICKS) PacketDistributor.sendToServer(new InterviewAnswerPayload(0));
        }
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void draw(GuiGraphics g, int mx, int my, float partial) {
        Ui.card(g, 0, 0, VW, canvasH);
        drawPortrait(g);
        drawSheet(g);
        drawSteps(g);
        drawBar(g, partial);
        drawBubble(g);
        if (phase(InterviewStatePayload.CALL)) drawPhone(g, partial);
        if (phase(InterviewStatePayload.TRIAL)) drawTask(g);
        if (phase(InterviewStatePayload.CONTRACT)) drawContract(g, partial);
        drawOptions(g, mx, my);
        if (finalPhase() && ready) drawStamp(g, partial);
    }

    /**
     * The manager himself is drawn after the canvas, in window coordinates: the game clips an entity with a rectangle that
     * does not follow the scaling of the canvas.
     */
    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        super.render(g, mouseX, mouseY, partial);
        if (Minecraft.getInstance().level != null
                && Minecraft.getInstance().level.getEntity(managerId) instanceof LivingEntity living) {
            InventoryScreen.renderEntityInInventoryFollowsMouse(g,
                    ox + Math.round((MARGIN + 3) * scale), oy + Math.round((MARGIN + 3) * scale),
                    ox + Math.round((MARGIN + SIDE_W - 3) * scale), oy + Math.round(portraitBottom * scale),
                    Math.max(1, Math.round(40 * scale)), 0.0625F, mouseX, mouseY, living);
        }
    }

    private void drawPortrait(GuiGraphics g) {
        Ui.box(g, MARGIN, MARGIN, SIDE_W, PORTRAIT_H, Ui.KHAKI, Ui.TAN);
        Entity e = Minecraft.getInstance().level == null ? null : Minecraft.getInstance().level.getEntity(managerId);
        Component name = e == null ? Component.translatable("interview.manager") : e.getName();
        int lines = Ui.lines(font, name, SIDE_W - 14, 2).size();
        int plate = MARGIN + PORTRAIT_H - 7 - lines * LINE;
        portraitBottom = plate - 1;
        Ui.box(g, MARGIN + 3, plate, SIDE_W - 6, lines * LINE + 4, Ui.KHAKI, Ui.CREAM);
        int y = plate + 3;
        for (String line : Ui.lines(font, name, SIDE_W - 14, 2)) {
            g.drawString(font, line, MARGIN + (SIDE_W - font.width(line)) / 2, y, Ui.INK, false);
            y += LINE;
        }
    }

    /** The resume on the table, with ticks and crosses. */
    private void drawSheet(GuiGraphics g) {
        int y = MARGIN + PORTRAIT_H + 6, h = canvasH - y - MARGIN;
        Ui.box(g, MARGIN, y, SIDE_W, h, Ui.KHAKI, 0xFFFFFCF2);
        Ui.label(g, font, Component.translatable("interview.sheet.title"), MARGIN + SIDE_W / 2, y + 5, SIDE_W - 12, Ui.LABEL);
        g.fill(MARGIN + 8, y + 15, MARGIN + SIDE_W - 8, y + 16, Ui.KHAKI);
        int ly = y + 20;
        for (SheetLine line : sheet) {
            g.drawString(font, line.text(), MARGIN + 7, ly, line.color(), false);
            int mx = MARGIN + SIDE_W - 15;
            if (line.mark() == 1) tick(g, mx, ly);
            else if (line.mark() == 2) cross(g, mx, ly);
            else if (line.mark() == 3) g.fill(mx + 3, ly + 3, mx + 5, ly + 5, Ui.KHAKI);
            ly += LINE;
        }
    }

    private static void tick(GuiGraphics g, int x, int y) {
        Ui.line(g, x, y + 4, x + 3, y + 7, 2, 0xFF4F8A4A);
        Ui.line(g, x + 3, y + 7, x + 8, y + 1, 2, 0xFF4F8A4A);
    }

    private static void cross(GuiGraphics g, int x, int y) {
        Ui.line(g, x + 1, y + 1, x + 7, y + 7, 2, 0xFFB5543A);
        Ui.line(g, x + 1, y + 7, x + 7, y + 1, 2, 0xFFB5543A);
    }

    private void drawSteps(GuiGraphics g) {
        int at = Math.max(0, Math.min(STEPS - 1, state.progress()));
        Ui.paragraph(g, font, Component.translatable("interview.stage." + at), RX, 11, RW - STEPS * 16 - 6, 1, Ui.INK);
        int x = RX + RW - STEPS * 16;
        for (int i = 0; i < STEPS; i++) {
            if (i > 0) g.fill(x + i * 16 - 8, 14, x + i * 16, 16, i <= at ? Ui.GOOD_D : Ui.KHAKI);
            Ui.box(g, x + i * 16, 11, 8, 8, i <= at ? Ui.GOOD_D : Ui.KHAKI, i < at ? Ui.GOOD_D : i == at ? Ui.CREAM : Ui.TAN);
        }
    }

    private void drawBar(GuiGraphics g, float partial) {
        Ui.paragraph(g, font, Component.translatable("interview.impression"), RX, 30, RW - 40, 1, Ui.LABEL);
        double v = Math.max(0.0D, Math.min(1.0D, shownImpression / 100.0D));
        int color = v < 0.5D ? Ui.lerp(Ui.BAD_D, Ui.WARN_D, v * 2.0D) : Ui.lerp(Ui.WARN_D, Ui.GOOD_D, (v - 0.5D) * 2.0D);
        Ui.bar(g, RX, BAR_Y, RW, 8, v, color);
        int tx = RX + (int) Math.round(RW * state.threshold() / 100.0D);            // the hiring line
        g.fill(tx, BAR_Y - 3, tx + 1, BAR_Y + 11, Ui.INK);
        g.fill(tx - 1, BAR_Y - 4, tx + 2, BAR_Y - 3, Ui.INK);
        if (popT >= 0) {                                                            // +12 / -8 floats up beside the label
            float p = Math.min(1.0F, (popT + partial) / 44.0F);
            int alpha = Math.max(8, (int) (255 * (1.0F - p * p)));
            Component pop = Component.literal((popDelta > 0 ? "+" : "") + popDelta);
            g.drawString(font, pop, RX + RW - font.width(pop), 34 - (int) (p * 6),
                    alpha << 24 | (popDelta > 0 ? 0x3F7A3A : 0xB5432A), false);
        }
    }

    private void drawBubble(GuiGraphics g) {
        Ui.box(g, RX, BUBBLE_Y, RW, bubbleH, Ui.KHAKI, 0xFFFFFCF2);
        for (int i = 0; i <= 4; i++) {                                              // the tail towards the manager
            int x = RX - 4 + i, cy = BUBBLE_Y + 12;
            g.fill(x, cy - i, x + 1, cy + i + 1, Ui.KHAKI);
            if (i > 0) g.fill(x, cy - i + 1, x + 1, cy + i, 0xFFFFFCF2);
        }
        int left = (int) typed;
        int y = BUBBLE_Y + 7;
        for (String line : reactLines) {
            int take = Math.max(0, Math.min(line.length(), left));
            left -= line.length();
            if (take > 0) g.drawString(font, line.substring(0, take), RX + 10, y, Ui.LABEL, false);
            y += LINE;
        }
        if (!reactLines.isEmpty() && !lineLines.isEmpty()) y += 4;
        for (String line : lineLines) {
            int take = Math.max(0, Math.min(line.length(), left));
            left -= line.length();
            if (take > 0) g.drawString(font, line.substring(0, take), RX + 10, y, Ui.INK, false);
            y += LINE;
        }
    }

    private void drawOptions(GuiGraphics g, int mx, int my) {
        if (!ready) return;
        float fade = Math.min(1.0F, readyT / 6.0F);
        boolean last = finalPhase();
        for (int i = 0; i < optBoxes.size(); i++) {
            int[] b = optBoxes.get(i);
            int y = b[1] + (int) ((1.0F - fade) * 6.0F);
            boolean enabled = !answered && signT < 0;
            boolean hover = enabled && Ui.in(mx, my, b[0], b[1], b[2], b[3]);
            int border = hover || last ? Ui.GOOD_D : Ui.KHAKI;
            int fill = !enabled ? 0xFFE9E0CC : last ? hover ? 0xFFC9E0BA : Ui.GOOD : hover ? 0xFFFBF1D6 : Ui.TAN;
            Ui.box(g, b[0], y, b[2], b[3], border, fill);
            if (!last) {                                                            // the number of the key
                int cy = y + b[3] / 2;
                g.fill(b[0] + 6, cy - 6, b[0] + 18, cy + 6, hover ? Ui.GOOD_D : 0xFF8A6450);
                Ui.label(g, font, Component.literal(Integer.toString(i + 1)), b[0] + 12, cy - 4, 12, Ui.CREAM);
            }
            List<String> lines = optionLines.get(i);
            int ty = y + (b[3] - lines.size() * LINE) / 2 + 1;
            for (String line : lines) {
                int tx = last ? b[0] + (b[2] - font.width(line)) / 2 : b[0] + 24;
                g.drawString(font, line, tx, ty, enabled ? Ui.INK : 0xFF9A8A72, false);
                ty += LINE;
            }
        }
    }

    /** The phone call: a phone that rings and shakes, rings around it, dots. */
    private void drawPhone(GuiGraphics g, float partial) {
        int y = midY;
        Ui.box(g, RX, y, RW, 60, Ui.KHAKI, Ui.TAN);
        float t = callT + partial;
        int cx = RX + 40, cy = y + 30;
        int shake = t < 44 && ((int) (t / 2)) % 2 == 0 ? 1 : -1;
        Ui.box(g, cx - 9 + shake, cy - 16, 18, 32, Ui.INK, 0xFF52332A);            // the phone
        g.fill(cx - 6 + shake, cy - 12, cx + 6 + shake, cy + 7, 0xFFCDD3D6);        // the screen
        Ui.disc(g, cx + shake, cy + 11, 2, 0xFFCDD3D6);
        for (int i = 0; i < 3; i++) {                                               // the rings
            float p = ((t + i * 6) % 18.0F) / 18.0F;
            int alpha = Math.max(8, (int) (200 * (1.0F - p)));
            Ui.ring(g, cx, cy, 13 + (int) (p * 14), 1, alpha << 24 | 0x9A8A6A);
        }
        String dots = ".".repeat(1 + ((int) t / 8) % 3);
        Ui.paragraph(g, font, Component.translatable("interview.calling.dots", dots), RX + 80, cy - 4, RW - 88, 1, Ui.INK);
    }

    /** The task of the trial: the picture of the thing and what exactly to bring. */
    private void drawTask(GuiGraphics g) {
        Ui.box(g, RX, midY, RW, 30, Ui.WARN_D, 0xFFFFEFC0);
        g.fill(RX + 5, midY + 5, RX + 25, midY + 25, Ui.CREAM);
        TrialHud.icon(g, state.lineKey(), state.lineArgs(), RX + 7, midY + 7);
        Component what = TrialHud.what(state.lineKey(), state.lineArgs());
        int n = Ui.lines(font, what, RW - 40, 2).size();
        Ui.paragraph(g, font, what, RX + 32, midY + 16 - n * 5, RW - 40, 2, Ui.INK);
    }

    /** The employment contract; signing it writes the applicant's name along the line. */
    private void drawContract(GuiGraphics g, float partial) {
        int y = midY;
        Ui.box(g, RX, y, RW, 86, Ui.BORDER, 0xFFFFFDF6);
        Ui.label(g, font, Component.translatable("interview.contract.title"), RX + RW / 2, y + 6, RW - 12, Ui.INK);
        g.fill(RX + 10, y + 17, RX + RW - 10, y + 18, Ui.KHAKI);
        List<String> a = state.lineArgs();
        if (a.size() >= 3) {
            Ui.paragraph(g, font, Component.translatable("interview.contract.job", arg(a.get(0))), RX + 10, y + 22, RW - 20, 1, Ui.INK);
            Ui.paragraph(g, font, Component.translatable("interview.contract.rank", arg(a.get(1))), RX + 10, y + 33, RW - 20, 1, Ui.INK);
            Ui.paragraph(g, font, Component.translatable("interview.contract.wage", arg(a.get(2))), RX + 10, y + 44, RW - 20, 1, Ui.INK);
        }
        Component label = Component.translatable("interview.contract.signature");
        g.drawString(font, label, RX + 10, y + 66, Ui.LABEL, false);
        int lx = RX + 14 + font.width(label), lw = RX + RW - 36 - lx;
        g.fill(lx, y + 75, lx + lw, y + 76, Ui.INK);
        if (signT >= 0 && minecraft.player != null) {
            String name = font.plainSubstrByWidth(minecraft.player.getGameProfile().getName(), lw - 4);
            float p = Math.min(1.0F, (signT + partial) / (SIGN_TICKS - 8.0F));
            String shown = name.substring(0, Math.round(name.length() * p));
            g.drawString(font, shown, lx + 2, y + 65, 0xFF2F4A8A, false);
            int px = lx + 3 + font.width(shown);                                    // the pen
            if (p < 1.0F) Ui.line(g, px, y + 72, px + 7, y + 60, 2, 0xFF2F4A8A);
        }
        Ui.ring(g, RX + RW - 20, y + 68, 9, 1, 0x99B5543A);                          // the seal
        Ui.ring(g, RX + RW - 20, y + 68, 6, 1, 0x99B5543A);
    }

    /** The stamp: lands with a bump, tilted; green with confetti or red. */
    private void drawStamp(GuiGraphics g, float partial) {
        boolean good = phase(InterviewStatePayload.HIRED);
        float t = stampT + partial;
        float p = Math.min(1.0F, t / 8.0F);
        float ease = 1.0F - (1.0F - p) * (1.0F - p);
        float s = 2.2F - 1.2F * ease;
        int alpha = Math.max(8, (int) (255 * p));
        int col = alpha << 24 | (good ? 0x4F8A4A : 0xB5543A);
        Component text = Component.translatable(good ? "interview.stamp.hired" : "interview.stamp.rejected");
        int tw = font.width(text);
        g.pose().pushPose();
        g.pose().translate(RX + RW / 2.0F, midY + 24.0F, 0.0F);
        g.pose().mulPose(Axis.ZP.rotationDegrees(-8.0F));
        g.pose().scale(s, s, 1.0F);
        int w = Math.min(RW - 20, tw * 2 + 16), h = 28;
        g.renderOutline(-w / 2, -h / 2, w, h, col);
        g.renderOutline(-w / 2 + 2, -h / 2 + 2, w - 4, h - 4, col);
        float k = Math.min(2.0F, (w - 12.0F) / Math.max(1, tw));               // the one big word of the window
        g.pose().scale(k, k, 1.0F);
        g.drawString(font, text, -tw / 2, -4, col, false);
        g.pose().popPose();
        if (good) {
            for (int i = 0; i < confettiX.length; i++) {
                float ft = t - i * 0.4F;
                if (ft < 0) continue;
                int x = RX + 4 + confettiX[i] + (int) (Math.sin(ft * 0.3F + i) * 3.0F);
                int y = 22 + (int) (confettiV[i] * 0.5F * ft + 0.05F * ft * ft);
                if (y < canvasH - 8) g.fill(x, y, x + 3, y + 3, confettiC[i]);
            }
        }
    }

    // ------------------------------------------------------------------ input

    private void choose(int i) {
        if (!ready || answered || signT >= 0 || i < 0 || i >= state.options().size()) return;
        if (phase(InterviewStatePayload.CALL)) return;
        if (finalPhase() || phase(InterviewStatePayload.TRIAL) && i == 0) {       // "alright": go and do it
            onClose();
            return;
        }
        Ui.sound(SoundEvents.UI_BUTTON_CLICK.value(), 1.1F, 0.5F);
        if (phase(InterviewStatePayload.CONTRACT) && i == 0) {
            signT = 0;
            return;
        }
        answered = true;
        PacketDistributor.sendToServer(new InterviewAnswerPayload(i));
    }

    private boolean skipTyping() {
        if (ready) return false;
        typed = totalChars;
        ready = true;
        readyT = 0;
        return true;
    }

    @Override
    protected boolean click(int mx, int my, int button) {
        if (button != 0) return false;
        if (skipTyping()) return true;
        for (int i = 0; i < optBoxes.size(); i++) {
            int[] b = optBoxes.get(i);
            if (Ui.in(mx, my, b[0], b[1], b[2], b[3])) {
                choose(i);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (key == GLFW.GLFW_KEY_SPACE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
            if (!skipTyping() && finalPhase()) onClose();
            return true;
        }
        int n = key >= GLFW.GLFW_KEY_1 && key <= GLFW.GLFW_KEY_9 ? key - GLFW.GLFW_KEY_1
                : key >= GLFW.GLFW_KEY_KP_1 && key <= GLFW.GLFW_KEY_KP_9 ? key - GLFW.GLFW_KEY_KP_1 : -1;
        if (n >= 0) {
            choose(n);
            return true;
        }
        return super.keyPressed(key, scanCode, modifiers);
    }

    @Override
    public void onClose() {
        PacketDistributor.sendToServer(new InterviewCancelPayload());
        super.onClose();
    }
}
