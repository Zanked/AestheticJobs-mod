package dev.aestheticjobs.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;

/** Drawing helpers of the mod's screens, in the pastel palette of the mod. */
public final class Ui {
    public static final int BG = 0xFFF3E6C8, BORDER = 0xFF6A4A3A, INNER = 0xFFFFF6E2, INK = 0xFF4A3228;
    public static final int LABEL = 0xFF8A6A58, TAN = 0xFFEFE1C2, KHAKI = 0xFFBFA982, CREAM = 0xFFFFF6E2;
    public static final int GOOD = 0xFFA9C79A, GOOD_D = 0xFF7FA070, WARN = 0xFFF6D58A, WARN_D = 0xFFD9A850;
    public static final int BAD = 0xFFE3A08C, BAD_D = 0xFFC98468, STEEL = 0xFFCDD3D6, STEEL_D = 0xFF9AA4AA;
    public static final int ESPRESSO = 0xFF52332A, CREMA = 0xFFE0AA78, MILK = 0xFFFCF0D6;

    private Ui() {}

    public static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    public static int lerp(int a, int b, double t) {
        t = Math.max(0, Math.min(1, t));
        int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255;
        int br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
        return 0xFF000000 | (int) (ar + (br - ar) * t) << 16 | (int) (ag + (bg - ag) * t) << 8 | (int) (ab + (bb - ab) * t);
    }

    public static void sound(SoundEvent sound, float pitch, float volume) {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(sound, pitch, volume));
    }

    // ---------------------------------------------------------------- shapes

    /** A box with a 1px border and cut corners (soft, pixel-art look). */
    public static void box(GuiGraphics g, int x, int y, int w, int h, int border, int fill) {
        g.fill(x + 1, y, x + w - 1, y + h, border);
        g.fill(x, y + 1, x + w, y + h - 1, border);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, fill);
    }

    public static void disc(GuiGraphics g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.round(Math.sqrt(Math.max(0, r * r + 0.5 - dy * dy)));
            g.fill(cx - half, cy + dy, cx + half + 1, cy + dy + 1, color);
        }
    }

    public static void ring(GuiGraphics g, int cx, int cy, int r, int thick, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int outer = (int) Math.round(Math.sqrt(Math.max(0, r * r + 0.5 - dy * dy)));
            int ri = r - thick;
            int inner = Math.abs(dy) >= ri ? 0 : (int) Math.round(Math.sqrt(Math.max(0, ri * ri + 0.5 - dy * dy)));
            if (inner == 0) {
                g.fill(cx - outer, cy + dy, cx + outer + 1, cy + dy + 1, color);
            } else {
                g.fill(cx - outer, cy + dy, cx - inner, cy + dy + 1, color);
                g.fill(cx + inner + 1, cy + dy, cx + outer + 1, cy + dy + 1, color);
            }
        }
    }

    public static void line(GuiGraphics g, double x0, double y0, double x1, double y1, int thick, int color) {
        int steps = (int) Math.max(1, Math.ceil(Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0))));
        for (int i = 0; i <= steps; i++) {
            int x = (int) Math.round(x0 + (x1 - x0) * i / steps), y = (int) Math.round(y0 + (y1 - y0) * i / steps);
            g.fill(x, y, x + thick, y + thick, color);
        }
    }

    public static void bar(GuiGraphics g, int x, int y, int w, int h, double v, int color) {
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, KHAKI);
        g.fill(x, y, x + w, y + h, TAN);
        int fw = (int) Math.round(w * Math.max(0, Math.min(1, v)));
        if (fw > 0) g.fill(x, y, x + fw, y + h, color);
    }

    public static void icon(GuiGraphics g, ResourceLocation tex, int x, int y, int size) {
        g.blit(tex, x, y, size, size, 0, 0, 32, 32, 32, 32);
    }

    // ---------------------------------------------------------------- text and buttons

    public static void text(GuiGraphics g, Font font, Component c, int x, int y, int color) {
        g.drawString(font, c, x, y, color, false);
    }

    public static void centered(GuiGraphics g, Font font, Component c, int cx, int y, int color) {
        g.drawString(font, c, cx - font.width(c) / 2, y, color, false);
    }

    // ---------------------------------------------------------------- the one text style of the mod
    // The font is never scaled: a long text goes to the next line, and only when it has used all its lines it ends
    // with "..." (the screen then shows it whole in a tooltip).

    public static final int LINE = 10;

    /** The text in at most max lines no wider than w. */
    public static List<String> lines(Font font, Component c, int w, int max) {
        List<String> all = ScaledScreen.wrap(font, c, w);
        if (all.size() <= max) return all;
        List<String> out = new ArrayList<>(all.subList(0, Math.max(0, max - 1)));
        if (max > 0) {
            out.add(font.plainSubstrByWidth(all.get(max - 1), Math.max(0, w - font.width("..."))) + "...");
        }
        return out;
    }

    public static boolean cut(Font font, Component c, int w, int max) {
        return ScaledScreen.wrap(font, c, w).size() > max;
    }

    /** Draws the lines and returns their height. */
    public static int paragraph(GuiGraphics g, Font font, Component c, int x, int y, int w, int max, int color) {
        List<String> lines = lines(font, c, w, max);
        for (int i = 0; i < lines.size(); i++) g.drawString(font, lines.get(i), x, y + i * LINE, color, false);
        return lines.size() * LINE;
    }

    /** One centred line. */
    public static void label(GuiGraphics g, Font font, Component c, int cx, int y, int w, int color) {
        for (String s : lines(font, c, w, 1)) g.drawString(font, s, cx - font.width(s) / 2, y, color, false);
    }

    /** The paper card every panel of the mod is drawn on: shadow, wooden border, cream paper. */
    public static void card(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x + 3, y + 3, x + w + 3, y + h + 3, 0x55000000);
        g.fill(x + 1, y, x + w - 1, y + h, BORDER);
        g.fill(x, y + 1, x + w, y + h - 1, BORDER);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, INNER);
        g.fill(x + 2, y + h - 3, x + w - 2, y + h - 1, TAN);
    }

    /** The dark strip with the title on top of a card. */
    public static void header(GuiGraphics g, Font font, Component title, int x, int y, int w) {
        g.fill(x + 3, y + 3, x + w - 3, y + 16, 0xFF8A6450);
        g.fill(x + 3, y + 3, x + w - 3, y + 4, 0xFFA87E66);
        label(g, font, title, x + w / 2, y + 6, w - 12, CREAM);
    }

    /** kind: 0 normal, 1 main action (green), 2 selected (rose), 3 warning */
    public static void button(GuiGraphics g, Font font, int x, int y, int w, int h, Component label, boolean hover,
                              boolean enabled, int kind) {
        int border, base;
        if (!enabled) { border = 0xFFD2C6AC; base = 0xFFE9E0CC; }
        else if (kind == 1) { border = GOOD_D; base = hover ? 0xFFC9E0BA : GOOD; }
        else if (kind == 2) { border = BAD_D; base = hover ? 0xFFF7CDBB : 0xFFF0B8A4; }
        else if (kind == 3) { border = WARN_D; base = hover ? 0xFFFBE6AE : WARN; }
        else { border = KHAKI; base = hover ? 0xFFFBF1D6 : TAN; }
        box(g, x, y, w, h, border, base);
        g.drawString(font, label, x + w / 2 - font.width(label) / 2, y + (h - 8) / 2 + 1, enabled ? INK : 0xFFB5A58A, false);
    }
}
