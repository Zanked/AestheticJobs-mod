package dev.aestheticjobs.client;

import com.mojang.blaze3d.platform.NativeImage;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.cafe.Art;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.entity.CafeCustomerEntity;
import dev.aestheticjobs.item.Dessert;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

/**
 * Draws the customer and, over its head, the thought bubble:
 *  - waiting: the exact foam pattern it wants (16x16 cells on a saucer) + a patience bar that runs out;
 *  - drinking: the REAL drawing the barista made pops out of the cup, with the stars below it.
 * The bubble is a 32x32 texture (textures/entity/bubble.png); the pattern is a 16x16 dynamic texture on top of it.
 */
public class CafeCustomerRenderer extends CafePersonRenderer<CafeCustomerEntity> {
    private static final ResourceLocation BUBBLE =
            ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "textures/entity/bubble.png");

    private static final int FULL_BRIGHT = 0xF000F0;
    /** Width of the bubble in blocks; one texture pixel = W / 32. */
    private static final float W = 0.72F;
    private static final float P = W / 32.0F;

    // colours of the bar
    private static final int[] GREEN = {124, 158, 108};
    private static final int[] GOLD = {241, 199, 96};
    private static final int[] TERRA = {201, 132, 104};
    private static final int[] EMPTY = {168, 148, 108};

    public CafeCustomerRenderer(EntityRendererProvider.Context context) {
        super(context, CafePersonModel.LAYER);
    }

    @Override
    public void render(CafeCustomerEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
        renderBubble(entity, partialTick, poseStack, buffer);
    }

    // ------------------------------------------------------------------ the bubble

    private void renderBubble(CafeCustomerEntity entity, float partial, PoseStack ps, MultiBufferSource buffer) {
        int state = entity.getState();
        float age = entity.tickCount + partial;
        float t = age - entity.getClientStateStart();

        ResourceLocation art;
        ResourceLocation dessertArt = null;
        float scale;
        float rise = 0.0F;
        boolean starMode = false;
        boolean iconMode = false;
        int stars = 0;
        int patience = 100;

        if (state == CafeCustomerEntity.STATE_WAITING) {
            Drink drink = Drink.byIndex(entity.getDrink());
            if (drink == null) return;
            art = drink.iconTexture();                       // the detailed 32x32 picture of the drink
            iconMode = true;
            Dessert dessert = Dessert.byIndex(entity.getDessert());
            if (dessert != null) dessertArt = dessert.iconTexture();     // the dessert ordered with it, next to the cup
            scale = easeOutBack(Mth.clamp(t / 8.0F, 0.0F, 1.0F));
            patience = entity.getPatience();
        } else if (state == CafeCustomerEntity.STATE_DRINKING) {
            if (t < CafeCustomerEntity.REVEAL_TICK || t >= CafeCustomerEntity.BURST_TICK) return;
            String a = entity.getArt();
            if (a.length() != Drink.CELLS) return;
            Drink shown = Drink.byIndex(entity.getDrink());
            art = artTexture("a" + entity.getDrink() + a, servedPixels(a, shown));
            float k = t - CafeCustomerEntity.REVEAL_TICK;
            scale = easeOutBack(Mth.clamp(k / 8.0F, 0.0F, 1.0F));
            rise = k * 0.0075F;
            starMode = true;
            stars = entity.getStars();
        } else {
            return;
        }
        if (scale <= 0.001F) return;

        ps.pushPose();
        ps.translate(0.0F, entity.getBbHeight() + 0.28F + Mth.sin(age * 0.1F) * 0.03F + rise, 0.0F);
        ps.mulPose(this.entityRenderDispatcher.cameraOrientation());
        ps.mulPose(Axis.ZP.rotationDegrees(Mth.sin(age * 0.07F) * 3.0F));
        ps.scale(scale, scale, scale);                     // grows out of the tail, i.e. out of the head
        PoseStack.Pose pose = ps.last();

        // 1) bubble frame + bar (one render type, written completely before the next one is requested)
        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(BUBBLE));
        quad(vc, pose, px(1), py(32), px(31), py(0), 0.0F, 1.0F / 32.0F, 0.0F, 31.0F / 32.0F, 1.0F, 255, 255, 255);
        final float wu = 0.5F / 32.0F, wv = 31.5F / 32.0F;   // a white texel, used for coloured fills
        if (starMode) {
            float seg = 18.0F / 5.0F;
            for (int i = 0; i < 5; i++) {
                int[] c = i < stars ? GOLD : EMPTY;
                float x0 = 7.0F + i * seg + 0.3F, x1 = 7.0F + (i + 1) * seg - 0.3F;
                quad(vc, pose, px(x0), py(25), px(x1), py(22), 0.0015F, wu, wv, wu, wv, c[0], c[1], c[2]);
            }
        } else {
            int[] c = patience >= 60 ? GREEN : patience >= 25 ? GOLD : TERRA;
            float w = 18.0F * patience / 100.0F;
            if (w > 0.1F) {
                quad(vc, pose, px(7), py(25), px(7 + w), py(22), 0.0015F, wu, wv, wu, wv, c[0], c[1], c[2]);
            }
        }

        // 2) the foam pattern on the saucer (cells x 8..23, y 3..18 of the bubble texture)
        VertexConsumer artVc = buffer.getBuffer(RenderType.entityCutoutNoCull(art));
        if (iconMode && dessertArt != null) {
            quad(artVc, pose, px(2.5F), py(18.5F), px(16.5F), py(4.5F), 0.003F, 0.0F, 0.0F, 1.0F, 1.0F, 255, 255, 255);
            VertexConsumer dessertVc = buffer.getBuffer(RenderType.entityCutoutNoCull(dessertArt));
            quad(dessertVc, pose, px(15.5F), py(18.5F), px(29.5F), py(4.5F), 0.0035F, 0.0F, 0.0F, 1.0F, 1.0F, 255, 255, 255);
        } else if (iconMode) {
            quad(artVc, pose, px(6.5F), py(20.5F), px(25.5F), py(1.5F), 0.003F, 0.0F, 0.0F, 1.0F, 1.0F, 255, 255, 255);
        } else {
            quad(artVc, pose, px(8), py(19), px(24), py(3), 0.003F, 0.0F, 0.0F, 1.0F, 1.0F, 255, 255, 255);
        }
        ps.popPose();
    }

    private static float px(float x) {
        return -W / 2.0F + x * P;
    }

    private static float py(float y) {
        return W - y * P;
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose pose, float x0, float yBottom, float x1, float yTop, float z,
                             float u0, float v0, float u1, float v1, int r, int g, int b) {
        // yBottom/yTop are given in world units; (x0,yBottom) is the lower left corner
        float lo = Math.min(yBottom, yTop), hi = Math.max(yBottom, yTop);
        vc.addVertex(pose, x0, hi, z).setColor(r, g, b, 255).setUv(u0, v0)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(FULL_BRIGHT).setNormal(pose, 0.0F, 0.0F, 1.0F);
        vc.addVertex(pose, x0, lo, z).setColor(r, g, b, 255).setUv(u0, v1)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(FULL_BRIGHT).setNormal(pose, 0.0F, 0.0F, 1.0F);
        vc.addVertex(pose, x1, lo, z).setColor(r, g, b, 255).setUv(u1, v1)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(FULL_BRIGHT).setNormal(pose, 0.0F, 0.0F, 1.0F);
        vc.addVertex(pose, x1, hi, z).setColor(r, g, b, 255).setUv(u1, v0)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(FULL_BRIGHT).setNormal(pose, 0.0F, 0.0F, 1.0F);
    }

    private static float easeOutBack(float x) {
        float c1 = 1.70158F, c3 = c1 + 1.0F;
        float u = x - 1.0F;
        return 1.0F + c3 * u * u * u + c1 * u * u;
    }

    // ------------------------------------------------------------------ dynamic 16x16 art textures

    private static final Map<String, ResourceLocation> CACHE = new LinkedHashMap<>(16, 0.75F, true);
    private static int counter;

    private static int[] servedPixels(String art, Drink drink) {
        int[] px = new int[Drink.CELLS];
        for (int y = 0; y < Drink.SIZE; y++) {
            for (int x = 0; x < Drink.SIZE; x++) {
                px[y * Drink.SIZE + x] = !Drink.inCup(x, y) ? 0 : Art.rgb(art.charAt(y * Drink.SIZE + x), drink);
            }
        }
        return px;
    }

    private static ResourceLocation artTexture(String key, int[] argb) {
        ResourceLocation rl = CACHE.get(key);
        if (rl != null) return rl;

        Iterator<Map.Entry<String, ResourceLocation>> it = CACHE.entrySet().iterator();
        while (CACHE.size() >= 64 && it.hasNext()) {              // drop the least recently used
            Minecraft.getInstance().getTextureManager().release(it.next().getValue());
            it.remove();
        }
        NativeImage img = new NativeImage(16, 16, false);
        for (int y = 0; y < 16; y++) {
            for (int x = 0; x < 16; x++) {
                int c = argb[y * 16 + x];
                int a = c >>> 24 & 255, r = c >>> 16 & 255, g = c >>> 8 & 255, b = c & 255;
                img.setPixelRGBA(x, y, a << 24 | b << 16 | g << 8 | r);   // NativeImage wants ABGR
            }
        }
        rl = ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "dynamic/art_" + counter++);
        Minecraft.getInstance().getTextureManager().register(rl, new DynamicTexture(img));
        CACHE.put(key, rl);
        return rl;
    }
}
