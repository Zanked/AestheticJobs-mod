package dev.aestheticjobs.client;

import dev.aestheticjobs.block.StationBlockEntity;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.kitchen.CupRecipe;
import dev.aestheticjobs.cafe.kitchen.Extra;
import dev.aestheticjobs.cafe.kitchen.Knowledge;
import dev.aestheticjobs.cafe.kitchen.Menu;
import dev.aestheticjobs.cafe.kitchen.Pantry;
import dev.aestheticjobs.cafe.kitchen.Signature;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.network.ChooseRecipePayload;
import dev.aestheticjobs.network.OpenBookPayload;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The recipe book: the dishes on the left, on the right page how the chosen one is made, which additions suit it and its
 * signature recipe. Opened from an empty mixing bowl it also chooses the dessert for the bowl.
 */
public class RecipeBookScreen extends ScaledScreen {
    static final int W = 384, H = 250;
    private static final int LEFT_X = 8, LEFT_Y = 40, LEFT_W = 152, LEFT_H = 202;
    private static final int RIGHT_X = 166, RIGHT_Y = 8, RIGHT_W = 210, RIGHT_H = 234;
    private static final int TAB_W = 74, TAB_H = 16;
    private static final int BUTTON_W = 150, BUTTON_H = 18, BUTTON_Y = RIGHT_Y + RIGHT_H - BUTTON_H - 6;
    private static final int PINK = 0xFFA0567E;

    private static int lastDrink, lastDessert = Menu.DRINKS;

    private final boolean forBowl;
    private final BlockPos bowl;
    private final Knowledge knowledge = new Knowledge();
    private final int orderDrink, orderDessert;
    private final java.util.Map<String, ItemStack> stacks = new java.util.HashMap<>();
    private final List<Component> tooltip = new ArrayList<>();
    private boolean drinks;
    private int base;

    public RecipeBookScreen(OpenBookPayload payload) {
        super(Component.translatable("gui.aestheticjobs.book.title"));
        forBowl = payload.forBowl();
        bowl = payload.pos();
        int[] tried = new int[payload.tried().size()];
        for (int i = 0; i < tried.length; i++) tried[i] = payload.tried().get(i);
        knowledge.load(tried, payload.found());
        orderDrink = payload.drink();
        orderDessert = payload.dessert();
        drinks = !forBowl && (orderDrink >= 0 || orderDessert < 0);
        base = drinks ? orderDrink >= 0 ? orderDrink : lastDrink : orderDessert >= 0 ? orderDessert : lastDessert;
    }

    @Override
    protected int vw() {
        return W;
    }

    @Override
    protected int vh() {
        return H;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private int first() {
        return drinks ? 0 : Menu.DRINKS;
    }

    private int count() {
        return drinks ? Menu.DRINKS : Menu.DESSERTS;
    }

    private int cellW() {
        return drinks ? 70 : 24;
    }

    private int cellH() {
        return drinks ? 47 : 26;
    }

    private int cellX(int i) {
        return LEFT_X + (drinks ? 4 + (i % 2) * 74 : 4 + (i % 6) * 24);
    }

    private int cellY(int i) {
        return LEFT_Y + 5 + (drinks ? (i / 2) * 49 : (i / 6) * 27);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        tooltip.clear();
        super.render(g, mouseX, mouseY, partial);
        if (!tooltip.isEmpty()) g.renderComponentTooltip(font, tooltip, mouseX, mouseY);
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my, float partial) {
        tab(g, mx, my, LEFT_X, Component.translatable("gui.aestheticjobs.book.drinks"), drinks);
        tab(g, mx, my, LEFT_X + TAB_W + 4, Component.translatable("gui.aestheticjobs.book.desserts"), !drinks);
        Ui.label(g, font, getTitle(), LEFT_X + LEFT_W / 2, RIGHT_Y + 2, LEFT_W, Ui.CREAM);

        Ui.card(g, LEFT_X, LEFT_Y, LEFT_W, LEFT_H);
        for (int i = 0; i < count(); i++) {
            int b = first() + i, x = cellX(i), y = cellY(i);
            boolean hover = Ui.in(mx, my, x, y, cellW(), cellH() - 2);
            Ui.box(g, x, y, cellW(), cellH() - 2, b == base ? Ui.WARN_D : hover ? Ui.KHAKI : Ui.TAN,
                    b == base ? 0xFFFFE9A8 : hover ? 0xFFFBF1D6 : Ui.BG);
            int size = drinks ? 32 : 20;
            Ui.icon(g, icon(b), x + (cellW() - size) / 2, y + (cellH() - 2 - size) / 2, size);
            if (b == orderDrink || b == orderDessert) {
                g.fill(x + cellW() - 7, y + 2, x + cellW() - 2, y + 7, 0xFFD0503C);
            }
            if (hover) {
                tooltip.add(StationBlockEntity.recipeName(b, 0));
                if (b == orderDrink || b == orderDessert) {
                    tooltip.add(Component.translatable("gui.aestheticjobs.book.ordered").withStyle(ChatFormatting.RED));
                }
            }
        }
        page(g, mx, my);
    }

    private void tab(GuiGraphics g, int mx, int my, int x, Component label, boolean active) {
        int y = LEFT_Y - TAB_H - 3;
        boolean hover = Ui.in(mx, my, x, y, TAB_W, TAB_H);
        Ui.box(g, x, y, TAB_W, TAB_H, Ui.BORDER, active ? Ui.INNER : hover ? Ui.TAN : Ui.KHAKI);
        Ui.label(g, font, label, x + TAB_W / 2, y + 4, TAB_W - 6, Ui.INK);
    }

    /** The right page. */
    private void page(GuiGraphics g, int mx, int my) {
        Menu.Base b = Menu.get(base);
        Ui.card(g, RIGHT_X, RIGHT_Y, RIGHT_W, RIGHT_H);
        int x = RIGHT_X + 8, w = RIGHT_W - 16, y = RIGHT_Y + 6;

        Ui.icon(g, icon(base), x, y, 32);
        Ui.paragraph(g, font, StationBlockEntity.recipeName(base, 0), x + 38, y + 6, w - 38, 2, Ui.INK);
        y += 36;
        rule(g, x, y - 2, w);

        for (int i = 0; i < steps().size(); i++) {
            Component step = steps().get(i);
            g.fill(x, y, x + 9, y + 9, 0xFF8A6450);
            g.drawString(font, Integer.toString(i + 1), x + 5 - font.width(Integer.toString(i + 1)) / 2, y + 1, Ui.CREAM, false);
            int used = Ui.paragraph(g, font, step, x + 14, y + 1, w - 14, 3, Ui.INK);
            if (Ui.cut(font, step, w - 14, 3) && Ui.in(mx, my, x, y, w, used)) tooltip.add(step);
            y += used + 3;
        }

        // what has to be put in
        int ix = x + 14;
        for (String id : b.ingredients()) {
            itemSlot(g, mx, my, id, ix, y);
            ix += 20;
        }
        y += 22;
        rule(g, x, y - 2, w);

        y += Ui.paragraph(g, font, Component.translatable("gui.aestheticjobs.book.goes_with"), x, y, w, 1, Ui.LABEL) + 1;
        ix = x;
        for (Extra e : Extra.values()) {
            if (e.in(b.likes())) {
                itemSlot(g, mx, my, e.item(), ix, y);
                ix += 20;
            }
        }
        y += 21;

        Signature s = signature();
        if (s != null) {
            boolean known = knowledge.knows(s);
            Component name = known ? Component.translatable("signature.aestheticjobs." + s.id())
                    : Component.translatable("gui.aestheticjobs.book.secret");
            y += Ui.paragraph(g, font, name, x, y, w - 44, 2, PINK) + 1;
            int sx = x + w - 40, sy = y - 16;
            for (Extra e : Extra.values()) {
                if (!e.in(s.mask())) continue;
                if (known || e == s.hint()) {
                    itemSlot(g, mx, my, e.item(), sx, sy);
                } else {
                    g.fill(sx, sy, sx + 18, sy + 18, Ui.TAN);
                    Ui.label(g, font, Component.literal("?"), sx + 9, sy + 5, 12, PINK);
                }
                sx += 20;
            }
        }

        if (forBowl && !b.isDrink()) {
            boolean hover = Ui.in(mx, my, buttonX(), BUTTON_Y, BUTTON_W, BUTTON_H);
            Ui.button(g, font, buttonX(), BUTTON_Y, BUTTON_W, BUTTON_H,
                    ScaledScreen.fit(font, Component.translatable("gui.aestheticjobs.book.choose"), BUTTON_W - 8), hover, true, 1);
        }
    }

    private static void rule(GuiGraphics g, int x, int y, int w) {
        g.fill(x, y - 1, x + w, y, Ui.TAN);
    }

    private static int buttonX() {
        return RIGHT_X + (RIGHT_W - BUTTON_W) / 2;
    }

    private void itemSlot(GuiGraphics g, int mx, int my, String id, int x, int y) {
        ItemStack stack = stacks.computeIfAbsent(id, k -> new ItemStack(StationBlockEntity.item(k)));
        g.fill(x, y, x + 18, y + 18, Ui.TAN);
        g.renderItem(stack, x + 1, y + 1);
        if (Ui.in(mx, my, x, y, 18, 18)) tooltip.add(stack.getHoverName());
    }

    /** How the chosen dish is made, in the order of the clicks. */
    private List<Component> steps() {
        List<Component> out = new ArrayList<>();
        if (drinks) {
            out.add(Component.translatable("gui.aestheticjobs.book.drink.grind"));
            out.add(Component.translatable("gui.aestheticjobs.book.drink.brew" + (CupRecipe.shots(base) > 1 ? "_double" : "")));
            List<String> parts = new ArrayList<>();
            for (Pantry p : CupRecipe.parts(base)) parts.add(p.item());
            if (!parts.isEmpty()) out.add(Component.translatable("gui.aestheticjobs.book.drink.add", StationBlockEntity.list(parts)));
            out.add(Component.translatable("gui.aestheticjobs.book.drink.take"));
        } else {
            out.add(Component.translatable("gui.aestheticjobs.book.dessert.bowl"));
            out.add(Component.translatable("gui.aestheticjobs.book.dessert.whisk"));
            out.add(Component.translatable("gui.aestheticjobs.book.dessert.bake", Menu.get(base).ticks() / 20));
            out.add(Component.translatable("gui.aestheticjobs.book.dessert.decorate"));
        }
        return out;
    }

    private Signature signature() {
        for (Signature s : Signature.values()) {
            if (s.base() == base) return s;
        }
        return null;
    }

    private ResourceLocation icon(int b) {
        return b < Menu.DRINKS ? Drink.byIndex(b).iconTexture() : Dessert.byIndex(b - Menu.DRINKS).iconTexture();
    }

    @Override
    protected boolean click(int mx, int my, int button) {
        if (button != 0) return false;
        int ty = LEFT_Y - TAB_H - 3;
        for (int t = 0; t < 2; t++) {
            if (Ui.in(mx, my, LEFT_X + t * (TAB_W + 4), ty, TAB_W, TAB_H)) {
                drinks = t == 0;
                base = drinks ? lastDrink : lastDessert;
                sound(1.1F);
                return true;
            }
        }
        for (int i = 0; i < count(); i++) {
            if (Ui.in(mx, my, cellX(i), cellY(i), cellW(), cellH() - 2)) {
                base = first() + i;
                if (drinks) lastDrink = base;
                else lastDessert = base;
                sound(1.3F);
                return true;
            }
        }
        if (forBowl && !drinks && Ui.in(mx, my, buttonX(), BUTTON_Y, BUTTON_W, BUTTON_H)) {
            PacketDistributor.sendToServer(new ChooseRecipePayload(bowl, base));
            sound(1.0F);
            onClose();
            return true;
        }
        return false;
    }

    private void sound(float pitch) {
        Ui.sound(SoundEvents.BOOK_PAGE_TURN, pitch, 0.6F);
    }
}
