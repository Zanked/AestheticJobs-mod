package dev.aestheticjobs.client;

import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.kitchen.Menu;
import dev.aestheticjobs.network.InterviewStatePayload;
import java.util.List;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** The note in the corner while the trial task of an interview is waiting: what to bring and how long it is waited for. */
public final class TrialHud {
    private static final int W = 156;
    private static final long LASTS_MS = 20 * 60_000L;

    private static InterviewStatePayload task;
    private static long until;
    private static Object server;

    private TrialHud() {}

    /** Every state of the interview passes here. */
    public static void update(InterviewStatePayload payload) {
        if (payload.phase() == InterviewStatePayload.TRIAL) {
            if (task == null || !task.lineArgs().equals(payload.lineArgs())) until = System.currentTimeMillis() + LASTS_MS;
            task = payload;
            server = Minecraft.getInstance().getConnection();
        } else if (payload.phase() != InterviewStatePayload.CLOSE || !payload.lineKey().equals("keep")) {
            task = null;
        }
    }

    public static void render(GuiGraphics g, DeltaTracker delta) {
        if (task == null) return;
        Minecraft mc = Minecraft.getInstance();
        if (server != mc.getConnection() || System.currentTimeMillis() > until) {
            task = null;
            return;
        }
        if (mc.options.hideGui || mc.screen != null || mc.getDebugOverlay().showDebugScreen()) return;
        draw(g, mc.font, task.lineKey(), task.lineArgs(), Math.max(1, (until - System.currentTimeMillis() + 59_999L) / 60_000L));
    }

    static void draw(GuiGraphics g, Font font, String lineKey, List<String> args, long minutes) {
        Component what = what(lineKey, args);
        List<String> lines = Ui.lines(font, what, W - 36, 4);
        int body = Math.max(20, lines.size() * Ui.LINE);
        int h = 22 + body + 16;
        Ui.card(g, 4, 4, W, h);
        Ui.header(g, font, Component.translatable("interview.task.title"), 4, 4, W);
        int y = 26;
        icon(g, lineKey, args, 10, y);
        for (int i = 0; i < lines.size(); i++) g.drawString(font, lines.get(i), 32, y + i * Ui.LINE, Ui.INK, false);
        y += body + 3;
        Ui.paragraph(g, font, Component.translatable("interview.task.time", minutes), 10, y, W - 12, 1, Ui.LABEL);
    }

    /** What has to be brought, from the line of the trial. */
    static Component what(String lineKey, List<String> args) {
        if (lineKey.endsWith("office_manager")) return Component.translatable("interview.task.office_manager");
        if (lineKey.endsWith("shop_manager")) return Component.translatable("interview.task.shop_manager");
        Drink drink = drink(args);
        return Component.translatable("interview.task.cafe_manager",
                Component.translatable("drink.aestheticjobs." + (drink == null ? "latte" : Menu.get(drink.ordinal()).id())));
    }

    private static Drink drink(List<String> args) {
        String prefix = "t:drink.aestheticjobs.";
        if (args.isEmpty() || !args.get(0).startsWith(prefix)) return null;
        return Drink.byIndex(Menu.indexOf(args.get(0).substring(prefix.length())));
    }

    /** A 16 pixel picture of the thing. */
    static void icon(GuiGraphics g, String lineKey, List<String> args, int x, int y) {
        Drink drink = drink(args);
        if (drink != null) Ui.icon(g, drink.iconTexture(), x, y, 16);
        else if (lineKey.endsWith("office_manager")) g.renderItem(new ItemStack(Items.WRITABLE_BOOK), x, y);
        else g.renderItem(new ItemStack(Items.BREAD), x, y);
    }
}
