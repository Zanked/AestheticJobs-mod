package dev.aestheticjobs.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.cafe.anim.PersonRig;
import dev.aestheticjobs.cafe.anim.PoseInput;
import dev.aestheticjobs.cafe.anim.Poses;
import dev.aestheticjobs.cafe.anim.StaffAction;
import dev.aestheticjobs.entity.CafePerson;
import dev.aestheticjobs.entity.CafeCustomerEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

/**
 * A normal player body with slim (Alex) arms: 64x128 skin = the usual 64x64 player skin + the chef's toque below it.
 * Unlike the vanilla PlayerModel the arms have an ELBOW (the forearm is a child part), which the hand-to-mouth and
 * serving animations need. The second skin layer (sleeves, jacket, pants, hat) is part of the same ModelParts.
 * The poses come from the pure classes in cafe/anim (Poses); this class only copies them to the parts.
 */
public class CafePersonModel<T extends LivingEntity & CafePerson> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "cafe_person"), "main");
    public static final ModelLayerLocation CHEF_LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "cafe_person"), "chef");

    private final ModelPart root;
    public final ModelPart head, body, rightArm, leftArm, rightLeg, leftLeg, rightForearm, leftForearm;
    private final PersonRig rig = new PersonRig();
    private final PoseInput input = new PoseInput();

    public CafePersonModel(ModelPart root) {
        super(net.minecraft.client.renderer.RenderType::entityCutoutNoCull);
        this.root = root;
        this.head = root.getChild("head");
        this.body = root.getChild("body");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
        this.rightForearm = rightArm.getChild("forearm");
        this.leftForearm = leftArm.getChild("forearm");
    }

    public static LayerDefinition createLayer(boolean toque) {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        CubeDeformation sleeve = new CubeDeformation(0.25F);

        PartDefinition head = root.addOrReplaceChild("head",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F)
                        .texOffs(32, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.5F)),
                PartPose.ZERO);
        if (toque) {
            head.addOrReplaceChild("toque",
                    CubeListBuilder.create()
                            .texOffs(0, 80).addBox(-4.5F, -11.0F, -4.5F, 9.0F, 3.0F, 9.0F)
                            .texOffs(0, 64).addBox(-4.0F, -17.0F, -4.0F, 8.0F, 6.0F, 8.0F),
                    PartPose.ZERO);
        }
        root.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(16, 16).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F)
                        .texOffs(16, 32).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F, sleeve),
                PartPose.ZERO);

        // right arm: upper arm 6 px, then the elbow, then the forearm 6 px (the skin rows are split in two halves)
        PartDefinition ra = root.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(40, 16).addBox(-2.0F, -2.0F, -2.0F, 3.0F, 6.0F, 4.0F)
                        .texOffs(40, 32).addBox(-2.0F, -2.0F, -2.0F, 3.0F, 6.0F, 4.0F, sleeve),
                PartPose.offset(-5.0F, 2.0F, 0.0F));
        ra.addOrReplaceChild("forearm",
                CubeListBuilder.create().texOffs(40, 22).addBox(-2.0F, 0.0F, -2.0F, 3.0F, 6.0F, 4.0F)
                        .texOffs(40, 38).addBox(-2.0F, 0.0F, -2.0F, 3.0F, 6.0F, 4.0F, sleeve),
                PartPose.offset(0.0F, 4.0F, 0.0F));
        PartDefinition la = root.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(32, 48).addBox(-1.0F, -2.0F, -2.0F, 3.0F, 6.0F, 4.0F)
                        .texOffs(48, 48).addBox(-1.0F, -2.0F, -2.0F, 3.0F, 6.0F, 4.0F, sleeve),
                PartPose.offset(5.0F, 2.0F, 0.0F));
        la.addOrReplaceChild("forearm",
                CubeListBuilder.create().texOffs(32, 54).addBox(-1.0F, 0.0F, -2.0F, 3.0F, 6.0F, 4.0F)
                        .texOffs(48, 54).addBox(-1.0F, 0.0F, -2.0F, 3.0F, 6.0F, 4.0F, sleeve),
                PartPose.offset(0.0F, 4.0F, 0.0F));

        root.addOrReplaceChild("right_leg",
                CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F)
                        .texOffs(0, 32).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, sleeve),
                PartPose.offset(-1.9F, 12.0F, 0.0F));
        root.addOrReplaceChild("left_leg",
                CubeListBuilder.create().texOffs(16, 48).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F)
                        .texOffs(0, 48).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, sleeve),
                PartPose.offset(1.9F, 12.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 128);
    }

    @Override
    public void setupAnim(T e, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        PoseInput in = input;
        in.limbSwing = limbSwing;
        in.walk = Math.min(limbSwingAmount, 1.0F);
        in.headYaw = netHeadYaw;
        in.headPitch = headPitch;
        e.fillPose(in, ageInTicks);
        if (e instanceof CafeCustomerEntity) Poses.customer(rig, in);
        else Poses.staff(rig, in);
        apply(head, rig.head);
        apply(body, rig.body);
        apply(rightArm, rig.rightArm);
        apply(leftArm, rig.leftArm);
        apply(rightLeg, rig.rightLeg);
        apply(leftLeg, rig.leftLeg);
        rightForearm.xRot = -rig.rightArm.elbow;
        leftForearm.xRot = -rig.leftArm.elbow;
    }

    private static void apply(ModelPart part, PersonRig.Part p) {
        part.x = p.x;
        part.y = p.y;
        part.z = p.z;
        part.xRot = p.rx;
        part.yRot = p.ry;
        part.zRot = p.rz;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
        root.render(poseStack, buffer, packedLight, packedOverlay, color);
    }
}
