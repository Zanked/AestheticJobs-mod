package dev.aestheticjobs.economy;

import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.nbt.CompoundTag;

/** One line of an account history. Amount is signed: positive = money in, negative = money out. */
public record Transaction(long time, Type type, long amount, long balanceAfter, String reason, @Nullable UUID other) {

    public enum Type { DEPOSIT, WITHDRAW, TRANSFER_IN, TRANSFER_OUT, ADMIN_GIVE, ADMIN_TAKE, WAGE, PURCHASE, FINE, REFUND }

    public CompoundTag toTag() {
        CompoundTag tag = new CompoundTag();
        tag.putLong("time", time);
        tag.putString("type", type.name());
        tag.putLong("amount", amount);
        tag.putLong("balanceAfter", balanceAfter);
        tag.putString("reason", reason);
        if (other != null) tag.putUUID("other", other);
        return tag;
    }

    public static Transaction fromTag(CompoundTag tag) {
        Type type;
        try {
            type = Type.valueOf(tag.getString("type"));
        } catch (IllegalArgumentException e) {
            type = Type.DEPOSIT;
        }
        return new Transaction(tag.getLong("time"), type, tag.getLong("amount"), tag.getLong("balanceAfter"),
                tag.getString("reason"), tag.hasUUID("other") ? tag.getUUID("other") : null);
    }
}
