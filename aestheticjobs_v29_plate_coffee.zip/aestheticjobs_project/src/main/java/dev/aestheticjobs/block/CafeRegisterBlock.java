package dev.aestheticjobs.block;

import com.mojang.serialization.MapCodec;
import dev.aestheticjobs.cafe.CafeCareer;
import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.CafeRegisters;
import dev.aestheticjobs.cafe.CupData;
import dev.aestheticjobs.entity.CafeCustomerEntity;
import dev.aestheticjobs.registry.ModComponents;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * The cafe till. Empty hand: a barista at work takes the order of the customer who waits at the counter (customers come by themselves) or a paid order of a player;
 * everybody else opens the menu and orders for himself (paid from the bank account).
 * Cup in hand: serve the order. Pay = commission + tips (quality of the cup and how fast you were).
 * All the logic lives in {@link CafeLogic}.
 */
public class CafeRegisterBlock extends HorizontalDirectionalBlock {
    public static final MapCodec<CafeRegisterBlock> CODEC = simpleCodec(CafeRegisterBlock::new);

    private static final VoxelShape NORTH = Block.box(1, 0, 2, 15, 16, 14);
    private static final VoxelShape SOUTH = Block.box(1, 0, 2, 15, 16, 14);
    private static final VoxelShape EAST = Block.box(2, 0, 1, 14, 16, 15);
    private static final VoxelShape WEST = Block.box(2, 0, 1, 14, 16, 15);

    public CafeRegisterBlock(BlockBehaviour.Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(CafeStyle.PROPERTY, CafeStyle.CREAM));
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, CafeStyle.PROPERTY);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return switch (state.getValue(FACING)) {
            case SOUTH -> SOUTH;
            case EAST -> EAST;
            case WEST -> WEST;
            default -> NORTH;
        };
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }

    @Override
    protected BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }

    private static String dimKey(ServerLevel level) {
        return level.dimension().location().toString();
    }

    @Override
    protected void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
        super.onPlace(state, level, pos, oldState, movedByPiston);
        if (!level.isClientSide && level instanceof ServerLevel sl && !oldState.is(this)) {
            CafeRegisters.get(sl.getServer()).add(dimKey(sl), pos.asLong());          // customers will come to it by themselves
        }
    }

    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!level.isClientSide && level instanceof ServerLevel sl && !state.is(newState.getBlock())) {
            CafeRegisters.get(sl.getServer()).remove(dimKey(sl), pos.asLong());
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        CupData cup = stack.get(ModComponents.CUP.get());
        if (cup == null) {
            return CafePaint.use(stack, state, level, pos, player);
        }
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            ServerLevel sl = (ServerLevel) level;
            CafeRegisters.get(sp.server).add(dimKey(sl), pos.asLong());                // a register placed before the list existed
            // the barista's own customer, if one is waiting near the register, takes the cup
            CafeCustomerEntity npc = CafeCustomerEntity.findWaitingFor(sl, Vec3.atCenterOf(pos), sp.getUUID(), 12.0D);
            CafeLogic.serve(sp, sl, pos, stack, cup, npc);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            CafeRegisters.get(sp.server).add(dimKey((ServerLevel) level), pos.asLong());     // a register placed before the list existed
            if (sp.isShiftKeyDown()) {
                CafeCareer.openJournal(sp, pos);                                                           // the journal of the barista
            } else if (CafeLogic.isWorking(sp)) {
                CafeLogic.issueOrder(sp, (ServerLevel) level, pos, pos, state.getValue(FACING), null);     // a barista takes an order
            } else {
                CafeLogic.openOrderMenu(sp, (ServerLevel) level, pos);                                     // everybody else orders
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
