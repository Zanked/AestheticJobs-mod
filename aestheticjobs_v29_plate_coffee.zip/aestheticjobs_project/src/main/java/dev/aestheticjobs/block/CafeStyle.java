package dev.aestheticjobs.block;

import java.util.Locale;
import javax.annotation.Nullable;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.state.properties.EnumProperty;

/** The paint of the coffee machine and the register. Right-click with a dye to repaint them. */
public enum CafeStyle implements StringRepresentable {
    CREAM, MINT, ROSE, NOIR, CHERRY;

    public static final EnumProperty<CafeStyle> PROPERTY = EnumProperty.create("style", CafeStyle.class);

    @Override
    public String getSerializedName() {
        return name().toLowerCase(Locale.ROOT);
    }

    /** The paint a dye gives, null if this dye has none. */
    @Nullable
    public static CafeStyle ofDye(DyeColor dye) {
        return switch (dye) {
            case WHITE, YELLOW -> CREAM;
            case LIME, GREEN, CYAN, LIGHT_BLUE -> MINT;
            case PINK, MAGENTA -> ROSE;
            case BLACK, GRAY -> NOIR;
            case RED -> CHERRY;
            default -> null;
        };
    }
}
