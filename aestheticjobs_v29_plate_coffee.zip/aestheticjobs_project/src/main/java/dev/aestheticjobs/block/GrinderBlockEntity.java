package dev.aestheticjobs.block;

import dev.aestheticjobs.cafe.kitchen.GrinderState;
import dev.aestheticjobs.item.PortafilterItem;
import dev.aestheticjobs.registry.ModBlockEntities;
import dev.aestheticjobs.registry.ModItems;
import dev.aestheticjobs.registry.ModSounds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;

/** The hand grinder: beans in, three turns of the crank, the ground coffee goes into the portafilter. */
public class GrinderBlockEntity extends StationBlockEntity {
    private final GrinderState grinder = new GrinderState();

    public GrinderBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.GRINDER.get(), pos, state);
    }

    public GrinderState grinder() {
        return grinder;
    }

    @Override
    public boolean accepts(ItemStack stack) {
        return stack.is(ModItems.COFFEE_BEANS.get()) || stack.is(ModItems.PORTAFILTER.get());
    }

    @Override
    protected boolean useItem(ServerPlayer player, ItemStack held) {
        if (held.is(ModItems.COFFEE_BEANS.get())) {
            if (!grinder.addBean()) return tell(player, "station.aestheticjobs.grinder.full");
            spend(player, held);
            sound(SoundEvents.GRAVEL_PLACE, 0.5F, 1.7F);
            return true;
        }
        if (PortafilterItem.filled(held)) return tell(player, "station.aestheticjobs.grinder.filter_full");
        if (!grinder.takeGround()) return tell(player, "station.aestheticjobs.grinder.nothing_ground");
        PortafilterItem.fill(held, true);
        sound(SoundEvents.SAND_PLACE, 0.8F, 1.2F);
        return true;
    }

    @Override
    protected boolean useHand(ServerPlayer player, boolean sneaking) {
        int before = grinder.ground();
        if (!grinder.turn()) {
            return tell(player, grinder.ground() > 0 ? "station.aestheticjobs.grinder.next.take" : "station.aestheticjobs.grinder.next.beans");
        }
        sound(ModSounds.BARISTA_GRIND.get(), 0.5F, 1.0F + 0.1F * grinder.turns());
        if (grinder.ground() > before) {
            sound(SoundEvents.AMETHYST_BLOCK_CHIME, 0.8F, 1.7F);
            puff(ParticleTypes.WAX_ON, 5, 0.9);
        }
        return true;
    }

    @Override
    public List<Component> guide(Player player) {
        List<Component> out = new ArrayList<>();
        out.add(getBlockState().getBlock().getName());
        out.add(Component.translatable("station.aestheticjobs.grinder.state", grinder.beans(), grinder.ground()));
        String next = grinder.ground() > 0 ? "take" : grinder.beans() > 0 ? "turn" : "beans";
        out.add(next.equals("turn")
                ? Component.translatable("station.aestheticjobs.grinder.next.turn", grinder.turns(), GrinderState.TURNS)
                : Component.translatable("station.aestheticjobs.grinder.next." + next));
        return out;
    }

    @Override
    protected List<ItemStack> contents(ServerLevel level) {
        int n = grinder.beans() + grinder.ground();
        return n == 0 ? List.of() : List.of(new ItemStack(ModItems.COFFEE_BEANS.get(), n));
    }

    @Override
    protected void clearContents() {
        grinder.clear();
    }

    @Override
    protected long[] data() {
        return grinder.save();
    }

    @Override
    protected void data(long[] in) {
        grinder.load(in);
    }
}
