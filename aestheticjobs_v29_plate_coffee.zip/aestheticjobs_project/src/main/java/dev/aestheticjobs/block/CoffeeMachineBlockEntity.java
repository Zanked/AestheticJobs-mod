package dev.aestheticjobs.block;

import dev.aestheticjobs.cafe.CupData;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.Order;
import dev.aestheticjobs.cafe.kitchen.BrewState;
import dev.aestheticjobs.cafe.kitchen.Cooking;
import dev.aestheticjobs.cafe.kitchen.CupRecipe;
import dev.aestheticjobs.cafe.kitchen.LatteArt;
import dev.aestheticjobs.cafe.kitchen.Pantry;
import dev.aestheticjobs.item.PortafilterItem;
import dev.aestheticjobs.registry.ModBlockEntities;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.registry.ModItems;
import dev.aestheticjobs.registry.ModSounds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** The espresso machine: cup, ground coffee, lever, then milk and additions straight into the cup. */
public class CoffeeMachineBlockEntity extends StationBlockEntity {
    private final BrewState brew = new BrewState();
    private boolean chime;

    public CoffeeMachineBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.COFFEE_MACHINE.get(), pos, state);
    }

    public BrewState brew() {
        return brew;
    }

    @Override
    public boolean accepts(ItemStack stack) {
        return stack.is(ModItems.EMPTY_CUP.get()) || stack.is(ModItems.PORTAFILTER.get()) || Pantry.byItem(id(stack)) != null;
    }

    @Override
    protected boolean useItem(ServerPlayer player, ItemStack held) {
        long now = player.level().getGameTime();
        if (held.is(ModItems.EMPTY_CUP.get())) {
            if (!brew.putCup()) return tell(player, "station.aestheticjobs.machine.has_cup");
            spend(player, held);
            sound(SoundEvents.DECORATED_POT_PLACE, 0.8F, 1.4F);
            return true;
        }
        if (held.is(ModItems.PORTAFILTER.get())) {
            if (!PortafilterItem.filled(held)) return tell(player, "station.aestheticjobs.machine.empty_filter");
            if (!brew.putGrounds(now)) return tell(player, "station.aestheticjobs.machine.group_busy");
            PortafilterItem.fill(held, false);
            sound(SoundEvents.IRON_TRAPDOOR_CLOSE, 0.6F, 1.6F);
            return true;
        }
        Pantry p = Pantry.byItem(id(held));
        if (p == null) return false;
        if (!brew.cup()) return tell(player, "station.aestheticjobs.machine.need_cup");
        if (brew.shots() == 0) return tell(player, "station.aestheticjobs.machine.coffee_first");
        if (brew.pulling(now)) return tell(player, "station.aestheticjobs.machine.wait");
        if (!brew.pour(p, now)) return tell(player, "station.aestheticjobs.machine.no_match", held.getHoverName());
        if (p == Pantry.WATER) {                                              // hot water: the bucket is only the can
            sound(SoundEvents.BUCKET_EMPTY, 0.6F, 1.5F);
        } else {
            sound(p == Pantry.MILK || p == Pantry.CREAM ? ModSounds.BARISTA_STEAM.get() : ModSounds.BARISTA_POUR.get(), 0.7F, 1.0F);
            spendFood(player, held);
        }
        puff(ParticleTypes.CLOUD, 5, 0.6);
        return true;
    }

    @Override
    protected boolean useHand(ServerPlayer player, boolean sneaking) {
        long now = player.level().getGameTime();
        if (brew.pulling(now)) return tell(player, "station.aestheticjobs.machine.wait");
        if (sneaking) {
            if (brew.count(Pantry.MILK) + brew.count(Pantry.CREAM) > 0) {
                brew.nextArt();
                sound(SoundEvents.BUCKET_EMPTY, 0.3F, 1.9F);
                tell(player, "station.aestheticjobs.machine.art", Component.translatable("art.aestheticjobs." + LatteArt.STYLES[brew.art()]));
                return true;
            }
            if (brew.cup() && brew.shots() == 0) {
                brew.takeCup();
                if (!player.getAbilities().instabuild) give(player, new ItemStack(ModItems.EMPTY_CUP.get()));
                return true;
            }
        }
        if (brew.cup() && brew.grounds()) {
            brew.pull(now);
            chime = true;
            sound(ModSounds.BARISTA_PUMP.get(), 0.9F, 1.0F);
            return true;
        }
        CupRecipe.Result drink = brew.drink();
        if (brew.cup() && drink != null) {
            int quality = Cooking.quality(drink.drink(), drink.mask());
            ItemStack cup = cup(drink);
            brew.takeCup();                                                    // first empty the machine: never twice
            give(player, cup);
            finished(player, drink.drink(), drink.mask(), quality);
            return true;
        }
        if (!brew.cup()) return tell(player, "station.aestheticjobs.machine.need_cup");
        return tell(player, brew.shots() == 0 ? "station.aestheticjobs.machine.need_coffee" : "station.aestheticjobs.machine.next.milk");
    }

    private ItemStack cup(CupRecipe.Result result) {
        Drink drink = Drink.byIndex(result.drink());
        ItemStack cup = new ItemStack(ModItems.COFFEE_CUP.get());
        String art = LatteArt.picture(result.drink(), result.mask(), brew.art());
        cup.set(ModComponents.CUP.get(), new CupData(art, drink.ordinal(), Cooking.quality(result.drink(), result.mask()), result.mask()));
        cup.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(drink.modelData()));
        return cup;
    }

    @Override
    public List<Component> guide(Player player) {
        long now = player.level().getGameTime();
        List<Component> out = new ArrayList<>();
        out.add(getBlockState().getBlock().getName());
        CupRecipe.Result drink = brew.drink();
        if (drink != null) {
            out.add(Component.translatable("station.aestheticjobs.machine.in_cup", recipeName(drink.drink(), drink.mask())));
        }
        Order order = order(player);
        if (order != null) {
            List<String> parts = new ArrayList<>();
            for (Pantry p : CupRecipe.parts(order.drink())) parts.add(p.item());
            Component name = recipeName(order.drink(), 0);
            String key = "station.aestheticjobs.order." + (CupRecipe.shots(order.drink()) > 1 ? "double" : "single");
            out.add(parts.isEmpty() ? Component.translatable(key, name) : Component.translatable(key + "_with", name, list(parts)));
        }
        String next;
        if (brew.pulling(now)) next = "station.aestheticjobs.machine.next.pulling";
        else if (!brew.cup()) next = "station.aestheticjobs.machine.next.cup";
        else if (brew.grounds()) next = "station.aestheticjobs.machine.next.lever";
        else if (brew.shots() == 0) next = "station.aestheticjobs.machine.next.filter";
        else if (drink == null) next = "station.aestheticjobs.machine.next.milk";
        else if (brew.count(Pantry.MILK) + brew.count(Pantry.CREAM) > 0) next = "station.aestheticjobs.machine.next.take_art";
        else next = "station.aestheticjobs.machine.next.take";
        out.add(Component.translatable(next));
        return out;
    }

    /** What the carried order still needs. */
    @Override
    public List<ItemStack> guideItems(Player player) {
        List<ItemStack> out = new ArrayList<>();
        Order order = order(player);
        if (order == null) return out;
        if (!brew.cup()) out.add(new ItemStack(ModItems.EMPTY_CUP.get()));
        if (brew.shots() + (brew.grounds() ? 1 : 0) < CupRecipe.shots(order.drink())) out.add(new ItemStack(ModItems.PORTAFILTER.get()));
        int[] have = new int[Pantry.values().length];
        for (Pantry p : CupRecipe.parts(order.drink())) {
            if (++have[p.ordinal()] > brew.count(p)) out.add(new ItemStack(item(p.item())));
        }
        return out;
    }

    @Override
    protected List<ItemStack> contents(ServerLevel level) {
        List<ItemStack> out = new ArrayList<>();
        CupRecipe.Result drink = brew.drink();
        if (drink != null) out.add(cup(drink));
        else if (brew.cup()) out.add(new ItemStack(ModItems.EMPTY_CUP.get()));
        if (brew.grounds()) out.add(new ItemStack(ModItems.COFFEE_BEANS.get()));   // ground coffee turns back into a bean
        return out;
    }

    @Override
    protected void clearContents() {
        brew.clear();
    }

    @Override
    protected long[] data() {
        return brew.save();
    }

    @Override
    protected void data(long[] in) {
        brew.load(in);
    }

    /** BREWING switches to the model without the built-in cup: the renderer draws the live one. */
    @Override
    protected BlockState shown(BlockState state) {
        boolean busy = !brew.empty();
        if (!state.hasProperty(CoffeeMachineBlock.BREWING) || state.getValue(CoffeeMachineBlock.BREWING) == busy) return state;
        return state.setValue(CoffeeMachineBlock.BREWING, busy);
    }

    @Override
    protected void tick(long now) {
        if (chime && now >= brew.shotEnd()) {
            chime = false;
            sound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F, 1.5F);
        }
    }

    /** Steam from the cup, only while there is coffee in it. */
    public static void clientTick(Level level, BlockPos pos, BlockState state, CoffeeMachineBlockEntity be) {
        if (be.brew.shots() == 0 || level.random.nextInt(5) != 0) return;
        Direction f = state.getValue(CoffeeMachineBlock.FACING);
        double out = 0.32;                                                     // the cup stands in front of the middle
        level.addParticle(ParticleTypes.CLOUD, pos.getX() + 0.5 + f.getStepX() * out, pos.getY() + 0.27,
                pos.getZ() + 0.5 + f.getStepZ() * out, 0.0, 0.012, 0.0);
    }
}
