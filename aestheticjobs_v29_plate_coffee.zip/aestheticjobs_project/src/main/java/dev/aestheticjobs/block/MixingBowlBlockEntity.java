package dev.aestheticjobs.block;

import dev.aestheticjobs.cafe.Order;
import dev.aestheticjobs.cafe.kitchen.BowlState;
import dev.aestheticjobs.cafe.kitchen.Menu;
import dev.aestheticjobs.item.DoughItem;
import dev.aestheticjobs.item.RecipeBookItem;
import dev.aestheticjobs.registry.ModBlockEntities;
import dev.aestheticjobs.registry.ModItems;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;

/** The mixing bowl: pick a dessert in the recipe book, put the ingredients in, whisk, take the dough. */
public class MixingBowlBlockEntity extends StationBlockEntity {
    /** Every item some dessert is made of. */
    private static final List<String> INGREDIENTS = ingredients();

    private final BowlState bowl = new BowlState();

    public MixingBowlBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.MIXING_BOWL.get(), pos, state);
    }

    private static List<String> ingredients() {
        List<String> out = new ArrayList<>();
        for (int b = Menu.DRINKS; b < Menu.size(); b++) {
            for (String id : Menu.get(b).ingredients()) if (!out.contains(id)) out.add(id);
        }
        return out;
    }

    public BowlState bowl() {
        return bowl;
    }

    /** From the recipe book (network/ModNetwork checks the distance). */
    public void choose(ServerPlayer player, int base) {
        if (!bowl.choose(base)) {
            tell(player, "station.aestheticjobs.bowl.not_empty");
            return;
        }
        sound(SoundEvents.BOOK_PAGE_TURN, 0.8F, 1.0F);
        changed();
    }

    @Override
    public boolean accepts(ItemStack stack) {
        return stack.is(ModItems.WHISK.get()) || INGREDIENTS.contains(id(stack));
    }

    @Override
    protected boolean useItem(ServerPlayer player, ItemStack held) {
        if (bowl.recipe() < 0) return tell(player, "station.aestheticjobs.bowl.next.choose");
        if (held.is(ModItems.WHISK.get())) {
            if (!bowl.full()) return tell(player, "station.aestheticjobs.bowl.not_full");
            if (!bowl.whisk()) return tell(player, "station.aestheticjobs.bowl.next.take");
            sound(SoundEvents.HONEY_BLOCK_STEP, 0.8F, 1.2F + 0.1F * bowl.whisks());
            puff(ParticleTypes.POOF, 2, 0.9);
            if (bowl.mixed()) sound(SoundEvents.AMETHYST_BLOCK_CHIME, 0.8F, 1.6F);
            return true;
        }
        if (!bowl.add(id(held))) return tell(player, "station.aestheticjobs.bowl.not_needed", held.getHoverName());
        spend(player, held);
        sound(SoundEvents.SAND_PLACE, 0.6F, 1.5F);
        return true;
    }

    @Override
    protected boolean useHand(ServerPlayer player, boolean sneaking) {
        if (sneaking && !bowl.empty() && !bowl.mixed()) {                      // a mistake: take everything back
            if (!player.getAbilities().instabuild) {
                for (String id : bowl.inside()) give(player, new ItemStack(item(id)));
            }
            bowl.pourOut();
            sound(SoundEvents.ITEM_PICKUP, 0.6F, 1.0F);
            return true;
        }
        if (bowl.empty()) {
            RecipeBookItem.open(player, worldPosition);
            return true;
        }
        if (bowl.mixed()) {
            ItemStack dough = DoughItem.of(bowl.recipe());
            bowl.pourOut();
            give(player, dough);
            sound(SoundEvents.ITEM_PICKUP, 0.7F, 0.8F);
            return true;
        }
        return tell(player, bowl.full() ? "station.aestheticjobs.bowl.next.whisk_short" : "station.aestheticjobs.bowl.not_full");
    }

    @Override
    public List<Component> guide(Player player) {
        List<Component> out = new ArrayList<>();
        out.add(getBlockState().getBlock().getName());
        Order order = order(player);
        if (order != null && order.dessert() >= 0) {
            out.add(Component.translatable("station.aestheticjobs.order.dessert", recipeName(Menu.dessertIndex(order.dessert()), 0)));
        }
        if (bowl.recipe() < 0) {
            out.add(Component.translatable("station.aestheticjobs.bowl.next.choose"));
            return out;
        }
        out.add(Component.translatable("station.aestheticjobs.bowl.recipe", recipeName(bowl.recipe(), 0)));
        if (bowl.mixed()) out.add(Component.translatable("station.aestheticjobs.bowl.next.take"));
        else if (bowl.full()) out.add(Component.translatable("station.aestheticjobs.bowl.next.whisk", bowl.whisks(), BowlState.WHISKS));
        else {
            out.add(Component.translatable("station.aestheticjobs.bowl.next.add", list(bowl.missing())));
            if (bowl.empty()) out.add(Component.translatable("station.aestheticjobs.bowl.next.change"));
        }
        return out;
    }

    @Override
    public List<ItemStack> guideItems(Player player) {
        List<ItemStack> out = new ArrayList<>();
        if (bowl.recipe() < 0) return out;
        if (bowl.full()) {
            if (!bowl.mixed()) out.add(new ItemStack(ModItems.WHISK.get()));
        } else {
            for (String id : bowl.missing()) out.add(new ItemStack(item(id)));
        }
        return out;
    }

    @Override
    protected List<ItemStack> contents(ServerLevel level) {
        List<ItemStack> out = new ArrayList<>();
        if (bowl.mixed()) out.add(DoughItem.of(bowl.recipe()));
        else for (String id : bowl.inside()) out.add(new ItemStack(item(id)));
        return out;
    }

    @Override
    protected void clearContents() {
        bowl.pourOut();
    }

    @Override
    protected long[] data() {
        return bowl.save();
    }

    @Override
    protected void data(long[] in) {
        bowl.load(in);
    }
}
