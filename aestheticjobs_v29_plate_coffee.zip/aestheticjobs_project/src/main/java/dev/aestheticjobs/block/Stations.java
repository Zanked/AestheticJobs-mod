package dev.aestheticjobs.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** The clicks and the removal that every station block shares. */
public final class Stations {
    private Stations() {}

    /** An item that belongs to the station is used on it; every other item behaves as everywhere else. */
    public static ItemInteractionResult useItemOn(ItemStack stack, Level level, BlockPos pos, Player player, InteractionHand hand) {
        if (!(level.getBlockEntity(pos) instanceof StationBlockEntity station)) {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (hand == InteractionHand.MAIN_HAND && stack.isEmpty()) return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        if (stack.isEmpty() || !station.accepts(stack)) return ItemInteractionResult.SKIP_DEFAULT_BLOCK_INTERACTION;
        if (player instanceof ServerPlayer server) station.interact(server, stack, false);
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    public static InteractionResult useHand(Level level, BlockPos pos, Player player) {
        if (player instanceof ServerPlayer server && level.getBlockEntity(pos) instanceof StationBlockEntity station) {
            station.interact(server, ItemStack.EMPTY, true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /** A broken station gives back what is in it. */
    public static void removed(BlockState state, Level level, BlockPos pos, BlockState newState) {
        if (!state.is(newState.getBlock()) && !level.isClientSide && level.getBlockEntity(pos) instanceof StationBlockEntity station) {
            station.dropContents();
        }
    }
}
