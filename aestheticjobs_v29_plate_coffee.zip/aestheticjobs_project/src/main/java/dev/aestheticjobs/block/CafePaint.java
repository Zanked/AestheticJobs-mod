package dev.aestheticjobs.block;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** Repainting a block with a dye (see CafeStyle). */
final class CafePaint {
    private CafePaint() {}

    /** Handles a dye in the hand; any other item is passed on to the block. */
    static ItemInteractionResult use(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player) {
        if (!(stack.getItem() instanceof DyeItem dye)) return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        CafeStyle style = CafeStyle.ofDye(dye.getDyeColor());
        if (style == null || state.getValue(CafeStyle.PROPERTY) == style) {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        if (!level.isClientSide) {
            level.setBlock(pos, state.setValue(CafeStyle.PROPERTY, style), 3);
            level.playSound(null, pos, SoundEvents.DYE_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
            if (!player.getAbilities().instabuild) stack.shrink(1);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }
}
