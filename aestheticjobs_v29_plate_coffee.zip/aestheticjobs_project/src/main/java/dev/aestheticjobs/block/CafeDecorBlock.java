package dev.aestheticjobs.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** A decoration of the cafe. Different kinds near the register make the place cosy: better tips (see CafeCareer). */
public class CafeDecorBlock extends HorizontalDirectionalBlock {
    /** The shape is given for a block that faces north: x0, y0, z0, x1, y1, z1. */
    public enum Kind {
        PENDANT_LAMP(3, 3, 3, 13, 16, 13),
        PLANTER(2, 0, 5, 14, 15, 11),
        MENU_BOARD(1, 1, 14, 15, 15, 16),
        TIP_JAR(5, 0, 5, 11, 10, 11),
        COFFEE_GRINDER(4, 0, 4, 12, 15, 12),
        CAKE_STAND(2, 0, 2, 14, 13, 14),
        MIXING_BOWL(2, 0, 2, 14, 8, 14),
        CUP_STACK(2, 0, 4, 14, 10, 12),
        BEAN_SACK(3, 0, 3, 13, 12, 13),
        // the table setting
        FRUIT_BASKET(2, 0, 2, 14, 10, 14),
        GREENS_BASKET(2, 0, 2, 14, 13, 14),
        PLATE_STACK(3, 0, 3, 13, 5, 13),
        DRINK_BOTTLES(2, 0, 2, 14, 14, 13),
        TABLE_GLASSES(2, 0, 4, 14, 9, 12),
        PLACE_SETTING(1, 0, 1, 15, 2, 15),
        PIZZA_PLATE(0, 0, 0, 16, 2, 16),
        ROAST_PLATTER(0, 0, 0, 16, 6, 16),
        SUSHI_BOARD(1, 0, 3, 15, 6, 13);

        private final VoxelShape[] shapes = new VoxelShape[4];

        Kind(double x0, double y0, double z0, double x1, double y1, double z1) {
            shapes[Direction.NORTH.get2DDataValue()] = Block.box(x0, y0, z0, x1, y1, z1);
            shapes[Direction.SOUTH.get2DDataValue()] = Block.box(16 - x1, y0, 16 - z1, 16 - x0, y1, 16 - z0);
            shapes[Direction.EAST.get2DDataValue()] = Block.box(16 - z1, y0, x0, 16 - z0, y1, x1);
            shapes[Direction.WEST.get2DDataValue()] = Block.box(z0, y0, 16 - x1, z1, y1, 16 - x0);
        }
    }

    private final Kind kind;

    public CafeDecorBlock(Kind kind, BlockBehaviour.Properties properties) {
        super(properties);
        this.kind = kind;
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    public Kind kind() {
        return kind;
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
        return simpleCodec(p -> new CafeDecorBlock(kind, p));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return kind.shapes[state.getValue(FACING).get2DDataValue()];
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }

    @Override
    protected BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }
}
