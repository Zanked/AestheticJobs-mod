package dev.aestheticjobs.block;

import dev.aestheticjobs.cafe.CafeFraud;
import dev.aestheticjobs.cafe.CafeTreat;
import dev.aestheticjobs.cafe.anim.PlateMotion;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * The dessert on a plate: the item itself (with everything it remembers: buyer, masterpiece), how many bites are gone
 * and when the last one was taken. Everything is decided on the server; client/PlateRenderer draws it.
 */
public class PlateBlockEntity extends BlockEntity {
    private ItemStack food = ItemStack.EMPTY;
    private int bites;
    /** The dessert of the last bite (kept after the plate is empty: its last piece is still on the way to the mouth). */
    private ItemStack piece = ItemStack.EMPTY;
    private long bittenAt = -1000, readyAt;
    private int eater = -1;

    public PlateBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.PLATE.get(), pos, state);
    }

    public ItemStack food() {
        return food;
    }

    public ItemStack piece() {
        return piece;
    }

    public int bites() {
        return bites;
    }

    public long bittenAt() {
        return bittenAt;
    }

    public int eater() {
        return eater;
    }

    public boolean isEmpty() {
        return food.isEmpty();
    }

    /** Whether the next click counts (the same on both sides). */
    public boolean ready() {
        if (level == null) return false;
        long now = level.getGameTime();
        return now >= readyAt || readyAt - now > PlateMotion.BITE_TICKS;       // the second part: the world time was set back
    }

    // ------------------------------------------------------------------ server

    public void put(Player player, ItemStack held) {
        if (level == null || !food.isEmpty() || held.isEmpty() || player.isSpectator()
                || Dessert.ofItem(held.getItem()) == null) return;
        food = held.copyWithCount(1);
        if (!player.getAbilities().instabuild) held.shrink(1);
        bites = 0;
        bittenAt = -1000;
        eater = -1;
        piece = ItemStack.EMPTY;
        readyAt = level.getGameTime() + PlateMotion.PUT_TICKS;
        level.playSound(null, worldPosition, SoundEvents.ITEM_FRAME_ADD_ITEM, SoundSource.BLOCKS, 0.8F, 1.3F);
        changed();
    }

    public void takeBack(Player player) {
        if (level == null || food.isEmpty() || player.isSpectator()) return;
        if (bites > 0) {
            player.displayClientMessage(Component.translatable("plate.aestheticjobs.bitten"), true);
            return;
        }
        ItemStack out = food;
        food = ItemStack.EMPTY;                                                // first free the plate: never twice
        readyAt = level.getGameTime() + PlateMotion.PUT_TICKS;
        changed();
        player.getInventory().placeItemBackInInventory(out);
        level.playSound(null, worldPosition, SoundEvents.ITEM_FRAME_REMOVE_ITEM, SoundSource.BLOCKS, 0.8F, 1.3F);
    }

    public void bite(Player player) {
        if (!(level instanceof ServerLevel sl) || !(player instanceof ServerPlayer server) || food.isEmpty()
                || player.isSpectator()) return;
        Dessert dessert = Dessert.ofItem(food.getItem());
        if (dessert == null) return;
        long now = sl.getGameTime();
        ItemStack eaten = food.copy();
        piece = eaten;
        bittenAt = now;
        readyAt = now + PlateMotion.BITE_TICKS;
        eater = player.getId();
        bites++;
        boolean last = bites >= PlateMotion.BITES;
        if (last) food = ItemStack.EMPTY;                                      // first free the plate: never twice
        changed();
        crumbs(sl, eaten, worldPosition.getX() + 0.5, worldPosition.getY() + 0.3, worldPosition.getZ() + 0.5, 5);
        sl.playSound(null, worldPosition, SoundEvents.WOOL_HIT, SoundSource.BLOCKS, 0.5F, 1.5F);
        sl.scheduleTick(worldPosition, getBlockState().getBlock(), PlateMotion.ARRIVE);
        if (last) {
            server.getFoodData().eat(dessert.food());
            sl.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.PLAYER_BURP, SoundSource.PLAYERS,
                    0.5F, 0.9F + sl.random.nextFloat() * 0.1F);
            CafeFraud.consumed(server, eaten);
            CafeTreat.enjoy(server, eaten);
        }
    }

    /** The fork arrived: chewing and crumbs at the mouth of the eater. */
    void chew() {
        if (!(level instanceof ServerLevel sl) || piece.isEmpty()) return;
        Entity who = sl.getEntity(eater);
        if (who == null || who.distanceToSqr(Vec3.atCenterOf(worldPosition)) > 64.0) return;
        Vec3 mouth = who.getEyePosition().add(who.getLookAngle().scale(0.35)).add(0.0, -0.2, 0.0);
        crumbs(sl, piece, mouth.x, mouth.y, mouth.z, 4);
        sl.playSound(null, mouth.x, mouth.y, mouth.z, piece.getEatingSound(), SoundSource.PLAYERS,
                0.7F, 0.9F + sl.random.nextFloat() * 0.25F);
    }

    private static void crumbs(ServerLevel level, ItemStack of, double x, double y, double z, int count) {
        level.sendParticles(new ItemParticleOption(ParticleTypes.ITEM, of), x, y, z, count, 0.08, 0.05, 0.08, 0.04);
    }

    /** A broken plate gives an untouched dessert back; a bitten one is lost. */
    void drop() {
        if (level != null && !food.isEmpty() && bites == 0) Block.popResource(level, worldPosition, food);
        food = ItemStack.EMPTY;
    }

    private void changed() {
        if (level == null) return;
        setChanged();
        BlockState state = getBlockState();
        BlockState next = state.setValue(PlateBlock.FULL, !food.isEmpty());
        if (next != state) level.setBlock(worldPosition, next, Block.UPDATE_ALL);
        level.sendBlockUpdated(worldPosition, next, next, Block.UPDATE_CLIENTS);
    }

    // ------------------------------------------------------------------ saving and syncing

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        if (!food.isEmpty()) tag.put("food", food.save(registries));
        if (!piece.isEmpty()) tag.put("piece", piece.save(registries));
        tag.putInt("bites", bites);                                            // always written: the update is never empty
        tag.putLong("bittenAt", bittenAt);
        tag.putLong("readyAt", readyAt);
        tag.putInt("eater", eater);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        food = ItemStack.parseOptional(registries, tag.getCompound("food"));
        piece = ItemStack.parseOptional(registries, tag.getCompound("piece"));
        bites = tag.getInt("bites");
        bittenAt = tag.contains("bittenAt") ? tag.getLong("bittenAt") : -1000;
        readyAt = tag.getLong("readyAt");
        eater = tag.contains("eater") ? tag.getInt("eater") : -1;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
