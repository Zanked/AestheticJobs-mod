package dev.aestheticjobs.block;

import com.mojang.serialization.MapCodec;
import dev.aestheticjobs.item.Dessert;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * A plate to eat from. Right click with a dessert puts one on it; every right click with the empty hand takes a bite
 * (see {@link PlateBlockEntity}); sneaking with the empty hand takes an untouched dessert back. Breaking it drops the
 * plate and an untouched dessert.
 */
public class PlateBlock extends HorizontalDirectionalBlock implements EntityBlock {
    /** Whether a dessert is on the plate (only for the outline, which grows with it). */
    public static final BooleanProperty FULL = BooleanProperty.create("full");
    private static final VoxelShape PLATE = Block.box(1, 0, 1, 15, 1.5, 15);
    private static final VoxelShape WITH_FOOD = Block.box(1, 0, 1, 15, 9, 15);

    public PlateBlock(BlockBehaviour.Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH).setValue(FULL, false));
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
        return simpleCodec(PlateBlock::new);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, FULL);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection().getOpposite());
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return state.getValue(FULL) ? WITH_FOOD : PLATE;
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return PLATE;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new PlateBlockEntity(pos, state);
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        if (stack.isEmpty()) return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        if (Dessert.ofItem(stack.getItem()) == null || !(level.getBlockEntity(pos) instanceof PlateBlockEntity plate)) {
            return ItemInteractionResult.SKIP_DEFAULT_BLOCK_INTERACTION;       // other things behave as everywhere else
        }
        if (!plate.isEmpty()) {
            if (!level.isClientSide && plate.ready()) {
                player.displayClientMessage(Component.translatable("plate.aestheticjobs.taken"), true);
            }
            return ItemInteractionResult.CONSUME;
        }
        if (!level.isClientSide) plate.put(player, stack);
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (!player.getMainHandItem().isEmpty() || !(level.getBlockEntity(pos) instanceof PlateBlockEntity plate)) {
            return InteractionResult.PASS;
        }
        if (plate.isEmpty()) {                                                  // pass: a dessert in the other hand goes on
            if (!level.isClientSide && player.getOffhandItem().isEmpty() && plate.ready()) {
                player.displayClientMessage(Component.translatable("plate.aestheticjobs.empty"), true);
            }
            return InteractionResult.PASS;
        }
        if (!plate.ready()) return InteractionResult.CONSUME;                   // still chewing: no new swing of the arm
        if (!level.isClientSide) {
            if (player.isShiftKeyDown()) plate.takeBack(player);
            else plate.bite(player);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /** A moment after a bite the fork is at the mouth. */
    @Override
    protected void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (level.getBlockEntity(pos) instanceof PlateBlockEntity plate) plate.chew();
    }

    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && !level.isClientSide && level.getBlockEntity(pos) instanceof PlateBlockEntity plate) {
            plate.drop();
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }

    @Override
    protected BlockState rotate(BlockState state, Rotation rotation) {
        return state.setValue(FACING, rotation.rotate(state.getValue(FACING)));
    }

    @Override
    protected BlockState mirror(BlockState state, Mirror mirror) {
        return state.rotate(mirror.getRotation(state.getValue(FACING)));
    }
}
