package dev.aestheticjobs.block;

import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.Plate;
import dev.aestheticjobs.cafe.kitchen.Cooking;
import dev.aestheticjobs.cafe.kitchen.Extra;
import dev.aestheticjobs.cafe.kitchen.Menu;
import dev.aestheticjobs.cafe.kitchen.OvenState;
import dev.aestheticjobs.entity.CafeStaffEntity;
import dev.aestheticjobs.item.DoughItem;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.registry.ModBlockEntities;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.registry.ModItems;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.block.state.BlockState;

/** The pastry oven: the dough bakes inside, comes out golden, is decorated on top and taken. */
public class PastryOvenBlockEntity extends StationBlockEntity {
    private final OvenState oven = new OvenState();
    /** The stage the tick has seen last: a sound when it changes. */
    private OvenState.Stage heard;

    public PastryOvenBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.PASTRY_OVEN.get(), pos, state);
    }

    public OvenState oven() {
        return oven;
    }

    /** The dessert of a base of the menu, null for a drink. */
    public static Dessert dessert(int base) {
        return Dessert.byIndex(base - Menu.DRINKS);
    }

    private static Extra extra(ItemStack stack) {
        String id = id(stack);
        for (Extra e : Extra.values()) if (e.item().equals(id)) return e;
        return null;
    }

    @Override
    public boolean accepts(ItemStack stack) {
        return stack.is(ModItems.DOUGH.get()) || extra(stack) != null;
    }

    @Override
    protected boolean useItem(ServerPlayer player, ItemStack held) {
        long now = player.level().getGameTime();
        if (held.is(ModItems.DOUGH.get())) {
            if (DoughItem.recipe(held) < 0) return tell(player, "station.aestheticjobs.oven.bad_dough");
            if (!oven.put(DoughItem.recipe(held), now)) return tell(player, "station.aestheticjobs.oven.busy");
            spend(player, held);
            heard = OvenState.Stage.BAKING;
            sound(SoundEvents.IRON_TRAPDOOR_CLOSE, 0.8F, 1.0F);
            return true;
        }
        Extra e = extra(held);
        if (e == null) return false;
        if (oven.stage(now) != OvenState.Stage.PLATE) return tell(player, "station.aestheticjobs.oven.not_yet");
        if (!oven.decorate(e, now)) return tell(player, "station.aestheticjobs.oven.no_more");
        spendFood(player, held);
        sound(SoundEvents.HONEY_BLOCK_PLACE, 0.7F, 1.4F);
        puff(ParticleTypes.WAX_OFF, 4, 1.0);
        return true;
    }

    @Override
    protected boolean useHand(ServerPlayer player, boolean sneaking) {
        long now = player.level().getGameTime();
        switch (oven.stage(now)) {
            case FREE -> {
                return tell(player, "station.aestheticjobs.oven.next.dough");
            }
            case BAKING -> {
                return tell(player, "station.aestheticjobs.oven.next.baking", seconds(oven.ready() - now));
            }
            case GOLDEN, DARK -> {
                oven.takeOut(now);
                sound(SoundEvents.IRON_TRAPDOOR_OPEN, 0.8F, 1.0F);
                puff(ParticleTypes.CLOUD, 8, 0.8);
                return true;
            }
            case BURNT -> {
                oven.clear();
                give(player, new ItemStack(Items.CHARCOAL));
                sound(SoundEvents.FIRE_EXTINGUISH, 0.7F, 1.0F);
                puff(ParticleTypes.LARGE_SMOKE, 10, 0.8);
                return tell(player, "station.aestheticjobs.oven.burnt") || true;
            }
            default -> {
                int base = oven.recipe(), mask = oven.mask(), quality = oven.quality();
                ItemStack out = result(player.serverLevel(), CafeLogic.isWorking(player));
                oven.clear();                                                  // first free the oven: never twice
                give(player, out);
                finished(player, base, mask, quality);
                return true;
            }
        }
    }

    /**
     * A barista on duty gets a plate for the customer. Everybody else gets desserts to eat: one below three stars, two
     * from three stars on; five stars make them a masterpiece with a short effect (see cafe/CafeTreat).
     */
    private ItemStack result(ServerLevel level, boolean asBarista) {
        Dessert dessert = dessert(oven.recipe());
        if (dessert == null) return ItemStack.EMPTY;
        int stars = Cooking.stars(oven.quality());
        if (asBarista) {
            return CafeLogic.makePlate(new Plate(dessert.ordinal(), level.getGameTime() + CafeStaffEntity.PLATE_LIFE, stars));
        }
        ItemStack stack = new ItemStack(dessert.item(), stars >= 3 ? 2 : 1);
        if (stars < 5) return stack;
        Menu.Kind kind = Menu.get(oven.recipe()).kind();
        stack.set(ModComponents.MASTERPIECE.get(), kind.ordinal());
        stack.set(DataComponents.LORE, new ItemLore(List.of(
                Component.translatable("kitchen.aestheticjobs.masterpiece").withStyle(ChatFormatting.GOLD),
                Component.translatable("kitchen.aestheticjobs.effect." + kind.id()).withStyle(ChatFormatting.GRAY))));
        return stack;
    }

    private static long seconds(long ticks) {
        return Math.max(1, (ticks + 19) / 20);
    }

    @Override
    public List<Component> guide(Player player) {
        long now = player.level().getGameTime();
        List<Component> out = new ArrayList<>();
        out.add(getBlockState().getBlock().getName());
        OvenState.Stage stage = oven.stage(now);
        if (stage != OvenState.Stage.FREE) out.add(recipeName(oven.recipe(), oven.mask()));
        out.add(switch (stage) {
            case FREE -> Component.translatable("station.aestheticjobs.oven.next.dough");
            case BAKING -> Component.translatable("station.aestheticjobs.oven.next.baking", seconds(oven.ready() - now));
            case GOLDEN -> Component.translatable("station.aestheticjobs.oven.next.golden",
                    seconds(oven.ready() + OvenState.GOLDEN_TICKS - now));
            case DARK -> Component.translatable("station.aestheticjobs.oven.next.dark");
            case BURNT -> Component.translatable("station.aestheticjobs.oven.burnt");
            case PLATE -> Component.translatable("station.aestheticjobs.oven.next.plate", Integer.bitCount(oven.mask()), Cooking.MAX_EXTRAS);
        });
        return out;
    }

    @Override
    protected List<ItemStack> contents(ServerLevel level) {
        return switch (oven.stage(level.getGameTime())) {
            case FREE -> List.of();
            case BAKING -> List.of(DoughItem.of(oven.recipe()));
            case BURNT -> List.of(new ItemStack(Items.CHARCOAL));
            default -> List.of(result(level, false));
        };
    }

    @Override
    protected void clearContents() {
        oven.clear();
    }

    @Override
    protected long[] data() {
        return oven.save();
    }

    @Override
    protected void data(long[] in) {
        oven.load(in);
    }

    /** The model: free, baking (fire), something to take. */
    @Override
    protected BlockState shown(BlockState state) {
        OvenState.Stage stage = level == null ? OvenState.Stage.FREE : oven.stage(level.getGameTime());
        int look = switch (stage) {
            case FREE, PLATE -> 0;
            case BAKING -> 1;
            default -> 2;
        };
        return state.getValue(PastryOvenBlock.LOOK) == look ? state : state.setValue(PastryOvenBlock.LOOK, look);
    }

    @Override
    protected void tick(long now) {
        if (oven.recipe() < 0 || now % 4 != 0) return;
        OvenState.Stage stage = oven.stage(now);
        if (stage == heard) return;
        boolean first = heard == null;                                        // just loaded: no sound
        heard = stage;
        changed();
        if (first) return;
        if (stage == OvenState.Stage.GOLDEN) {
            sound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.4F, 1.3F);
            puff(ParticleTypes.WAX_ON, 8, 1.0);
        } else if (stage == OvenState.Stage.DARK) {
            sound(SoundEvents.NOTE_BLOCK_BELL.value(), 1.0F, 0.8F);
            puff(ParticleTypes.SMOKE, 8, 0.8);
        } else if (stage == OvenState.Stage.BURNT) {
            sound(SoundEvents.FIRE_EXTINGUISH, 0.8F, 0.8F);
            puff(ParticleTypes.LARGE_SMOKE, 12, 0.8);
        }
    }
}
