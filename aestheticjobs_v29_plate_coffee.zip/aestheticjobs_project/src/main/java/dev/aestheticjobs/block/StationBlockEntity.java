package dev.aestheticjobs.block;

import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.KitchenData;
import dev.aestheticjobs.cafe.Order;
import dev.aestheticjobs.cafe.kitchen.Cooking;
import dev.aestheticjobs.cafe.kitchen.Extra;
import dev.aestheticjobs.cafe.kitchen.Knowledge;
import dev.aestheticjobs.cafe.kitchen.Menu;
import dev.aestheticjobs.cafe.kitchen.Signature;
import dev.aestheticjobs.job.Shift;
import dev.aestheticjobs.registry.ModComponents;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;

/**
 * A station of the kitchen. Cooking happens in the world: the player clicks the block with the thing in his hand (or
 * with the empty hand) and the station does one step. The rules of every station are plain Java in cafe/kitchen; this
 * class takes and gives the items, makes the sounds, saves and syncs. The same {@link #guide} text is drawn next to
 * the crosshair (client/StationHud), so the next step is always visible.
 */
public abstract class StationBlockEntity extends BlockEntity {
    /** A held button repeats the click; one step at a time. */
    private static final int ACT_COOLDOWN = 7;

    /** Game time of the last step (synced: the renderer animates from it). */
    private long acted = -1000;

    protected StationBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    public long acted() {
        return acted;
    }

    // ------------------------------------------------------------------ what a station is

    /** Whether a click with this item belongs to the station (same answer on both sides: it depends on the item only). */
    public abstract boolean accepts(ItemStack stack);

    /** One step with the item in the hand (never empty, always one that {@link #accepts}). True when something happened. */
    protected abstract boolean useItem(ServerPlayer player, ItemStack held);

    /** One step with the empty hand. */
    protected abstract boolean useHand(ServerPlayer player, boolean sneaking);

    /** The card next to the crosshair: first the title, then the state, the last line is the next step. */
    public abstract List<Component> guide(Player player);

    /** Items shown as pictures on the card: what is still needed. */
    public List<ItemStack> guideItems(Player player) {
        return List.of();
    }

    /** What drops when the station is broken. */
    protected abstract List<ItemStack> contents(ServerLevel level);

    protected abstract void clearContents();

    protected abstract long[] data();

    protected abstract void data(long[] in);

    /** The block state that fits the content. */
    protected BlockState shown(BlockState state) {
        return state;
    }

    // ------------------------------------------------------------------ clicks (server)

    public final void interact(ServerPlayer player, ItemStack held, boolean emptyHand) {
        if (!(level instanceof ServerLevel sl) || player.isSpectator()) return;
        long now = sl.getGameTime();
        if (now >= acted && now - acted < ACT_COOLDOWN) return;
        long before = acted;
        acted = now;
        boolean done = emptyHand ? useHand(player, player.isShiftKeyDown()) : useItem(player, held);
        if (!done) {
            acted = before;
            return;
        }
        if (CafeLogic.isWorking(player)) Shift.touch(player);
        changed();
    }

    public void dropContents() {
        if (!(level instanceof ServerLevel sl)) return;
        for (ItemStack s : contents(sl)) {
            if (!s.isEmpty()) Block.popResource(sl, worldPosition, s);
        }
        clearContents();
    }

    // ------------------------------------------------------------------ helpers of the stations

    public static Item item(String id) {
        return BuiltInRegistries.ITEM.get(ResourceLocation.parse(id));
    }

    public static String id(ItemStack stack) {
        return BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
    }

    protected static Component itemName(String id) {
        return item(id).getDescription();
    }

    /** One item of the held stack goes into the station (a creative player keeps it). */
    protected static void spend(ServerPlayer player, ItemStack held) {
        if (!player.getAbilities().instabuild) held.shrink(1);
    }

    /** The empty bottle of the honey comes back. */
    protected static void spendFood(ServerPlayer player, ItemStack held) {
        boolean honey = held.is(Items.HONEY_BOTTLE) && !player.getAbilities().instabuild;
        spend(player, held);
        if (honey) give(player, new ItemStack(Items.GLASS_BOTTLE));
    }

    protected static void give(ServerPlayer player, ItemStack stack) {
        if (!stack.isEmpty()) player.getInventory().placeItemBackInInventory(stack);
    }

    protected static boolean tell(ServerPlayer player, String key, Object... args) {
        player.displayClientMessage(Component.translatable(key, args), true);
        return false;
    }

    protected void sound(SoundEvent sound, float volume, float pitch) {
        if (level instanceof ServerLevel sl) sl.playSound(null, worldPosition, sound, SoundSource.BLOCKS, volume, pitch);
    }

    protected void puff(ParticleOptions particle, int count, double height) {
        if (level instanceof ServerLevel sl) {
            sl.sendParticles(particle, worldPosition.getX() + 0.5, worldPosition.getY() + height, worldPosition.getZ() + 0.5,
                    count, 0.18, 0.08, 0.18, 0.01);
        }
    }

    /** A finished portion: the player learns the combination and reads how every addition suited it. */
    protected void finished(ServerPlayer player, int base, int mask, int quality) {
        KitchenData data = KitchenData.get(player.server);
        Knowledge knowledge = data.of(player.getUUID());
        Signature found = knowledge.learn(base, mask);
        data.setDirty();
        int stars = Cooking.stars(quality);
        MutableComponent line = Component.translatable("kitchen.aestheticjobs.done", recipeName(base, mask),
                dev.aestheticjobs.cafe.CupData.starText(stars));
        player.displayClientMessage(line, true);
        for (Extra e : Extra.values()) {
            if (!e.in(mask) || Signature.of(base, mask) != null) continue;
            int m = Cooking.match(base, e);
            player.sendSystemMessage(Component.translatable("kitchen.aestheticjobs.note." + (m > 0 ? "good" : m < 0 ? "bad" : "ok"),
                    Component.translatable("extra.aestheticjobs." + e.id()), recipeName(base, 0))
                    .withStyle(m > 0 ? ChatFormatting.GREEN : m < 0 ? ChatFormatting.RED : ChatFormatting.GRAY));
        }
        if (found != null) {
            player.sendSystemMessage(Component.translatable("kitchen.aestheticjobs.discovered",
                    Component.translatable("signature.aestheticjobs." + found.id())).withStyle(ChatFormatting.GOLD));
            sound(SoundEvents.PLAYER_LEVELUP, 0.7F, 1.4F);
        }
        sound(SoundEvents.EXPERIENCE_ORB_PICKUP, 0.8F, 0.8F + stars * 0.12F);
        puff(stars >= 5 ? ParticleTypes.HEART : ParticleTypes.HAPPY_VILLAGER, 2 + stars * 2, 1.1);
    }

    /** The name of a recipe: its signature name if it has one. */
    public static Component recipeName(int base, int mask) {
        Signature s = Signature.of(base, mask);
        if (s != null) return Component.translatable("signature.aestheticjobs." + s.id());
        Menu.Base b = Menu.get(base);
        if (b == null) return Component.empty();
        return b.isDrink() ? Component.translatable("drink.aestheticjobs." + b.id())
                : Component.translatable("item.aestheticjobs." + b.id());
    }

    /** The names of several items, joined with commas; repeated ones once with their number. */
    public static Component list(List<String> ids) {
        MutableComponent out = Component.empty();
        List<String> seen = new ArrayList<>();
        for (String id : ids) {
            if (seen.contains(id)) continue;
            long n = ids.stream().filter(id::equals).count();
            if (!seen.isEmpty()) out.append(", ");
            out.append(itemName(id));
            if (n > 1) out.append(" ×" + n);
            seen.add(id);
        }
        return out;
    }

    /** The order the player carries (null when none). */
    protected static Order order(Player player) {
        ItemStack ticket = CafeLogic.findTicket(player);
        return ticket.isEmpty() ? null : ticket.get(ModComponents.ORDER.get());
    }

    // ------------------------------------------------------------------ saving and syncing

    protected void changed() {
        if (level == null) return;
        setChanged();
        BlockState state = getBlockState();
        BlockState next = shown(state);
        if (next != state) level.setBlock(worldPosition, next, Block.UPDATE_ALL);
        level.sendBlockUpdated(worldPosition, next, next, Block.UPDATE_CLIENTS);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putLongArray("station", data());
        tag.putLong("acted", acted);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        data(tag.getLongArray("station"));
        acted = tag.contains("acted") ? tag.getLong("acted") : -1000;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    /** Only the stations where something happens by itself tick; an idle one returns at once. */
    public static void serverTick(Level level, BlockPos pos, BlockState state, StationBlockEntity station) {
        station.tick(level.getGameTime());
    }

    protected void tick(long now) {}
}
