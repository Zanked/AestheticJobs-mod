package dev.aestheticjobs.registry;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.entity.CafeCustomerEntity;
import dev.aestheticjobs.entity.CafeStaffEntity;
import dev.aestheticjobs.entity.JobManagerEntity;
import dev.aestheticjobs.job.interview.ManagerKind;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, AestheticJobs.MODID);

    /** The cafe customer: a small NPC with a thought bubble over the head. */
    public static final DeferredHolder<EntityType<?>, EntityType<CafeCustomerEntity>> CAFE_CUSTOMER =
            ENTITIES.register("cafe_customer", () -> EntityType.Builder
                    .of(CafeCustomerEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .build("cafe_customer"));

    /** The pastry chef: bakes the desserts in a furnace next to him. */
    public static final DeferredHolder<EntityType<?>, EntityType<CafeStaffEntity>> CAFE_CHEF =
            ENTITIES.register("cafe_chef", () -> EntityType.Builder
                    .<CafeStaffEntity>of((type, level) -> new CafeStaffEntity(type, level, CafeStaffEntity.Role.CHEF), MobCategory.MISC)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .build("cafe_chef"));

    /** The NPC barista: serves the NPC customers and the paid orders of players. */
    public static final DeferredHolder<EntityType<?>, EntityType<CafeStaffEntity>> CAFE_BARISTA =
            ENTITIES.register("cafe_barista", () -> EntityType.Builder
                    .<CafeStaffEntity>of((type, level) -> new CafeStaffEntity(type, level, CafeStaffEntity.Role.BARISTA), MobCategory.MISC)
                    .sized(0.6F, 1.8F)
                    .clientTrackingRange(10)
                    .build("cafe_barista"));

    /** The managers who interview applicants: one per job (cafe, office, shop). */
    public static final DeferredHolder<EntityType<?>, EntityType<JobManagerEntity>> CAFE_MANAGER = manager(ManagerKind.CAFE);
    public static final DeferredHolder<EntityType<?>, EntityType<JobManagerEntity>> OFFICE_MANAGER = manager(ManagerKind.OFFICE);
    public static final DeferredHolder<EntityType<?>, EntityType<JobManagerEntity>> SHOP_MANAGER = manager(ManagerKind.SHOP);

    private static DeferredHolder<EntityType<?>, EntityType<JobManagerEntity>> manager(ManagerKind kind) {
        return ENTITIES.register(kind.id, () -> EntityType.Builder
                .<JobManagerEntity>of((type, level) -> new JobManagerEntity(type, level, kind), MobCategory.MISC)
                .sized(0.6F, 1.8F)
                .clientTrackingRange(10)
                .build(kind.id));
    }

    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(CAFE_CUSTOMER.get(), CafeCustomerEntity.createAttributes().build());
        event.put(CAFE_CHEF.get(), CafeStaffEntity.createAttributes().build());
        event.put(CAFE_BARISTA.get(), CafeStaffEntity.createAttributes().build());
        event.put(CAFE_MANAGER.get(), JobManagerEntity.createAttributes().build());
        event.put(OFFICE_MANAGER.get(), JobManagerEntity.createAttributes().build());
        event.put(SHOP_MANAGER.get(), JobManagerEntity.createAttributes().build());
    }

    private ModEntities() {}
}
