package dev.aestheticjobs.registry;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.economy.Denomination;
import dev.aestheticjobs.item.Dessert;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AestheticJobs.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup." + AestheticJobs.MODID))
                    .icon(() -> ModItems.BANK_CARD.get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.ATM.get());
                        output.accept(ModItems.BANK_CARD.get());
                        output.accept(ModItems.WORK_BADGE.get());
                        output.accept(ModItems.COFFEE_MACHINE.get());
                        output.accept(ModItems.PASTRY_OVEN.get());
                        output.accept(ModItems.CAFE_REGISTER.get());
                        output.accept(ModItems.PENDANT_LAMP.get());
                        output.accept(ModItems.PLANTER.get());
                        output.accept(ModItems.MENU_BOARD.get());
                        output.accept(ModItems.TIP_JAR.get());
                        output.accept(ModItems.COFFEE_GRINDER.get());
                        output.accept(ModItems.PORTAFILTER.get());
                        output.accept(ModItems.MIXING_BOWL.get());
                        output.accept(ModItems.WHISK.get());
                        output.accept(ModItems.RECIPE_BOOK.get());
                        output.accept(ModItems.CAKE_STAND.get());
                        output.accept(ModItems.CUP_STACK.get());
                        output.accept(ModItems.BEAN_SACK.get());
                        output.accept(ModItems.FRUIT_BASKET.get());
                        output.accept(ModItems.GREENS_BASKET.get());
                        output.accept(ModItems.SERVING_PLATE.get());
                        output.accept(ModItems.PLATE_STACK.get());
                        output.accept(ModItems.DRINK_BOTTLES.get());
                        output.accept(ModItems.TABLE_GLASSES.get());
                        output.accept(ModItems.PLACE_SETTING.get());
                        output.accept(ModItems.PIZZA_PLATE.get());
                        output.accept(ModItems.ROAST_PLATTER.get());
                        output.accept(ModItems.SUSHI_BOARD.get());
                        output.accept(ModItems.EMPTY_CUP.get());
                        output.accept(ModItems.COFFEE_BEANS.get());
                        output.accept(ModItems.MILK_CARTON.get());
                        output.accept(ModItems.CREAM_CARTON.get());
                        output.accept(ModItems.SYRUP_VANILLA.get());
                        output.accept(ModItems.SYRUP_CARAMEL.get());
                        output.accept(ModItems.CHOCOLATE.get());
                        for (Dessert d : Dessert.values()) {
                            output.accept(ModItems.DESSERTS.get(d).get());
                        }
                        output.accept(ModItems.CAFE_CUSTOMER_SPAWN_EGG.get());
                        output.accept(ModItems.CAFE_CHEF_SPAWN_EGG.get());
                        output.accept(ModItems.CAFE_BARISTA_SPAWN_EGG.get());
                        output.accept(ModItems.RESUME.get());
                        output.accept(ModItems.CAFE_MANAGER_SPAWN_EGG.get());
                        output.accept(ModItems.OFFICE_MANAGER_SPAWN_EGG.get());
                        output.accept(ModItems.SHOP_MANAGER_SPAWN_EGG.get());
                        for (Denomination d : Denomination.values()) {
                            output.accept(ModItems.MONEY.get(d).get());
                        }
                    })
                    .build());

    private ModCreativeTabs() {}
}
