package dev.aestheticjobs.registry;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.block.CoffeeMachineBlockEntity;
import dev.aestheticjobs.block.GrinderBlockEntity;
import dev.aestheticjobs.block.MixingBowlBlockEntity;
import dev.aestheticjobs.block.PastryOvenBlockEntity;
import dev.aestheticjobs.block.PlateBlockEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, AestheticJobs.MODID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CoffeeMachineBlockEntity>> COFFEE_MACHINE =
            BLOCK_ENTITIES.register("coffee_machine", () ->
                    BlockEntityType.Builder.of(CoffeeMachineBlockEntity::new, ModBlocks.COFFEE_MACHINE.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PastryOvenBlockEntity>> PASTRY_OVEN =
            BLOCK_ENTITIES.register("pastry_oven", () ->
                    BlockEntityType.Builder.of(PastryOvenBlockEntity::new, ModBlocks.PASTRY_OVEN.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<GrinderBlockEntity>> GRINDER =
            BLOCK_ENTITIES.register("coffee_grinder", () ->
                    BlockEntityType.Builder.of(GrinderBlockEntity::new, ModBlocks.COFFEE_GRINDER.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<MixingBowlBlockEntity>> MIXING_BOWL =
            BLOCK_ENTITIES.register("mixing_bowl", () ->
                    BlockEntityType.Builder.of(MixingBowlBlockEntity::new, ModBlocks.MIXING_BOWL.get()).build(null));

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PlateBlockEntity>> PLATE =
            BLOCK_ENTITIES.register("serving_plate", () ->
                    BlockEntityType.Builder.of(PlateBlockEntity::new, ModBlocks.SERVING_PLATE.get()).build(null));

    private ModBlockEntities() {}
}
