package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Server -> client: opens the customer menu of a register: the desserts that are on the chefs' trays and the balance of the account. */
public record OpenOrderPayload(BlockPos pos, List<Integer> desserts, long balance) implements CustomPacketPayload {
    public static final Type<OpenOrderPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "open_order"));

    public static final StreamCodec<RegistryFriendlyByteBuf, OpenOrderPayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, OpenOrderPayload::pos,
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(64)), OpenOrderPayload::desserts,
            ByteBufCodecs.VAR_LONG, OpenOrderPayload::balance,
            OpenOrderPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
