package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client -> server: the interview window was closed (the interview is over, nothing is lost). */
public record InterviewCancelPayload() implements CustomPacketPayload {
    public static final Type<InterviewCancelPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "interview_cancel"));

    public static final StreamCodec<RegistryFriendlyByteBuf, InterviewCancelPayload> STREAM_CODEC =
            StreamCodec.unit(new InterviewCancelPayload());

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
