package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Server to client: open the recipe book. With forBowl the shown dessert can be chosen for the mixing bowl at pos.
 * tried / found are the player's knowledge; drink / dessert the order he carries (menu index, -1 none).
 */
public record OpenBookPayload(boolean forBowl, BlockPos pos, List<Integer> tried, long found, int drink, int dessert)
        implements CustomPacketPayload {
    public static final Type<OpenBookPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "open_book"));

    public static final StreamCodec<RegistryFriendlyByteBuf, OpenBookPayload> STREAM_CODEC =
            StreamCodec.of(OpenBookPayload::write, OpenBookPayload::read);

    private static void write(RegistryFriendlyByteBuf buf, OpenBookPayload p) {
        buf.writeBoolean(p.forBowl);
        buf.writeBlockPos(p.pos);
        buf.writeVarInt(p.tried.size());
        for (int v : p.tried) buf.writeInt(v);
        buf.writeLong(p.found);
        buf.writeInt(p.drink);
        buf.writeInt(p.dessert);
    }

    private static OpenBookPayload read(RegistryFriendlyByteBuf buf) {
        boolean forBowl = buf.readBoolean();
        BlockPos pos = buf.readBlockPos();
        int n = Math.min(256, buf.readVarInt());
        List<Integer> tried = new ArrayList<>(n);
        for (int i = 0; i < n; i++) tried.add(buf.readInt());
        return new OpenBookPayload(forBowl, pos, tried, buf.readLong(), buf.readInt(), buf.readInt());
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
