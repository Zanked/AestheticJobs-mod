package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Server -> client: opens the journal of a barista. rating = average of the reviews times ten (0 = none yet). */
public record JournalPayload(int daily, int streak, int best, int served, long tips, int rating, int decor,
                             List<Integer> cups, List<Task> tasks) implements CustomPacketPayload {
    /** type = ordinal of cafe/career/Quest.Type. */
    public record Task(int type, int drink, int target, int progress, long reward, boolean done) {}

    public static final Type<JournalPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "journal"));

    public static final StreamCodec<RegistryFriendlyByteBuf, JournalPayload> STREAM_CODEC =
            StreamCodec.of(JournalPayload::write, JournalPayload::read);

    private static void write(RegistryFriendlyByteBuf buf, JournalPayload p) {
        buf.writeVarInt(p.daily);
        buf.writeVarInt(p.streak);
        buf.writeVarInt(p.best);
        buf.writeVarInt(p.served);
        buf.writeVarLong(p.tips);
        buf.writeVarInt(p.rating);
        buf.writeVarInt(p.decor);
        buf.writeVarInt(p.cups.size());
        for (int c : p.cups) buf.writeVarInt(c);
        buf.writeVarInt(p.tasks.size());
        for (Task t : p.tasks) {
            buf.writeVarInt(t.type());
            buf.writeInt(t.drink());
            buf.writeVarInt(t.target());
            buf.writeVarInt(t.progress());
            buf.writeVarLong(t.reward());
            buf.writeBoolean(t.done());
        }
    }

    private static JournalPayload read(RegistryFriendlyByteBuf buf) {
        int daily = buf.readVarInt(), streak = buf.readVarInt(), best = buf.readVarInt(), served = buf.readVarInt();
        long tips = buf.readVarLong();
        int rating = buf.readVarInt(), decor = buf.readVarInt();
        List<Integer> cups = new ArrayList<>();
        for (int i = 0, n = Math.min(buf.readVarInt(), 32); i < n; i++) cups.add(buf.readVarInt());
        List<Task> tasks = new ArrayList<>();
        for (int i = 0, n = Math.min(buf.readVarInt(), 8); i < n; i++) {
            tasks.add(new Task(buf.readVarInt(), buf.readInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarLong(), buf.readBoolean()));
        }
        return new JournalPayload(daily, streak, best, served, tips, rating, decor, cups, tasks);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
