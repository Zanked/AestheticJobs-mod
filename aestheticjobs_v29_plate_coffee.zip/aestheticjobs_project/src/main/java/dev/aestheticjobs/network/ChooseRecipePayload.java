package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client to server: the dessert chosen in the recipe book for the mixing bowl at pos. */
public record ChooseRecipePayload(BlockPos pos, int base) implements CustomPacketPayload {
    public static final Type<ChooseRecipePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "choose_recipe"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ChooseRecipePayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, ChooseRecipePayload::pos,
            ByteBufCodecs.VAR_INT, ChooseRecipePayload::base,
            ChooseRecipePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
