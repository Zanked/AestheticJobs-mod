package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client -> server: the applicant picked this option (the index in the list the server sent). */
public record InterviewAnswerPayload(int choice) implements CustomPacketPayload {
    public static final Type<InterviewAnswerPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "interview_answer"));

    public static final StreamCodec<RegistryFriendlyByteBuf, InterviewAnswerPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, InterviewAnswerPayload::choice,
            InterviewAnswerPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
