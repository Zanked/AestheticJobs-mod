package dev.aestheticjobs.network;

import dev.aestheticjobs.block.MixingBowlBlockEntity;
import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.client.ClientHooks;
import dev.aestheticjobs.job.interview.Interview;
import dev.aestheticjobs.job.interview.Resumes;
import dev.aestheticjobs.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class ModNetwork {
    private ModNetwork() {}

    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("7");
        registrar.playToServer(ChooseRecipePayload.TYPE, ChooseRecipePayload.STREAM_CODEC, ModNetwork::handleChooseRecipe);
        registrar.playToClient(OpenBookPayload.TYPE, OpenBookPayload.STREAM_CODEC, ModNetwork::handleOpenBook);
        registrar.playToServer(PlaceOrderPayload.TYPE, PlaceOrderPayload.STREAM_CODEC, ModNetwork::handlePlaceOrder);
        registrar.playToClient(OpenOrderPayload.TYPE, OpenOrderPayload.STREAM_CODEC, ModNetwork::handleOpenOrder);
        registrar.playToServer(SubmitResumePayload.TYPE, SubmitResumePayload.STREAM_CODEC, ModNetwork::handleSubmitResume);
        registrar.playToServer(InterviewAnswerPayload.TYPE, InterviewAnswerPayload.STREAM_CODEC, ModNetwork::handleInterviewAnswer);
        registrar.playToServer(InterviewCancelPayload.TYPE, InterviewCancelPayload.STREAM_CODEC, ModNetwork::handleInterviewCancel);
        registrar.playToClient(InterviewStatePayload.TYPE, InterviewStatePayload.STREAM_CODEC, ModNetwork::handleInterviewState);
        registrar.playToClient(ReceiptPayload.TYPE, ReceiptPayload.STREAM_CODEC, ModNetwork::handleReceipt);
        registrar.playToClient(JournalPayload.TYPE, JournalPayload.STREAM_CODEC, ModNetwork::handleJournal);
    }

    private static void handleReceipt(ReceiptPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ClientHooks.showReceipt(payload));
    }

    private static void handleJournal(JournalPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ClientHooks.openJournal(payload));
    }

    private static void handleInterviewState(InterviewStatePayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ClientHooks.openInterview(payload));
    }

    private static void handleInterviewAnswer(InterviewAnswerPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        Interview.answer(player, payload.choice());
    }

    private static void handleInterviewCancel(InterviewCancelPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        Interview.cancel(player);
    }

    /** The player signed his resume: the server writes only numbers it has checked. */
    private static void handleSubmitResume(SubmitResumePayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        ItemStack stack = player.getItemInHand(payload.hand() == 1 ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND);
        if (!Resumes.isResume(stack)) return;
        Resumes.write(stack, new Resumes.Data(Resumes.clamp(payload.exp(), 0, Resumes.EXP_COUNT - 1), Resumes.limitSkills(payload.skills()),
                Resumes.clamp(payload.trait(), 0, Resumes.TRAIT_COUNT - 1), Resumes.clamp(payload.goal(), 0, Resumes.GOAL_COUNT - 1),
                player.getGameProfile().getName()));
        player.level().playSound(null, player.blockPosition(), SoundEvents.BOOK_PAGE_TURN, SoundSource.PLAYERS, 0.8F, 1.0F);
        player.displayClientMessage(Component.translatable("resume.saved"), true);
    }

    private static void handleOpenOrder(OpenOrderPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ClientHooks.openOrder(payload));
    }

    private static void handlePlaceOrder(PlaceOrderPayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        ServerLevel level = player.serverLevel();
        BlockPos pos = payload.pos();
        if (player.distanceToSqr(Vec3.atCenterOf(pos)) > 64.0) return;
        if (!level.isLoaded(pos) || !level.getBlockState(pos).is(ModBlocks.CAFE_REGISTER.get())) return;
        if (CafeLogic.isWorking(player)) return;                             // a barista at work takes orders, he does not place them
        CafeLogic.placeOrder(player, level, pos, payload.drink(), payload.dessert());
    }

    private static void handleOpenBook(OpenBookPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ClientHooks.openBook(payload));
    }

    private static void handleChooseRecipe(ChooseRecipePayload payload, IPayloadContext context) {
        if (!(context.player() instanceof ServerPlayer player)) return;
        ServerLevel level = player.serverLevel();
        BlockPos pos = payload.pos();
        if (player.isSpectator() || player.distanceToSqr(Vec3.atCenterOf(pos)) > 64.0) return;
        if (!level.isLoaded(pos) || !(level.getBlockEntity(pos) instanceof MixingBowlBlockEntity bowl)) return;
        bowl.choose(player, payload.base());
    }
}
