package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client -> server: the player signed his resume (hand: 0 main, 1 off hand). The server checks every number and writes the item. */
public record SubmitResumePayload(int hand, int exp, int skills, int trait, int goal) implements CustomPacketPayload {
    public static final Type<SubmitResumePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "submit_resume"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SubmitResumePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, SubmitResumePayload::hand,
            ByteBufCodecs.VAR_INT, SubmitResumePayload::exp,
            ByteBufCodecs.VAR_INT, SubmitResumePayload::skills,
            ByteBufCodecs.VAR_INT, SubmitResumePayload::trait,
            ByteBufCodecs.VAR_INT, SubmitResumePayload::goal,
            SubmitResumePayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
