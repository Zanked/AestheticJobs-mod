package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client -> server: the customer orders a drink (index) with an optional dessert (index, -1 = none). The server checks everything itself. */
public record PlaceOrderPayload(BlockPos pos, int drink, int dessert) implements CustomPacketPayload {
    public static final Type<PlaceOrderPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "place_order"));

    public static final StreamCodec<RegistryFriendlyByteBuf, PlaceOrderPayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, PlaceOrderPayload::pos,
            ByteBufCodecs.VAR_INT, PlaceOrderPayload::drink,
            ByteBufCodecs.INT, PlaceOrderPayload::dessert,
            PlaceOrderPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
