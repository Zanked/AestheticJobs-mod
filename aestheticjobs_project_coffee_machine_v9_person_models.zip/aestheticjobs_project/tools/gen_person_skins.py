#!/usr/bin/env python3
"""
Skins of every person in the cafe: 8 customers (0..7), the pastry chef (8) and the NPC barista (9).
Player-model skins (slim "Alex" arms) of 64x128: the first 64x64 is the standard skin layout, the part below holds the
chef's hat. Every person gets four faces: neutral, blink, happy, angry (the renderer swaps them; no animation of the mesh).

  textures/entity/person_<skin>_<face>.png        face: 0 neutral, 1 blink, 2 happy, 3 angry

The arms are split in two (upper arm + forearm = elbow); the forearm uses the lower half of the arm texture, so the
ordinary skin layout stays valid (see cafe/anim/PersonGeometry.java).

Run: python3 tools/gen_person_skins.py
"""
import os
from PIL import Image

OUT = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources", "assets", "aestheticjobs", "textures", "entity")
W, H = 64, 128


def hexc(s):
    s = s.lstrip("#")
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), 255)


def shade(c, f):
    """f > 0 lighter, f < 0 darker."""
    if f >= 0:
        return tuple(int(v + (255 - v) * f) for v in c[:3]) + (255,)
    return tuple(int(v * (1 + f)) for v in c[:3]) + (255,)


def faces(u, v, w, h, d):
    """The six faces of a box at texture (u, v): (x, y, w, h) of each, as Minecraft unwraps it."""
    return {
        "top": (u + d, v, w, d),
        "bottom": (u + d + w, v, w, d),
        "right": (u, v + d, d, h),
        "front": (u + d, v + d, w, h),
        "left": (u + d + w, v + d, d, h),
        "back": (u + 2 * d + w, v + d, w, h),
    }


class Skin:
    def __init__(self):
        self.im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        self.px = self.im.load()

    def rect(self, x, y, w, h, c):
        for j in range(h):
            for i in range(w):
                if 0 <= x + i < W and 0 <= y + j < H:
                    self.px[x + i, y + j] = c

    def dot(self, x, y, c):
        if 0 <= x < W and 0 <= y < H:
            self.px[x, y] = c

    def fill_box(self, u, v, w, h, d, c, names=None):
        for n, (x, y, fw, fh) in faces(u, v, w, h, d).items():
            if names is None or n in names:
                self.rect(x, y, fw, fh, c)


# ------------------------------------------------------------------ characters
# style of hair: short, long, bun, pigtails, messy, bald-ish (gray), braid, cap
PEOPLE = [
    dict(name="Emma", skin="#f6d8bc", hair="#d9a066", hairstyle="long", eyes="#5a9a6a", top="#f2a7c3", trim="#ffffff",
         sleeve=4, bottom="#8aa7d6", shoes="#f4f4f4", lash=True),
    dict(name="Liam", skin="#e8b98f", hair="#3a2a22", hairstyle="short", eyes="#5a3a2a", top="#5b8bd6", trim="#e8eefc",
         sleeve=12, bottom="#4a5a7a", shoes="#e8e8e8", hoodie=True),
    dict(name="Sofia", skin="#f2cfae", hair="#1f1a1c", hairstyle="bun", eyes="#3a3236", top="#f4ecd8", trim="#c9a97e",
         sleeve=12, bottom="#2e2a30", shoes="#1c1a1e", coat="#c9a97e", lash=True, lips="#c0485a"),
    dict(name="Noah", skin="#d9a67c", hair="#6b4a2e", hairstyle="messy", eyes="#4a3220", top="#f0a35e", trim="#fbd9b0",
         sleeve=4, bottom="#b9a57a", shoes="#6a4a32", stripes=True),
    dict(name="Mia", skin="#fbe0c8", hair="#f4d36a", hairstyle="pigtails", eyes="#5b8fd0", top="#f7d65c", trim="#fff3b8",
         sleeve=3, bottom="#f7d65c", shoes="#d6584e", lash=True, skirt=4),
    dict(name="Oliver", skin="#e6c2a2", hair="#b9b9b9", hairstyle="short", eyes="#4a4a52", top="#8b6a4a", trim="#f2ead8",
         sleeve=12, bottom="#55504a", shoes="#2a2622", beard="#b0b0b0", cardigan=True),
    dict(name="Lily", skin="#f6d3b8", hair="#a6482c", hairstyle="braid", eyes="#6a7a4a", top="#78b08a", trim="#a8d4b6",
         sleeve=12, bottom="#3f4a6b", shoes="#6a4a32", glasses="#3a2a28", lash=True),
    dict(name="Max", skin="#c68e63", hair="#1a1a1a", hairstyle="cap", eyes="#2a1c14", top="#d65a4e", trim="#f2b0a8",
         sleeve=4, bottom="#3d4f78", shoes="#f2f2f2", cap="#2f6fb5"),
    dict(name="Chef", skin="#f0cba8", hair="#6a4a3a", hairstyle="short", eyes="#6a8fb0", top="#fffaf0", trim="#d8d2c4",
         sleeve=12, bottom="#7a7a84", shoes="#3a3030", chef=True, mustache="#5a3e30"),
    dict(name="Barista", skin="#eec1a0", hair="#4a3830", hairstyle="ponytail", eyes="#5a8a5a", top="#f4e6c8", trim="#a0714f",
         sleeve=8, bottom="#5a4636", shoes="#3a2a22", apron="#8a5a3a", beanie="#a0714f", lash=True),
]
FACES = ["neutral", "blink", "happy", "angry"]


def paint_head(s, p, face):
    skin = hexc(p["skin"])
    hair = hexc(p["hair"])
    s.fill_box(0, 0, 8, 8, 8, skin)
    dark = shade(skin, -0.14)
    style = p["hairstyle"]

    def hair_front(rows, fringe=None):
        s.rect(8, 8, 8, rows, hair)
        if fringe:
            for x, y in fringe:
                s.dot(8 + x, 8 + y, hair)

    # hair on the base head: top always; back and sides according to the style
    s.rect(8, 0, 8, 8, hair)                       # top
    back = {"short": 5, "messy": 5, "cap": 4, "bun": 8, "long": 8, "pigtails": 6, "braid": 8, "ponytail": 8}[style]
    s.rect(24, 8, 8, back, hair)                   # back of the head (24,8)
    side = {"short": 3, "messy": 3, "cap": 3, "bun": 4, "long": 7, "pigtails": 4, "braid": 5, "ponytail": 4}[style]
    s.rect(0, 8, 8, side, hair)                    # right side (0,8)
    s.rect(16, 8, 8, side, hair)                   # left side (16,8)
    if style in ("short", "cap"):
        hair_front(2, [(0, 2), (7, 2)])
    elif style == "messy":
        hair_front(2, [(0, 2), (1, 2), (6, 2), (7, 2), (3, 2)])
    elif style in ("long", "braid", "bun", "ponytail"):
        hair_front(2, [(0, 2), (0, 3), (1, 2), (7, 2), (7, 3), (6, 2)])
    elif style == "pigtails":
        hair_front(2, [(0, 2), (7, 2), (3, 2), (4, 2)])
    if p.get("chef"):
        s.rect(8, 8, 8, 1, hair)
    if p.get("beanie"):                            # the beanie hides the fringe
        s.rect(8, 8, 8, 2, hexc(p["beanie"]))

    # ---- the face (front, local coordinates 0..7)
    ox, oy = 8, 8
    iris = hexc(p["eyes"])
    white = (250, 250, 250, 255)
    brow = shade(hair, -0.1)
    lash = shade(hair, -0.3)
    mouth = hexc(p.get("lips", "#b5584a"))
    blush = (240, 150, 150, 255)

    def d(x, y, c):
        s.dot(ox + x, oy + y, c)

    eye_row = 5 if face == "angry" else 4
    if face == "blink":
        for x in (1, 2, 5, 6):
            d(x, 4, lash if p.get("lash") else dark)
    else:
        d(1, eye_row, white); d(2, eye_row, iris)
        d(5, eye_row, iris); d(6, eye_row, white)
        if face == "happy":
            d(2, eye_row, shade(iris, 0.25)); d(5, eye_row, shade(iris, 0.25))
    if p.get("lash") and face != "blink":
        d(0, eye_row, lash); d(7, eye_row, lash)
    # brows (not under a fringe)
    if face == "angry":
        d(1, 3, brow); d(2, 4, brow); d(5, 4, brow); d(6, 3, brow)
    elif face == "happy":
        d(1, 2, brow); d(2, 2, brow); d(5, 2, brow); d(6, 2, brow)
    elif not p.get("cap") or True:
        d(1, 3, brow); d(2, 3, brow); d(5, 3, brow); d(6, 3, brow)
    if style == "pigtails" and face != "happy":
        pass
    # beard / mustache first, the mouth on top
    if p.get("beard"):
        b = hexc(p["beard"])
        for y in range(5, 8):
            for x in range(1, 7):
                if y == 5 and x not in (1, 2, 5, 6):
                    continue
                d(x, y, b)
        d(0, 5, b); d(7, 5, b); d(0, 6, b); d(7, 6, b)
    if p.get("mustache"):
        m = hexc(p["mustache"])
        for x in (2, 3, 4, 5):
            d(x, 5, m)
    # mouth
    if face == "happy":
        d(2, 5, dark if not p.get("beard") else mouth); d(5, 5, dark if not p.get("beard") else mouth)
        d(3, 6, mouth); d(4, 6, mouth)
        if not p.get("beard"):
            d(1, 6, blush); d(6, 6, blush)
    elif face == "angry":
        d(3, 6, mouth); d(4, 6, mouth)
        d(2, 7, dark if not p.get("beard") else mouth); d(5, 7, dark if not p.get("beard") else mouth)
    else:
        d(3, 6, mouth); d(4, 6, mouth)
    # nose
    if not p.get("beard") or True:
        d(3, 5, shade(skin, -0.08)) if not p.get("mustache") else None

    # ---- the second layer of the head (hat layer, (32,0)): volume of the hair, cap, glasses
    if style in ("long", "braid"):
        s.rect(40, 0, 8, 8, hair)                  # top
        s.rect(56, 8, 8, 9 if False else 8, hair)  # back
        s.rect(32, 8, 8, 6, hair); s.rect(48, 8, 8, 6, hair)
        s.rect(40, 8, 8, 2, hair)
    elif style == "bun":
        s.rect(40, 0, 8, 8, hair); s.rect(56, 8, 8, 6, hair); s.rect(32, 8, 8, 3, hair); s.rect(48, 8, 8, 3, hair)
        s.rect(40, 8, 8, 1, hair)
        s.rect(59, 1, 2, 2, hair)                  # (a knot is painted on the back top row, cheap bun)
    elif style == "pigtails":
        s.rect(40, 0, 8, 8, hair); s.rect(56, 8, 8, 4, hair); s.rect(32, 8, 8, 8, hair); s.rect(48, 8, 8, 8, hair)
        s.rect(40, 8, 8, 2, hair)
    elif style == "ponytail":
        s.rect(40, 0, 8, 8, hair); s.rect(56, 8, 8, 8, hair); s.rect(32, 8, 8, 3, hair); s.rect(48, 8, 8, 3, hair)
        s.rect(40, 8, 8, 2, hair)
    elif style == "messy":
        s.rect(40, 0, 8, 8, hair); s.rect(40, 8, 8, 1, hair); s.rect(56, 8, 8, 3, hair)
        s.rect(32, 8, 8, 2, hair); s.rect(48, 8, 8, 2, hair)
    else:                                          # short / cap
        s.rect(40, 0, 8, 8, hair); s.rect(40, 8, 8, 1, hair); s.rect(56, 8, 8, 4, hair)
        s.rect(32, 8, 8, 2, hair); s.rect(48, 8, 8, 2, hair)
    if p.get("cap"):
        c = hexc(p["cap"])
        s.rect(40, 0, 8, 8, c)                     # crown
        s.rect(40, 8, 8, 3, c)                     # front rows 0..2
        s.rect(32, 8, 8, 3, c); s.rect(48, 8, 8, 3, c); s.rect(56, 8, 8, 3, c)
        s.rect(40, 11 - 0, 8, 0, c)
        s.rect(40, 10, 8, 1, shade(c, -0.25))      # brim shadow line
        s.rect(40, 0, 8, 1, shade(c, 0.15))
    if p.get("beanie"):
        c = hexc(p["beanie"]); stripe = hexc(p["trim"])
        s.rect(40, 0, 8, 8, c)
        for (x, y) in ((40, 8), (32, 8), (48, 8), (56, 8)):
            s.rect(x, y, 8, 3, c)
            s.rect(x, y + 2, 8, 1, shade(c, -0.18))
            s.rect(x, y, 8, 1, shade(c, 0.12))
    if p.get("glasses"):
        g = hexc(p["glasses"])
        for (x0, x1) in ((0, 3), (4, 7)):
            for x in range(x0, x1 + 1):
                s.dot(40 + x, 8 + 3, g); s.dot(40 + x, 8 + 5, g)
            s.dot(40 + x0, 8 + 4, g); s.dot(40 + x1, 8 + 4, g)
        s.dot(40 + 3, 8 + 3, g); s.dot(40 + 4, 8 + 3, g)       # bridge
        s.rect(32 + 0, 8 + 3, 8, 1, g); s.rect(48, 8 + 3, 8, 1, g)   # temples
    if p.get("chef"):
        pass                                       # the toque is a separate model part (below)


def paint_body(s, p):
    top = hexc(p["top"]); trim = hexc(p["trim"]); bottom = hexc(p["bottom"]); skin = hexc(p["skin"])
    shoes = hexc(p["shoes"])
    # body (16,16): 8x12x4
    s.fill_box(16, 16, 8, 12, 4, top)
    f = faces(16, 16, 8, 12, 4)["front"]
    fx, fy = f[0], f[1]
    # collar
    s.rect(fx + 2, fy, 4, 1, shade(skin, -0.05))
    s.rect(fx + 3, fy + 1, 2, 1, shade(skin, -0.05))
    s.rect(fx + 1, fy, 1, 1, trim); s.rect(fx + 6, fy, 1, 1, trim)
    if p.get("stripes"):
        for y in range(2, 11, 3):
            s.rect(fx, fy + y, 8, 1, trim)
    if p.get("hoodie"):
        s.rect(fx + 3, fy + 1, 1, 4, trim); s.rect(fx + 4, fy + 1, 1, 4, trim)       # strings
        s.rect(fx + 1, fy + 8, 6, 3, shade(top, -0.12))                              # pocket
    if p.get("cardigan"):
        s.rect(fx + 2, fy, 4, 12, trim)                                              # white shirt under the cardigan
        s.rect(fx + 3, fy, 2, 12, shade(trim, -0.06))
        for y in (3, 6, 9):
            s.dot(fx + 3, fy + y, (80, 60, 40, 255))
    if p.get("chef"):
        for y in (2, 5, 8):
            s.rect(fx + 3, fy + y, 2, 1, (170, 170, 175, 255)); s.dot(fx + 3, fy + y, (110, 110, 118, 255))
        s.rect(fx + 3, fy, 2, 12, shade(top, -0.04))
        s.rect(fx + 2, fy, 4, 1, (200, 60, 60, 255))                                  # neckerchief
    # waist
    s.rect(fx, fy + 11, 8, 1, shade(bottom, -0.1))
    # bottom face of the body
    s.rect(28, 16, 8, 4, shade(bottom, -0.1))
    # jacket layer (16,32): coat / apron / dress skirt overlays
    jf = faces(16, 32, 8, 12, 4)
    jx, jy = jf["front"][0], jf["front"][1]
    if p.get("coat"):
        c = hexc(p["coat"])
        for n, (x, y, w, h) in jf.items():
            if n not in ("top", "bottom"):
                s.rect(x, y, w, h, c)
        s.rect(jx + 3, jy, 2, 12, shade(c, -0.15))                                    # open front
        s.rect(jx + 3, jy, 2, 1, (0, 0, 0, 0))
        s.rect(jx + 3, jy + 1, 2, 11, (0, 0, 0, 0))
        s.rect(jx, jy + 11, 8, 1, shade(c, -0.15))
    if p.get("apron"):
        a = hexc(p["apron"])
        s.rect(jx + 1, jy + 2, 6, 10, a)                                              # front panel
        s.rect(jx + 1, jy + 2, 6, 1, shade(a, 0.2))
        s.rect(jx + 2, jy + 1, 1, 1, shade(a, -0.2)); s.rect(jx + 5, jy + 1, 1, 1, shade(a, -0.2))   # straps up
        s.rect(jx + 2, jy + 7, 4, 3, shade(a, -0.12))                                 # pocket
        s.rect(jx + 2, jy + 7, 4, 1, shade(a, 0.1))
        s.rect(jx, jy + 3, 1, 1, shade(a, -0.2)); s.rect(jx + 7, jy + 3, 1, 1, shade(a, -0.2))   # tie around the waist
        sx, sy = jf["right"][0], jf["right"][1]
        s.rect(sx, sy + 3, 4, 1, shade(a, -0.2))
        sx, sy = jf["left"][0], jf["left"][1]
        s.rect(sx, sy + 3, 4, 1, shade(a, -0.2))
        bx, by = jf["back"][0], jf["back"][1]
        s.rect(bx, by + 3, 8, 1, shade(a, -0.2))
    if p.get("chef"):
        c = hexc(p["top"])
        for n, (x, y, w, h) in jf.items():
            if n not in ("top", "bottom"):
                s.rect(x, y, w, h, c)
        s.rect(jx + 3, jy, 2, 12, (0, 0, 0, 0))
        s.rect(jx + 3, jy, 1, 12, (210, 205, 195, 255)); s.rect(jx + 4, jy, 1, 12, (235, 230, 220, 255))
        for y in (2, 5, 8):
            s.rect(jx + 5, jy + y, 1, 1, (150, 150, 158, 255)); s.rect(jx + 2, jy + y, 1, 1, (150, 150, 158, 255))
        s.rect(jx + 2, jy, 4, 1, (200, 60, 60, 255))
        s.rect(jx + 5, jy + 6, 2, 3, (235, 230, 220, 255))
        # double breasted: the right panel
        for y in range(12):
            s.dot(jx + 2, jy + y, (225, 220, 210, 255))

    # ---- arms: sleeve rows, then skin; the second layer repeats the sleeve for long sleeves
    arms = [(40, 16, 40, 32), (32, 48, 48, 48)]          # (arm u, v), (sleeve u, v)
    for (au, av, su, sv) in arms:
        for n, (x, y, w, h) in faces_slim(au, av).items():
            if n in ("top",):
                s.rect(x, y, w, h, top)
            elif n == "bottom":
                s.rect(x, y, w, h, skin)
            else:
                s.rect(x, y, w, h, skin)
                rows = min(p["sleeve"], h)
                s.rect(x, y, w, rows, top)
                if rows < h and p["sleeve"] < 12 and n in ("front", "back", "left", "right"):
                    s.rect(x, y + rows - 1, w, 1, trim)           # hem of a short sleeve
        if p.get("chef") or p.get("cardigan") or p.get("coat") or p.get("hoodie"):
            col = hexc(p["coat"]) if p.get("coat") else top
            for n, (x, y, w, h) in faces_slim(su, sv).items():
                if n not in ("top", "bottom"):
                    s.rect(x, y, w, 12 if n != "top" else h, col)
            if p.get("chef"):
                # cuffs
                for n, (x, y, w, h) in faces_slim(su, sv).items():
                    if n not in ("top", "bottom"):
                        s.rect(x, y + 10, w, 2, (225, 220, 210, 255))
        if p.get("apron") and p["sleeve"] < 12:
            pass
    # hands are skin already (rows below the sleeve)

    # ---- legs: pants colour down to the shoes
    legs = [(0, 16, 0, 32), (16, 48, 0, 48)]
    for (lu, lv, pu, pv) in legs:
        for n, (x, y, w, h) in faces(lu, lv, 4, 12, 4).items():
            if n == "top":
                s.rect(x, y, w, h, bottom)
            elif n == "bottom":
                s.rect(x, y, w, h, shoes)
            else:
                s.rect(x, y, w, h, bottom)
                s.rect(x, y + 10, w, 2, shoes)
                s.rect(x, y + 10, w, 1, shade(shoes, 0.12))
        if p.get("chef"):
            for n, (x, y, w, h) in faces(lu, lv, 4, 12, 4).items():
                if n not in ("top", "bottom"):
                    for j in range(0, 10):
                        for i in range(w):
                            if (i + j) % 2 == 0:
                                s.dot(x + i, y + j, shade(hexc(p["bottom"]), -0.12))
        if p.get("skirt"):
            sk = hexc(p["bottom"])
            for n, (x, y, w, h) in faces(lu, lv, 4, 12, 4).items():
                if n not in ("top", "bottom"):
                    s.rect(x, y + p["skirt"], w, 10 - p["skirt"], skin)
                    s.rect(x, y + 10, w, 2, shoes)
                    s.rect(x, y, w, p["skirt"], sk)
            # the skirt itself on the pants layer
            for n, (x, y, w, h) in faces(pu, pv, 4, 12, 4).items():
                if n not in ("top", "bottom"):
                    s.rect(x, y, w, p["skirt"] + 2, sk)
                    s.rect(x, y + p["skirt"] + 1, w, 1, shade(sk, -0.15))
        if p.get("skirt") is None and p.get("name") == "Emma":
            pass
    if p.get("apron") is not None:
        pass


def faces_slim(u, v):
    return faces(u, v, 3, 12, 4)


def paint_toque(s):
    """The chef's tall hat: two boxes in the free area under the skin (y >= 64), see PersonGeometry."""
    white = (252, 250, 244, 255)
    fold = (228, 224, 214, 255)
    # puff: box 8x6x8 at (0,64)
    for n, (x, y, w, h) in faces(0, 64, 8, 6, 8).items():
        s.rect(x, y, w, h, white)
        if n not in ("top", "bottom"):
            for xx in range(x + 1, x + w, 3):
                s.rect(xx, y, 1, h, fold)
        if n == "top":
            s.rect(x + 2, y + 2, w - 4, h - 4, shade(white, -0.03))
    # band: box 9x3x9 at (0,80)
    for n, (x, y, w, h) in faces(0, 80, 9, 3, 9).items():
        s.rect(x, y, w, h, white)
        if n not in ("top", "bottom"):
            s.rect(x, y + h - 1, w, 1, fold)


def make(p, face):
    s = Skin()
    paint_body(s, p)
    paint_head(s, p, face)
    if p.get("chef"):
        paint_toque(s)
    return s.im


def main():
    os.makedirs(OUT, exist_ok=True)
    for i, p in enumerate(PEOPLE):
        for k, face in enumerate(FACES):
            make(p, face).save(os.path.join(OUT, "person_%d_%d.png" % (i, k)))
    print("wrote", len(PEOPLE) * len(FACES), "skins")


if __name__ == "__main__":
    main()
