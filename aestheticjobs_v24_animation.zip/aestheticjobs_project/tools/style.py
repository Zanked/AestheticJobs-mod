"""The painted miniature finish shared by the 3D food and the table blocks (in the spirit of cosy decoration mods):
a soft warm palette, quiet mottling instead of speckle noise, a light upper edge and a shaded lower edge.
"""
import zlib

import numpy as np

CREAM_LIGHT = np.array((255.0, 240.0, 214.0))
PLUM_SHADE = np.array((94.0, 56.0, 70.0))


def _hash(x, y, z, salt):
    return (zlib.crc32(bytes((x & 255, y & 255, z & 255, salt))) & 0xFFFF) / 65535.0


def mottle(x, y, z):
    """A brightness factor around 1 for the texture pixel at integer position x, y, z: soft patches plus a fine grain."""
    cell = 3
    base = (x // cell, y // cell, z // cell)
    t = [(v % cell + 0.5) / cell for v in (x, y, z)]
    soft = 0.0
    for i in (0, 1):
        for j in (0, 1):
            for k in (0, 1):
                w = (t[0] if i else 1 - t[0]) * (t[1] if j else 1 - t[1]) * (t[2] if k else 1 - t[2])
                soft += w * _hash(base[0] + i, base[1] + j, base[2] + k, 71)
    return 1.0 + (soft - 0.5) * 0.085 + (_hash(x, y, z, 72) - 0.5) * 0.035


def shade(rgb, k=1.0, light=0.0):
    """Multiplies a colour by k, then mixes `light` of warm cream into it."""
    c = np.array(rgb[:3], np.float64) * k
    c = c + (CREAM_LIGHT - c) * light
    return tuple(int(v) for v in np.clip(c.round(), 0, 255))


def grade(im):
    """The palette of the whole texture: a little muted, shadows lean to plum, highlights to cream. Alpha is kept."""
    c = im[..., :3].astype(np.float64)
    lum = (c * (0.299, 0.587, 0.114)).sum(axis=-1, keepdims=True) / 255.0
    grey = lum * 255.0
    c = grey + (c - grey) * 0.96
    c += (PLUM_SHADE - c) * (0.13 * np.clip(1.0 - lum * 1.5, 0, 1))
    c += (CREAM_LIGHT - c) * (0.10 * np.clip((lum - 0.55) / 0.45, 0, 1))
    out = im.copy()
    out[..., :3] = np.clip(c.round(), 0, 255).astype(np.uint8)
    return out
