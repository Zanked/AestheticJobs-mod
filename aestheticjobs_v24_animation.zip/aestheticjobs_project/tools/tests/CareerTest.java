import dev.aestheticjobs.cafe.career.*; import java.util.*;
public class CareerTest { static void ok(boolean b,String m){if(!b)throw new AssertionError(m);}
 public static void main(String[] a){
  for(long d=0;d<3000;d++){var q=Quest.ofDay(d,d*77,8);ok(q.size()==3&&q.stream().map(Quest::type).distinct().count()==3,"quests");ok(q.equals(Quest.ofDay(d,d*77,8)),"stable");for(var x:q)ok(x.type()!=Quest.Type.DRINK||x.drink()>=0&&x.drink()<8,"drink");
   int dd=Career.dailyDrink(d,8);ok(dd>=0&&dd<8,"daily");}
  var c=new Career(); var q=List.of(new Quest(Quest.Type.STREAK,-1,5,1000,15),new Quest(Quest.Type.DRINK,2,3,600,15),new Quest(Quest.Type.WISH,-1,2,800,15));
  long prizes=0;int done=0;for(int i=0;i<10;i++){var r=c.serve(new Career.Serve(2,5,false,false,i<2),1,q,100);prizes+=r.streakPrize();done+=r.completed().size();if(i==4)ok(r.masteryUp()==1,"bronze");}
  ok(c.streak==10&&done==3&&prizes==200+500+1500,"streak "+prizes+" "+done);
  var r=c.serve(new Career.Serve(2,3,false,false,false),1,q,0);ok(r.streak()==10&&r.streakPrize()==0,"3 keeps, no double prize");
  c.serve(new Career.Serve(2,2,false,false,false),1,q,0);ok(c.streak==0&&c.bestStreak==10,"reset");
  c.rollDay(2);ok(!c.done[0]&&c.progress[1]==0,"new day");
  ok(Career.streakBonus(99)==50&&Career.comfortBonus(8)==21&&Career.masteryBonus(40)==15,"caps");
  var rnd=new Random(1);Set<Wish> seen=new HashSet<>();for(int i=0;i<5000;i++){ok(Wish.pick(rnd,-1).step()==Wish.Step.PULL,"no milk");Wish w=Wish.pick(rnd,0.5);ok(w!=Wish.FLUFFY,"fluffy");seen.add(Wish.pick(rnd,0.18));ok(Guest.pickSpecial(rnd)!=Guest.REGULAR,"guest");}
  ok(seen.size()==6,"all wishes");
  for(double base:new double[]{.18,.45,.10,.25,.15,.5})for(Wish w:Wish.values())ok(w.foam(base)>0&&w.foam(base)<=.65,"foam");
  ok(62+6<72,"hot below scald");
  System.out.println("career tests ok");
 }}
