#!/usr/bin/env python3
"""The table decorations of the cafe: smooth octagonal plates, wicker baskets and painted food on top.

    python3 tools/gen_table.py            # textures, block/item models, blockstates, loot tables, recipes
    python3 tools/gen_table.py --check    # verifies the written models

Model units (16 = one block), 2 texture pixels per unit, front = north.
"""
import json
import math
import os
import sys

from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gen_decor as gd  # noqa: E402
import smooth  # noqa: E402
from smooth import box, octagon, ring  # noqa: E402
import style  # noqa: E402
from voxel_food import mix, rgb, rnd  # noqa: E402


# ------------------------------------------------------------------------------------------ materials (shaders)
def px(x, y, z):
    return int(math.floor(x * 2)), int(math.floor(y * 2)), int(math.floor(z * 2))


def flat(h):
    c = rgb(h)
    return lambda x, y, z, f: c


def speck(base, light, dark, salt=0, amount=0.22):
    cs = rgb(base), mix(rgb(base), rgb(light), 0.6), mix(rgb(base), rgb(dark), 0.6)

    def sh(x, y, z, f):
        r = rnd(*px(x, y, z), salt)
        return cs[1] if r < amount else cs[2] if r > 1 - amount else cs[0]
    return sh


def octd(x, z, cx=8.0, cz=8.0):
    dx, dz = abs(x - cx), abs(z - cz)
    return max(dx, dz, (dx + dz) * 0.7071)


def wicker(x, y, z, f):
    """Woven willow: little over-under bricks."""
    a, b, c = px(x, y, z)
    u = a + c
    row = b // 2
    cell = ((u + (row % 2) * 2) // 4) % 2
    if b % 2 == 0 and (u + row) % 4 == 0:
        return rgb("6E421E")
    tone = ("D39A52", "B87C3A") if cell else ("A66A2E", "8C5524")
    return rgb(tone[0] if b % 2 else tone[1])


def porcelain(r, cx=8.0, cz=8.0, flowers=True):
    """The upper face of a plate: a shaded well, a gold line and tiny painted flowers around the rim."""
    marks = {}
    if flowers:
        for k in range(8):
            a = 2 * math.pi * (k + 0.5) / 8
            x, z = int(math.floor((cx + math.cos(a) * (r - 1.45)) * 2)), int(math.floor((cz + math.sin(a) * (r - 1.45)) * 2))
            petal = ("D9808F", "8DA6C8")[k % 2]
            for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                marks[(x + dx, z + dz)] = petal
            marks[(x, z)] = "E8B84C"
            tx, tz = int(round(-math.sin(a) * 2.4)), int(round(math.cos(a) * 2.4))
            marks[(x + tx, z + tz)] = "86A878"
            marks[(x - tx, z - tz)] = "86A878"

    def sh(x, y, z, f):
        a, _, c = px(x, y, z)
        d = octd(x, z, cx, cz)
        if (a, c) in marks:
            return rgb(marks[(a, c)])
        if r - 1.0 < d <= r - 0.5:
            return rgb("D9B25E")
        return rgb("DDD3CA") if r - 2.9 < d <= r - 2.4 else rgb("F8F4EF")
    return sh


def gingham(base, mid, dark):
    """A checked cloth."""
    def sh(x, y, z, f):
        a, b, c = px(x, y, z)
        u, v = (a, c) if f in ("up", "down") else (a + c, b)
        n = (u // 2) % 2 + (v // 2) % 2
        return rgb((base, mid, dark)[n])
    return sh


def plate(r=6.5, y=0.0, cx=8.0, cz=8.0):
    return (octagon(cx, cz, r - 1.2, y, y + 0.5, flat("CBC2BA"), flat("E6DFD8"))
            + octagon(cx, cz, r, y + 0.5, y + 1.0, flat("E4DDD6"), porcelain(r, cx, cz)))


def fruit(x0, y0, z0, size, base, light, dark):
    """A chunky fruit: a cube with a shine on one upper corner."""
    def sh(x, y, z, f):
        if f == "up":
            return rgb(light) if x - x0 < size / 2 and z - z0 < size / 2 else rgb(base)
        return rgb(dark) if y - y0 < size / 3 else rgb(base)
    return box((x0, y0, z0), (x0 + size, y0 + size, z0 + size), sh, ("north", "south", "east", "west", "up"))     # it rests: no bottom


def basket(cloth):
    return (octagon(8, 8, 4.0, 0, 1, wicker, speck("8C5524", "A66A2E", "6E421E", 3))
            + octagon(8, 8, 4.6, 1, 3, wicker, speck("8C5524", "A66A2E", "6E421E", 3))
            + ring(8, 8, 5.4, 1.2, 3, 5.5, wicker, flat("7A4A22"), speck("D39A52", "E8B468", "A66A2E", 4, 0.3))
            # a checked cloth hanging over the front rim
            + [box((6.2, 5.5, 2.35), (9.8, 5.85, 4.0), gingham(*cloth)),
               box((6.2, 3.8, 2.35), (9.8, 5.5, 2.6), gingham(*cloth)),
               box((7.0, 3.0, 2.35), (9.0, 3.8, 2.6), gingham(*cloth), ("north", "south", "east", "west", "down"))])


def leaf_blade(x, z, y0, y1, along_x, base, light):
    sh = lambda a, y, c, f: rgb(light) if px(a, y, c)[1] % 3 == 0 else rgb(base)
    up = ("north", "south", "east", "west", "up")
    mid = y1 - 2.0                                                     # a narrow tip on a wide blade
    if along_x:
        return [box((x, y0, z), (x + 2.2, mid, z + 0.5), sh, up), box((x + 0.6, mid, z), (x + 1.6, y1, z + 0.5), sh, up)]
    return [box((x, y0, z), (x + 0.5, mid, z + 2.2), sh, up), box((x, mid, z + 0.6), (x + 0.5, y1, z + 1.6), sh, up)]


# ------------------------------------------------------------------------------------------ the blocks
def fruit_basket():
    p = basket(("F6E9D8", "E4A49C", "C25A58")) + octagon(8, 8, 4.1, 3, 4.5, speck("7A4A22", "8C5524", "66391A", 5))
    red, orange, yellow = ("D8303A", "FF7A78", "9E1C2C"), ("F28A1E", "FFC060", "C0620C"), ("F6CC2E", "FFEC80", "C89A12")
    green, plum = ("6CB43A", "AEE070", "468026"), ("8A3A82", "C06CB8", "5E2058")
    for x, z, y, s, c in ((4.2, 5.1, 4.5, 2.6, red), (7.1, 4.0, 4.5, 2.4, orange), (9.4, 6.0, 4.5, 2.5, yellow),
                          (4.6, 8.3, 4.5, 2.4, green), (7.4, 9.3, 4.5, 2.6, red), (9.6, 9.0, 4.5, 2.0, plum),
                          (6.9, 6.7, 5.4, 2.8, orange), (5.5, 6.4, 7.0, 1.7, plum), (8.4, 8.4, 6.6, 1.9, green)):
        p.append(fruit(x, y, z, s, *c))
    for i in range(3):                                                 # a bunch of bananas leaning out
        p.append(box((9.2 + i * 1.1, 6.5 + i * 0.2, 5.45 + i * 0.35), (10.2 + i * 1.1, 9.4 + i * 0.3, 6.45 + i * 0.35),
                     speck(yellow[0], yellow[1], yellow[2], 7)))
    p.append(box((6.1, 8.7, 7.0), (6.6, 9.8, 7.5), flat("5E3A1E")))                  # the stalk of a plum
    return p


def greens_basket():
    p = basket(("F4EEDC", "B8CCA8", "7C9A72")) + octagon(8, 8, 4.1, 3, 4.5, speck("4E8A2A", "74B43E", "36661C", 8, 0.35))
    for i, (x, z, top, ax) in enumerate(((4.0, 5.0, 10.5, True), (6.4, 4.2, 12.0, False), (8.8, 5.75, 11.0, True),
                                          (4.8, 7.6, 12.5, False), (7.0, 8.2, 13.5, True), (9.8, 8.0, 10.0, False),
                                          (5.8, 10.4, 9.5, True), (10.6, 5.0, 8.5, False), (8.2, 6.8, 9.2, False))):
        c = (("5C9E2E", "8CCC4C"), ("78B838", "ACDC60"), ("46821E", "68A834"))[i % 3]
        p += leaf_blade(x, z, 4.5, top, ax, *c)
    for x, z in ((5.2, 6.0), (9.0, 9.4), (8.9, 4.9)):
        p.append(fruit(x, 4.5, z, 1.8, "E23A30", "FF8678", "A81E24"))
    p.append(box((11.6, 4.5, 9.8), (12.2, 11.5, 10.4), speck("8A5628", "A86C34", "6C401C", 9)))     # a wooden fork
    return p


def plate_stack():
    p = []
    for i in range(4):
        p += octagon(8, 8, 3.8, i * 1.2, i * 1.2 + 0.5, flat("B9B0A8"), flat("D8D0C8"))
        edge = ("D9808F", "8DA6C8", "86A878", "D9B25E")[i]            # each plate of the stack has its own rim colour

        def side(x, y, z, f, i=i, edge=edge):
            return rgb(edge) if y > i * 1.2 + 0.75 else rgb("EEE8E2")
        p += octagon(8, 8, 5.0, i * 1.2 + 0.5, i * 1.2 + 1.2, side, porcelain(5.0))
    return p


def bottle(cx, cz, r, h, glass, light, label, cap):
    def body(x, y, z, f):
        if h * 0.22 <= y <= h * 0.62:
            if y < h * 0.22 + 0.5 or y > h * 0.62 - 0.5:
                return rgb("D9B25E")                                    # the gilt edges of the label
            across = z - cz if f in ("east", "west") else x - cx
            return rgb(cap) if abs(across) + abs(y - h * 0.42) < 1.2 else rgb(label)
        if f in ("north", "west") and (x - cx) < -r * 0.2:
            return rgb(light)
        return rgb(glass)
    return (octagon(cx, cz, r, 0, h, body, flat(light)) + octagon(cx, cz, r * 0.62, h, h + 1, flat(glass), flat(light))
            + [box((cx - 0.6, h + 1, cz - 0.6), (cx + 0.6, h + 3.5, cz + 0.6), flat(glass)),
               box((cx - 0.8, h + 3.5, cz - 0.8), (cx + 0.8, h + 4.7, cz + 0.8), speck(cap, label, cap, 11))])


def drink_bottles():
    return (bottle(5.0, 9.8, 2.3, 8.0, "B8641A", "F2A838", "FFF0D0", "8A2E22")
            + bottle(10.8, 10.4, 2.2, 9.5, "2C4A86", "5A86C8", "F4F0E8", "D9B25E")
            + bottle(8.4, 4.8, 2.4, 6.5, "C03048", "EE6A78", "FFE8E0", "4E8A34"))


def wine_glass(cx, cz, drink, drink_l):
    clear, edge = (224, 244, 250, 70), (236, 250, 255, 185)

    def wall(x, y, z, f):
        a, b, c = px(x, y, z)
        return edge if b in (9, 17) or (a + c) % 5 == 0 else clear
    p = octagon(cx, cz, 1.9, 0, 0.4, flat("DCEEF2"), flat("F4FDFF"))
    p.append(box((cx - 0.35, 0.4, cz - 0.35), (cx + 0.35, 4.5, cz + 0.35), flat("E6F6FA")))
    p += octagon(cx, cz, 1.5, 4.5, 5.0, flat("DCEEF2"), flat("F4FDFF"))
    p += octagon(cx, cz, 1.75, 5.0, 7.2, flat(drink), flat(drink_l))
    p += ring(cx, cz, 2.2, 0.4, 4.6, 9.0, wall, wall, lambda x, y, z, f: edge)
    return p


def table_glasses():
    return wine_glass(5.0, 9.0, "C8283E", "EA5A68") + wine_glass(11.0, 6.8, "F0A020", "FFD060")


def place_setting():
    p = plate(5.2)
    cloth = gingham("F6EEDC", "C3D3B4", "8CA982")
    p.append(box((3.4, 1.0, 6.4), (12.6, 1.35, 9.8), cloth))
    p.append(box((7.2, 1.35, 6.3), (8.8, 1.6, 9.9), speck("D9B25E", "F2D78E", "B1873A", 12)))     # a brass napkin ring
    silver, shine = flat("B9BEC4"), flat("E8ECF0")
    p += [box((1.4, 0, 5.6), (1.9, 0.4, 13), silver),                  # the fork on the left
          box((0.9, 0, 4.6), (2.4, 0.4, 5.6), silver)]
    for k in range(3):
        p.append(box((0.9 + k * 0.55, 0, 3.0), (1.3 + k * 0.55, 0.4, 4.6), shine))
    p += [box((14.1, 0, 8.0), (14.7, 0.4, 13), flat("8A5A30")),        # the knife on the right
          box((14.0, 0, 2.8), (15.0, 0.3, 8.0), shine),
          box((5.5, 0, 14.2), (9.8, 0.35, 14.8), silver)]              # the spoon above the plate
    p += octagon(10.9, 14.5, 1.0, 0, 0.45, silver, shine)
    return p


def pizza_plate():
    def top(x, y, z, f):
        d = octd(x, z)
        a, _, c = px(x, y, z)
        if d > 5.3:
            return rgb("C8721E") if rnd(a, 0, c, 21) < 0.3 else rgb("E69A38")
        for sx, sz, s in ((5.4, 5.6, 1.3), (10.2, 5.2, 1.2), (8.0, 8.2, 1.3), (5.2, 10.4, 1.2), (10.6, 10.2, 1.4)):
            if (x - sx) ** 2 + (z - sz) ** 2 < s * s:
                return rgb("F0625A") if x < sx and z < sz else rgb("C8302A")
        r = rnd(a, 1, c, 22)
        if d > 4.7:
            return rgb("D8481E")
        return rgb("4E8A2A") if r < 0.07 else rgb("FFF2AC") if r < 0.3 else rgb("E8A030") if r > 0.86 else rgb("FAD45C")
    p = plate(7.8) + octagon(8, 8, 6.2, 1.0, 1.8, speck("E69A38", "F2B050", "C8721E", 23), top)
    basil = speck("4E8E34", "78B84C", "336A24", 24, 0.3)
    for x, z in ((7.4, 4.4), (4.0, 7.6), (11.4, 7.4), (8.2, 11.6)):
        p += [box((x, 1.8, z), (x + 1.5, 2.15, z + 1.0), basil), box((x + 0.5, 1.8, z + 1.0), (x + 1.0, 2.15, z + 1.5), basil)]
    for x, z in ((6.4, 7.0), (9.6, 9.4), (9.2, 6.6), (7.0, 10.0)):     # olives
        p.append(box((x, 1.8, z), (x + 0.8, 2.3, z + 0.8), speck("3A2C30", "6A5660", "22181C", 25)))
    return p


def roast_platter():
    skin = speck("C05A14", "E88A28", "8E3A0A", 31, 0.28)
    gloss = lambda x, y, z, f: rgb("FFC058") if f == "up" and x < 7.6 and rnd(*px(x, y, z), 32) < 0.5 else skin(x, y, z, f)
    p = plate(7.8)
    p += octagon(8, 8, 5.8, 1.0, 1.4, speck("5C9E2E", "8CCC4C", "3E761C", 33, 0.35))
    p += octagon(7.6, 8.4, 3.6, 1.4, 3.4, skin, gloss) + octagon(7.6, 8.4, 3.0, 3.4, 5.0, skin, gloss)
    p += octagon(7.4, 8.2, 1.9, 5.0, 5.8, skin, gloss)
    for z in (4.0, 11.4):                                              # the drumsticks
        p += [box((10.2, 1.4, z), (12.0, 3.6, z + 1.6), gloss), box((12.0, 2.6, z + 0.35), (13.0, 4.2, z + 1.25), skin),
              box((13.0, 3.4, z + 0.45), (14.0, 4.6, z + 1.15), flat("FFF4DC"))]
    for x, z in ((3.0, 5.4), (3.6, 11.6), (8.2, 13.2), (7.4, 2.4), (2.8, 9.0)):
        p.append(fruit(x, 1.4, z, 1.1, "D82E34", "FF807A", "96181E"))
    return p


def sushi_board():
    wood = lambda x, y, z, f: rgb(("E8C285", "DCB070", "F0D098")[(px(x, y, z)[2] // 2 + (rnd(px(x, y, z)[0] // 5, 0, px(x, y, z)[2], 41) < 0.4)) % 3])
    framed = lambda x, y, z, f: rgb("A8743E") if f == "up" and (x < 2.0 or x > 14.0 or z < 4.0 or z > 12.0) else wood(x, y, z, f)
    p = [box((1.5, 2.0, 3.5), (14.5, 3.2, 12.5), framed),
         box((2.8, 0, 4.2), (4.6, 2.0, 11.8), speck("B8864A", "CC9A5C", "9C6E36", 42)),
         box((11.4, 0, 4.2), (13.2, 2.0, 11.8), speck("B8864A", "CC9A5C", "9C6E36", 42))]
    rice = speck("FBF8F0", "FFFFFF", "E6E0D2", 43, 0.3)

    def stripes(base, light):
        return lambda x, y, z, f: rgb(light) if (px(x, y, z)[0] + px(x, y, z)[2]) % 4 == 0 else rgb(base)
    tops = (stripes("F4784A", "FFC4A4"), stripes("D8343C", "F2767A"), stripes("F8D038", "FFE880"), stripes("F6B8A8", "FFF0EA"))
    for i, top in enumerate(tops):                                     # nigiri
        x = 2.3 + i * 2.7
        p += [box((x, 3.2, 4.4), (x + 2.0, 4.4, 7.4), rice), box((x - 0.15, 4.4, 4.2), (x + 2.15, 5.2, 7.6), top)]
    for i, core in enumerate(("F4784A", "6CB43A", "D8343C")):          # rolls wrapped in nori
        x = 2.4 + i * 2.8

        def cut(a, y, c, f, x=x, core=core):
            if f == "up":
                d = max(abs(a - x - 1.1), abs(c - 10.1))
                return rgb(core) if d < 0.5 else rgb("FBF8F0") if d < 1.0 else rgb("1E3A28")
            return rgb("1E3A28") if rnd(*px(a, y, c), 44) > 0.2 else rgb("2E5438")
        p.append(box((x, 3.2, 9.0), (x + 2.2, 5.2, 11.2), cut))
    p += octagon(12.3, 10.4, 1.1, 3.2, 4.3, speck("9CCC4C", "BCE070", "7AAA32", 45, 0.3))       # wasabi
    p.append(box((13.3, 3.2, 5.0), (13.7, 6.4, 7.6), speck("3E8A34", "62B04E", "2A6624", 46)))
    return p


BLOCKS = {  # id -> (builder, render type, recipe pattern, key)
    "fruit_basket": (fruit_basket, None, ["ACM", " B "], {"A": "apple", "C": "carrot", "M": "melon_slice", "B": "bowl"}),
    "greens_basket": (greens_basket, None, ["SKS", " B "], {"S": "wheat_seeds", "K": "carrot", "B": "bowl"}),
    "plate_stack": (plate_stack, None, [" Q ", "QNQ"], {"Q": "quartz", "N": "iron_nugget"}),
    "drink_bottles": (drink_bottles, None, ["BBB", " H "], {"B": "glass_bottle", "H": "honey_bottle"}),
    "table_glasses": (table_glasses, "minecraft:translucent", ["P P", " N ", " P "], {"P": "glass_pane", "N": "iron_nugget"}),
    "place_setting": (place_setting, None, ["NQN", " W "], {"N": "iron_nugget", "Q": "quartz", "W": "yellow_wool"}),
    "pizza_plate": (pizza_plate, None, ["MSM", " B ", " Q "], {"M": "brown_mushroom", "S": "sweet_berries", "B": "bread", "Q": "quartz"}),
    "roast_platter": (roast_platter, None, [" C ", "SQS"], {"C": "cooked_chicken", "S": "sweet_berries", "Q": "quartz"}),
    "sushi_board": (sushi_board, None, ["SKS", "WWW"], {"S": "cooked_salmon", "K": "dried_kelp", "W": "bamboo_slab"}),
}
WOODEN = ["fruit_basket", "greens_basket", "sushi_board"]


# ------------------------------------------------------------------------------------------ files
def gui_display(parts):
    """The standard block display, but the flat and small things fill their inventory slot better."""
    d = dict(gd.DISPLAY)
    pts = []
    for e in parts:
        for y in (e["f"][1], e["t"][1]):
            for x in (e["f"][0], e["t"][0]):
                for z in (e["f"][2], e["t"][2]):
                    a, b = (smooth.turn(x, z, *e["rot"]) if e["rot"] else (x, z))
                    pts.append((a - 8, y - 8, b - 8))
    ry, rx = math.radians(225), math.radians(30)
    q = []
    for x, y, z in pts:
        x, z = x * math.cos(ry) + z * math.sin(ry), -x * math.sin(ry) + z * math.cos(ry)
        y, z = y * math.cos(rx) - z * math.sin(rx), y * math.sin(rx) + z * math.cos(rx)
        q.append((x, y))
    lo = [min(p[i] for p in q) for i in (0, 1)]
    hi = [max(p[i] for p in q) for i in (0, 1)]
    s = min(15.0 / max(hi[0] - lo[0], hi[1] - lo[1]), 1.1)
    d["gui"] = {"rotation": [30, 225, 0], "translation": [round(-(lo[i] + hi[i]) / 2 * s, 2) for i in (0, 1)] + [0],
                "scale": [round(s, 3)] * 3}
    return d


def write(name, parts, render_type):
    patches, index, ids = [], {}, []
    for part in parts:
        face_ids = {}
        for face, im, w, h in smooth.patches_of(part):
            key = (w, h, im.tobytes())
            if key not in index:
                index[key] = len(patches)
                patches.append(style.grade(im))
            face_ids[face] = index[key]
        ids.append(face_ids)
    atlas, place = smooth.pack(patches, gutter=2, smallest=64)
    size = atlas.shape[0]
    k = 16.0 / size
    Image.fromarray(atlas, "RGBA").save(os.path.join(gd.ASSETS, "textures", "block", name + ".png"), optimize=True)

    def uv(i):
        x, y = place[i]
        h, w = patches[i].shape[:2]
        return [x * k, y * k, (x + w) * k, (y + h) * k]
    elements = [smooth.element(p["f"], p["t"], {f: uv(i) for f, i in fi.items()}, p["rot"]) for p, fi in zip(parts, ids)]
    tex = "aestheticjobs:block/" + name
    model = {"credit": "tools/gen_table.py", "parent": "minecraft:block/block", "ambientocclusion": False}
    if render_type:
        model["render_type"] = render_type
    model.update({"texture_size": [size, size], "textures": {"particle": tex, "t": tex}, "elements": elements,
                  "display": gui_display(parts)})
    with open(os.path.join(gd.ASSETS, "models", "block", name + ".json"), "w") as f:
        json.dump(model, f, separators=(",", ":"))
        f.write("\n")
    return len(elements), size


def main():
    for name, (build, rtype, pattern, key) in BLOCKS.items():
        n, size = write(name, build(), rtype)
        print(f"{name}: {n} elements, {size} px")
        gd.write_json(os.path.join(gd.ASSETS, "blockstates", name + ".json"),
                      {"variants": {f"facing={f}": gd.variant(name, f) for f in gd.Y}})
        gd.write_json(os.path.join(gd.ASSETS, "models", "item", name + ".json"), {"parent": "aestheticjobs:block/" + name})
        gd.loot(name)
        gd.write_json(os.path.join(gd.DATA, "recipe", name + ".json"), {
            "type": "minecraft:crafting_shaped", "category": "misc", "pattern": pattern,
            "key": {k: {"item": "minecraft:" + v} for k, v in key.items()},
            "result": {"id": "aestheticjobs:" + name, "count": 1}})


def check():
    for name, (build, *_) in BLOCKS.items():
        m = json.load(open(os.path.join(gd.ASSETS, "models", "block", name + ".json")))
        im = Image.open(os.path.join(gd.ASSETS, "textures", "block", name + ".png"))
        assert im.width == im.height and im.width & (im.width - 1) == 0, (name, im.size)
        for e in m["elements"]:
            assert all(-16 <= a <= b <= 32 for a, b in zip(e["from"], e["to"])), (name, e)
            for face in e["faces"]:                                    # the real (turned) corners stay inside the block
                axis, d = smooth.FACES[face][:2]
                r = e.get("rotation")
                for x in (e["from"][0], e["to"][0]):
                    for z in (e["from"][2], e["to"][2]):
                        x2, z2 = smooth.turn(x, z, r["angle"], r["origin"][0], r["origin"][2]) if r else (x, z)
                        assert -0.01 <= x2 <= 16.01 and -0.01 <= z2 <= 16.01, (name, "outside the block", e)
                assert 0 <= e["from"][1] and e["to"][1] <= 16, (name, e)
            if "rotation" in e:
                assert e["rotation"]["angle"] in (-45, 45), (name, e)
            for d in e["faces"].values():
                assert all(0 <= v <= 16 for v in d["uv"]), (name, d)
        boxes = []                                                     # nothing floats: every piece touches the table or another
        for e in m["elements"]:
            r = e.get("rotation")
            pts = [(smooth.turn(x, z, r["angle"], r["origin"][0], r["origin"][2]) if r else (x, z))
                   for x in (e["from"][0], e["to"][0]) for z in (e["from"][2], e["to"][2])]
            boxes.append(((min(p[0] for p in pts), e["from"][1], min(p[1] for p in pts)),
                          (max(p[0] for p in pts), e["to"][1], max(p[1] for p in pts))))
        held = {i for i, b in enumerate(boxes) if b[0][1] <= 0.05}
        grew = True
        while grew:
            grew = False
            for i, (lo, hi) in enumerate(boxes):
                if i not in held and any(all(lo[k] <= boxes[j][1][k] + 0.05 and boxes[j][0][k] <= hi[k] + 0.05 for k in range(3)) for j in held):
                    held.add(i)
                    grew = True
        assert len(held) == len(boxes), (name, "floating", [boxes[i] for i in range(len(boxes)) if i not in held])
        bad = smooth.fighting_faces(m["elements"])
        assert not bad, (name, "flickering", len(bad), [(m["elements"][i]["from"], m["elements"][i]["to"],
                         m["elements"][j]["from"], m["elements"][j]["to"], f) for i, j, f, o in bad[:4]])
    print("checked", len(BLOCKS), "table blocks")


if __name__ == "__main__":
    check() if "--check" in sys.argv else main()
