package dev.aestheticjobs.item;

import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.Order;
import dev.aestheticjobs.cafe.OrderExtra;
import dev.aestheticjobs.cafe.career.Guest;
import dev.aestheticjobs.cafe.career.Wish;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.registry.ModComponents;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

/** A paper slip from the till: who ordered what, and what the recipe needs. */
public class OrderTicketItem extends Item {
    public OrderTicketItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        Order order = stack.get(ModComponents.ORDER.get());
        if (order == null) return;
        Drink drink = Drink.byIndex(order.drink());
        Component who = order.isPlayerOrder() ? Component.literal(order.buyerName())
                : Component.translatable("customer.aestheticjobs." + Math.floorMod(order.customer(), Order.CUSTOMERS));
        tooltip.add(Component.translatable("item.aestheticjobs.order_ticket.customer", who).withStyle(ChatFormatting.GRAY));
        if (drink != null) {
            tooltip.add(Component.translatable("item.aestheticjobs.order_ticket.drink", drink.displayName(), Money.format(drink.priceCents()))
                    .withStyle(ChatFormatting.GRAY));
            for (Drink.Supply s : drink.supplies()) {
                tooltip.add(Component.literal("  \u2022 ").append(s.item().getDescription()).withStyle(ChatFormatting.DARK_GRAY));
            }
        }
        Dessert dessert = Dessert.byIndex(order.dessert());
        if (dessert != null) {
            tooltip.add(Component.translatable("item.aestheticjobs.order_ticket.dessert", dessert.displayName(), Money.format(dessert.priceCents()))
                    .withStyle(ChatFormatting.GRAY));
        }
        OrderExtra special = stack.getOrDefault(ModComponents.ORDER_EXTRA.get(), OrderExtra.PLAIN);
        if (special.guestType() != Guest.REGULAR) {
            tooltip.add(Component.translatable("guest.aestheticjobs." + special.guestType().id()).withStyle(ChatFormatting.GOLD));
        }
        if (special.wishType() != Wish.NONE) {
            tooltip.add(Component.translatable("wish.aestheticjobs." + special.wishType().id()).withStyle(ChatFormatting.AQUA));
        }
        tooltip.add(Component.translatable("item.aestheticjobs.order_ticket.hint").withStyle(ChatFormatting.DARK_GRAY));
    }
}
