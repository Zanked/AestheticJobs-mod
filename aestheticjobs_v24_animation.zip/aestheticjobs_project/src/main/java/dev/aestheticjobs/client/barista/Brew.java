package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.cafe.Art;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.cafe.career.Wish;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;

/** Everything that is carried from one step of the recipe to the next. */
public final class Brew {
    public static final int GRID = 32;

    public final Drink drink;
    public final BlockPos pos;
    public final List<Integer> scores = new ArrayList<>();

    /** The special wish of the guest: it moves the targets of the shot and of the milk. */
    public Wish wish = Wish.NONE;
    /** 1..10, set by the grinder: coarser = a faster shot. */
    public double fineness = 5.0;
    /** The fineness that is right for these beans today (found by the barista with test shots). */
    public double idealFineness = 7.0;
    /** 0..1: how uneven the puck was tamped (a streaming, sputtering shot). */
    public double channeling = 0.0;
    /** 0..1: how hard the puck was pressed (0.70 = right on the 14 kg mark); a harder puck runs slower. */
    public double tampForce = 0.70;
    /** 0..100: the result of the last shot, and how much crema survived. */
    public int shotQuality = 100;
    public double cremaKept = 1.0;
    /** From the steaming: share of foam, microfoam quality 0..1, temperature. */
    public double foam = 0.2, micro = 1.0, milkTemp = 60;

    /** The surface of the milk (32x32, 0..1) and the decoration on top (16x16 chars, '0' = nothing). */
    public final float[] milk = new float[GRID * GRID];
    public final char[] deco = new char[Drink.CELLS];

    public Brew(Drink drink, BlockPos pos) {
        this.drink = drink;
        this.pos = pos;
        java.util.Arrays.fill(deco, '0');
        if (!hasStep(Step.POUR)) {                 // no pouring: the surface is plain foam (macchiato)
            java.util.Arrays.fill(milk, 1.0F);
        }
    }

    public boolean hasStep(Step s) {
        for (Step x : drink.steps()) if (x == s) return true;
        return false;
    }

    /** The picture on the surface as the 16x16 string that goes into the cup. */
    public String art() {
        if (!hasStep(Step.POUR) && !hasStep(Step.CARAMEL)) {
            return Art.crema(Math.min(shotQuality, (int) Math.round(cremaKept * 100)), pos.asLong());
        }
        StringBuilder sb = new StringBuilder(Drink.CELLS);
        for (int y = 0; y < Drink.SIZE; y++) {
            for (int x = 0; x < Drink.SIZE; x++) {
                if (!Drink.inCup(x, y)) {
                    sb.append('0');
                    continue;
                }
                char d = deco[y * Drink.SIZE + x];
                if (d != '0') {
                    sb.append(d);
                    continue;
                }
                float a = milk[(y * 2) * GRID + x * 2] + milk[(y * 2) * GRID + x * 2 + 1]
                        + milk[(y * 2 + 1) * GRID + x * 2] + milk[(y * 2 + 1) * GRID + x * 2 + 1];
                sb.append(a / 4.0F > 0.5F ? '1' : '0');
            }
        }
        return sb.toString();
    }

    public int stars(int quality) {
        if (quality >= 90) return 5;
        if (quality >= 75) return 4;
        if (quality >= 60) return 3;
        if (quality >= 40) return 2;
        return 1;
    }

    /** The quality the server will compute from the scores (the art step is estimated from the picture). */
    public int estimate() {
        Step[] steps = drink.steps();
        double sum = 0, w = 0;
        for (int i = 0; i < steps.length && i < scores.size(); i++) {
            sum += scores.get(i) * steps[i].weight();
            w += steps[i].weight();
        }
        return w == 0 ? 0 : (int) Math.round(sum / w);
    }
}
