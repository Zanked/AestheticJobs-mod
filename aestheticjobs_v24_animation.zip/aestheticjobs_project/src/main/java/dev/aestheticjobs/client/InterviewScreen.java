package dev.aestheticjobs.client;

import com.mojang.math.Axis;
import dev.aestheticjobs.client.barista.Ui;
import dev.aestheticjobs.network.InterviewAnswerPayload;
import dev.aestheticjobs.network.InterviewCancelPayload;
import dev.aestheticjobs.network.InterviewStatePayload;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

/**
 * The interview window: the real manager (the entity of the world, with his face) on the left, his words in a speech
 * bubble that is typed out, the answers as buttons, and the IMPRESSION bar that moves with every answer. A phone call
 * with a ringing phone checks a bluff; at the end a stamp lands: hired (with confetti) or refused.
 * Everything is drawn on one canvas scaled to the window (ScaledScreen), so the texts always fit and have one size.
 */
public class InterviewScreen extends ScaledScreen {
    private static final int VW = 400, MARGIN = 12, PORT_W = 118, RX = MARGIN + PORT_W + 10, RW = VW - RX - MARGIN;
    private static final int BUBBLE_W = RW - 20, OPT_W = RW - 38, LINE_H = 9, BAR_Y = 37, BUBBLE_Y = 54;

    private int managerId;
    private InterviewStatePayload state;

    private List<String> reactLines = List.of(), lineLines = List.of();
    private final List<List<String>> optionLines = new ArrayList<>();
    private int totalChars;
    private float typed;
    private boolean ready, answered;
    private int readyT, callT, stampT;
    private float shownImpression;
    private int popT = -1, popDelta;

    // the layout of the current frame
    private int bubbleH, optsY, canvasH = 236;
    private final List<int[]> optBoxes = new ArrayList<>();       // x, y, w, h

    private final int[] confettiX = new int[40], confettiV = new int[40], confettiC = new int[40];

    public InterviewScreen(InterviewStatePayload payload) {
        super(Component.translatable("interview.title"));
        this.state = payload;
        this.managerId = payload.manager();
        this.shownImpression = payload.impression();
        java.util.Random r = new java.util.Random(payload.manager() * 31L + 7L);
        int[] palette = {0xFFE3A08C, 0xFFF6D58A, 0xFFA9C79A, 0xFFB8C8E8, 0xFFF0B8D8};
        for (int i = 0; i < confettiX.length; i++) {
            confettiX[i] = r.nextInt(RW);
            confettiV[i] = 6 + r.nextInt(10);
            confettiC[i] = palette[r.nextInt(palette.length)];
        }
    }

    public int manager() {
        return managerId;
    }

    /** A new state from the server (the answer was taken): the manager answers. */
    public void update(InterviewStatePayload payload) {
        this.state = payload;
        this.managerId = payload.manager();
        rebuildText();
        Ui.sound(SoundEvents.UI_BUTTON_CLICK.value(), 1.5F, 0.3F);
    }

    @Override
    protected void init() {
        rebuildText();
    }

    private static Component arg(String s) {
        if (s.startsWith("t:")) return Component.translatable(s.substring(2));
        if (s.startsWith("T:")) {
            Component out = Component.empty();
            String[] keys = s.substring(2).split(",");
            for (int i = 0; i < keys.length; i++) out = Component.empty().append(out).append(i == 0 ? "" : ", ").append(Component.translatable(keys[i]));
            return out;
        }
        return Component.literal(s);
    }

    private static Component tr(String key, List<String> args) {
        Object[] a = new Object[args.size()];
        for (int i = 0; i < a.length; i++) a[i] = arg(args.get(i));
        return Component.translatable(key, a);
    }

    private void rebuildText() {
        if (font == null) return;
        reactLines = state.reactKey().isEmpty() ? List.of() : wrap(font, tr(state.reactKey(), state.reactArgs()), BUBBLE_W);
        lineLines = state.lineKey().isEmpty() ? List.of() : wrap(font, tr(state.lineKey(), state.lineArgs()), BUBBLE_W);
        optionLines.clear();
        for (String key : state.options()) optionLines.add(key.isEmpty() ? List.of() : wrap(font, Component.translatable(key), OPT_W));
        totalChars = 0;
        for (String s : reactLines) totalChars += s.length();
        for (String s : lineLines) totalChars += s.length();
        typed = 0.0F;
        ready = totalChars == 0;
        readyT = 0;
        answered = false;
        callT = 0;
        stampT = 0;
        if (state.delta() != 0) {
            popT = 0;
            popDelta = state.delta();
        }
    }

    private boolean finalPhase() {
        return state.phase() == InterviewStatePayload.HIRED || state.phase() == InterviewStatePayload.REJECTED;
    }

    @Override
    protected int vw() {
        return VW;
    }

    @Override
    protected int vh() {
        return canvasH;
    }

    @Override
    protected void prepare() {
        int lines = reactLines.size() + lineLines.size();
        int gap = reactLines.isEmpty() || lineLines.isEmpty() ? 0 : 4;
        bubbleH = Math.max(40, lines * LINE_H + gap + 16);
        optsY = BUBBLE_Y + bubbleH + 8;
        optBoxes.clear();
        int y = optsY;
        if (state.phase() == InterviewStatePayload.CALL) {
            y += 68;
        } else {
            for (List<String> ol : optionLines) {
                int h = Math.max(22, ol.size() * LINE_H + 10);
                optBoxes.add(new int[]{RX, y, RW, h});
                y += h + 5;
            }
        }
        canvasH = Math.max(236, y + 10);
    }

    @Override
    public void tick() {
        if (typed < totalChars) {
            typed += 3.0F;
            if (typed >= totalChars) {
                typed = totalChars;
                ready = true;
            }
        } else if (!ready) {
            ready = true;
        }
        if (ready) {
            readyT++;
            if (finalPhase()) stampT++;
        }
        shownImpression += (state.impression() - shownImpression) * 0.12F;
        if (Math.abs(state.impression() - shownImpression) < 0.2F) shownImpression = state.impression();
        if (popT >= 0 && ++popT > 44) popT = -1;
        if (state.phase() == InterviewStatePayload.CALL && !answered) {
            if (++callT >= 50) {
                answered = true;
                PacketDistributor.sendToServer(new InterviewAnswerPayload(0));
            }
        }
    }

    // ------------------------------------------------------------------ drawing

    @Override
    protected void draw(GuiGraphics g, int mx, int my, float partial) {
        int h = canvasH;
        Ui.box(g, 0, 0, VW, h, Ui.BORDER, Ui.BG);
        g.renderOutline(3, 3, VW - 6, h - 6, 0x66FFFFFF);

        drawPortrait(g, mx, my, h);

        // the title and the step
        Ui.text(g, font, fit(font, Component.translatable("interview.title"), RW - 80), RX, 12, Ui.INK);
        if (state.phase() == InterviewStatePayload.Q) {
            Component step = Component.translatable("interview.step", state.step(), state.total());
            Ui.text(g, font, step, RX + RW - font.width(step), 12, Ui.LABEL);
        }
        drawBar(g, partial);

        drawBubble(g);
        if (state.phase() == InterviewStatePayload.CALL) {
            drawPhone(g, partial);
        } else {
            drawOptions(g, mx, my);
        }
        if (finalPhase() && ready) drawStamp(g, partial);
    }

    private void drawPortrait(GuiGraphics g, int mx, int my, int h) {
        int bh = h - 2 * MARGIN;
        Ui.box(g, MARGIN, MARGIN, PORT_W, bh, Ui.KHAKI, Ui.TAN);
        Entity e = Minecraft.getInstance().level == null ? null : Minecraft.getInstance().level.getEntity(managerId);
        int plateH = 26;
        if (e instanceof LivingEntity living) {
            InventoryScreen.renderEntityInInventoryFollowsMouse(g, MARGIN + 3, MARGIN + 3, MARGIN + PORT_W - 3, MARGIN + bh - plateH - 3,
                    78, 0.0625F, mx, my, living);
        }
        Ui.box(g, MARGIN + 4, MARGIN + bh - plateH, PORT_W - 8, plateH - 4, Ui.KHAKI, Ui.CREAM);
        Component name = e == null ? Component.empty() : e.getName();
        Ui.centered(g, font, fit(font, name, PORT_W - 16), MARGIN + PORT_W / 2, MARGIN + bh - plateH + 4, Ui.INK);
        Ui.centered(g, font, fit(font, Component.translatable("interview.manager"), PORT_W - 16), MARGIN + PORT_W / 2, MARGIN + bh - plateH + 13, Ui.LABEL);
    }

    private void drawBar(GuiGraphics g, float partial) {
        Ui.text(g, font, fit(font, Component.translatable("interview.impression"), RW - 40), RX, 26, Ui.LABEL);
        double v = Math.max(0.0D, Math.min(1.0D, (shownImpression) / 100.0D));
        int color = v < 0.5D ? Ui.lerp(Ui.BAD_D, Ui.WARN_D, v * 2.0D) : Ui.lerp(Ui.WARN_D, Ui.GOOD_D, (v - 0.5D) * 2.0D);
        Ui.bar(g, RX, BAR_Y, RW, 8, v, color);
        int tx = RX + (int) Math.round(RW * state.threshold() / 100.0D);            // the hiring line
        g.fill(tx, BAR_Y - 3, tx + 1, BAR_Y + 11, Ui.INK);
        g.fill(tx - 1, BAR_Y - 4, tx + 2, BAR_Y - 3, Ui.INK);
        if (popT >= 0) {                                                            // +12 / -8 floats up from the end of the bar
            float p = (popT + partial) / 44.0F;
            int alpha = Math.max(8, (int) (255 * (1.0F - p * p)));
            Component pop = Component.literal((popDelta > 0 ? "+" : "") + popDelta).withStyle(popDelta > 0 ? ChatFormatting.DARK_GREEN : ChatFormatting.DARK_RED);
            int px = RX + (int) Math.round(RW * v) - font.width(pop) / 2;
            g.drawString(font, pop, Math.max(RX, Math.min(RX + RW - font.width(pop), px)), BAR_Y + 12 - (int) (p * 12), (alpha << 24) | 0xFFFFFF, false);
        }
    }

    private void drawBubble(GuiGraphics g) {
        Ui.box(g, RX, BUBBLE_Y, RW, bubbleH, Ui.KHAKI, Ui.CREAM);
        g.fill(RX - 4, BUBBLE_Y + 12, RX, BUBBLE_Y + 13, Ui.KHAKI);                  // the tail towards the manager
        g.fill(RX - 3, BUBBLE_Y + 11, RX, BUBBLE_Y + 14, Ui.CREAM);
        int left = (int) typed;
        int y = BUBBLE_Y + 8;
        for (String line : reactLines) {
            int take = Math.max(0, Math.min(line.length(), left));
            left -= line.length();
            if (take > 0) Ui.text(g, font, Component.literal(line.substring(0, take)).withStyle(ChatFormatting.ITALIC), RX + 10, y, Ui.LABEL);
            y += LINE_H;
        }
        if (!reactLines.isEmpty() && !lineLines.isEmpty()) y += 4;
        for (String line : lineLines) {
            int take = Math.max(0, Math.min(line.length(), left));
            left -= line.length();
            if (take > 0) Ui.text(g, font, Component.literal(line.substring(0, take)), RX + 10, y, Ui.INK);
            y += LINE_H;
        }
    }

    private void drawOptions(GuiGraphics g, int mx, int my) {
        if (!ready) return;
        float fade = Math.min(1.0F, readyT / 6.0F);
        for (int i = 0; i < optBoxes.size(); i++) {
            int[] b = optBoxes.get(i);
            int slide = (int) ((1.0F - fade) * 8.0F);
            int y = b[1] + slide;
            boolean enabled = !answered;
            boolean hover = enabled && fade >= 1.0F && Ui.in(mx, my, b[0], b[1], b[2], b[3]);
            boolean last = finalPhase();
            int border = hover ? Ui.GOOD_D : Ui.KHAKI;
            int fill = !enabled ? 0xFFE9E0CC : hover ? 0xFFFBF1D6 : Ui.TAN;
            if (last) {
                border = Ui.GOOD_D;
                fill = hover ? 0xFFC9E0BA : Ui.GOOD;
            }
            Ui.box(g, b[0], y, b[2], b[3], border, fill);
            // the number badge
            int cy = y + b[3] / 2;
            if (!last) {
                Ui.disc(g, b[0] + 13, cy, 7, hover ? Ui.GOOD_D : Ui.KHAKI);
                Ui.centered(g, font, Component.literal(Integer.toString(i + 1)), b[0] + 13, cy - 4, Ui.CREAM);
            }
            List<String> lines = optionLines.get(i);
            int ty = y + (b[3] - lines.size() * LINE_H) / 2 + 1;
            int tx = last ? b[0] + b[2] / 2 : b[0] + 26;
            for (String line : lines) {
                Component c = Component.literal(line);
                if (last) {
                    Ui.centered(g, font, c, tx, ty, enabled ? Ui.INK : 0xFFB5A58A);
                } else {
                    Ui.text(g, font, c, tx, ty, enabled ? Ui.INK : 0xFFB5A58A);
                }
                ty += LINE_H;
            }
        }
    }

    /** The phone call: a phone that rings and shakes, rings around it, dots. */
    private void drawPhone(GuiGraphics g, float partial) {
        int y = optsY;
        Ui.box(g, RX, y, RW, 60, Ui.KHAKI, Ui.TAN);
        float t = callT + partial;
        int cx = RX + 40, cy = y + 30;
        int shake = t < 44 && ((int) (t / 2)) % 2 == 0 ? 1 : -1;
        Ui.box(g, cx - 10 + shake, cy - 18, 20, 36, Ui.INK, 0xFF52332A);           // the phone
        g.fill(cx - 7 + shake, cy - 14, cx + 7 + shake, cy + 8, 0xFFCDD3D6);        // the screen
        Ui.disc(g, cx + shake, cy + 13, 2, 0xFFCDD3D6);
        for (int i = 0; i < 3; i++) {                                               // the rings
            float p = ((t + i * 6) % 18.0F) / 18.0F;
            int alpha = Math.max(8, (int) (200 * (1.0F - p)));
            int r = 14 + (int) (p * 16);
            Ui.ring(g, cx, cy, r, 1, (alpha << 24) | 0x9A8A6A);
        }
        String dots = ".".repeat(1 + ((int) t / 8) % 3);
        Ui.text(g, font, Component.translatable("interview.calling.dots", dots), RX + 80, cy - 4, Ui.INK);
    }

    /** The stamp: lands with a bump, tilted; green with confetti or red. */
    private void drawStamp(GuiGraphics g, float partial) {
        boolean good = state.phase() == InterviewStatePayload.HIRED;
        float t = stampT + partial;
        float p = Math.min(1.0F, t / 8.0F);
        float ease = 1.0F - (1.0F - p) * (1.0F - p);
        float s = 2.8F - 1.8F * ease;
        int alpha = Math.max(8, (int) (255 * p));
        int rgb = good ? 0x4F8A4A : 0xB5543A;
        Component text = Component.translatable(good ? "interview.stamp.hired" : "interview.stamp.rejected");
        int tw = font.width(text);
        int cx = RX + RW / 2, cy = optsY - 6 + (optBoxes.isEmpty() ? 0 : -2);
        cy = Math.min(cy, canvasH - 70);
        g.pose().pushPose();
        g.pose().translate(cx, cy + 16, 0.0F);
        g.pose().mulPose(Axis.ZP.rotationDegrees(-10.0F));
        g.pose().scale(s, s, 1.0F);
        int w = tw * 2 + 14, h = 28;
        int col = (alpha << 24) | rgb;
        g.renderOutline(-w / 2, -h / 2, w, h, col);
        g.renderOutline(-w / 2 + 2, -h / 2 + 2, w - 4, h - 4, col);
        g.pose().pushPose();
        g.pose().scale(2.0F, 2.0F, 1.0F);
        g.drawString(font, text, -tw / 2, -4, col, false);
        g.pose().popPose();
        g.pose().popPose();
        if (good) {
            for (int i = 0; i < confettiX.length; i++) {
                float ft = t - i * 0.4F;
                if (ft < 0) continue;
                int x = RX + (confettiX[i] + (int) (Math.sin(ft * 0.3F + i) * 6.0F));
                int y = 20 + (int) (confettiV[i] * 0.5F * ft + 0.05F * ft * ft);
                if (y < canvasH - 14 && x > RX && x < RX + RW) g.fill(x, y, x + 3, y + 3, confettiC[i]);
            }
        }
    }

    // ------------------------------------------------------------------ input

    private void choose(int i) {
        if (!ready || answered || i < 0) return;
        if (finalPhase()) {
            onClose();
            return;
        }
        if (state.phase() != InterviewStatePayload.Q && state.phase() != InterviewStatePayload.OFFER) return;
        if (i >= state.options().size()) return;
        answered = true;
        Ui.sound(SoundEvents.UI_BUTTON_CLICK.value(), 1.1F, 0.5F);
        PacketDistributor.sendToServer(new InterviewAnswerPayload(i));
    }

    @Override
    protected boolean click(int mx, int my, int button) {
        if (button != 0) return false;
        if (!ready) {
            typed = totalChars;
            ready = true;
            return true;
        }
        for (int i = 0; i < optBoxes.size(); i++) {
            int[] b = optBoxes.get(i);
            if (Ui.in(mx, my, b[0], b[1], b[2], b[3])) {
                choose(i);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (key == GLFW.GLFW_KEY_SPACE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
            if (!ready) {
                typed = totalChars;
                ready = true;
            } else if (finalPhase()) {
                onClose();
            }
            return true;
        }
        int n = key >= GLFW.GLFW_KEY_1 && key <= GLFW.GLFW_KEY_9 ? key - GLFW.GLFW_KEY_1 : key >= GLFW.GLFW_KEY_KP_1 && key <= GLFW.GLFW_KEY_KP_9 ? key - GLFW.GLFW_KEY_KP_1 : -1;
        if (n >= 0 && ready && !finalPhase()) {
            choose(n);
            return true;
        }
        return super.keyPressed(key, scanCode, modifiers);
    }

    @Override
    public void onClose() {
        PacketDistributor.sendToServer(new InterviewCancelPayload());
        super.onClose();
    }
}
