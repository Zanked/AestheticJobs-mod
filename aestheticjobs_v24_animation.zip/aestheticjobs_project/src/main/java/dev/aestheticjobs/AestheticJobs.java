package dev.aestheticjobs;

import com.mojang.logging.LogUtils;
import dev.aestheticjobs.client.ClientSetup;
import dev.aestheticjobs.client.barista.CameraRig;
import dev.aestheticjobs.cafe.CafeFraud;
import dev.aestheticjobs.cafe.CafeServer;
import dev.aestheticjobs.cafe.CafeTreat;
import dev.aestheticjobs.client.FoodAnimation;
import dev.aestheticjobs.command.BankCommands;
import dev.aestheticjobs.command.CafeCommands;
import dev.aestheticjobs.command.JobCommands;
import dev.aestheticjobs.command.ShiftCommands;
import dev.aestheticjobs.job.ProfessionManager;
import dev.aestheticjobs.job.Shift;
import dev.aestheticjobs.network.ModNetwork;
import dev.aestheticjobs.registry.ModBlockEntities;
import dev.aestheticjobs.registry.ModBlocks;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.registry.ModCreativeTabs;
import dev.aestheticjobs.registry.ModEntities;
import dev.aestheticjobs.registry.ModItems;
import dev.aestheticjobs.registry.ModMenus;
import dev.aestheticjobs.registry.ModSounds;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.common.NeoForge;
import org.slf4j.Logger;

@Mod(AestheticJobs.MODID)
public class AestheticJobs {
    public static final String MODID = "aestheticjobs";
    public static final Logger LOGGER = LogUtils.getLogger();

    public AestheticJobs(IEventBus modEventBus, ModContainer modContainer) {
        ModComponents.COMPONENTS.register(modEventBus);
        ModBlocks.BLOCKS.register(modEventBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modEventBus);
        ModEntities.ENTITIES.register(modEventBus);
        ModItems.ITEMS.register(modEventBus);
        ModMenus.MENUS.register(modEventBus);
        ModSounds.SOUNDS.register(modEventBus);
        ModCreativeTabs.TABS.register(modEventBus);

        modEventBus.addListener(ModNetwork::register);
        modEventBus.addListener(ModEntities::registerAttributes);

        NeoForge.EVENT_BUS.addListener(BankCommands::register);
        NeoForge.EVENT_BUS.addListener(JobCommands::register);
        NeoForge.EVENT_BUS.addListener(ShiftCommands::register);
        NeoForge.EVENT_BUS.addListener(CafeCommands::register);
        NeoForge.EVENT_BUS.addListener(CafeServer::onServerTick);
        NeoForge.EVENT_BUS.addListener(CafeServer::onInteractPlayer);
        NeoForge.EVENT_BUS.addListener(CafeFraud::onUseFinish);
        NeoForge.EVENT_BUS.addListener(CafeTreat::onUseFinish);
        NeoForge.EVENT_BUS.addListener(Shift::onPlayerTick);
        NeoForge.EVENT_BUS.addListener(Shift::onLogin);
        NeoForge.EVENT_BUS.addListener(Shift::onLogout);
        NeoForge.EVENT_BUS.addListener(ProfessionManager::onAddReloadListeners);

        if (FMLEnvironment.dist == Dist.CLIENT) {
            modEventBus.addListener(ClientSetup::registerRenderers);
            modEventBus.addListener(ClientSetup::registerLayers);
            modEventBus.addListener(ClientSetup::registerScreens);
            modEventBus.addListener(ClientSetup::registerHud);
            modEventBus.addListener(ClientSetup::registerTooltips);
            modEventBus.addListener(FoodAnimation::register);
            NeoForge.EVENT_BUS.addListener(CameraRig::onFov);
            NeoForge.EVENT_BUS.addListener(CameraRig::onRenderPlayer);
        }
    }
}
