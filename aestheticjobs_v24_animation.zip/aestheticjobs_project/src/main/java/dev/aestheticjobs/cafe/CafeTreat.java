package dev.aestheticjobs.cafe;

import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.registry.ModComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.event.entity.living.LivingEntityUseItemEvent;

/** A little joy: hearts over the head of a player who finished a cafe drink or dessert. */
public final class CafeTreat {
    private CafeTreat() {}

    public static void onUseFinish(LivingEntityUseItemEvent.Finish event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        ItemStack stack = event.getItem();
        if (stack.get(ModComponents.CUP.get()) == null && Dessert.ofItem(stack.getItem()) == null) return;
        player.serverLevel().sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + player.getBbHeight() + 0.3,
                player.getZ(), 3, 0.3, 0.12, 0.3, 0.0);
    }
}
