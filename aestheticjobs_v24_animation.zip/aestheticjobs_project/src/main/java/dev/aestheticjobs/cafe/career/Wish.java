package dev.aestheticjobs.cafe.career;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * A special wish of a guest: it changes the target of a mini-game (milk temperature, amount of foam, length of the shot).
 * Plain Java, no Minecraft classes.
 */
public enum Wish {
    NONE("none", Step.ANY, 0, 0, 1.0),
    HOT("hot", Step.STEAM, 6, 0, 1.0),
    MILD("mild", Step.STEAM, -7, 0, 1.0),
    FLUFFY("fluffy", Step.STEAM, 0, 0.14, 1.0),
    SILKY("silky", Step.STEAM, 0, -0.08, 1.0),
    LONG("long", Step.PULL, 0, 0, 1.28),
    SHORT("short", Step.PULL, 0, 0, 0.76);

    /** Which mini-game the wish is about. */
    public enum Step { ANY, STEAM, PULL }

    /** The step of the wish must reach this score, then the wish counts as fulfilled. */
    public static final int FULFILLED = 70;
    /** Below this score the guest is disappointed. */
    public static final int FAILED = 45;

    private final String id;
    private final Step step;
    private final double tempDelta, foamDelta, shotFactor;

    Wish(String id, Step step, double tempDelta, double foamDelta, double shotFactor) {
        this.id = id;
        this.step = step;
        this.tempDelta = tempDelta;
        this.foamDelta = foamDelta;
        this.shotFactor = shotFactor;
    }

    public String id() { return id; }
    public Step step() { return step; }

    public double foam(double base) {
        return foamDelta == 0 ? base : Math.max(0.05, Math.min(0.65, base + foamDelta));
    }

    public double temperature(double base) { return base + tempDelta; }

    public double shotTime(double base) { return base * shotFactor; }

    public static Wish byIndex(int i) {
        return i >= 0 && i < values().length ? values()[i] : NONE;
    }

    /**
     * A random wish that makes sense for a recipe.
     *
     * @param foamBase foam target of the steaming step, negative when the recipe has no milk
     */
    public static Wish pick(Random random, double foamBase) {
        List<Wish> all = new ArrayList<>(List.of(LONG, SHORT));
        if (foamBase >= 0) {
            all.add(HOT);
            all.add(MILD);
            if (foamBase <= 0.40) all.add(FLUFFY);
            if (foamBase >= 0.15) all.add(SILKY);
        }
        return all.get(random.nextInt(all.size()));
    }
}
