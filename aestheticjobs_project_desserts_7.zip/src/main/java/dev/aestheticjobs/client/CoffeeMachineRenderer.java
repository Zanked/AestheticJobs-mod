package dev.aestheticjobs.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.block.CoffeeMachineBlock;
import dev.aestheticjobs.block.CoffeeMachineBlockEntity;
import dev.aestheticjobs.cafe.Art;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.client.barista.Ui;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import static dev.aestheticjobs.block.CoffeeMachineBlockEntity.*;

/**
 * Draws the LIVE parts of the espresso machine on top of its static model, driven by the phase the barista is in
 * (see CoffeeMachineBlockEntity): the cup that fills up (with the latte art on top when the drink is ready),
 * the coffee / water / milk stream, the portafilter, the pressure gauge, the steam pitcher and the status lamp.
 * Everything is built from coloured boxes on one white texel, in block pixels (1/16) of the north-facing machine;
 * the whole thing is turned to the facing of the block.
 */
public class CoffeeMachineRenderer implements BlockEntityRenderer<CoffeeMachineBlockEntity> {
    private static final ResourceLocation WHITE =
            ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "textures/block/fx_white.png");

    private static final int STEEL = 0xFFB8BEC2, STEEL_D = 0xFF8F979C, DARK = 0xFF4A3228, PORCELAIN = 0xFFF4EEE2;
    private static final int FOAM = 0xFFFCF0D6, WATER_C = 0xFFD8EEF4, STREAM = 0xFF8A5A30;

    // cup (outer box and wall) and its inside
    private static final double CUP_X0 = 6.6, CUP_X1 = 9.4, CUP_Z0 = 1.2, CUP_Z1 = 3.95, CUP_Y0 = 2.02, CUP_Y1 = 4.0, WALL = 0.3;
    private static final double IN_X0 = CUP_X0 + WALL, IN_X1 = CUP_X1 - WALL, IN_Z0 = CUP_Z0 + WALL, IN_Z1 = CUP_Z1 - WALL;
    private static final double IN_Y0 = CUP_Y0 + 0.3, IN_Y1 = CUP_Y1 - 0.15;

    public CoffeeMachineRenderer(BlockEntityRendererProvider.Context context) {}

    @Override
    public void render(CoffeeMachineBlockEntity be, float pt, PoseStack ps, MultiBufferSource buffers, int light, int overlay) {
        Level level = be.getLevel();
        if (level == null) return;
        BlockState state = be.getBlockState();
        Direction facing = state.hasProperty(CoffeeMachineBlock.FACING) ? state.getValue(CoffeeMachineBlock.FACING) : Direction.NORTH;
        int phase = be.getPhase();
        Drink drink = Drink.byIndex(be.getDrinkIndex());
        if (drink == null) drink = Drink.ESPRESSO;
        double t = Math.max(0.0, (level.getGameTime() + pt - be.getPhaseStart()) / 20.0);   // seconds in this phase
        double clock = (level.getGameTime() + pt) / 20.0;

        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(WHITE));
        int full = LightTexture.FULL_BRIGHT;

        ps.pushPose();
        ps.translate(0.5, 0.0, 0.5);
        ps.mulPose(Axis.YP.rotationDegrees(-yRot(facing)));
        ps.translate(-0.5, 0.0, -0.5);

        gauge(ps, vc, phase, t, clock, light, overlay);
        lamp(ps, vc, phase, clock, full, overlay);

        if (phase != IDLE) {
            cup(ps, vc, be, drink, phase, t, light, overlay);
            if (phase == TAMP || phase == PULL) portafilter(ps, vc, phase, clock, light, overlay);
            if (phase == PULL) stream(ps, vc, 8.0, 4.2, 2.9, 0.34, STREAM, t, clock, drink, phase, full, overlay);
            if (phase == WATER) stream(ps, vc, 8.0, 4.2, 2.9, 0.5, WATER_C, t, clock, drink, phase, full, overlay);
            if (phase == STEAM) steamPitcher(ps, vc, t, clock, light, overlay);
            if (phase == POUR) pourPitcher(ps, vc, drink, t, clock, light, overlay);
        }
        ps.popPose();
    }

    private static int yRot(Direction facing) {
        return switch (facing) {
            case EAST -> 90;
            case SOUTH -> 180;
            case WEST -> 270;
            default -> 0;
        };
    }

    // ------------------------------------------------------------------ the pieces

    /** Pressure gauge on the front: rests low, jumps while the shot is pulled, wobbles with the steam. */
    private static void gauge(PoseStack ps, VertexConsumer vc, int phase, double t, double clock, int light, int overlay) {
        double target = switch (phase) {
            case PULL -> 0.66 + 0.035 * Math.sin(clock * 9.0);
            case WATER -> 0.36;
            case STEAM -> 0.30 + 0.025 * Math.sin(clock * 13.0);
            case IDLE -> 0.10;
            default -> 0.14;
        };
        double rest = 0.10;
        double k = Math.min(1.0, t / 1.0);
        double v = rest + (target - rest) * (k * k * (3 - 2 * k));        // eases into the new value
        if (phase == IDLE) v = rest;
        double angle = -115.0 + 230.0 * v;                                  // clockwise from 12 o'clock, seen from the front

        box(ps, vc, 10.8, 7.4, 3.8, 13.2, 9.8, 4.0, DARK, light, overlay);          // rim
        box(ps, vc, 11.0, 7.6, 3.72, 13.0, 9.6, 3.8, 0xFFFFF6E2, light, overlay);   // face
        box(ps, vc, 11.2, 7.7, 3.69, 11.45, 8.0, 3.72, 0xFF7FA070, light, overlay);  // green zone marks
        box(ps, vc, 12.55, 7.7, 3.69, 12.8, 8.0, 3.72, 0xFFC98468, light, overlay);  // red zone mark
        ps.pushPose();
        ps.translate(12.0 / 16.0, 8.6 / 16.0, 0.0);   // dial centre
        ps.mulPose(Axis.ZP.rotationDegrees((float) angle));
        box(ps, vc, -0.09, -0.25, 3.62, 0.09, 0.8, 3.69, 0xFFC03A2A, light, overlay);   // needle (pivot at the origin)
        ps.popPose();
        box(ps, vc, 11.85, 8.45, 3.58, 12.15, 8.75, 3.69, DARK, light, overlay);     // hub
    }

    /** Status lamp: dim green when idle, pulsing amber while working, bright green when the drink is ready. */
    private static void lamp(PoseStack ps, VertexConsumer vc, int phase, double clock, int light, int overlay) {
        int color;
        if (phase == IDLE) {
            color = 0xFF3E6A44;
            light = LightTexture.pack(4, 4);
        } else if (phase == DONE) {
            color = 0xFF5CFF72;
        } else {
            color = Ui.lerp(0xFFFF9A20, 0xFFFFD070, 0.5 + 0.5 * Math.sin(clock * 6.0));
        }
        box(ps, vc, 3.2, 9.4, 3.82, 4.4, 10.3, 4.0, 0xFF2E2420, light, overlay);
        box(ps, vc, 3.35, 9.55, 3.78, 4.25, 10.15, 3.82, color, light, overlay);
    }

    private static double finalLevel(Drink d) {
        return switch (d) {
            case ESPRESSO -> 0.34;
            case AMERICANO -> 0.80;
            default -> 0.88;
        };
    }

    private static double ease(double t, double tau) {
        return 1.0 - Math.exp(-t / tau);
    }

    /** How full the cup is (0..1 of its inside) in a phase. */
    private static double level(Drink d, int phase, double t) {
        double shot = 0.34, fin = finalLevel(d);
        return switch (phase) {
            case GRIND, TAMP -> 0.0;
            case PULL -> shot * ease(t, 4.0);
            case WATER, LAYER, POUR -> shot + (fin - shot) * ease(t, phase == WATER ? 3.0 : 4.0);
            case STEAM, STIR -> d == Drink.MACCHIATO ? 0.0 : shot;
            default -> fin;
        };
    }

    private static boolean hasMilk(Drink d) {
        for (Drink.Supply s : d.supplies()) if (s == Drink.Supply.MILK || s == Drink.Supply.CREAM) return true;
        return false;
    }

    /** The cup that stands under the group head while a barista works, filling up; the finished art on top. */
    private static void cup(PoseStack ps, VertexConsumer vc, CoffeeMachineBlockEntity be, Drink drink, int phase,
                            double t, int light, int overlay) {
        vessel(ps, vc, CUP_X0, CUP_Y0, CUP_Z0, CUP_X1, CUP_Y1, CUP_Z1, WALL, PORCELAIN, light, overlay);
        // a saucer under the cup
        box(ps, vc, CUP_X0 - 0.5, CUP_Y0, CUP_Z0 - 0.3, CUP_X1 + 0.5, CUP_Y0 + 0.12, CUP_Z1 - 0.1, 0xFFE6D9BA, light, overlay);

        double lv = level(drink, phase, t);
        if (lv <= 0.005) return;
        double top = IN_Y0 + (IN_Y1 - IN_Y0) * lv;

        // colour of the liquid, and of its surface (crema, then milk foam)
        int espresso = Ui.ESPRESSO;
        double mix = switch (phase) {
            case WATER, LAYER, POUR -> ease(t, 3.0);
            case FINISH, DONE -> 1.0;
            default -> 0.0;
        };
        int liquid = Ui.lerp(espresso, drink.baseColor(), mix);
        int surface;
        if (phase == PULL) {
            surface = Ui.lerp(liquid, Ui.CREMA, Math.min(1.0, t / 3.0));
        } else if (hasMilk(drink) && (phase == POUR || phase == LAYER)) {
            surface = Ui.lerp(Ui.CREMA, FOAM, ease(t, 3.0));
        } else if (hasMilk(drink) && (phase == FINISH || phase == DONE)) {
            surface = FOAM;
        } else if (phase == WATER) {
            surface = Ui.lerp(Ui.CREMA, drink.baseColor(), ease(t, 3.0));
        } else {
            surface = Ui.CREMA;
        }

        box(ps, vc, IN_X0, IN_Y0, IN_Z0, IN_X1, top, IN_Z1, liquid, light, overlay);
        String art = be.getArt();
        if (phase == DONE && art.length() == Drink.CELLS) {
            artTop(ps, vc, art, drink, top + 0.01, light, overlay);
        } else {
            quadUp(ps, vc, IN_X0, IN_Z0, IN_X1, IN_Z1, top + 0.01, surface, light, overlay);
        }
    }

    /** The 16x16 picture of the cup laid on the surface. Seen from the front: top of the picture = far side. */
    private static void artTop(PoseStack ps, VertexConsumer vc, String art, Drink drink, double y, int light, int overlay) {
        double cw = (IN_X1 - IN_X0) / Drink.SIZE, cd = (IN_Z1 - IN_Z0) / Drink.SIZE;
        for (int row = 0; row < Drink.SIZE; row++) {
            for (int col = 0; col < Drink.SIZE; col++) {
                if (!Drink.inCup(col, row)) continue;
                int rgb = Art.rgb(art.charAt(row * Drink.SIZE + col), drink);
                double x1 = IN_X1 - col * cw, x0 = x1 - cw;
                double z1 = IN_Z1 - row * cd, z0 = z1 - cd;
                quadUp(ps, vc, x0, z0, x1, z1, y, rgb, light, overlay);
            }
        }
    }

    private static void portafilter(PoseStack ps, VertexConsumer vc, int phase, double clock, int light, int overlay) {
        double shake = phase == PULL ? 0.025 * Math.sin(clock * 38.0) : 0.0;
        ps.pushPose();
        ps.translate(shake / 16.0, 0.0, 0.0);
        box(ps, vc, 6.4, 4.2, 2.5, 9.6, 5.0, 4.0, STEEL, light, overlay);                    // basket
        box(ps, vc, 6.7, 4.05, 2.8, 9.3, 4.2, 3.7, STEEL_D, light, overlay);                 // its bottom with the spouts
        box(ps, vc, 7.55, 4.35, 0.7, 8.45, 4.95, 2.5, DARK, light, overlay);                 // the handle toward the barista
        box(ps, vc, 7.55, 4.35, 0.5, 8.45, 4.95, 0.7, 0xFF6A4A3A, light, overlay);           // its end cap
        ps.popPose();
    }

    /** A thin stream falling from y0 down to the surface of the cup; flickers a little. */
    private static void stream(PoseStack ps, VertexConsumer vc, double cx, double y0, double cz, double width, int color,
                               double t, double clock, Drink drink, int phase, int light, int overlay) {
        if (t < 0.5) return;                                                   // the pump needs a moment
        double lv = level(drink, phase, t);
        double bottom = IN_Y0 + (IN_Y1 - IN_Y0) * lv;
        double w = width * (0.85 + 0.15 * Math.sin(clock * 31.0));
        double half = w / 2.0;
        if (phase == PULL) {                                                   // two spouts of a portafilter
            box(ps, vc, cx - 0.55 - half, bottom, cz - half, cx - 0.55 + half, y0, cz + half, color, light, overlay);
            box(ps, vc, cx + 0.55 - half, bottom, cz - half, cx + 0.55 + half, y0, cz + half, color, light, overlay);
        } else {
            box(ps, vc, cx - half, bottom, cz - half, cx + half, y0, cz + half, color, light, overlay);
        }
    }

    /** The pitcher by the steam wand: the milk in it gets lighter and rises while it is steamed. */
    private static void steamPitcher(PoseStack ps, VertexConsumer vc, double t, double clock, int light, int overlay) {
        double sh = 0.03 * Math.sin(clock * 47.0);
        ps.pushPose();
        ps.translate(sh / 16.0, 0.0, 0.0);
        vessel(ps, vc, 14.1, 0.6, 4.3, 16.5, 4.0, 6.7, 0.3, STEEL, light, overlay);
        double lv = 0.45 + 0.30 * ease(t, 10.0);
        double top = 0.9 + (3.85 - 0.9) * lv;
        box(ps, vc, 14.4, 0.9, 4.6, 16.2, top, 6.4, 0xFFF2EDE0, light, overlay);
        quadUp(ps, vc, 14.4, 4.6, 16.2, 6.4, top + 0.01, Ui.lerp(0xFFF2EDE0, FOAM, ease(t, 8.0)), light, overlay);
        ps.popPose();
    }

    /** The pitcher over the cup that sways like a barista's hand drawing the art. */
    private static void pourPitcher(PoseStack ps, VertexConsumer vc, Drink drink, double t, double clock, int light, int overlay) {
        double sway = 0.55 * Math.sin(clock * 2.6);
        double spoutY = 6.7, spoutZ = 2.6, x = 8.0 + sway;
        ps.pushPose();
        ps.translate(x / 16.0, spoutY / 16.0, spoutZ / 16.0);
        ps.mulPose(Axis.XP.rotationDegrees(30.0F));                                          // tilted: the back end is up
        vessel(ps, vc, -1.1, -0.2, -2.4, 1.1, 2.2, 0.0, 0.3, STEEL, light, overlay);
        ps.popPose();
        if (t > 0.3) {                                                                       // the milk stream
            double lv = level(drink, POUR, t);
            double bottom = IN_Y0 + (IN_Y1 - IN_Y0) * lv;
            double w = 0.3 * (0.85 + 0.15 * Math.sin(clock * 29.0));
            box(ps, vc, x - w / 2, bottom, spoutZ - w / 2, x + w / 2, spoutY - 0.1, spoutZ + w / 2, FOAM, light, overlay);
        }
    }

    // ------------------------------------------------------------------ geometry helpers (block pixels)

    /** An open vessel: a bottom and four walls. */
    private static void vessel(PoseStack ps, VertexConsumer vc, double x0, double y0, double z0, double x1, double y1, double z1,
                               double wall, int color, int light, int overlay) {
        box(ps, vc, x0, y0, z0, x1, y0 + wall, z1, color, light, overlay);
        box(ps, vc, x0, y0 + wall, z0, x0 + wall, y1, z1, color, light, overlay);
        box(ps, vc, x1 - wall, y0 + wall, z0, x1, y1, z1, color, light, overlay);
        box(ps, vc, x0 + wall, y0 + wall, z0, x1 - wall, y1, z0 + wall, color, light, overlay);
        box(ps, vc, x0 + wall, y0 + wall, z1 - wall, x1 - wall, y1, z1, color, light, overlay);
    }

    private static void box(PoseStack ps, VertexConsumer vc, double ax, double ay, double az, double bx, double by, double bz,
                            int argb, int light, int overlay) {
        PoseStack.Pose p = ps.last();
        float x0 = (float) (ax / 16.0), y0 = (float) (ay / 16.0), z0 = (float) (az / 16.0);
        float x1 = (float) (bx / 16.0), y1 = (float) (by / 16.0), z1 = (float) (bz / 16.0);
        int r = argb >> 16 & 255, g = argb >> 8 & 255, b = argb & 255;
        // up
        v(vc, p, x0, y1, z0, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x0, y1, z1, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x1, y1, z1, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x1, y1, z0, r, g, b, light, overlay, 0, 1, 0);
        // down
        v(vc, p, x0, y0, z0, r, g, b, light, overlay, 0, -1, 0);
        v(vc, p, x1, y0, z0, r, g, b, light, overlay, 0, -1, 0);
        v(vc, p, x1, y0, z1, r, g, b, light, overlay, 0, -1, 0);
        v(vc, p, x0, y0, z1, r, g, b, light, overlay, 0, -1, 0);
        // north (-z)
        v(vc, p, x1, y1, z0, r, g, b, light, overlay, 0, 0, -1);
        v(vc, p, x1, y0, z0, r, g, b, light, overlay, 0, 0, -1);
        v(vc, p, x0, y0, z0, r, g, b, light, overlay, 0, 0, -1);
        v(vc, p, x0, y1, z0, r, g, b, light, overlay, 0, 0, -1);
        // south (+z)
        v(vc, p, x0, y1, z1, r, g, b, light, overlay, 0, 0, 1);
        v(vc, p, x0, y0, z1, r, g, b, light, overlay, 0, 0, 1);
        v(vc, p, x1, y0, z1, r, g, b, light, overlay, 0, 0, 1);
        v(vc, p, x1, y1, z1, r, g, b, light, overlay, 0, 0, 1);
        // west (-x)
        v(vc, p, x0, y1, z0, r, g, b, light, overlay, -1, 0, 0);
        v(vc, p, x0, y0, z0, r, g, b, light, overlay, -1, 0, 0);
        v(vc, p, x0, y0, z1, r, g, b, light, overlay, -1, 0, 0);
        v(vc, p, x0, y1, z1, r, g, b, light, overlay, -1, 0, 0);
        // east (+x)
        v(vc, p, x1, y1, z1, r, g, b, light, overlay, 1, 0, 0);
        v(vc, p, x1, y0, z1, r, g, b, light, overlay, 1, 0, 0);
        v(vc, p, x1, y0, z0, r, g, b, light, overlay, 1, 0, 0);
        v(vc, p, x1, y1, z0, r, g, b, light, overlay, 1, 0, 0);
    }

    /** Only the top face (the surface of a liquid). */
    private static void quadUp(PoseStack ps, VertexConsumer vc, double ax, double az, double bx, double bz, double y,
                               int argb, int light, int overlay) {
        PoseStack.Pose p = ps.last();
        float x0 = (float) (ax / 16.0), z0 = (float) (az / 16.0), x1 = (float) (bx / 16.0), z1 = (float) (bz / 16.0);
        float yy = (float) (y / 16.0);
        int r = argb >> 16 & 255, g = argb >> 8 & 255, b = argb & 255;
        v(vc, p, x0, yy, z0, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x0, yy, z1, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x1, yy, z1, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x1, yy, z0, r, g, b, light, overlay, 0, 1, 0);
    }

    private static void v(VertexConsumer vc, PoseStack.Pose p, float x, float y, float z, int r, int g, int b,
                          int light, int overlay, float nx, float ny, float nz) {
        vc.addVertex(p, x, y, z).setColor(r, g, b, 255).setUv(0.5F, 0.5F).setOverlay(overlay).setLight(light).setNormal(p, nx, ny, nz);
    }
}
