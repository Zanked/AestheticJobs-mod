package dev.aestheticjobs.client.barista;

import com.mojang.blaze3d.platform.NativeImage;
import dev.aestheticjobs.AestheticJobs;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

/**
 * The customer who waits for the drink, behind the counter on the right side of the bar. It is drawn from the very
 * skin of the customer entity (head, body and arms are cut out of textures/entity/customer_N.png), so it is the same
 * person you see in the cafe. The face changes while the customer waits:
 *   HAPPY (still within the speed bonus) -> OK -> IMPATIENT (sweat, worried brows, tapping fingers) -> ANGRY (red face,
 *   steam, shaking), and it reacts to every step you finish (see SceneFx.grade): cheers, hearts, winces.
 */
public final class CustomerPortrait {
    public enum Mood { HAPPY, OK, IMPATIENT, ANGRY }

    private CustomerPortrait() {}

    private static final int DK = 0xFF4A3228, BROW = 0xFF3A2418, MOUTH = 0xFFB4574E, INNER = 0xFF7A2E2E;
    private static final int TEETH = 0xFFFFF6E2, TONGUE = 0xFFE98A84, VEIN = 0xFFD2463C;

    private static final Map<Integer, int[][]> CACHE = new HashMap<>();      // head 8x8, body 6x8, arm 2x6 (ARGB)

    public static Mood moodFor(long elapsed, long fast, long ok) {
        if (elapsed <= fast) return Mood.HAPPY;
        double r = elapsed / (double) Math.max(1L, ok);
        if (r < 0.72) return Mood.OK;
        if (r <= 1.0) return Mood.IMPATIENT;
        return Mood.ANGRY;
    }

    public static int moodColor(Mood m, float t) {
        return switch (m) {
            case HAPPY -> Ui.GOOD_D;
            case OK -> Ui.GOOD;
            case IMPATIENT -> Ui.WARN_D;
            case ANGRY -> ((int) (t * 5.0F)) % 2 == 0 ? Ui.BAD_D : Ui.BAD;
        };
    }

    // ------------------------------------------------------------------ the skin

    private static int[][] skin(int variant) {
        int[][] hit = CACHE.get(variant);
        if (hit != null) return hit;
        int[] head = new int[64], body = new int[48], arm = new int[12];
        java.util.Arrays.fill(head, 0xFFF6D8BC);
        java.util.Arrays.fill(body, 0xFFE3A08C);
        java.util.Arrays.fill(arm, 0xFFE3A08C);
        ResourceLocation rl = ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "textures/entity/customer_" + variant + ".png");
        try {
            var res = Minecraft.getInstance().getResourceManager().getResource(rl);
            if (res.isPresent()) {
                try (InputStream in = res.get().open(); NativeImage img = NativeImage.read(in)) {
                    cut(img, 8, 8, 8, 8, head);                 // head: box 8x8x8 at (0,0), the front is at (8,8)
                    cut(img, 4, 20, 6, 8, body);                // body: box 6x8x4 at (0,16), the front is at (4,20)
                    cut(img, 22, 18, 2, 6, arm);                // arm: box 2x6x2 at (20,16), the front is at (22,18)
                }
            }
        } catch (Exception ignored) {
            // the portrait stays in the plain colours
        }
        int[][] all = {head, body, arm};
        CACHE.put(variant, all);
        return all;
    }

    private static void cut(NativeImage img, int u, int v, int w, int h, int[] out) {
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int p = img.getPixelRGBA(u + x, v + y);           // ABGR
                int a = p >>> 24, b = p >> 16 & 255, g = p >> 8 & 255, r = p & 255;
                out[y * w + x] = a << 24 | r << 16 | g << 8 | b;
            }
        }
    }

    // ------------------------------------------------------------------ drawing helpers

    /** A rectangle in "face cells" (one cell = c pixels, fractions allowed) of a head whose top left corner is (x0, y0). */
    private static void rect(GuiGraphics g, int x0, int y0, int c, float gx, float gy, float gw, float gh, int color) {
        int x1 = x0 + Math.round(gx * c), y1 = y0 + Math.round(gy * c);
        int x2 = x0 + Math.round((gx + gw) * c), y2 = y0 + Math.round((gy + gh) * c);
        if (x2 <= x1) x2 = x1 + 1;
        if (y2 <= y1) y2 = y1 + 1;
        g.fill(x1, y1, x2, y2, color);
    }

    /** The same, mirrored to the right half of the face (the face is 8 cells wide). */
    private static void rectM(GuiGraphics g, int x0, int y0, int c, float gx, float gy, float gw, float gh, int color) {
        rect(g, x0, y0, c, 8.0F - gx - gw, gy, gw, gh, color);
    }

    private static void grid(GuiGraphics g, int[] px, int gw, int gh, int x, int y, int c, int clipY, boolean mirror) {
        for (int j = 0; j < gh; j++) {
            int yy = y + j * c;
            if (yy >= clipY) break;
            int hh = Math.min(c, clipY - yy);
            for (int i = 0; i < gw; i++) {
                int col = px[j * gw + (mirror ? gw - 1 - i : i)];
                if ((col >>> 24) == 0) continue;
                g.fill(x + i * c, yy, x + i * c + c, yy + hh, col);
            }
        }
    }

    private enum Eyes { OPEN, BLINK, HAPPY, SQUINT }

    private enum Brows { NONE, WORRY, ANGRY }

    private enum Mouth { SMILE, BIG, FLAT, WAVY, FROWN, SHOUT, OOO }

    // ------------------------------------------------------------------ the portrait

    /**
     * @param cx       centre of the customer
     * @param counterY the top of the counter: the customer stands behind it, only the upper body shows
     * @param cell     size of one pixel of the skin on the screen
     */
    public static void draw(GuiGraphics g, Font font, SceneFx fx, int variant, Component name, Mood mood,
                            int cx, int counterY, int cell, float t) {
        int c = cell;
        int[][] sk = skin(variant);
        int[] head = sk[0];
        int skinCol = head[4 * 8 + 3];

        int reaction = fx.reaction();
        float rt = fx.reactTime();
        float k = fx.reactHold() ? 0.6F : Math.max(0.0F, 1.0F - rt / 1.4F);          // how strong the reaction is now

        // movement
        float ox = 0.0F, oy = 0.0F;
        if (reaction == 5) oy = -Math.abs((float) Math.sin(rt * 10.0F)) * k * c * 1.1F;
        else if (reaction == 4) oy = -Math.abs((float) Math.sin(rt * 9.0F)) * k * c * 0.5F;
        else if (reaction == 1) ox = (float) Math.sin(rt * 52.0F) * k * c * 0.25F;
        if (reaction == 0) {
            if (mood == Mood.ANGRY) ox = (float) Math.sin(t * 38.0F) * c * 0.12F;
            else if (mood != Mood.IMPATIENT) ox = (float) Math.sin(t * 1.4F + variant) * c * 0.12F;
        }

        int baseTop = counterY - 13 * c;
        int x0 = Math.round(cx - 4 * c + ox);
        int headTop = baseTop + Math.round(oy);
        int bodyTop = headTop + 8 * c;

        // a soft shadow on the wall behind
        g.fill(x0 + 3, headTop + 4, x0 + 8 * c + 3, counterY, 0x30000000);

        // arms (up when cheering, one taps the counter when the customer is impatient)
        boolean cheer = reaction == 5 && k > 0.05F;
        int armL = bodyTop, armR = bodyTop, armShift = 0;
        if (cheer) {
            armL = bodyTop - 3 * c;
            armR = bodyTop - 3 * c;
            armShift = c;
        } else if (reaction == 0 && mood == Mood.IMPATIENT) {
            armL = bodyTop - Math.round(Math.max(0.0F, (float) Math.sin(t * 9.0F)) * 0.7F * c);
        }
        grid(g, sk[2], 2, 6, x0 - c - armShift, armL, c, counterY, false);
        grid(g, sk[2], 2, 6, x0 + 7 * c + armShift, armR, c, counterY, true);
        // body
        grid(g, sk[1], 6, 8, x0 + c, bodyTop, c, counterY, false);

        // ---- the face: first the picture of the skin
        for (int y = 0; y < 8; y++) {
            for (int x = 0; x < 8; x++) {
                int col = head[y * 8 + x];
                if ((col >>> 24) == 0) continue;
                g.fill(x0 + x * c, headTop + y * c, x0 + x * c + c, headTop + y * c + c, col);
            }
        }

        // ---- what the face does now
        Eyes eyes = Eyes.OPEN;
        Brows brows = Brows.NONE;
        Mouth mouth;
        boolean blush = false;
        if (reaction == 5) {
            eyes = Eyes.HAPPY;
            mouth = Mouth.BIG;
            blush = true;
        } else if (reaction == 4) {
            eyes = Eyes.HAPPY;
            mouth = Mouth.SMILE;
            blush = true;
        } else if (reaction == 3) {
            mouth = Mouth.SMILE;
        } else if (reaction == 2) {
            brows = Brows.WORRY;
            mouth = Mouth.WAVY;
        } else if (reaction == 1) {
            eyes = Eyes.SQUINT;
            brows = Brows.WORRY;
            mouth = Mouth.OOO;
        } else {
            switch (mood) {
                case HAPPY -> {
                    mouth = Mouth.SMILE;
                    blush = true;
                }
                case OK -> mouth = Mouth.FLAT;
                case IMPATIENT -> {
                    brows = Brows.WORRY;
                    mouth = Mouth.WAVY;
                }
                default -> {
                    brows = Brows.ANGRY;
                    mouth = Mouth.SHOUT;
                }
            }
        }
        if (eyes == Eyes.OPEN && ((t + variant * 0.77F) % 3.6F) < 0.14F) eyes = Eyes.BLINK;

        // eyes: wipe the painted ones if they change
        if (eyes != Eyes.OPEN) {
            rect(g, x0, headTop, c, 2, 3, 1, 3, skinCol);
            rect(g, x0, headTop, c, 5, 3, 1, 3, skinCol);
        }
        switch (eyes) {
            case BLINK -> {
                rect(g, x0, headTop, c, 1.7F, 4.4F, 1.6F, 0.5F, DK);
                rect(g, x0, headTop, c, 4.7F, 4.4F, 1.6F, 0.5F, DK);
            }
            case HAPPY -> {
                for (int side = 0; side < 2; side++) {
                    float e = side == 0 ? 2 : 5;
                    rect(g, x0, headTop, c, e - 0.5F, 4.5F, 0.5F, 0.5F, DK);
                    rect(g, x0, headTop, c, e, 4.0F, 1.0F, 0.5F, DK);
                    rect(g, x0, headTop, c, e + 1.0F, 4.5F, 0.5F, 0.5F, DK);
                }
            }
            case SQUINT -> {
                rect(g, x0, headTop, c, 1.5F, 3.4F, 0.8F, 0.5F, DK);
                rect(g, x0, headTop, c, 2.2F, 4.0F, 0.8F, 0.5F, DK);
                rect(g, x0, headTop, c, 1.5F, 4.6F, 0.8F, 0.5F, DK);
                rectM(g, x0, headTop, c, 1.5F, 3.4F, 0.8F, 0.5F, DK);
                rectM(g, x0, headTop, c, 2.2F, 4.0F, 0.8F, 0.5F, DK);
                rectM(g, x0, headTop, c, 1.5F, 4.6F, 0.8F, 0.5F, DK);
            }
            default -> { }
        }

        // brows
        if (brows == Brows.WORRY) {
            rect(g, x0, headTop, c, 1.3F, 2.9F, 0.9F, 0.45F, BROW);
            rect(g, x0, headTop, c, 2.2F, 2.5F, 0.9F, 0.45F, BROW);
            rectM(g, x0, headTop, c, 1.3F, 2.9F, 0.9F, 0.45F, BROW);
            rectM(g, x0, headTop, c, 2.2F, 2.5F, 0.9F, 0.45F, BROW);
        } else if (brows == Brows.ANGRY) {
            rect(g, x0, headTop, c, 1.3F, 2.4F, 0.9F, 0.45F, BROW);
            rect(g, x0, headTop, c, 2.2F, 2.8F, 0.9F, 0.45F, BROW);
            rectM(g, x0, headTop, c, 1.3F, 2.4F, 0.9F, 0.45F, BROW);
            rectM(g, x0, headTop, c, 2.2F, 2.8F, 0.9F, 0.45F, BROW);
        }

        // mouth: wipe the painted one, draw ours
        rect(g, x0, headTop, c, 3, 6, 2, 1, skinCol);
        switch (mouth) {
            case SMILE -> {
                rect(g, x0, headTop, c, 3.0F, 6.5F, 2.0F, 0.5F, MOUTH);
                rect(g, x0, headTop, c, 2.5F, 6.0F, 0.5F, 0.5F, MOUTH);
                rect(g, x0, headTop, c, 5.0F, 6.0F, 0.5F, 0.5F, MOUTH);
            }
            case BIG -> {
                rect(g, x0, headTop, c, 2.9F, 6.0F, 2.2F, 1.3F, INNER);
                rect(g, x0, headTop, c, 2.9F, 6.0F, 2.2F, 0.4F, TEETH);
                rect(g, x0, headTop, c, 3.4F, 6.8F, 1.2F, 0.5F, TONGUE);
            }
            case FLAT -> rect(g, x0, headTop, c, 3.2F, 6.5F, 1.6F, 0.45F, MOUTH);
            case WAVY -> {
                float o = ((int) (t * 4.0F)) % 2 == 0 ? 0.0F : 0.3F;
                rect(g, x0, headTop, c, 3.0F, 6.4F + o, 1.0F, 0.45F, MOUTH);
                rect(g, x0, headTop, c, 4.0F, 6.8F - o, 1.0F, 0.45F, MOUTH);
            }
            case FROWN -> {
                rect(g, x0, headTop, c, 3.0F, 6.2F, 2.0F, 0.5F, MOUTH);
                rect(g, x0, headTop, c, 2.5F, 6.6F, 0.5F, 0.5F, MOUTH);
                rect(g, x0, headTop, c, 5.0F, 6.6F, 0.5F, 0.5F, MOUTH);
            }
            case SHOUT -> {
                float open = 0.95F + 0.35F * (float) Math.sin(t * 30.0F);
                rect(g, x0, headTop, c, 2.9F, 6.0F, 2.2F, open, INNER);
                rect(g, x0, headTop, c, 2.9F, 6.0F, 2.2F, 0.35F, TEETH);
            }
            default -> {                                                           // OOO
                rect(g, x0, headTop, c, 3.4F, 6.1F, 1.2F, 1.0F, INNER);
                rect(g, x0, headTop, c, 3.4F, 6.1F, 1.2F, 0.3F, MOUTH);
            }
        }

        // blush and the red face of an angry customer
        if (blush) {
            rect(g, x0, headTop, c, 0.8F, 5.7F, 1.3F, 1.2F, 0x66F28A8A);
            rectM(g, x0, headTop, c, 0.8F, 5.7F, 1.3F, 1.2F, 0x66F28A8A);
        }
        if (reaction == 0 && mood == Mood.ANGRY) {
            int a = 0x1E + (int) (0x16 * (0.5F + 0.5F * Math.sin(t * 10.0F)));
            g.fill(x0, headTop, x0 + 8 * c, headTop + 8 * c, a << 24 | 0xE0403A);
            float pulse = 0.8F + 0.2F * (float) Math.sin(t * 14.0F);
            rect(g, x0, headTop, c, 6.0F, 0.9F, 1.5F * pulse, 0.4F, VEIN);
            rect(g, x0, headTop, c, 6.55F, 0.35F, 0.4F, 1.5F * pulse, VEIN);
        }

        // little things that float around the head
        int hx = x0 + 4 * c, hy = headTop + 4 * c;
        fx.headBurst(hx, headTop, c);
        if (reaction == 0) {
            if (mood == Mood.ANGRY && fx.chance(4.0F)) {
                fx.emitSteam(x0 - 0.3F * c, headTop + 1.0F * c, -10.0F);
                fx.emitSteam(x0 + 8.3F * c, headTop + 1.0F * c, 10.0F);
            } else if (mood == Mood.IMPATIENT && fx.chance(0.8F)) {
                fx.emitSweat(x0 + 6.8F * c, headTop + 2.0F * c);
            } else if (mood == Mood.HAPPY && fx.chance(1.0F)) {
                fx.emitSparkle(hx + (float) Math.sin(t * 3.0F) * 4.2F * c, hy - 1.5F * c);
            }
        }

        // the name plate, with the mood as a little lamp
        String s = name.getString();
        int w = font.width(s) + 18;
        int sx = cx - w / 2, sy = baseTop - 15;
        g.fill(sx + 2, sy + 3, sx + w + 2, sy + 15, 0x55000000);
        Ui.box(g, sx, sy, w, 12, 0xFF2A1A13, 0xFF6A4A3A);
        Ui.disc(g, sx + 7, sy + 6, 2, moodColor(mood, t));
        g.drawString(font, s, sx + 13, sy + 2, 0xFFFFF6E2, false);
    }
}
