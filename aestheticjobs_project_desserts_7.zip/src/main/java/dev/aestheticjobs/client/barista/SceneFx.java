package dev.aestheticjobs.client.barista;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.aestheticjobs.registry.ModSounds;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * The bar reacts to the game. Every finished step has a grade (Perfect! .. Missed): the stage reports it with
 * {@link #grade(int)} and the whole scene answers: the pendant lamp flares gold (or stutters and turns red), the
 * machine kicks, glows and throws sparks (or coughs smoke), the grade pops up over the machine and the customer
 * on the right shows a reaction. Stages can also poke the scene while they run: {@link #hiss(float)} (the machine
 * puffs steam) and {@link #thump(float)} (a small kick of the machine, for the tamper).
 *
 * One instance per client (the barista screen is the only one that uses it). Everything is drawn in screen
 * coordinates, on top of the other things (z = 400), by {@link #render}.
 */
public final class SceneFx {
    private static final SceneFx INSTANCE = new SceneFx();

    public static SceneFx get() {
        return INSTANCE;
    }

    private static final int SPARK = 0, STAR = 1, PUFF = 2, RING = 3, HEART = 4, DROP = 5, MOTE = 6;
    private static final int[] GOLDS = {0xF6D58A, 0xFFE9B0, 0xFFFFFF, 0xEEC37A, 0xFFD27A};

    private static final class P {
        float x, y, vx, vy, life, max, size, grow;
        int color, kind;
    }

    private static final class Popup {
        Component text;
        int color;
        float x, y, life, max, scale;
    }

    private final List<P> parts = new ArrayList<>();
    private final List<Popup> popups = new ArrayList<>();
    private final Random rnd = new Random();

    // the lamp
    private float lampFlare, lampDim, lampRed;
    // the machine
    private float kick, shake, glow;
    private int glowColor = 0xFFD58A;
    private float hiss, hissAcc;
    // what is still to be shown where it belongs (each part of the scene takes its own)
    private int pendingMachine, pendingLamp, pendingHead;
    // the customer
    private int reactGrade;
    private float reactT;
    private boolean reactHold;

    private float time, lastDt = 0.016F;

    private SceneFx() {}

    public void reset() {
        parts.clear();
        popups.clear();
        lampFlare = lampDim = lampRed = kick = shake = glow = hiss = hissAcc = 0.0F;
        pendingMachine = pendingLamp = pendingHead = 0;
        reactGrade = 0;
        reactT = 0.0F;
        reactHold = false;
    }

    // ------------------------------------------------------------------ events

    private static int gradeOf(int score) {
        return score >= 90 ? 5 : score >= 75 ? 4 : score >= 60 ? 3 : score >= 40 ? 2 : 1;
    }

    /** A step is over: 0..100. */
    public void grade(int score) {
        int g = gradeOf(score);
        pendingMachine = g;
        pendingLamp = g;
        pendingHead = g;
        reactGrade = g;
        reactT = 0.0F;
        reactHold = false;
        switch (g) {
            case 5 -> {
                lampFlare = 1.0F;
                kick = 1.0F;
                glow = 1.0F;
                glowColor = 0xFFD58A;
                Ui.sound(ModSounds.BARISTA_DING.get(), 1.7F, 0.5F);
                Ui.sound(ModSounds.CUSTOMER_HAPPY.get(), 1.25F, 0.35F);
            }
            case 4 -> {
                lampFlare = 0.55F;
                kick = 0.6F;
                glow = 0.6F;
                glowColor = 0xFFD58A;
                Ui.sound(ModSounds.BARISTA_DING.get(), 1.35F, 0.4F);
            }
            case 3 -> {
                lampFlare = 0.2F;
                kick = 0.25F;
                glow = 0.25F;
                glowColor = 0xFFF0C8;
                Ui.sound(ModSounds.BARISTA_DING.get(), 1.0F, 0.2F);
            }
            case 2 -> {
                lampDim = 0.45F;
                shake = 0.35F;
                glow = 0.3F;
                glowColor = 0xBFA982;
                Ui.sound(ModSounds.CUSTOMER_IMPATIENT.get(), 1.0F, 0.25F);
            }
            default -> {
                lampDim = 1.0F;
                lampRed = 1.0F;
                shake = 1.0F;
                glow = 0.8F;
                glowColor = 0xE3604C;
                Ui.sound(ModSounds.CUSTOMER_GRUMBLE.get(), 0.8F, 0.4F);
            }
        }
    }

    /** The drink is ready: the customer holds the reaction (1..5 stars) while the summary is on screen. */
    public void finalReaction(int stars) {
        int g = Math.max(1, Math.min(5, stars));
        reactGrade = g;
        reactT = 0.0F;
        reactHold = true;
        pendingHead = g;
        if (g >= 4) {
            lampFlare = Math.max(lampFlare, 0.6F);
        }
    }

    /** A stage that makes steam keeps calling this (0..1) while it does. */
    public void hiss(float level) {
        hiss = Math.max(hiss, Math.max(0.0F, Math.min(1.0F, level)));
    }

    /** A small knock: the machine and the lamp jump a little (0..1). */
    public void thump(float strength) {
        float s = Math.max(0.0F, Math.min(1.0F, strength));
        kick = Math.max(kick, 0.5F * s);
        lampFlare = Math.max(lampFlare, 0.18F * s);
    }

    // ------------------------------------------------------------------ the frame

    public void tick(float dt) {
        lastDt = dt;
        time += dt;
        lampFlare = Math.max(0.0F, lampFlare - dt * 0.85F);
        lampDim = Math.max(0.0F, lampDim - dt * 0.6F);
        lampRed = Math.max(0.0F, lampRed - dt * 0.7F);
        kick = Math.max(0.0F, kick - dt * 3.2F);
        shake = Math.max(0.0F, shake - dt * 1.6F);
        glow = Math.max(0.0F, glow - dt * 1.0F);
        hiss = Math.max(0.0F, hiss - dt * 6.0F);
        reactT += dt;
        if (!reactHold && reactGrade != 0 && reactT > 1.8F) reactGrade = 0;

        for (int i = parts.size() - 1; i >= 0; i--) {
            P p = parts.get(i);
            p.life -= dt;
            if (p.life <= 0.0F) {
                parts.remove(i);
                continue;
            }
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            switch (p.kind) {
                case SPARK -> {
                    p.vy += 230.0F * dt;
                    p.vx *= 1.0F - 0.9F * dt;
                }
                case DROP -> p.vy += 140.0F * dt;
                case HEART -> p.vx += (float) Math.sin(time * 6.0F + p.size * 3.0F) * 18.0F * dt;
                case PUFF -> {
                    p.vx *= 1.0F - 0.8F * dt;
                    p.vy *= 1.0F - 0.5F * dt;
                }
                case MOTE -> p.vx += (float) Math.sin(time * 5.0F + p.y * 0.1F) * 20.0F * dt;
                default -> { }
            }
        }
        for (int i = popups.size() - 1; i >= 0; i--) {
            Popup p = popups.get(i);
            p.life -= dt;
            if (p.life <= 0.0F) {
                popups.remove(i);
                continue;
            }
            p.y -= 20.0F * dt;
        }
        if (parts.size() > 260) parts.subList(0, parts.size() - 260).clear();
    }

    /** What has not found its place in the scene this frame is dropped (the part may be off screen). */
    public void endFrame() {
        pendingMachine = 0;
        pendingLamp = 0;
        pendingHead = 0;
    }

    // ------------------------------------------------------------------ lamp

    public float lampFlare() { return lampFlare; }

    public float lampDim() { return lampDim; }

    public float lampRed() { return lampRed; }

    /** Called by the room with the place of the bulb: the pending grade throws its glitter (or a short circuit) from it. */
    public void lampBurst(int lx, int ly) {
        int g = pendingLamp;
        if (g == 0) return;
        pendingLamp = 0;
        if (g >= 4) {
            int n = g == 5 ? 18 : 7;
            for (int i = 0; i < n; i++) {
                spawn(MOTE, lx + rr(-16, 16), ly + rr(0, 6), rr(-12, 12), rr(8, 30), 1.2F + rnd.nextFloat() * 0.8F, 1.0F, 0, gold());
            }
            if (g == 5) spawn(RING, lx, ly, 0, 0, 0.9F, 0, 80.0F, 0xFFD58A);
        } else if (g == 1) {
            for (int i = 0; i < 6; i++) {
                spawn(SPARK, lx + rr(-5, 5), ly + 3, rr(-40, 40), rr(-30, 20), 0.45F, 1.0F, 0, i % 2 == 0 ? 0xFFFFFF : 0xFFE6A0);
            }
        }
    }

    // ------------------------------------------------------------------ machine

    public float kick() { return kick; }

    /** Degrees added to the lean of the machine: it shudders after a bad step. */
    public float wobble() {
        return (float) Math.sin(time * 42.0F) * shake * 6.0F;
    }

    /**
     * The glow behind the machine; also where the pending grade throws its sparks / smoke from and where the
     * machine puffs steam. cx / baseY / s are those of BarScene.machine.
     */
    public void machineBack(GuiGraphics g, int cx, int baseY, float s) {
        float nx = cx + 2.0F * s, ny = baseY - 11.0F * s;
        if (glow > 0.02F) {
            int r = (int) (s * 9.0F + glow * s * 6.0F);
            int cy = (int) (baseY - 8.0F * s);
            Ui.disc(g, cx, cy, r + 10, argb((int) (glow * 18), glowColor));
            Ui.disc(g, cx, cy, r + 4, argb((int) (glow * 26), glowColor));
            Ui.disc(g, cx, cy, r - 2, argb((int) (glow * 34), glowColor));
        }
        if (hiss > 0.05F) {
            hissAcc += lastDt * 16.0F * hiss;
            while (hissAcc >= 1.0F) {
                hissAcc -= 1.0F;
                spawn(PUFF, nx + rr(-s, s), ny, rr(-7, 7), -(26.0F + rnd.nextFloat() * 16.0F), 0.9F, 2.0F, 7.0F, 0xFFFFFF);
            }
        }
        int gr = pendingMachine;
        if (gr == 0) return;
        pendingMachine = 0;

        Popup pop = new Popup();
        pop.text = Component.translatable("gui.aestheticjobs.cafe.grade." + gr);
        pop.x = cx;
        pop.y = baseY - 18.0F * s;
        pop.life = pop.max = 1.6F;
        pop.scale = gr == 5 ? 1.5F : gr == 4 ? 1.25F : 1.0F;
        pop.color = gr == 5 ? 0xF6D58A : gr == 4 ? 0xC9E0BA : gr == 3 ? 0xFFF6E2 : gr == 2 ? 0xF6D58A : 0xE3A08C;
        popups.add(pop);

        switch (gr) {
            case 5 -> {
                for (int i = 0; i < 30; i++) {
                    double a = -Math.PI / 2 + (rnd.nextDouble() - 0.5) * 2.6;
                    float sp = 55.0F + rnd.nextFloat() * 120.0F;
                    spawn(SPARK, nx, ny, (float) Math.cos(a) * sp, (float) Math.sin(a) * sp, 0.6F + rnd.nextFloat() * 0.5F, 2.0F, 0, gold());
                }
                for (int i = 0; i < 7; i++) {
                    spawn(STAR, nx + rr(-22, 22), ny + rr(-26, 8), rr(-10, 10), rr(-26, -6), 0.8F + rnd.nextFloat() * 0.5F, 2.0F + rnd.nextInt(3), 0, gold());
                }
                spawn(RING, nx, ny, 0, 0, 0.7F, 0, 38.0F, 0xFFD58A);
                spawn(RING, nx, ny, 0, 0, 1.0F, 0, 64.0F, 0xFFF0C8);
            }
            case 4 -> {
                for (int i = 0; i < 14; i++) {
                    double a = -Math.PI / 2 + (rnd.nextDouble() - 0.5) * 2.0;
                    float sp = 40.0F + rnd.nextFloat() * 80.0F;
                    spawn(SPARK, nx, ny, (float) Math.cos(a) * sp, (float) Math.sin(a) * sp, 0.5F + rnd.nextFloat() * 0.4F, 2.0F, 0, gold());
                }
                for (int i = 0; i < 3; i++) {
                    spawn(STAR, nx + rr(-16, 16), ny + rr(-18, 4), rr(-8, 8), rr(-20, -5), 0.7F, 2.0F, 0, gold());
                }
                spawn(RING, nx, ny, 0, 0, 0.7F, 0, 32.0F, 0xFFD58A);
            }
            case 3 -> {
                for (int i = 0; i < 6; i++) {
                    double a = -Math.PI / 2 + (rnd.nextDouble() - 0.5) * 1.6;
                    float sp = 30.0F + rnd.nextFloat() * 50.0F;
                    spawn(SPARK, nx, ny, (float) Math.cos(a) * sp, (float) Math.sin(a) * sp, 0.45F, 2.0F, 0, 0xFFF0C8);
                }
                for (int i = 0; i < 2; i++) {
                    spawn(PUFF, nx + rr(-4, 4), ny, rr(-8, 8), -30.0F, 0.9F, 3.0F, 8.0F, 0xFFFFFF);
                }
            }
            case 2 -> {
                for (int i = 0; i < 3; i++) {
                    spawn(PUFF, nx + rr(-5, 5), ny, rr(-10, 10), -22.0F - rnd.nextFloat() * 8.0F, 1.1F, 3.0F, 9.0F, 0xA8A8A0);
                }
            }
            default -> {
                for (int i = 0; i < 7; i++) {
                    spawn(PUFF, nx + rr(-8, 8), ny + rr(-4, 4), rr(-16, 16), -20.0F - rnd.nextFloat() * 20.0F, 1.7F, 4.0F, 14.0F, i % 2 == 0 ? 0x4A4040 : 0x6A6060);
                }
                spawn(RING, nx, ny, 0, 0, 0.6F, 0, 30.0F, 0xE3604C);
            }
        }
    }

    // ------------------------------------------------------------------ the customer

    /** 0 = nothing, 1..5 = the reaction to the last step (or to the finished drink). */
    public int reaction() { return reactGrade; }

    public float reactTime() { return reactT; }

    public boolean reactHold() { return reactHold; }

    public float dt() { return lastDt; }

    public float time() { return time; }

    public boolean chance(float perSecond) {
        return rnd.nextFloat() < perSecond * lastDt;
    }

    /** The head of the customer is at (x, y), one cell of its picture is c pixels: the pending grade is shown on it. */
    public void headBurst(int x, int y, int c) {
        int g = pendingHead;
        if (g == 0) return;
        pendingHead = 0;
        if (g == 5) {
            for (int i = 0; i < 6; i++) {
                spawn(HEART, x + rr(-3.5F * c, 3.5F * c), y - c + rr(0, c), rr(-8, 8), -(24.0F + rnd.nextFloat() * 18.0F), 1.5F, 2.0F, 0, i % 2 == 0 ? 0xE3A08C : 0xF29A9A);
            }
            for (int i = 0; i < 6; i++) {
                spawn(MOTE, x + rr(-4.0F * c, 4.0F * c), y + rr(-c, 3.0F * c), rr(-10, 10), rr(-20, 4), 1.1F, 1.0F, 0, gold());
            }
        } else if (g == 4) {
            for (int i = 0; i < 2; i++) {
                spawn(HEART, x + rr(-2.5F * c, 2.5F * c), y - c, rr(-6, 6), -(22.0F + rnd.nextFloat() * 10.0F), 1.3F, 1.0F, 0, 0xE3A08C);
            }
        } else if (g == 2) {
            spawn(DROP, x + 2.8F * c, y + 0.4F * c, 2, 16.0F, 1.1F, 1.0F, 0, 0x8FC4E8);
        } else if (g == 1) {
            for (int i = 0; i < 3; i++) {
                spawn(DROP, x + (i - 1) * 2.6F * c, y + 0.2F * c, rr(-6, 6), 8.0F + rnd.nextFloat() * 12.0F, 1.2F, 1.0F, 0, 0x8FC4E8);
            }
            for (int i = 0; i < 2; i++) {
                spawn(PUFF, x + rr(-c, c), y - 0.5F * c, rr(-6, 6), -14.0F, 1.2F, 3.0F, 8.0F, 0x9A9AA2);
            }
        }
    }

    /** A free particle for the customer: steam from the ears, a drop of sweat, a sparkle. */
    public void emitSteam(float x, float y, float vx) {
        spawn(PUFF, x, y, vx, -30.0F, 0.8F, 2.0F, 6.0F, 0xFFFFFF);
    }

    public void emitSweat(float x, float y) {
        spawn(DROP, x, y, 0, 14.0F, 1.0F, 1.0F, 0, 0x8FC4E8);
    }

    public void emitSparkle(float x, float y) {
        spawn(MOTE, x, y, rr(-6, 6), rr(-14, -4), 0.9F, 1.0F, 0, gold());
    }

    // ------------------------------------------------------------------ helpers

    private float rr(float a, float b) {
        return a + rnd.nextFloat() * (b - a);
    }

    private int gold() {
        return GOLDS[rnd.nextInt(GOLDS.length)];
    }

    private void spawn(int kind, float x, float y, float vx, float vy, float life, float size, float grow, int rgb) {
        P p = new P();
        p.kind = kind;
        p.x = x;
        p.y = y;
        p.vx = vx;
        p.vy = vy;
        p.life = p.max = life;
        p.size = size;
        p.grow = grow;
        p.color = rgb & 0xFFFFFF;
        parts.add(p);
    }

    private static int argb(int a, int rgb) {
        return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF);
    }

    // ------------------------------------------------------------------ drawing

    private static final int[] HEART_ROWS = {0b01010, 0b11111, 0b01110, 0b00100};

    public void render(GuiGraphics g, Font font) {
        if (parts.isEmpty() && popups.isEmpty()) return;
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(0.0F, 0.0F, 400.0F);
        for (P p : parts) {
            float t = p.life / p.max;                      // 1 -> 0
            int x = Math.round(p.x), y = Math.round(p.y);
            switch (p.kind) {
                case SPARK -> {
                    int sz = (int) p.size;
                    g.fill(x, y, x + sz, y + sz, argb((int) (255 * Math.min(1.0F, t * 1.6F)), p.color));
                }
                case STAR -> {
                    float tw = 0.65F + 0.35F * (float) Math.sin(time * 18.0F + p.x);
                    int r = Math.max(1, Math.round(p.size * 1.5F * tw * Math.min(1.0F, t * 2.0F + 0.2F)));
                    int a = (int) (255 * Math.min(1.0F, t * 1.8F));
                    g.fill(x - r, y, x + r + 1, y + 1, argb(a, p.color));
                    g.fill(x, y - r, x + 1, y + r + 1, argb(a, p.color));
                    g.fill(x - 1, y - 1, x + 2, y + 2, argb(a, 0xFFFFFF));
                }
                case PUFF -> {
                    int r = Math.round(p.size + p.grow * (1.0F - t));
                    Ui.disc(g, x, y, r, argb((int) (110 * t), p.color));
                }
                case RING -> {
                    int r = 2 + Math.round(p.grow * (1.0F - t) * (1.0F - t * 0.35F));
                    Ui.ring(g, x, y, r, 1, argb((int) (200 * t), p.color));
                }
                case HEART -> {
                    int k = Math.max(1, (int) p.size);
                    int a = (int) (255 * Math.min(1.0F, t * 2.0F));
                    for (int row = 0; row < 4; row++) {
                        for (int col = 0; col < 5; col++) {
                            if ((HEART_ROWS[row] >> (4 - col) & 1) == 0) continue;
                            int c = (row == 1 && col == 1) ? 0xFFFFFF : p.color;
                            g.fill(x + col * k, y + row * k, x + col * k + k, y + row * k + k, argb(a, c));
                        }
                    }
                }
                case DROP -> {
                    int a = (int) (255 * Math.min(1.0F, t * 2.0F));
                    g.fill(x, y, x + 1, y + 1, argb(a, p.color));
                    g.fill(x - 1, y + 1, x + 2, y + 3, argb(a, p.color));
                    g.fill(x, y + 2, x + 1, y + 3, argb(a, 0xFFFFFF));
                }
                default -> {                                                    // MOTE
                    float tw = 0.5F + 0.5F * (float) Math.sin(time * 14.0F + p.y);
                    g.fill(x, y, x + 1, y + 1, argb((int) (255 * Math.min(1.0F, t * 2.0F) * (0.45F + 0.55F * tw)), p.color));
                }
            }
        }
        for (Popup p : popups) {
            float t = p.life / p.max;
            int a = (int) (255 * Math.min(1.0F, t * 2.5F));
            if (a < 12) continue;
            float pop = 1.0F + 0.35F * Math.max(0.0F, 1.0F - (p.max - p.life) * 7.0F);       // a quick pop at the start
            ps.pushPose();
            ps.translate(p.x, p.y, 0.0F);
            ps.scale(p.scale * pop, p.scale * pop, 1.0F);
            g.drawString(font, p.text, -font.width(p.text) / 2, -4, argb(a, p.color), true);
            ps.popPose();
        }
        ps.popPose();
    }
}
