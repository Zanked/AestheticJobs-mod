package dev.aestheticjobs.client.barista;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.Order;
import dev.aestheticjobs.item.Dessert;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

/**
 * The bar behind the barista screen: a tiled wall with a warm pendant lamp, a shelf with the supplies, the wooden
 * counter, the REAL 3D model of the coffee machine (it leans toward the mouse), an order ticket on a pin and a
 * stand where the cup of the drink appears step by step. Everything is drawn from the item pictures of the mod.
 */
public final class BarScene {
    private BarScene() {}

    private static final String[] SHELF = {"coffee_beans", "syrup_vanilla", "milk_carton", "cream_carton", "syrup_caramel",
            "chocolate", "empty_cup", "macaron_pink", "cookie_heart", "macaron_mint", "cake_pop", "macaron_lemon"};
    private static final int[] CONFETTI = {0xFFE3A08C, 0xFFF6D58A, 0xFFA9C79A, 0xFFFFF6E2, 0xFFD9A850};

    private static ResourceLocation item(String name) {
        return ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "textures/item/" + name + ".png");
    }

    private static int alpha(int a, int rgb) {
        return (Math.max(0, Math.min(255, a)) << 24) | (rgb & 0xFFFFFF);
    }

    // ------------------------------------------------------------------ the room

    public static int counterTop(int h) {
        return (int) (h * 0.80F);
    }

    public static void background(GuiGraphics g, int w, int h, float t) {
        int counter = counterTop(h);
        g.fillGradient(0, 0, w, counter, 0xFF2E221E, 0xFF5C4034);

        // subway tiles
        for (int row = 0, y = 0; y < counter; row++, y += 12) {
            g.fill(0, y, w, y + 1, 0x24000000);
            g.fill(0, y + 1, w, y + 2, 0x0EFFFFFF);
            for (int x = (row % 2 == 0 ? 0 : 12); x < w; x += 24) {
                g.fill(x, y, x + 1, Math.min(y + 12, counter), 0x1C000000);
            }
        }

        // the pendant lamp and its warm light on the wall (it flares gold after a perfect step, stutters red after a bad one)
        SceneFx fx = SceneFx.get();
        int lx = w / 2, ly = (int) (h * 0.10F);
        float flicker = 1.0F + 0.04F * (float) Math.sin(t * 7.0 + Math.sin(t * 2.3) * 2.0);
        float flare = fx.lampFlare(), dim = fx.lampDim(), red = fx.lampRed();
        if (dim > 0.02F) flicker *= 1.0F - 0.55F * dim * (0.5F + 0.5F * (float) Math.sin(t * 38.0F));
        float boost = 1.0F + 0.35F * flare;
        int warm = Ui.lerp(0xFFFFD9A0, 0xFFFF7A66, red) & 0xFFFFFF;
        Ui.disc(g, lx, ly + 10, (int) (130 * flicker * boost), alpha(12 + (int) (flare * 8), warm));
        Ui.disc(g, lx, ly + 10, (int) (92 * flicker * boost), alpha(14 + (int) (flare * 10), warm));
        Ui.disc(g, lx, ly + 10, (int) (58 * flicker * boost), alpha(18 + (int) (flare * 12), Ui.lerp(0xFFFFE4B8, 0xFFFF9080, red) & 0xFFFFFF));
        if (flare > 0.05F) Ui.disc(g, lx, ly + 10, (int) (175 * flare), alpha((int) (14 * flare), 0xFFE9A8));
        int bulb = Ui.lerp(0xFFFFE9B0, 0xFFFFFFFF, flare);
        bulb = Ui.lerp(bulb, 0xFF9A6A4A, Math.min(1.0F, dim * 0.8F * (0.5F + 0.5F * (float) Math.sin(t * 38.0F))));
        bulb = Ui.lerp(bulb, 0xFFFF8A78, red * 0.6F);
        g.fill(lx, 0, lx + 1, ly - 6, 0xFF1E1614);
        g.fill(lx - 9, ly - 6, lx + 10, ly - 3, 0xFF3A2A22);
        g.fill(lx - 12, ly - 3, lx + 13, ly + 3, 0xFF4A3830);
        g.fill(lx - 6, ly + 3, lx + 7, ly + 6, bulb);
        fx.lampBurst(lx, ly + 6);

        // the shelf with the supplies and a few sweets
        int shelfY = (int) (h * 0.27F);
        int s = Math.max(24, Math.min(40, h / 8));
        int gap = s + 10;
        for (int i = 0, x = 12; x < w; i++, x += gap) {
            ResourceLocation tex = item(SHELF[i % SHELF.length]);
            g.fill(x + 3, shelfY - 3, x + s - 3, shelfY, 0x33000000);           // a soft shadow under the thing
            Ui.icon(g, tex, x, shelfY - s + 1, s);
        }
        g.fill(0, shelfY, w, shelfY + 5, 0xFF4A3228);
        g.fill(0, shelfY, w, shelfY + 1, 0xFF8A6450);
        g.fill(0, shelfY + 5, w, shelfY + 9, 0x33000000);
        for (int x = 30; x < w; x += 150) {
            g.fill(x, shelfY + 5, x + 4, shelfY + 16, 0xFF3A2820);                 // brackets
        }

        // the counter
        g.fillGradient(0, counter, w, h, 0xFF8A5E40, 0xFF5E3E2C);
        g.fill(0, counter, w, counter + 2, 0xFFB88660);
        g.fill(0, counter + 2, w, counter + 4, 0x44000000);
        for (int x = 40, k = 0; x < w; x += 56, k++) {
            g.fill(x + (k % 2) * 14, counter + 4, x + (k % 2) * 14 + 1, h, 0x26000000);
        }

        // soft darkening of the edges
        g.fillGradient(0, 0, w, h / 5, 0x66000000, 0x00000000);
        g.fillGradient(0, h - h / 6, w, h, 0x00000000, 0x77000000);
    }

    /** The wooden frame and the shadow of the work panel. */
    public static void frame(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x + 3, y + 6, x + w + 9, y + h + 11, 0x55000000);
        Ui.box(g, x - 6, y - 6, w + 12, h + 12, 0xFF2A1A13, 0xFF6A4A3A);
        g.fill(x - 5, y - 5, x + w + 5, y - 4, 0x44FFFFFF);
        g.fill(x - 5, y + h + 4, x + w + 5, y + h + 5, 0x33000000);
        for (int[] c : new int[][]{{x - 3, y - 3}, {x + w + 1, y - 3}, {x - 3, y + h + 1}, {x + w + 1, y + h + 1}}) {
            g.fill(c[0], c[1], c[0] + 2, c[1] + 2, 0xFFD2B48A);                         // nails
        }
    }

    // ------------------------------------------------------------------ the 3D machine

    /** The real block model of the machine. tilt = degrees toward the mouse; steam rises while a drink is brewed. */
    public static void machine(GuiGraphics g, ItemStack stack, int cx, int baseY, float scale, float tilt, float t, boolean working) {
        int sw = (int) (scale * 7.0F);
        g.fill(cx - sw, baseY - 3, cx + sw, baseY + 2, 0x33000000);                  // contact shadow
        g.fill(cx - sw + 3, baseY + 2, cx + sw - 3, baseY + 4, 0x22000000);

        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(cx, baseY - 8.0F * scale, 0.0F);
        ps.mulPose(Axis.YP.rotationDegrees(tilt));
        ps.scale(scale, scale, scale);
        g.renderItem(stack, -8, -8);
        ps.popPose();

        if (working) {
            ps.pushPose();
            ps.translate(0.0F, 0.0F, 400.0F);                                         // above the model
            for (int i = 0; i < 6; i++) {
                float ph = (t * 0.55F + i / 6.0F) % 1.0F;
                int px = cx + (int) (Math.sin(t * 2.0 + i * 1.7) * 3.0 * scale / 2.0F) + (int) (scale * 3);
                int py = (int) (baseY - 15.0F * scale - ph * 22.0F * scale / 2.0F);
                int size = 2 + (int) (ph * 5);
                g.fill(px, py, px + size, py + size, alpha((int) ((1.0F - ph) * 150), 0xFFFFFF));
            }
            ps.popPose();
        }
    }

    // ------------------------------------------------------------------ the cup stand

    public static void coaster(GuiGraphics g, int cx, int baseY, int size) {
        int hw = size / 2 + 8;
        g.fill(cx - hw + 2, baseY - 1, cx + hw - 2, baseY + 5, 0x44000000);
        g.fill(cx - hw, baseY - 3, cx + hw, baseY + 1, 0xFF3A2820);
        g.fill(cx - hw, baseY - 3, cx + hw, baseY - 2, 0xFF8A6450);
    }

    /** The picture as a dark silhouette, revealed from the bottom to p (0..1), full colour at 1. */
    public static void reveal(GuiGraphics g, ResourceLocation tex, int x, int y, int size, float p) {
        p = Math.max(0.0F, Math.min(1.0F, p));
        if (p < 1.0F) {
            g.setColor(0.13F, 0.10F, 0.10F, 0.80F);
            Ui.icon(g, tex, x, y, size);
            g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
        }
        if (p > 0.0F) {
            g.enableScissor(x, y + (int) (size * (1.0F - p)), x + size, y + size);
            Ui.icon(g, tex, x, y, size);
            g.disableScissor();
        }
    }

    /** A turntable: the picture turns around its axis (squashed in width, shaded when edge-on). */
    public static void spin(GuiGraphics g, ResourceLocation tex, int cx, int y, int size, float t) {
        float c = (float) Math.cos(t * 2.2);
        float wScale = Math.max(0.14F, Math.abs(c));
        float shade = 0.62F + 0.38F * wScale;
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(cx, 0.0F, 0.0F);
        ps.scale(wScale, 1.0F, 1.0F);
        g.setColor(shade, shade, shade, 1.0F);
        Ui.icon(g, tex, -size / 2, y, size);
        g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
        ps.popPose();
    }

    public static void confetti(GuiGraphics g, int cx, int width, int height, float t) {
        for (int i = 0; i < 26; i++) {
            float seed = i * 37.17F;
            int x = cx + (int) (Math.sin(seed * 1.3 + t * 1.4) * width * 0.5);
            int y = (int) ((t * 52.0F + i * 29.0F) % (height * 0.8F)) - 6;
            int size = 2 + (i % 3);
            g.fill(x, y, x + size, y + size, CONFETTI[i % CONFETTI.length]);
        }
    }

    // ------------------------------------------------------------------ the order ticket

    private static String fit(Font font, Component c, int maxW) {
        String s = c.getString();
        return font.width(s) <= maxW ? s : font.plainSubstrByWidth(s, maxW - 6) + "...";
    }

    /** A ticket on a pin: the customer, the drink (and dessert) and how long the customer still waits. */
    public static void ticket(GuiGraphics g, Font font, int x, int y, int w, Order o, long now) {
        Drink drink = Drink.byIndex(o.drink());
        Dessert dessert = Dessert.byIndex(o.dessert());
        if (drink == null) return;
        int h = dessert != null ? 128 : 92;
        int cx = x + w / 2;

        g.fill(x + 2, y + 4, x + w + 2, y + h + 4, 0x44000000);
        g.fill(x, y, x + w, y + h, 0xFFFFF6E2);
        g.fill(x, y, x + w, y + 1, 0xFFFFFFFF);
        g.fill(x, y + h - 1, x + w, y + h, 0xFFE6D9BA);
        for (int i = 0; i < w; i += 4) {                                                // torn bottom edge
            g.fill(x + i, y + h, x + i + 2, y + h + 2, 0xFFFFF6E2);
        }
        Ui.disc(g, cx, y + 4, 3, 0xFFC03A2A);                                           // the pin
        g.fill(cx - 1, y + 2, cx, y + 3, 0xFFF2A090);

        Ui.centered(g, font, Component.translatable("gui.aestheticjobs.cafe.ticket"), cx, y + 11, Ui.LABEL);
        Component who = Component.translatable("customer.aestheticjobs." + Math.floorMod(o.customer(), Order.CUSTOMERS));
        Ui.centered(g, font, Component.literal(fit(font, who, w - 6)), cx, y + 21, Ui.INK);

        Ui.icon(g, drink.iconTexture(), cx - 16, y + 31, 32);
        Ui.centered(g, font, Component.literal(fit(font, drink.displayName(), w - 6)), cx, y + 65, Ui.INK);
        int barY = y + 80;
        if (dessert != null) {
            Ui.icon(g, dessert.iconTexture(), cx - 12, y + 76, 24);
            Ui.centered(g, font, Component.literal(fit(font, dessert.displayName(), w - 6)), cx, y + 102, Ui.INK);
            barY = y + 114;
        }

        long elapsed = Math.max(0L, now - o.created());
        long fast = CafeLogic.fastTicks(drink, o.dessert());
        long ok = CafeLogic.okTicks(drink, o.dessert());
        double left = Math.max(0.0, 1.0 - elapsed / (double) ok);
        boolean bonus = elapsed <= fast, late = elapsed > ok;
        int color = bonus ? Ui.GOOD_D : late ? Ui.BAD_D : Ui.WARN_D;
        Ui.bar(g, x + 6, barY, w - 12, 5, left, color);
        int mark = x + 6 + (int) Math.round((w - 12) * (1.0 - fast / (double) ok));    // where the speed bonus ends
        g.fill(mark, barY - 2, mark + 1, barY + 7, Ui.INK);
        String key = bonus ? "gui.aestheticjobs.cafe.ticket.bonus" : late ? "gui.aestheticjobs.cafe.ticket.late" : "gui.aestheticjobs.cafe.ticket.ok";
        Ui.centered(g, font, Component.translatable(key), cx, barY + 9 - (dessert != null ? 1 : -1), color);
    }

    public static void noTicket(GuiGraphics g, Font font, int x, int y, int w) {
        int cx = x + w / 2;
        g.fill(x + 2, y + 4, x + w + 2, y + 44, 0x33000000);
        g.fill(x, y, x + w, y + 40, 0xCCFFF6E2);
        Ui.disc(g, cx, y + 4, 3, 0xFFB5A58A);
        Ui.centered(g, font, Component.translatable("gui.aestheticjobs.cafe.ticket"), cx, y + 12, Ui.LABEL);
        Ui.centered(g, font, Component.literal(fit(font, Component.translatable("gui.aestheticjobs.cafe.ticket.none"), w - 6)), cx, y + 24, Ui.LABEL);
    }
}
