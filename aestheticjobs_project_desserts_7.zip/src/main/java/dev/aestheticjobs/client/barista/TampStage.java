package dev.aestheticjobs.client.barista;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModSounds;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Tamp like a barista, in two moves.
 *
 *   1. PRESS: hold LMB and lean on the tamper: the force grows on the dial. Keep the bubble level in the middle
 *      with the mouse (a crooked press packs the puck crooked) and LET GO when the needle is in the green zone
 *      (about 14 kg). Too soft and the shot runs through, too hard and it chokes: the force you choose goes on
 *      to the shot (see Brew.tampForce and PullStage).
 *   2. TWIST: hold LMB lightly and circle the mouse around the ring, one smooth turn, to polish the puck.
 *      Even speed and a steady radius give a glossy, even surface.
 *
 * The score is the force, the level and the polish; a bad one makes the shot channel.
 */
public class TampStage extends Stage {
    private static final double TOLERANCE = 0.30;
    private static final double TARGET = 0.70, ZONE = 0.09;
    private static final double TURN = Math.PI * 2.0;
    private static final double TWIST_OMEGA = 4.0;

    private boolean twist;                                    // false: pressing, true: polishing

    // the level
    private double driftX, driftY, velX, velY, bx, by;
    // the press
    private double force, committedForce, pressTime, offSum, slopeSum;
    private boolean pressing, inZoneBefore;
    private double pressScore, levelScore, slope;
    private double liftT, flash, time;
    private float tickSound;
    // the twist
    private double lastAng, turn, dirSign, arcStart, omegaS, speedErr, radErr, twistTime;
    private boolean haveAng;
    private double twistScore;
    private float scrape;
    private int lastTickStep;

    public TampStage(Brew brew, Step step) {
        super(brew, step);
        driftX = (Math.random() - 0.5) * 0.8;
        driftY = (Math.random() - 0.5) * 0.8;
    }

    private int vcx() { return rx + 142; }

    private int vcy() { return ry + 68; }

    private static double clamp(double v, double a, double b) { return Math.max(a, Math.min(b, v)); }

    // ------------------------------------------------------------------ logic

    @Override
    public void update(float dt, int mx, int my) {
        if (done) {
            liftT = Math.min(1.0, liftT + dt * 2.5);
            return;
        }
        time += dt;
        flash = Math.max(0.0, flash - dt * 2.0);
        boolean hold = Ui.lmb();
        if (!twist) updatePress(dt, mx, my, hold);
        else updateTwist(dt, mx, my, hold);
    }

    private void updatePress(float dt, int mx, int my, boolean hold) {
        // the bubble level: the tamper tilts by itself, the mouse counters it
        velX += (Math.random() - 0.5) * 2.4 * dt;
        velY += (Math.random() - 0.5) * 2.4 * dt;
        velX = clamp(velX * (1 - 0.8 * dt), -0.5, 0.5);
        velY = clamp(velY * (1 - 0.8 * dt), -0.5, 0.5);
        driftX = clamp(driftX + velX * dt, -0.9, 0.9);
        driftY = clamp(driftY + velY * dt, -0.9, 0.9);
        double relX = clamp((mx - vcx()) / 38.0, -1.5, 1.5);
        double relY = clamp((my - vcy()) / 38.0, -1.5, 1.5);
        bx = relX * 0.6 + driftX;
        by = relY * 0.6 + driftY;
        double off = Math.sqrt(bx * bx + by * by);

        if (hold) {
            pressing = true;
            force = Math.min(1.0, force + (0.42 + 0.30 * force) * dt);     // leaning in: it gets heavier
            pressTime += dt * force;
            offSum += off * force * dt;
            slopeSum += bx * force * dt;
            int step = (int) (force * 10);
            if (step != lastTickStep) {
                lastTickStep = step;
                Ui.sound(ModSounds.BARISTA_TAMP.get(), 0.8F + (float) force * 0.8F, 0.12F);
            }
            boolean inZone = Math.abs(force - TARGET) <= ZONE;
            if (inZone && !inZoneBefore) Ui.sound(ModSounds.BARISTA_DING.get(), 1.7F, 0.22F);
            inZoneBefore = inZone;
        } else if (pressing) {
            if (force < 0.18) {                                           // just a tap: start again
                pressing = false;
                force = 0.0;
                pressTime = offSum = slopeSum = 0.0;
                lastTickStep = 0;
            } else {
                commit();
            }
        } else {
            force = Math.max(0.0, force - 2.0 * dt);
        }
    }

    private void commit() {
        committedForce = force;
        brew.tampForce = force;
        pressScore = clamp(100.0 - Math.abs(force - TARGET) * 190.0, 0.0, 100.0);
        double avgOff = pressTime <= 0 ? 0.5 : offSum / pressTime;
        levelScore = clamp(100.0 - avgOff * 230.0, 0.0, 100.0);
        slope = pressTime <= 0 ? 0.0 : clamp(slopeSum / pressTime, -1.0, 1.0);
        twist = true;
        flash = 1.0;
        Ui.sound(ModSounds.BARISTA_TAMP.get(), 0.7F, 0.8F);
        SceneFx.get().thump((float) force);
    }

    private void updateTwist(float dt, int mx, int my, boolean hold) {
        double dx = mx - vcx(), dy = my - vcy();
        double r = Math.sqrt(dx * dx + dy * dy), ang = Math.atan2(dy, dx);
        if (hold && r > 14 && r < 54) {
            if (haveAng && dt > 0) {
                double da = ang - lastAng;
                while (da > Math.PI) da -= TURN;
                while (da < -Math.PI) da += TURN;
                if (Math.abs(da) < 1.4) {
                    if (dirSign == 0 && Math.abs(da) > 0.03) {
                        dirSign = Math.signum(da);
                        arcStart = lastAng;
                    }
                    if (dirSign != 0) turn = clamp(turn + da * dirSign, 0.0, TURN);
                    double w = Math.abs(da) / dt;
                    omegaS += (w - omegaS) * Math.min(1.0, dt * 8.0);
                    if (Math.abs(da) > 0.004) {
                        twistTime += dt;
                        speedErr += Math.min(1.0, Math.abs(omegaS - TWIST_OMEGA) / TWIST_OMEGA) * dt;
                        radErr += Math.min(1.0, Math.abs(r - 30.0) / 22.0) * dt;
                        scrape += dt;
                        if (scrape > 0.3F) {
                            scrape = 0;
                            Ui.sound(ModSounds.BARISTA_GRIND.get(), 1.8F, 0.1F);
                        }
                    }
                }
            }
            lastAng = ang;
            haveAng = true;
        } else {
            haveAng = false;
            omegaS *= 1.0 - Math.min(1.0, dt * 4.0);
        }
        if (turn >= TURN - 0.01) {
            double tt = Math.max(0.3, twistTime);
            twistScore = clamp(100.0 - (speedErr / tt) * 60.0 - (radErr / tt) * 45.0, 0.0, 100.0);
            done = true;
            brew.channeling = 1.0 - score() / 100.0;
            Ui.sound(ModSounds.BARISTA_TAMP.get(), 0.8F, 1.0F);
            Ui.sound(ModSounds.BARISTA_DING.get(), 1.1F, 0.5F);
            SceneFx.get().thump(0.8F);
        }
    }

    @Override
    public int score() {
        double tw = done ? twistScore : 50.0;
        return (int) Math.round(clamp(0.34 * pressScore + 0.33 * levelScore + 0.33 * tw, 0.0, 100.0));
    }

    @Override
    public Component status() {
        if (done) return Component.translatable("step.aestheticjobs.tamp.done");
        if (!twist) {
            if (!pressing) return ((int) (time / 4.0)) % 2 == 0 ? Component.translatable("step.aestheticjobs.tamp.press") : step.hint();
            double off = Math.sqrt(bx * bx + by * by);
            if (off >= TOLERANCE) return Component.translatable("step.aestheticjobs.tamp.tilt");
            if (force > TARGET + ZONE) return Component.translatable("step.aestheticjobs.tamp.too_hard");
            if (force >= TARGET - ZONE) return Component.translatable("step.aestheticjobs.tamp.zone");
            return Component.translatable("step.aestheticjobs.tamp.level");
        }
        if (!haveAng || dirSign == 0) return Component.translatable("step.aestheticjobs.tamp.twist");
        if (omegaS > TWIST_OMEGA * 1.5) return Component.translatable("step.aestheticjobs.tamp.twist_fast");
        if (omegaS < TWIST_OMEGA * 0.5) return Component.translatable("step.aestheticjobs.tamp.twist_slow");
        return Component.translatable("step.aestheticjobs.tamp.twist_ok");
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void render(GuiGraphics g, Font font, int mx, int my) {
        drawChips(g, font);
        drawSide(g);
        if (!twist) drawVial(g);
        else drawTwist(g, mx, my);
        drawDial(g, font);
        double overall = done ? 1.0 : twist ? 0.5 + 0.5 * (turn / TURN) : 0.5 * (pressing ? Math.min(1.0, force / TARGET) : 0.0);
        Ui.bar(g, rx + 10, ry + rh - 14, rw - 20, 7, overall, Ui.GOOD);
        g.fill(rx + rw / 2 - 1, ry + rh - 17, rx + rw / 2 + 1, ry + rh - 4, Ui.INK);
    }

    private void drawChips(GuiGraphics g, Font font) {
        for (int i = 0; i < 2; i++) {
            boolean active = (i == 0) != twist && !done;
            boolean ok = done || (i == 0 && twist);
            int x = rx + 8 + i * 62, y = ry + 5;
            Ui.box(g, x, y, 58, 11, ok ? Ui.GOOD_D : active ? Ui.WARN_D : Ui.KHAKI, ok ? 0xFFE3F0DA : active ? 0xFFFBF1D0 : Ui.TAN);
            Ui.disc(g, x + 6, y + 5, 2, ok ? Ui.GOOD_D : active ? Ui.WARN_D : Ui.KHAKI);
            Ui.text(g, font, Component.translatable(i == 0 ? "step.aestheticjobs.tamp.chip.press" : "step.aestheticjobs.tamp.chip.twist"), x + 12, y + 2, Ui.INK);
        }
    }

    /** The portafilter from the side: the puck packs down under the tamper, which tilts like the bubble. */
    private void drawSide(GuiGraphics g) {
        int scx = rx + 52, bb = ry + rh - 24, bt = bb - 34;
        // the basket
        for (int y = bt; y < bb; y++) {
            double k = (y - bt) / 34.0;
            int half = (int) Math.round(32 - 6 * k);
            g.fill(scx - half - 3, y, scx - half, y + 1, Ui.STEEL_D);
            g.fill(scx + half, y, scx + half + 3, y + 1, Ui.STEEL_D);
            g.fill(scx - half, y, scx + half, y + 1, 0xFF8A6A58);
        }
        g.fill(scx - 8, bb, scx + 8, bb + 4, Ui.STEEL_D);
        g.fill(scx + 34, bt + 5, scx + 62, bt + 13, 0xFF6A4A3A);                 // the handle
        g.fill(scx + 34, bt + 5, scx + 62, bt + 6, 0xFF9A7258);

        double f = committed() ? committedForce : force;
        double looseTop = bb - 26;
        double contact = 0.30;
        double comp = f <= contact ? 0.0 : (f - contact) / (1.0 - contact);
        double puckTop = looseTop + 9.0 * comp;
        double sl = committed() ? slope : clamp(bx, -1.0, 1.0) * Math.min(1.0, f * 2.0);
        // the puck (a mound when loose, flat and a little crooked when packed)
        for (int x = -26; x <= 26; x++) {
            double mound = 4.0 * (1.0 - (x / 26.0) * (x / 26.0)) * (1.0 - Math.min(1.0, comp * 3.0 + (committed() ? 1.0 : 0.0)));
            int topY = (int) Math.round(puckTop - mound + sl * (x / 26.0) * 3.0);
            g.fill(scx + x, topY, scx + x + 1, bb, 0xFF4A2E22);
            g.fill(scx + x, topY, scx + x + 1, topY + 2, done ? 0xFF9A6E58 : 0xFF7A5642);
            if (((x * 7) & 3) == 0) g.fill(scx + x, topY + 4 + ((x * 3) & 7), scx + x + 1, topY + 5 + ((x * 3) & 7), 0xFF5E3C2E);
        }
        // the tamper
        double baseY;
        if (f < contact) baseY = looseTop - 2 - 34.0 * (1.0 - f / contact);
        else baseY = puckTop - 1;
        if (done) baseY -= 40.0 * liftT;
        else if (committed() && !done) baseY -= 0;                                  // it stays down while polishing
        float angle = done ? 0.0F : (float) clamp(bx * 10.0, -16.0, 16.0) * (committed() ? 0.0F : 1.0F);
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(scx, (float) baseY, 0.0F);
        ps.mulPose(Axis.ZP.rotationDegrees(angle));
        g.fill(-4, -18, 4, -5, Ui.STEEL_D);
        g.fill(-26, -5, 26, 0, Ui.STEEL);
        g.fill(-26, -1, 26, 0, Ui.STEEL_D);
        g.fill(-24, -5, 24, -4, 0xAAFFFFFF);
        if (twist && !done) {                                                        // a highlight that runs round the base
            int hx = (int) Math.round(Math.sin(turn * 2.0 + time * 6.0) * 20);
            g.fill(hx - 3, -4, hx + 3, -2, 0x88FFFFFF);
        }
        Ui.box(g, -13, -34, 26, 16, 0xFF6A4A3A, 0xFFD2A878);
        g.fill(-11, -32, 11, -31, 0x66FFFFFF);
        ps.popPose();
        if (flash > 0) g.fill(scx - 30, bt - 4, scx + 30, bb, ((int) (flash * 70)) << 24 | 0xFFFFFF);
    }

    private boolean committed() { return twist || done; }

    private void drawVial(GuiGraphics g) {
        int lx = vcx(), ly = vcy(), R = 40;
        Ui.disc(g, lx, ly, R + 2, Ui.KHAKI);
        Ui.disc(g, lx, ly, R, 0xFFE6F2F4);
        Ui.ring(g, lx, ly, (int) (TOLERANCE * 38), 1, Ui.GOOD_D);
        g.fill(lx - R, ly, lx + R + 1, ly + 1, 0xFFBDD7DC);
        g.fill(lx, ly - R, lx + 1, ly + R + 1, 0xFFBDD7DC);
        int px = lx + (int) clamp(bx * 38, -34, 34), py = ly + (int) clamp(by * 38, -34, 34);
        double off = Math.sqrt(bx * bx + by * by);
        Ui.disc(g, px, py, 7, off < TOLERANCE ? Ui.GOOD : off < 0.6 ? Ui.WARN : Ui.BAD);
        Ui.disc(g, px - 2, py - 2, 2, 0xFFFFFFFF);
    }

    /** The puck from above with the track to circle: the trail behind the mouse shows the polish. */
    private void drawTwist(GuiGraphics g, int mx, int my) {
        int cx = vcx(), cy = vcy(), R = 42;
        Ui.disc(g, cx, cy, R + 5, 0xFF8A6A58);
        Ui.disc(g, cx, cy, R + 2, 0xFFA9B2B6);
        double polish = turn / TURN;
        for (int y = -R; y <= R; y += 4) {
            for (int x = -R; x <= R; x += 4) {
                if (x * x + y * y > R * R) continue;
                int c = Ui.lerp(0xFF6A4435, 0xFF8A6050, 0.35 + 0.15 * Math.sin((x + y) * 0.2));
                c = Ui.lerp(c, 0xFFB88A70, polish * 0.55);
                g.fill(cx + x, cy + y, cx + x + 4, cy + y + 4, c);
            }
        }
        // the track: a dotted ring to follow
        for (int i = 0; i < 48; i++) {
            double a = i * TURN / 48.0;
            int x = cx + (int) Math.round(Math.cos(a) * 30), y = cy + (int) Math.round(Math.sin(a) * 30);
            g.fill(x, y, x + 2, y + 2, 0x66FFF6E2);
        }
        // the polished part
        if (dirSign != 0) {
            for (double k = 0; k < turn; k += 0.06) {
                double a = arcStart + dirSign * k;
                int x = cx + (int) Math.round(Math.cos(a) * 30), y = cy + (int) Math.round(Math.sin(a) * 30);
                g.fill(x - 1, y - 1, x + 3, y + 3, 0xFFFFF6E2);
            }
        }
        // the tamper head under the mouse
        double dx = mx - cx, dy = my - cy, d = Math.sqrt(dx * dx + dy * dy);
        if (d > 54) {
            dx = dx / d * 54;
            dy = dy / d * 54;
        }
        Ui.disc(g, cx + (int) dx, cy + (int) dy, 6, Ui.STEEL);
        Ui.disc(g, cx + (int) dx - 2, cy + (int) dy - 2, 2, 0xFFFFFFFF);
    }

    /** The pressure dial: green zone at the target, the needle follows the force. */
    private void drawDial(GuiGraphics g, Font font) {
        int cx = rx + 233, cy = ry + 64, R = 34;
        Ui.disc(g, cx, cy, R + 2, Ui.KHAKI);
        Ui.disc(g, cx, cy, R, 0xFFF6EEDC);
        for (double f = 0.0; f <= 1.0001; f += 0.1) {
            double a = Math.toRadians(225.0 - 270.0 * f);
            Ui.line(g, cx + Math.cos(a) * (R - 6), cy - Math.sin(a) * (R - 6), cx + Math.cos(a) * (R - 2), cy - Math.sin(a) * (R - 2), 1, Ui.LABEL);
        }
        for (double f = TARGET - ZONE; f <= TARGET + ZONE; f += 0.006) {
            double a = Math.toRadians(225.0 - 270.0 * f);
            int x = cx + (int) Math.round(Math.cos(a) * (R - 9)), y = cy - (int) Math.round(Math.sin(a) * (R - 9));
            g.fill(x - 1, y - 1, x + 2, y + 2, Ui.GOOD);
        }
        for (double f = TARGET + ZONE; f <= 1.0; f += 0.012) {
            double a = Math.toRadians(225.0 - 270.0 * f);
            int x = cx + (int) Math.round(Math.cos(a) * (R - 9)), y = cy - (int) Math.round(Math.sin(a) * (R - 9));
            g.fill(x - 1, y - 1, x + 2, y + 2, Ui.BAD);
        }
        double shown = committed() ? committedForce : force;
        double a = Math.toRadians(225.0 - 270.0 * shown);
        Ui.line(g, cx, cy, cx + Math.cos(a) * (R - 7), cy - Math.sin(a) * (R - 7), 2, Ui.INK);
        Ui.disc(g, cx, cy, 3, Ui.INK);
        Ui.centered(g, font, Component.translatable("step.aestheticjobs.tamp.kg", (int) Math.round(shown * 20)), cx, cy + 14, Ui.INK);
    }
}
