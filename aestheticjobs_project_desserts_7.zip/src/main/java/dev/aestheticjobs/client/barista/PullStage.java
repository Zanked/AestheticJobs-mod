package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModSounds;
import java.util.Locale;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Pull the shot. Two ways, depending on what comes next in the recipe:
 *
 * PARALLEL (the next step is the steaming or stirring): press BREW and the shot runs for real, about 20 seconds,
 * while you move on and steam the milk. A strip at the bottom of the screen shows the stream and the golden
 * window; press STOP (or R) when the stream is golden, whatever you are doing. Too early is sour, too late is
 * bitter, forget it and it over-extracts by itself. The next step that needs the espresso waits for it.
 *
 * SINGLE (the espresso is needed right away): hold LMB (or Space) to run the pump, let go when the stream is golden.
 *
 * The stream tells the stage of the shot: dark at the start, golden honey in the sweet spot, pale and watery when
 * it is over-extracted. A dialed-in grind runs at the normal speed, a finer one slower, a coarser one faster;
 * a crooked tamp makes the stream sputter.
 */
public class PullStage extends Stage {
    private final boolean parallel;
    private final double target, window, max;
    private double t;                       // shot time in "shot seconds"
    private boolean started, pumping, shotDone;
    private float soundTimer;
    private double jitter;
    private int finalScore;

    public PullStage(Brew brew, Step step, boolean parallel) {
        super(brew, step);
        this.parallel = parallel;
        this.target = parallel ? step.p1() * 2.8 : step.p1();            // espresso: 22 s while you steam, 8 s when you hold it
        this.window = parallel ? 1.5 : 0.7;
        this.max = target * (parallel ? 1.6 : 2.2);
    }

    private double flow() {
        return Math.max(0.5, Math.min(1.7, (1.0 - (brew.fineness - brew.idealFineness) * 0.12) * (1.0 - (brew.tampForce - 0.70) * 0.5)));
    }

    private double streamU() { return t / target; }

    private boolean inWindow() { return Math.abs(t - target) <= window; }

    // ------------------------------------------------------------------ the foreground stage

    @Override
    public void update(float dt, int mx, int my) {
        if (done) return;
        if (parallel) {
            if (!started && Ui.space()) begin();
            return;
        }
        boolean hold = Ui.lmb() || Ui.space();
        if (hold && !(started && !pumping)) {
            started = true;
            pumping = true;
            t += dt * flow();
            soundTimer += dt;
            if (soundTimer > 0.3) {
                soundTimer = 0;
                Ui.sound(ModSounds.BARISTA_PUMP.get(), 0.9F + (float) streamU() * 0.2F, 0.5F);
            }
            jitter = (Math.random() - 0.5) * 2 * brew.channeling * 5;
        } else if (started) {
            pumping = false;
            stopShot();
        }
        if (started && t >= max) stopShot();
    }

    private void begin() {
        if (started) return;
        started = true;
        pumping = true;
        Ui.sound(ModSounds.BARISTA_PUMP.get(), 0.9F, 0.7F);
    }

    private void stopShot() {
        if (shotDone) return;
        shotDone = true;
        pumping = false;
        finalScore = compute();
        brew.shotQuality = finalScore;
        brew.cremaKept = Math.max(0.2, Math.min(1.0, finalScore / 100.0 + 0.25));
        Ui.sound(ModSounds.BARISTA_DING.get(), 1.2F, 0.5F);
        if (!parallel) done = true;
    }

    private int compute() {
        double d = Math.abs(t - target);
        double s = d <= window ? 100 : Math.max(0, 100 - (d - window) * (parallel ? 14 : 30));
        s *= (1.0 - 0.35 * brew.channeling);
        return started ? (int) Math.round(s) : 0;
    }

    @Override
    public int score() {
        return shotDone ? finalScore : compute();
    }

    @Override
    public boolean click(double mx, double my, int button) {
        if (done || !parallel || started) return false;
        if (Ui.in(mx, my, rx + rw / 2 + 4, ry + 52, 110, 26)) {
            begin();
            return true;
        }
        return false;
    }

    @Override
    public boolean canFinish() { return false; }

    // ------------------------------------------------------------------ the background job

    @Override
    public boolean wantsBackground() { return parallel && started && !shotDone; }

    @Override
    public void updateBackground(float dt) {
        if (shotDone) return;
        t += dt * flow();
        soundTimer += dt;
        if (soundTimer > 0.7) {
            soundTimer = 0;
            Ui.sound(ModSounds.BARISTA_PUMP.get(), 0.9F + (float) streamU() * 0.2F, 0.3F);
        }
        jitter = (Math.random() - 0.5) * 2 * brew.channeling * 5;
        if (t >= max) stopShot();
    }

    @Override
    public boolean backgroundDone() { return shotDone; }

    @Override
    public void requestStop() {
        if (parallel && started) stopShot();
    }

    @Override
    public boolean clickStrip(double mx, double my, int x, int y, int w, int h) {
        if (shotDone) return false;
        if (Ui.in(mx, my, x + w - 54, y + 2, 50, h - 4)) {
            stopShot();
            return true;
        }
        return false;
    }

    @Override
    public void renderStrip(GuiGraphics g, Font font, int x, int y, int w, int h, int mx, int my) {
        Ui.box(g, x, y, w, h, Ui.KHAKI, 0xFFE9DDBF);
        if (!shotDone && inWindow()) g.renderOutline(x - 1, y - 1, w + 2, h + 2, Ui.GOOD_D);   // flashes green: now!
        // a little glass filling up
        int gx = x + 5, gy = y + 3, gw = 12, gh = h - 6;
        g.fill(gx - 1, gy - 1, gx + gw + 1, gy + gh + 1, 0xFFBDD7DC);
        g.fill(gx, gy, gx + gw, gy + gh, 0xFFF1F8F9);
        int lh = (int) (gh * Math.min(1.0, t / (target * 1.5)));
        g.fill(gx, gy + gh - lh, gx + gw, gy + gh, shotDone ? 0xFF52332A : streamColor());
        // the timeline with the golden window
        int bx = x + 24, bw = w - 24 - 62, by = y + h - 9;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 7, Ui.KHAKI);
        g.fill(bx, by, bx + bw, by + 6, Ui.TAN);
        int w0 = bx + (int) (bw * (target - window) / max), w1 = bx + (int) (bw * (target + window) / max);
        g.fill(w0, by, w1, by + 6, Ui.GOOD);
        int nx = bx + (int) (bw * Math.min(1.0, t / max));
        g.fill(nx - 1, by - 3, nx + 2, by + 9, Ui.INK);
        Ui.text(g, font, Component.literal(String.format(Locale.ROOT, "%.1f", t) + " c"), bx, y + 2, Ui.LABEL);
        Ui.text(g, font, streamWord(), bx + 38, y + 2, inWindow() ? Ui.GOOD_D : Ui.LABEL);
        Ui.button(g, font, x + w - 54, y + 2, 50, h - 4, Component.translatable("step.aestheticjobs.pull.stop"),
                Ui.in(mx, my, x + w - 54, y + 2, 50, h - 4), !shotDone, 2);
    }

    private Component streamWord() {
        double u = streamU();
        return Component.translatable(u < 0.55 ? "step.aestheticjobs.pull.dark" : u < 1.15 ? "step.aestheticjobs.pull.golden" : "step.aestheticjobs.pull.pale");
    }

    // ------------------------------------------------------------------ drawing of the foreground stage

    private int streamColor() {
        double u = streamU();
        if (u < 0.55) return Ui.lerp(0xFF3B241B, 0xFF7A4A28, u / 0.55);
        if (u < 1.15) return Ui.lerp(0xFFB87838, 0xFFD9A850, (u - 0.55) / 0.6);
        return Ui.lerp(0xFFE8C98A, 0xFFF4E4BC, Math.min(1.0, (u - 1.15) / 0.8));
    }

    @Override
    public Component status() {
        if (parallel) return Component.translatable("step.aestheticjobs.pull.parallel");
        if (!started) return step.hint();
        if (done) return Component.translatable("step.aestheticjobs.pull.time", String.format(Locale.ROOT, "%.1f", t));
        return streamWord();
    }

    @Override
    public void render(GuiGraphics g, Font font, int mx, int my) {
        int cx = rx + rw / 2 - 20, top = ry + 6;
        // group head
        Ui.box(g, cx - 40, top, 80, 22, Ui.STEEL_D, Ui.STEEL);
        g.fill(cx - 36, top + 3, cx - 30, top + 18, 0xFFEAEFF1);
        Ui.box(g, cx - 28, top + 22, 56, 10, 0xFF6A4A3A, 0xFF8A6A58);
        g.fill(cx - 22, top + 32, cx - 16, top + 38, 0xFF6A4A3A);
        g.fill(cx + 16, top + 32, cx + 22, top + 38, 0xFF6A4A3A);
        // the glass
        int gx = cx - 30, gy = top + 76, gw = 60, gh = 56 - (rh < 120 ? 10 : 0);
        double level = Math.min(1.0, t / (target * 1.5));
        int liquidH = (int) (gh * level);
        Ui.box(g, gx - 2, gy - 2, gw + 4, gh + 4, 0xFFBDD7DC, 0xFFE6F2F4);
        if (liquidH > 0) {
            g.fill(gx, gy + gh - liquidH, gx + gw, gy + gh, 0xFF52332A);
            int cremaH = Math.min(liquidH, 2 + (int) (6 * Math.min(1.0, streamU()) * (1.0 - 0.6 * Math.max(0, streamU() - 1.0))));
            g.fill(gx, gy + gh - liquidH, gx + gw, gy + gh - liquidH + cremaH, streamU() > 1.2 ? 0xFFE8C98A : Ui.GOLDEN);
        }
        g.fill(gx + 3, gy + 2, gx + 6, gy + gh - 2, 0x66FFFFFF);
        // the streams from the two spouts
        if (pumping) {
            int c = streamColor();
            int surfaceY = gy + gh - liquidH;
            for (int s = -1; s <= 1; s += 2) {
                int x = cx + s * 19 + (int) jitter;
                g.fill(x, top + 38, x + 3, Math.max(top + 40, surfaceY), c);
                if (brew.channeling > 0.35 && Math.random() < 0.5) {            // a sputtering jet
                    g.fill(x + (int) ((Math.random() - 0.5) * 16), top + 40, x + 2, surfaceY - 4, c);
                }
            }
        }
        if (parallel && !started) {
            // the BREW button: the shot runs on its own after this, go and steam the milk
            int bx = rx + rw / 2 + 4, by = ry + 52;
            Ui.button(g, font, bx, by, 110, 26, Component.translatable("step.aestheticjobs.pull.start"),
                    Ui.in(mx, my, bx, by, 110, 26), true, 1);
            Ui.text(g, font, Component.translatable("step.aestheticjobs.pull.start_hint", (int) Math.round(target)), bx, by + 32, Ui.LABEL);
        }
        // timeline with the golden window
        int bx = rx + 14, by = ry + rh - 22, bw = rw - 28;
        g.fill(bx - 1, by - 1, bx + bw + 1, by + 9, Ui.KHAKI);
        g.fill(bx, by, bx + bw, by + 8, Ui.TAN);
        int w0 = bx + (int) (bw * (target - window) / max), w1 = bx + (int) (bw * (target + window) / max);
        g.fill(w0, by, w1, by + 8, Ui.GOOD);
        int nx = bx + (int) (bw * Math.min(1.0, t / max));
        g.fill(nx - 1, by - 3, nx + 2, by + 11, Ui.INK);
        Ui.text(g, font, Component.literal(String.format(Locale.ROOT, "%.1f c", t)), bx, by - 12, Ui.LABEL);
    }
}
