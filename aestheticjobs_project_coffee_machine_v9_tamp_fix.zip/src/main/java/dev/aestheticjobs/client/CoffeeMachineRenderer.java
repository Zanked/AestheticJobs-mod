package dev.aestheticjobs.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.block.CoffeeMachineBlock;
import dev.aestheticjobs.block.CoffeeMachineBlockEntity;
import dev.aestheticjobs.cafe.Art;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.client.barista.LiveMachine;
import dev.aestheticjobs.client.barista.Ui;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import static dev.aestheticjobs.block.CoffeeMachineBlockEntity.*;

/**
 * Draws the LIVE parts of the espresso machine on top of its static model, driven by the phase the barista is in
 * (see CoffeeMachineBlockEntity): the cup that fills up (with the latte art on top when the drink is ready),
 * the coffee / water / milk stream, the portafilter, the pressure gauge, the steam pitcher and the status lamp.
 * Everything is built from coloured boxes on one white texel, in block pixels (1/16) of the north-facing machine;
 * the whole thing is turned to the facing of the block.
 */
public class CoffeeMachineRenderer implements BlockEntityRenderer<CoffeeMachineBlockEntity> {
    private static final ResourceLocation WHITE =
            ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "textures/block/fx_white.png");

    private static final int STEEL = 0xFFB8BEC2, STEEL_D = 0xFF8F979C, DARK = 0xFF4A3228, PORCELAIN = 0xFFF4EEE2;
    private static final int FOAM = 0xFFFCF0D6, WATER_C = 0xFFD8EEF4, STREAM = 0xFF8A5A30;

    // cup (outer box and wall) and its inside
    private static final double CUP_X0 = 6.6, CUP_X1 = 9.4, CUP_Z0 = 1.2, CUP_Z1 = 3.95, CUP_Y0 = 2.02, CUP_Y1 = 4.0, WALL = 0.3;
    private static final double IN_X0 = CUP_X0 + WALL, IN_X1 = CUP_X1 - WALL, IN_Z0 = CUP_Z0 + WALL, IN_Z1 = CUP_Z1 - WALL;
    private static final double IN_Y0 = CUP_Y0 + 0.3, IN_Y1 = CUP_Y1 - 0.15;

    /** Alpha of everything drawn right now (255 = solid). The pitchers and kettles over the cup are drawn as ghosts, so the art under them stays visible. */
    private static int ALPHA = 255;
    private static final int GHOST = 70;

    public CoffeeMachineRenderer(BlockEntityRendererProvider.Context context) {}

    /** The pitcher by the steam wand sticks out of the block (no @Override: the hook lives in the renderer on 1.21.1 NeoForge). */
    public AABB getRenderBoundingBox(CoffeeMachineBlockEntity be) {
        return new AABB(be.getBlockPos()).inflate(1.0);
    }

    @Override
    public void render(CoffeeMachineBlockEntity be, float pt, PoseStack ps, MultiBufferSource buffers, int light, int overlay) {
        Level level = be.getLevel();
        if (level == null) return;
        BlockState state = be.getBlockState();
        Direction facing = state.hasProperty(CoffeeMachineBlock.FACING) ? state.getValue(CoffeeMachineBlock.FACING) : Direction.NORTH;
        int phase = be.getPhase();
        Drink drink = Drink.byIndex(be.getDrinkIndex());
        if (drink == null) drink = Drink.ESPRESSO;
        double t = Math.max(0.0, (level.getGameTime() + pt - be.getPhaseStart()) / 20.0);   // seconds in this phase
        double clock = (level.getGameTime() + pt) / 20.0;

        VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucent(WHITE));   // quads are sorted, so the see-through pitcher blends right
        ALPHA = 255;
        int full = LightTexture.FULL_BRIGHT;

        ps.pushPose();
        ps.translate(0.5, 0.0, 0.5);
        ps.mulPose(Axis.YP.rotationDegrees(-yRot(facing)));
        ps.translate(-0.5, 0.0, -0.5);

        gauge(ps, vc, phase, t, clock, light, overlay);
        lamp(ps, vc, phase, clock, full, overlay);

        if (phase != IDLE) {
            LiveMachine.Live live = phase == PULL ? LiveMachine.get(be.getBlockPos()) : null;     // the barista's own game drives the real shot
            if (phase == GRIND) liveGrind(ps, vc, LiveMachine.grind(be.getBlockPos()), clock, light, overlay);     // everybody sees the grinder
            LiveMachine.Pour pr = phase == POUR ? LiveMachine.pour(be.getBlockPos()) : null;      // the latte art is poured by hand
            int tk = phase == WATER ? 0 : phase == LAYER ? 1 : phase == STIR ? 2 : phase == FINISH ? 3 : -1;
            LiveMachine.Top tp = tk < 0 ? null : LiveMachine.top(be.getBlockPos(), tk);          // played on the surface of the cup
            cup(ps, vc, be, drink, phase, t, live, pr, tp, light, overlay);
            if (tp != null) liveTool(ps, vc, tp, drink, light, overlay);
            if (phase == TAMP || phase == PULL) portafilter(ps, vc, phase, t, clock, light, overlay);
            LiveMachine.Tamp tl = LiveMachine.tamp(be.getBlockPos());
            if (tl != null && (phase == TAMP || phase == PULL)) liveTamp(ps, vc, tl, phase == TAMP, t, light, overlay);
            if (phase == PULL && live != null) liveStream(ps, vc, live, clock, full, overlay);
            else if (phase == PULL) stream(ps, vc, 8.0, 4.2, 2.9, 0.34, STREAM, t, clock, drink, phase, full, overlay);
            if (phase == WATER && tp == null) stream(ps, vc, 8.0, 4.2, 2.9, 0.5, WATER_C, t, clock, drink, phase, full, overlay);
            LiveMachine.Steam sl = LiveMachine.steam(be.getBlockPos());
            if (sl != null && (sl.active || phase == STEAM)) liveSteam(ps, vc, sl, light, overlay);       // the pitcher hangs on the barista's mouse
            else if (phase == STEAM) steamPitcher(ps, vc, t, clock, light, overlay);
            if (pr != null) {
                aimMark(ps, vc, pr, drink, light, overlay);
                livePitcher(ps, vc, pr, drink, light, overlay);
            }
            else if (phase == POUR) pourPitcher(ps, vc, drink, t, clock, light, overlay);
        }
        ps.popPose();
    }

    private static int yRot(Direction facing) {
        return switch (facing) {
            case EAST -> 90;
            case SOUTH -> 180;
            case WEST -> 270;
            default -> 0;
        };
    }

    // ------------------------------------------------------------------ the pieces

    /** Pressure gauge on the front: rests low, jumps while the shot is pulled, wobbles with the steam. */
    private static void gauge(PoseStack ps, VertexConsumer vc, int phase, double t, double clock, int light, int overlay) {
        double target = switch (phase) {
            case PULL -> 0.66 + 0.035 * Math.sin(clock * 9.0);
            case WATER -> 0.36;
            case STEAM -> 0.30 + 0.025 * Math.sin(clock * 13.0);
            case IDLE -> 0.10;
            default -> 0.14;
        };
        double rest = 0.10;
        double k = Math.min(1.0, t / 1.0);
        double v = rest + (target - rest) * (k * k * (3 - 2 * k));        // eases into the new value
        if (phase == IDLE) v = rest;
        double angle = -115.0 + 230.0 * v;                                  // clockwise from 12 o'clock, seen from the front

        box(ps, vc, 10.8, 7.4, 3.8, 13.2, 9.8, 4.0, DARK, light, overlay);          // rim
        box(ps, vc, 11.0, 7.6, 3.72, 13.0, 9.6, 3.8, 0xFFFFF6E2, light, overlay);   // face
        box(ps, vc, 11.2, 7.7, 3.69, 11.45, 8.0, 3.72, 0xFF7FA070, light, overlay);  // green zone marks
        box(ps, vc, 12.55, 7.7, 3.69, 12.8, 8.0, 3.72, 0xFFC98468, light, overlay);  // red zone mark
        ps.pushPose();
        ps.translate(12.0 / 16.0, 8.6 / 16.0, 0.0);   // dial centre
        ps.mulPose(Axis.ZP.rotationDegrees((float) angle));
        box(ps, vc, -0.09, -0.25, 3.62, 0.09, 0.8, 3.69, 0xFFC03A2A, light, overlay);   // needle (pivot at the origin)
        ps.popPose();
        box(ps, vc, 11.85, 8.45, 3.58, 12.15, 8.75, 3.69, DARK, light, overlay);     // hub
    }

    /** Status lamp: dim green when idle, pulsing amber while working, bright green when the drink is ready. */
    private static void lamp(PoseStack ps, VertexConsumer vc, int phase, double clock, int light, int overlay) {
        int color;
        if (phase == IDLE) {
            color = 0xFF3E6A44;
            light = LightTexture.pack(4, 4);
        } else if (phase == DONE) {
            color = 0xFF5CFF72;
        } else {
            color = Ui.lerp(0xFFFF9A20, 0xFFFFD070, 0.5 + 0.5 * Math.sin(clock * 6.0));
        }
        box(ps, vc, 3.2, 9.4, 3.82, 4.4, 10.3, 4.0, 0xFF2E2420, light, overlay);
        box(ps, vc, 3.35, 9.55, 3.78, 4.25, 10.15, 3.82, color, light, overlay);
    }

    private static double finalLevel(Drink d) {
        return switch (d) {
            case ESPRESSO -> 0.34;
            case AMERICANO -> 0.80;
            default -> 0.88;
        };
    }

    private static double ease(double t, double tau) {
        return 1.0 - Math.exp(-t / tau);
    }

    /** How full the cup is (0..1 of its inside) in a phase. */
    private static double level(Drink d, int phase, double t) {
        double shot = 0.34, fin = finalLevel(d);
        return switch (phase) {
            case GRIND, TAMP -> 0.0;
            case PULL -> shot * ease(t, 4.0);
            case WATER, LAYER, POUR -> shot + (fin - shot) * ease(t, phase == WATER ? 3.0 : 4.0);
            case STEAM, STIR -> d == Drink.MACCHIATO ? 0.0 : shot;
            default -> fin;
        };
    }

    private static boolean hasMilk(Drink d) {
        for (Drink.Supply s : d.supplies()) if (s == Drink.Supply.MILK || s == Drink.Supply.CREAM) return true;
        return false;
    }

    /** The cup that stands under the group head while a barista works, filling up; the finished art on top. */
    private static void cup(PoseStack ps, VertexConsumer vc, CoffeeMachineBlockEntity be, Drink drink, int phase,
                            double t, LiveMachine.Live live, LiveMachine.Pour pour, LiveMachine.Top tp, int light, int overlay) {
        if (phase == TAMP || (phase == PULL && t < 0.5)) return;     // the cup comes after the tamping: the portafilter lies on the tray, then is lifted into the group
        vessel(ps, vc, CUP_X0, CUP_Y0, CUP_Z0, CUP_X1, CUP_Y1, CUP_Z1, WALL, PORCELAIN, light, overlay);
        // a saucer under the cup
        box(ps, vc, CUP_X0 - 0.5, CUP_Y0, CUP_Z0 - 0.3, CUP_X1 + 0.5, CUP_Y0 + 0.12, CUP_Z1 - 0.1, 0xFFE6D9BA, light, overlay);

        double lv = live != null ? 0.34 * live.level
                : pour != null ? 0.34 + (finalLevel(drink) - 0.34) * pour.fill
                : tp != null && tp.kind == LiveMachine.Top.WATER
                        ? 0.34 + (finalLevel(drink) - 0.34) * Math.max(0.0, Math.min(1.0, (tp.level - 0.26) / 0.74))
                : level(drink, phase, t);
        if (lv <= 0.005) return;
        double top = IN_Y0 + (IN_Y1 - IN_Y0) * lv;
        if (pour != null) pour.surfaceY = top;
        if (tp != null) tp.surfaceY = top;

        // colour of the liquid, and of its surface (crema, then milk foam)
        int espresso = Ui.ESPRESSO;
        double mix = switch (phase) {
            case WATER, LAYER, POUR -> ease(t, 3.0);
            case FINISH, DONE -> 1.0;
            default -> 0.0;
        };
        int liquid = live != null ? live.liquid : pour != null ? drink.baseColor()
                : tp != null && tp.kind == LiveMachine.Top.WATER
                        ? Ui.lerp(espresso, drink.baseColor(), Math.max(0.0, Math.min(1.0, (tp.level - 0.26) * 1.6)))
                : Ui.lerp(espresso, drink.baseColor(), mix);
        int surface;
        if (phase == PULL) {
            surface = live != null ? live.surface : Ui.lerp(liquid, Ui.CREMA, Math.min(1.0, t / 3.0));
        } else if (hasMilk(drink) && (phase == POUR || phase == LAYER)) {
            surface = Ui.lerp(Ui.CREMA, FOAM, ease(t, 3.0));
        } else if (hasMilk(drink) && (phase == FINISH || phase == DONE)) {
            surface = FOAM;
        } else if (phase == WATER) {
            surface = Ui.lerp(Ui.CREMA, drink.baseColor(), ease(t, 3.0));
        } else {
            surface = Ui.CREMA;
        }

        box(ps, vc, IN_X0, IN_Y0, IN_Z0, IN_X1, top, IN_Z1, liquid, light, overlay);
        String shown = LiveMachine.doneArt(be.getBlockPos());
        String art = shown != null ? shown : be.getArt();
        if (phase == DONE && art.length() == Drink.CELLS) {
            artTop(ps, vc, art, drink, top + 0.01, light, overlay);
        } else if (pour != null) {
            liveArt(ps, vc, pour, top + 0.01, light, overlay);
        } else if (tp != null) {
            liveTop(ps, vc, tp, drink, liquid, top + 0.01, light, overlay);
        } else {
            quadUp(ps, vc, IN_X0, IN_Z0, IN_X1, IN_Z1, top + 0.01, surface, light, overlay);
        }
    }

    /** The 16x16 picture of the cup laid on the surface. Seen from the front: top of the picture = far side. */
    private static void artTop(PoseStack ps, VertexConsumer vc, String art, Drink drink, double y, int light, int overlay) {
        double cw = (IN_X1 - IN_X0) / Drink.SIZE, cd = (IN_Z1 - IN_Z0) / Drink.SIZE;
        for (int row = 0; row < Drink.SIZE; row++) {
            for (int col = 0; col < Drink.SIZE; col++) {
                if (!Drink.inCup(col, row)) continue;
                int rgb = Art.rgb(art.charAt(row * Drink.SIZE + col), drink);
                double x1 = IN_X1 - col * cw, x0 = x1 - cw;
                double z1 = IN_Z1 - row * cd, z0 = z1 - cd;
                quadUp(ps, vc, x0, z0, x1, z1, y, rgb, light, overlay);
            }
        }
    }

    /**
     * Where the portafilter is. While it is tamped it is NOT in the group head (the tamper would be inside the machine):
     * it lies on the drip tray in front of the group, the way a barista tamps on the counter. When the shot starts it
     * is lifted and locked into the group head. Returns {dy, dz} in machine pixels, relative to the docked position.
     */
    private static double[] pfOffset(int phase, double t) {
        double a = phase == TAMP ? 0.0 : Math.min(1.0, t / 0.5);          // 0 = on the tray, 1 = docked; PULL: half a second to lock in
        a = a * a * (3.0 - 2.0 * a);
        return new double[]{-TAMP_DY * (1.0 - a), -TAMP_DZ * (1.0 - a)};
    }

    /** The tray position of the portafilter, as an offset from the docked one: the basket lies on the tray (y = 2), toward the front. */
    private static final double TAMP_DY = 2.2, TAMP_DZ = 1.75;

    private static void portafilter(PoseStack ps, VertexConsumer vc, int phase, double t, double clock, int light, int overlay) {
        double shake = phase == PULL ? 0.025 * Math.sin(clock * 38.0) : 0.0;
        double[] o = pfOffset(phase, t);
        ps.pushPose();
        ps.translate(shake / 16.0, o[0] / 16.0, o[1] / 16.0);
        box(ps, vc, 6.4, 4.2, 2.5, 9.6, 5.0, 4.0, STEEL, light, overlay);                    // basket
        box(ps, vc, 6.7, 4.05, 2.8, 9.3, 4.2, 3.7, STEEL_D, light, overlay);                 // its bottom with the spouts
        box(ps, vc, 7.55, 4.35, 0.7, 8.45, 4.95, 2.5, DARK, light, overlay);                 // the handle toward the barista
        box(ps, vc, 7.55, 4.35, 0.5, 8.45, 4.95, 0.7, 0xFF6A4A3A, light, overlay);           // its end cap
        ps.popPose();
    }

    /** A thin stream falling from y0 down to the surface of the cup; flickers a little. */
    private static void stream(PoseStack ps, VertexConsumer vc, double cx, double y0, double cz, double width, int color,
                               double t, double clock, Drink drink, int phase, int light, int overlay) {
        if (t < 0.5) return;                                                   // the pump needs a moment
        double lv = level(drink, phase, t);
        double bottom = IN_Y0 + (IN_Y1 - IN_Y0) * lv;
        double w = width * (0.85 + 0.15 * Math.sin(clock * 31.0));
        double half = w / 2.0;
        if (phase == PULL) {                                                   // two spouts of a portafilter
            box(ps, vc, cx - 0.55 - half, bottom, cz - half, cx - 0.55 + half, y0, cz + half, color, light, overlay);
            box(ps, vc, cx + 0.55 - half, bottom, cz - half, cx + 0.55 + half, y0, cz + half, color, light, overlay);
        } else {
            box(ps, vc, cx - half, bottom, cz - half, cx + half, y0, cz + half, color, light, overlay);
        }
    }

    /** The stream of the shot as the barista pulls it: only while the pump runs, the colour tells the stage, a bad tamp sputters. */
    private static void liveStream(PoseStack ps, VertexConsumer vc, LiveMachine.Live live, double clock, int light, int overlay) {
        if (!live.pumping) return;
        double y0 = 4.2, cx = 8.0, cz = 2.9;
        double bottom = IN_Y0 + (IN_Y1 - IN_Y0) * (0.34 * live.level);
        if (bottom >= y0 - 0.1) return;
        double half = 0.34 * (0.85 + 0.15 * Math.sin(clock * 31.0)) / 2.0;
        double j = live.jitter * 0.06;
        box(ps, vc, cx - 0.55 - half + j, bottom, cz - half, cx - 0.55 + half + j, y0, cz + half, live.stream, light, overlay);
        box(ps, vc, cx + 0.55 - half - j, bottom, cz - half, cx + 0.55 + half - j, y0, cz + half, live.stream, light, overlay);
        if (live.channeling > 0.35 && Math.sin(clock * 41.0) > -0.2) {                      // a sputtering jet to the side
            double off = 0.9 * Math.sin(clock * 57.0);
            box(ps, vc, cx + off - 0.07, bottom, cz - 0.07, cx + off + 0.07, y0 - 0.3, cz + 0.07, live.stream, light, overlay);
        }
    }

    /** The grinder with its portafilter: a crank and a dial that turn, buttons, a hopper of beans, the heap of grounds growing below. */
    private static void liveGrind(PoseStack ps, VertexConsumer vc, LiveMachine.Grind g, double clock, int light, int overlay) {
        double fz = LiveMachine.GRIND_FACE_Z;
        double dose = g == null ? 0.0 : Math.min(1.4, g.dose01);
        box(ps, vc, 1.0, 2.0, 1.4, 4.8, 2.4, 4.0, STEEL_D, light, overlay);                       // the base plate
        box(ps, vc, 1.0, 2.4, 3.4, 4.8, 4.6, 4.0, STEEL_D, light, overlay);                       // the pillar
        box(ps, vc, 1.0, 4.6, fz, 4.8, 10.6, 4.0, STEEL, light, overlay);                         // the body
        box(ps, vc, 1.2, 4.8, fz - 0.1, 1.5, 10.4, fz, 0xFFEAEFF1, light, overlay);               // a highlight
        box(ps, vc, 1.3, 10.6, 1.7, 4.5, 13.4, 3.7, 0xFFE9D9B0, light, overlay);                  // the hopper
        box(ps, vc, 1.5, 13.2, 1.9, 4.3, 13.45, 3.5, 0xFF4A2E22, light, overlay);                 // the beans in it
        box(ps, vc, 2.5, 3.9, 2.0, 3.3, 4.6, 2.6, STEEL_D, light, overlay);                       // the nozzle
        // the portafilter under it
        box(ps, vc, 1.3, 2.4, 1.5, 4.5, 3.2, 3.1, STEEL, light, overlay);
        box(ps, vc, 2.45, 2.55, 0.0, 3.35, 3.15, 1.5, DARK, light, overlay);
        box(ps, vc, 2.45, 2.55, -0.2, 3.35, 3.15, 0.0, 0xFF6A4A3A, light, overlay);
        double heap = dose <= 0.0 ? 0.0 : 0.06 + 0.85 * dose;
        if (heap > 0.0) box(ps, vc, 1.5, 3.2, 1.7, 4.3, 3.2 + heap, 2.9, 0xFF6A4435, light, overlay);
        if (g != null && g.grinding) {                                                            // the grounds falling
            double w = 0.12 * (0.8 + 0.4 * Math.sin(clock * 40.0));
            box(ps, vc, 2.9 - w, 3.2 + heap, 2.3 - w, 2.9 + w, 3.9, 2.3 + w, 0xFF6A4435, light, overlay);
        }
        // buttons: + (above the dial), - and the test shot (below it)
        box(ps, vc, LiveMachine.BTN_PLUS[0] - 0.25, LiveMachine.BTN_PLUS[1] - 0.25, fz - 0.15, LiveMachine.BTN_PLUS[0] + 0.25, LiveMachine.BTN_PLUS[1] + 0.25, fz, 0xFFA9C79A, light, overlay);
        box(ps, vc, LiveMachine.BTN_MINUS[0] - 0.25, LiveMachine.BTN_MINUS[1] - 0.25, fz - 0.15, LiveMachine.BTN_MINUS[0] + 0.25, LiveMachine.BTN_MINUS[1] + 0.25, fz, 0xFFE3B08C, light, overlay);
        box(ps, vc, LiveMachine.BTN_TEST[0] - 0.3, LiveMachine.BTN_TEST[1] - 0.3, fz - 0.2, LiveMachine.BTN_TEST[0] + 0.3, LiveMachine.BTN_TEST[1] + 0.3, fz, 0xFFD9604C, light, overlay);
        // the dial of the fineness: the pointer shows the setting
        ps.pushPose();
        ps.translate(LiveMachine.DIAL[0] / 16.0, LiveMachine.DIAL[1] / 16.0, fz / 16.0);
        ps.mulPose(Axis.ZP.rotationDegrees((float) (g == null ? 0.0 : g.dialDeg)));
        box(ps, vc, -0.55, -0.55, -0.4, 0.55, 0.55, 0.0, STEEL_D, light, overlay);
        box(ps, vc, 0.0, -0.08, -0.5, 0.55, 0.08, -0.35, 0xFF2A1A13, light, overlay);
        ps.popPose();
        // the crank
        ps.pushPose();
        ps.translate(LiveMachine.CRANK_X / 16.0, LiveMachine.CRANK_Y / 16.0, fz / 16.0);
        ps.mulPose(Axis.ZP.rotationDegrees((float) (g == null ? clock * 25.0 : g.crankDeg)));
        box(ps, vc, -0.25, -0.25, -0.3, 0.25, 0.25, 0.0, STEEL_D, light, overlay);                // the axle
        box(ps, vc, 0.0, -0.15, -0.55, LiveMachine.CRANK_R, 0.15, -0.25, STEEL_D, light, overlay);  // the arm
        box(ps, vc, LiveMachine.CRANK_R - 0.15, -0.3, -1.1, LiveMachine.CRANK_R + 0.3, 0.3, -0.25, 0xFFE3A08C, light, overlay);  // the knob
        ps.popPose();
    }

    /** The surface of the cup as the step on it shapes it: the water thinning the crema, the espresso over the foam, the swirl, the finishing touch. */
    private static void liveTop(PoseStack ps, VertexConsumer vc, LiveMachine.Top tp, Drink drink, int liquid, double y, int light, int overlay) {
        switch (tp.kind) {
            case LiveMachine.Top.WATER -> quadUp(ps, vc, IN_X0, IN_Z0, IN_X1, IN_Z1, y, Ui.lerp(liquid, Ui.CREMA, Math.min(1.0, tp.b)), light, overlay);
            case LiveMachine.Top.LAYER -> {
                int esp = Ui.lerp(Ui.ESPRESSO, 0xFFB98A60, Math.min(1.0, tp.b / 1.6));
                quadUp(ps, vc, IN_X0, IN_Z0, IN_X1, IN_Z1, y, Ui.lerp(FOAM, esp, Math.min(1.0, tp.a)), light, overlay);
            }
            case LiveMachine.Top.STIR -> liveSwirl(ps, vc, tp, y, light, overlay);
            default -> liveDecor(ps, vc, tp, drink, y, light, overlay);
        }
    }

    /** The two colours swirling into one, cell by cell (the same formula as the flat game). */
    private static void liveSwirl(PoseStack ps, VertexConsumer vc, LiveMachine.Top tp, double y, int light, int overlay) {
        int n = 32;
        double c = (n - 1) / 2.0, rad = 0.475 * n, cw = (IN_X1 - IN_X0) / n, cd = (IN_Z1 - IN_Z0) / n, k = 52.0 / c;
        int a = Ui.ESPRESSO, b = tp.flag ? 0xFFB98A70 : 0xFFFBECCB;
        for (int row = 0; row < n; row++) {
            for (int col = 0; col < n; col++) {
                if ((col - c) * (col - c) + (row - c) * (row - c) > rad * rad) continue;
                double dx = (col - c) * k, dy = (row - c) * k, r = Math.sqrt(dx * dx + dy * dy);
                double t = 0.5 + 0.5 * Math.sin(Math.atan2(dy, dx) * 3 + r * 0.16 - tp.a * 2.2);
                int rgb = Ui.lerp(a, b, t * (1 - tp.b) + 0.5 * tp.b);
                if (tp.b < 0.55 && tp.omega < 3.4 && ((col * 7 + row * 13) % 11 == 0)) rgb = b;       // lumps when stirred too slowly
                double x1 = IN_X1 - col * cw, z1 = IN_Z1 - row * cd;
                quadUp(ps, vc, x1 - cw, z1 - cd, x1, z1, y, rgb, light, overlay);
            }
        }
    }

    /** The art of the pour, the faint guide and the touch laid over it. */
    private static void liveDecor(PoseStack ps, VertexConsumer vc, LiveMachine.Top tp, Drink drink, double y, int light, int overlay) {
        if (tp.milk == null || tp.deco == null || tp.guide == null) return;
        int base = Art.rgb('0', drink);
        int n = (int) Math.round(Math.sqrt(tp.milk.length));
        double c = (n - 1) / 2.0, rad = 0.475 * n, cw = (IN_X1 - IN_X0) / n, cd = (IN_Z1 - IN_Z0) / n;
        for (int row = 0; row < n; row++) {
            for (int col = 0; col < n; col++) {
                if ((col - c) * (col - c) + (row - c) * (row - c) > rad * rad) continue;
                double x1 = IN_X1 - col * cw, z1 = IN_Z1 - row * cd;
                quadUp(ps, vc, x1 - cw, z1 - cd, x1, z1, y, Ui.lerp(base, Ui.MILK, tp.milk[row * n + col]), light, overlay);
            }
        }
        int s = Drink.SIZE;
        double cw16 = (IN_X1 - IN_X0) / s, cd16 = (IN_Z1 - IN_Z0) / s;
        for (int row = 0; row < s; row++) {
            for (int col = 0; col < s; col++) {
                if (!Drink.inCup(col, row)) continue;
                char ch = tp.deco[row * s + col];
                int rgb;
                if (ch != '0') {
                    rgb = Art.rgb(ch, drink);
                } else if (tp.guide[row * s + col]) {                                      // the guide: a faint tint of what is under it
                    int under = Ui.lerp(base, Ui.MILK, tp.milk[(row * 2 + 1) * n + col * 2 + 1]);
                    rgb = Ui.lerp(under, 0xFFC98468, 0.35);
                } else {
                    continue;
                }
                double x1 = IN_X1 - col * cw16, z1 = IN_Z1 - row * cd16;
                quadUp(ps, vc, x1 - cw16, z1 - cd16, x1, z1, y + 0.01, rgb, light, overlay);
            }
        }
    }

    /** A vessel held over the cup: its lip at (x, y, z), the body leaning to the right of the screen. */
    private static void tiltedVessel(PoseStack ps, VertexConsumer vc, double x, double y, double z, int dir, double angle, int color, int light, int overlay) {
        ps.pushPose();
        ps.translate(x / 16.0, y / 16.0, z / 16.0);
        if (dir < 0) ps.mulPose(Axis.YP.rotationDegrees(180.0F));
        ps.mulPose(Axis.ZP.rotationDegrees((float) angle));
        ALPHA = GHOST;                                                                       // see-through: the cup under it stays readable
        vessel(ps, vc, 0.0, -0.9, -1.2, 3.3, 1.6, 1.2, 0.2, color, light, overlay);
        box(ps, vc, 3.3, 0.0, -0.2, 4.2, 1.2, 0.2, STEEL_D, light, overlay);
        ALPHA = 255;
        ps.popPose();
    }

    /** The tool of the step: the kettle, the jug of espresso with the spoon, the stirring spoon, the shaker / bag / bottle. */
    private static void liveTool(PoseStack ps, VertexConsumer vc, LiveMachine.Top tp, Drink drink, int light, int overlay) {
        double cx = LiveMachine.CUP_X, cz = LiveMachine.CUP_Z, y = tp.surfaceY + 0.01;
        switch (tp.kind) {
            case LiveMachine.Top.WATER -> {
                tiltedVessel(ps, vc, cx + tp.toolX, y + 2.4, cz, tp.dir, 38.0, STEEL, light, overlay);
                if (tp.active) box(ps, vc, cx + tp.toolX - 0.08, y, cz - 0.08, cx + tp.toolX + 0.08, y + 2.4, cz + 0.08, WATER_C, light, overlay);
            }
            case LiveMachine.Top.LAYER -> {
                double sx = cx + tp.spoonX;                                                  // the spoon swings over the foam
                box(ps, vc, sx - 0.6, y + 0.1, cz - 0.35, sx + 0.6, y + 0.22, cz + 0.35, STEEL, light, overlay);
                box(ps, vc, sx + (tp.dir > 0 ? 0.6 : -2.8), y + 0.12, cz - 0.07, sx + (tp.dir > 0 ? 2.8 : -0.6), y + 0.2, cz + 0.07, STEEL_D, light, overlay);
                tiltedVessel(ps, vc, cx + tp.toolX, y + 2.6, cz, tp.dir, 40.0, 0xFF8A6A58, light, overlay);
                if (tp.active) box(ps, vc, cx + tp.toolX - 0.08, tp.aimed ? y + 0.22 : y, cz - 0.08, cx + tp.toolX + 0.08, y + 2.6, cz + 0.08, 0xFF52332A, light, overlay);
            }
            case LiveMachine.Top.STIR -> {
                if (!tp.active) return;
                ps.pushPose();
                ps.translate((cx + tp.toolX) / 16.0, (y + 0.1) / 16.0, (cz + tp.toolZ) / 16.0);
                if (tp.dir < 0) ps.mulPose(Axis.YP.rotationDegrees(180.0F));
                ps.mulPose(Axis.ZP.rotationDegrees(62.0F));
                box(ps, vc, 0.0, -0.07, -0.07, 5.0, 0.07, 0.07, STEEL_D, light, overlay);
                box(ps, vc, -0.1, -0.1, -0.3, 0.5, 0.1, 0.3, STEEL, light, overlay);
                ps.popPose();
            }
            default -> {
                int col = (int) tp.a == 0 ? 0xFF8A5E40 : (int) tp.a == 1 ? 0xFFFFF9EC : 0xFFE2A85A;
                double lift = tp.active ? 1.6 : 2.3;
                tiltedVessel(ps, vc, cx + tp.toolX, y + lift, cz + tp.toolZ, tp.dir, 38.0, col, light, overlay);
                if (tp.active) {
                    double w = (int) tp.a == 0 ? 0.22 : 0.1;
                    box(ps, vc, cx + tp.toolX - w, y, cz + tp.toolZ - w, cx + tp.toolX + w, y + lift, cz + tp.toolZ + w, tp.color, light, overlay);
                }
            }
        }
    }

    /** The milk grid of the barista's own pour laid on the surface of the cup (the same orientation as artTop). */
    private static void liveArt(PoseStack ps, VertexConsumer vc, LiveMachine.Pour pr, double y, int light, int overlay) {
        if (pr.milk == null) return;
        int n = (int) Math.round(Math.sqrt(pr.milk.length));
        double c = (n - 1) / 2.0, rad = 0.475 * n;
        double cw = (IN_X1 - IN_X0) / n, cd = (IN_Z1 - IN_Z0) / n;
        for (int row = 0; row < n; row++) {
            for (int col = 0; col < n; col++) {
                if ((col - c) * (col - c) + (row - c) * (row - c) > rad * rad) continue;
                int rgb = Ui.lerp(pr.base, Ui.MILK, pr.milk[row * n + col]);
                double x1 = IN_X1 - col * cw, z1 = IN_Z1 - row * cd;
                quadUp(ps, vc, x1 - cw, z1 - cd, x1, z1, y, rgb, light, overlay);
            }
        }
    }

    /** A small ring on the foam under the spout: shows exactly where the milk lands, whatever the pitcher covers. */
    private static void aimMark(PoseStack ps, VertexConsumer vc, LiveMachine.Pour pr, Drink drink, int light, int overlay) {
        if (pr.done) return;
        double y = IN_Y0 + (IN_Y1 - IN_Y0) * (0.34 + (finalLevel(drink) - 0.34) * pr.fill) + 0.03;
        double r = pr.picking ? 0.3 : 0.42, w = 0.09;
        int col = pr.pouring ? 0xFFE2574C : pr.picking ? 0xFF4A3228 : 0xFFF2A8B8;
        quadUp(ps, vc, pr.x - r, pr.z - r, pr.x + r, pr.z - r + w, y, col, light, overlay);
        quadUp(ps, vc, pr.x - r, pr.z + r - w, pr.x + r, pr.z + r, y, col, light, overlay);
        quadUp(ps, vc, pr.x - r, pr.z - r, pr.x - r + w, pr.z + r, y, col, light, overlay);
        quadUp(ps, vc, pr.x + r - w, pr.z - r, pr.x + r, pr.z + r, y, col, light, overlay);
    }

    /** The pitcher the barista pours from (its lip at the pour point, the body leaning to the right of the screen) or the pick. */
    private static void livePitcher(PoseStack ps, VertexConsumer vc, LiveMachine.Pour pr, Drink drink, int light, int overlay) {
        if (pr.done) return;
        double top = IN_Y0 + (IN_Y1 - IN_Y0) * (0.34 + (finalLevel(drink) - 0.34) * pr.fill) + 0.01;
        ps.pushPose();
        if (pr.picking) {                                                                  // the pick: a thin stick through the foam
            ps.translate(pr.x / 16.0, (top + 0.05) / 16.0, pr.z / 16.0);
            if (pr.dir < 0) ps.mulPose(Axis.YP.rotationDegrees(180.0F));
            ps.mulPose(Axis.ZP.rotationDegrees(55.0F));
            box(ps, vc, 0.0, -0.05, -0.05, 4.0, 0.05, 0.05, STEEL_D, light, overlay);
            box(ps, vc, 0.0, -0.07, -0.07, 0.3, 0.07, 0.07, DARK, light, overlay);
            ps.popPose();
            return;
        }
        double lift = 0.5 + 0.7 * (1.0 - pr.tilt);                                          // barely tilted: the pitcher stands higher
        ps.translate(pr.x / 16.0, (top + lift) / 16.0, pr.z / 16.0);
        if (pr.dir < 0) ps.mulPose(Axis.YP.rotationDegrees(180.0F));
        ps.mulPose(Axis.ZP.rotationDegrees((float) (18.0 + 40.0 * pr.tilt)));
        ALPHA = GHOST;                                                                      // the pitcher is a ghost: you must see the art under it
        vessel(ps, vc, 0.0, -0.9, -1.2, 3.3, 1.6, 1.2, 0.2, STEEL, light, overlay);
        box(ps, vc, 3.3, 0.0, -0.2, 4.2, 1.2, 0.2, STEEL_D, light, overlay);               // the handle
        ALPHA = 255;
        ps.popPose();
        if (pr.pouring) {                                                                   // the thread of milk
            double w = 0.18 * (0.6 + 0.8 * pr.tilt);
            box(ps, vc, pr.x - w / 2, top, pr.z - w / 2, pr.x + w / 2, top + lift, pr.z + w / 2, FOAM, light, overlay);
        }
    }

    /** The puck of ground coffee in the basket and, while it is tamped, the tamper above it (tilted like the bubble). */
    private static void liveTamp(PoseStack ps, VertexConsumer vc, LiveMachine.Tamp t, boolean withTamper, double time, int light, int overlay) {
        double[] o = pfOffset(withTamper ? TAMP : PULL, time);
        double top = 5.0 + o[0], cx = 8.0, cz = 3.25 + o[1];
        double h = 0.45 * (1.0 - t.comp) + 0.04;
        int grounds = Ui.lerp(0xFF4A2E22, 0xFF9A6E58, t.polish);
        box(ps, vc, 6.6, top, cz - 0.55, 9.4, top + h, cz + 0.55, grounds, light, overlay);
        if (!withTamper || !t.tamper) return;
        ps.pushPose();
        ps.translate((cx + t.offX) / 16.0, (top + h + t.lift) / 16.0, (cz + t.offZ) / 16.0);
        ps.mulPose(Axis.ZP.rotationDegrees((float) t.rotZ));
        ps.mulPose(Axis.XP.rotationDegrees((float) t.rotX));
        box(ps, vc, -1.5, 0.0, -0.9, 1.5, 0.4, 0.9, STEEL, light, overlay);                    // the base
        box(ps, vc, -0.45, 0.4, -0.45, 0.45, 3.0, 0.45, STEEL_D, light, overlay);              // the neck
        box(ps, vc, -1.0, 3.0, -0.8, 1.0, 4.4, 0.8, 0xFFD2A878, light, overlay);               // the wooden handle
        ps.popPose();
    }

    /** The steam wand and the pitcher the barista holds: it hangs on the mouse, tilts, and the milk in it slops and scorches. */
    private static void liveSteam(PoseStack ps, VertexConsumer vc, LiveMachine.Steam s, int light, int overlay) {
        double wx = LiveMachine.WAND_X, wy = LiveMachine.WAND_Y, wz = LiveMachine.WAND_Z;
        box(ps, vc, wx - 0.12, wy, wz - 0.12, wx + 0.12, wy + 8.0, wz + 0.12, STEEL_D, light, overlay);       // the wand
        if (s.valve && s.active) {                                                                            // the jet from the tip
            double len = s.inAir ? 1.4 : 0.6;
            box(ps, vc, wx - 0.1, wy - len, wz - 0.1, wx + 0.1, wy, wz + 0.1, 0xFFF4F4F0, light, overlay);
        }
        double hw = 1.65, hd = 1.2, h = 3.4;
        ps.pushPose();
        ps.translate(s.x / 16.0, s.y / 16.0, s.z / 16.0);
        ps.mulPose(Axis.ZP.rotationDegrees((float) s.tilt));
        vessel(ps, vc, -hw, -h, -hd, hw, 0.0, hd, 0.25, STEEL, light, overlay);
        double top = -s.depth;
        int milk = Ui.lerp(0xFFF8EBD0, 0xFFD6A55A, Math.min(1.0, s.burn));
        box(ps, vc, -hw + 0.25, -h + 0.25, -hd + 0.25, hw - 0.25, top, hd - 0.25, milk, light, overlay);       // the milk
        ps.pushPose();                                                                                        // the foam: its surface stays level
        ps.translate(0.0, top / 16.0, 0.0);
        ps.mulPose(Axis.ZP.rotationDegrees((float) (-s.tilt + s.slosh * 16.0)));
        int foam = Ui.lerp(0xFFFCF0D6, 0xFFE6C080, Math.min(1.0, s.burn));
        box(ps, vc, -hw + 0.25, 0.0, -hd + 0.25, hw - 0.25, Math.min(1.0, s.foam * 1.4) + 0.05, hd - 0.25, foam, light, overlay);
        ps.popPose();
        box(ps, vc, hw, -2.6, -0.25, hw + 1.1, -0.5, 0.25, STEEL_D, light, overlay);                          // the handle
        ps.popPose();
    }

    /** The pitcher by the steam wand: the milk in it gets lighter and rises while it is steamed. */
    private static void steamPitcher(PoseStack ps, VertexConsumer vc, double t, double clock, int light, int overlay) {
        double sh = 0.03 * Math.sin(clock * 47.0);
        ps.pushPose();
        ps.translate(sh / 16.0, 0.0, 0.0);
        vessel(ps, vc, 14.1, 0.6, 4.3, 16.5, 4.0, 6.7, 0.3, STEEL, light, overlay);
        double lv = 0.45 + 0.30 * ease(t, 10.0);
        double top = 0.9 + (3.85 - 0.9) * lv;
        box(ps, vc, 14.4, 0.9, 4.6, 16.2, top, 6.4, 0xFFF2EDE0, light, overlay);
        quadUp(ps, vc, 14.4, 4.6, 16.2, 6.4, top + 0.01, Ui.lerp(0xFFF2EDE0, FOAM, ease(t, 8.0)), light, overlay);
        ps.popPose();
    }

    /** The pitcher over the cup that sways like a barista's hand drawing the art. */
    private static void pourPitcher(PoseStack ps, VertexConsumer vc, Drink drink, double t, double clock, int light, int overlay) {
        double sway = 0.55 * Math.sin(clock * 2.6);
        double spoutY = 6.7, spoutZ = 2.6, x = 8.0 + sway;
        ps.pushPose();
        ps.translate(x / 16.0, spoutY / 16.0, spoutZ / 16.0);
        ps.mulPose(Axis.XP.rotationDegrees(30.0F));                                          // tilted: the back end is up
        vessel(ps, vc, -1.1, -0.2, -2.4, 1.1, 2.2, 0.0, 0.3, STEEL, light, overlay);
        ps.popPose();
        if (t > 0.3) {                                                                       // the milk stream
            double lv = level(drink, POUR, t);
            double bottom = IN_Y0 + (IN_Y1 - IN_Y0) * lv;
            double w = 0.3 * (0.85 + 0.15 * Math.sin(clock * 29.0));
            box(ps, vc, x - w / 2, bottom, spoutZ - w / 2, x + w / 2, spoutY - 0.1, spoutZ + w / 2, FOAM, light, overlay);
        }
    }

    // ------------------------------------------------------------------ geometry helpers (block pixels)

    /** An open vessel: a bottom and four walls. */
    private static void vessel(PoseStack ps, VertexConsumer vc, double x0, double y0, double z0, double x1, double y1, double z1,
                               double wall, int color, int light, int overlay) {
        box(ps, vc, x0, y0, z0, x1, y0 + wall, z1, color, light, overlay);
        box(ps, vc, x0, y0 + wall, z0, x0 + wall, y1, z1, color, light, overlay);
        box(ps, vc, x1 - wall, y0 + wall, z0, x1, y1, z1, color, light, overlay);
        box(ps, vc, x0 + wall, y0 + wall, z0, x1 - wall, y1, z0 + wall, color, light, overlay);
        box(ps, vc, x0 + wall, y0 + wall, z1 - wall, x1 - wall, y1, z1, color, light, overlay);
    }

    private static void box(PoseStack ps, VertexConsumer vc, double ax, double ay, double az, double bx, double by, double bz,
                            int argb, int light, int overlay) {
        PoseStack.Pose p = ps.last();
        float x0 = (float) (ax / 16.0), y0 = (float) (ay / 16.0), z0 = (float) (az / 16.0);
        float x1 = (float) (bx / 16.0), y1 = (float) (by / 16.0), z1 = (float) (bz / 16.0);
        int r = argb >> 16 & 255, g = argb >> 8 & 255, b = argb & 255;
        // up
        v(vc, p, x0, y1, z0, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x0, y1, z1, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x1, y1, z1, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x1, y1, z0, r, g, b, light, overlay, 0, 1, 0);
        // down
        v(vc, p, x0, y0, z0, r, g, b, light, overlay, 0, -1, 0);
        v(vc, p, x1, y0, z0, r, g, b, light, overlay, 0, -1, 0);
        v(vc, p, x1, y0, z1, r, g, b, light, overlay, 0, -1, 0);
        v(vc, p, x0, y0, z1, r, g, b, light, overlay, 0, -1, 0);
        // north (-z)
        v(vc, p, x1, y1, z0, r, g, b, light, overlay, 0, 0, -1);
        v(vc, p, x1, y0, z0, r, g, b, light, overlay, 0, 0, -1);
        v(vc, p, x0, y0, z0, r, g, b, light, overlay, 0, 0, -1);
        v(vc, p, x0, y1, z0, r, g, b, light, overlay, 0, 0, -1);
        // south (+z)
        v(vc, p, x0, y1, z1, r, g, b, light, overlay, 0, 0, 1);
        v(vc, p, x0, y0, z1, r, g, b, light, overlay, 0, 0, 1);
        v(vc, p, x1, y0, z1, r, g, b, light, overlay, 0, 0, 1);
        v(vc, p, x1, y1, z1, r, g, b, light, overlay, 0, 0, 1);
        // west (-x)
        v(vc, p, x0, y1, z0, r, g, b, light, overlay, -1, 0, 0);
        v(vc, p, x0, y0, z0, r, g, b, light, overlay, -1, 0, 0);
        v(vc, p, x0, y0, z1, r, g, b, light, overlay, -1, 0, 0);
        v(vc, p, x0, y1, z1, r, g, b, light, overlay, -1, 0, 0);
        // east (+x)
        v(vc, p, x1, y1, z1, r, g, b, light, overlay, 1, 0, 0);
        v(vc, p, x1, y0, z1, r, g, b, light, overlay, 1, 0, 0);
        v(vc, p, x1, y0, z0, r, g, b, light, overlay, 1, 0, 0);
        v(vc, p, x1, y1, z0, r, g, b, light, overlay, 1, 0, 0);
    }

    /** Only the top face (the surface of a liquid). */
    private static void quadUp(PoseStack ps, VertexConsumer vc, double ax, double az, double bx, double bz, double y,
                               int argb, int light, int overlay) {
        PoseStack.Pose p = ps.last();
        float x0 = (float) (ax / 16.0), z0 = (float) (az / 16.0), x1 = (float) (bx / 16.0), z1 = (float) (bz / 16.0);
        float yy = (float) (y / 16.0);
        int r = argb >> 16 & 255, g = argb >> 8 & 255, b = argb & 255;
        v(vc, p, x0, yy, z0, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x0, yy, z1, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x1, yy, z1, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x1, yy, z0, r, g, b, light, overlay, 0, 1, 0);
    }

    private static void v(VertexConsumer vc, PoseStack.Pose p, float x, float y, float z, int r, int g, int b,
                          int light, int overlay, float nx, float ny, float nz) {
        vc.addVertex(p, x, y, z).setColor(r, g, b, ALPHA).setUv(0.5F, 0.5F).setOverlay(overlay).setLight(light).setNormal(p, nx, ny, nz);
    }
}
