package dev.aestheticjobs.cafe;

import dev.aestheticjobs.economy.Bank;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.economy.Transaction;
import dev.aestheticjobs.entity.CafeCustomerEntity;
import dev.aestheticjobs.job.Jobs;
import dev.aestheticjobs.job.Profession;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.job.Shift;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.registry.ModItems;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

public final class CafeLogic {
    public static final String CAFE_JOB = "cafe_worker";
    /** The average chance that a customer orders a dessert (every customer has its own, see Personality), and the extra patience / speed-bonus time a dessert gives. */
    public static final float DESSERT_CHANCE = 0.45F;
    public static final long DESSERT_EXTRA_TICKS = 600L;

    private CafeLogic() {}

    public static int count(Player player, Item item) {
        int n = 0;
        for (ItemStack s : player.getInventory().items) {
            if (s.is(item)) n += s.getCount();
        }
        return n;
    }

    public static boolean takeOne(Player player, Item item) {
        for (ItemStack s : player.getInventory().items) {
            if (s.is(item)) {
                s.shrink(1);
                return true;
            }
        }
        return false;
    }

    public static ItemStack findTicket(Player player) {
        for (ItemStack s : player.getInventory().items) {
            if (s.get(ModComponents.ORDER.get()) != null) return s;
        }
        return ItemStack.EMPTY;
    }

    /** Removes the ticket of an order that was never served (the customer lost patience). */
    public static void voidTicket(ServerPlayer player, long created) {
        for (ItemStack s : player.getInventory().items) {
            Order o = s.get(ModComponents.ORDER.get());
            if (o != null && o.created() == created) {
                s.shrink(1);
                return;
            }
        }
    }

    /** Speed-bonus window of a drink, longer when a dessert has to be fetched too. */
    public static long fastTicks(Drink drink, int dessert) {
        return drink.fastTicks() + (Dessert.byIndex(dessert) != null ? DESSERT_EXTRA_TICKS : 0L);
    }

    /** How long the customer waits in total. */
    public static long okTicks(Drink drink, int dessert) {
        return drink.okTicks() + (Dessert.byIndex(dessert) != null ? DESSERT_EXTRA_TICKS : 0L);
    }

    /** The same windows for a particular customer: a patient one waits longer, a hasty one shorter (see Personality). */
    public static long fastTicks(Drink drink, int dessert, int customer) {
        return Math.round(fastTicks(drink, dessert) * Personality.of(customer).patience());
    }

    public static long okTicks(Drink drink, int dessert, int customer) {
        return Math.round(okTicks(drink, dessert) * Personality.of(customer).patience());
    }

    /** A random drink for this customer: its favourites are ordered much more often than the rest. */
    public static Drink pickDrink(Personality who, RandomSource random) {
        Drink[] all = Drink.values();
        int[] w = new int[all.length];
        for (int i = 0; i < all.length; i++) w[i] = who.drinkWeight(all[i].id());
        return all[Personality.weightedPick(w, random::nextInt)];
    }

    /** Index of a random dessert for this customer and drink: its favourites and the classic pairs of the drink come up more often. */
    public static int pickDessert(Personality who, Drink drink, RandomSource random) {
        Dessert[] all = Dessert.values();
        int[] w = new int[all.length];
        for (int i = 0; i < all.length; i++) w[i] = Pairing.dessertWeight(who, drink.id(), all[i].id());
        return Personality.weightedPick(w, random::nextInt);
    }

    /** A dessert from the inventory that is a classic pair of the drink and can stand in for the missing ordered one (liked ones first). */
    @Nullable
    public static Dessert findSubstitute(Player player, Drink drink, Personality who) {
        Dessert found = null;
        for (Dessert d : Dessert.values()) {
            if (!Pairing.isPair(drink.id(), d.id()) || count(player, d.item()) <= 0) continue;
            if (who.likesDessert(d.id())) return d;
            if (found == null) found = d;
        }
        return found;
    }

    /** Quality 0..100 from the art score and the espresso shot. */
    public static int quality(int artScore, int extraction) {
        return (int) Math.round(0.7 * artScore + 0.3 * extraction);
    }

    public static boolean isCafeWorker(ServerPlayer player) {
        Optional<Profession> job = Jobs.currentProfession(player.server, player.getUUID());
        return job.isPresent() && job.get().id().getPath().equals(CAFE_JOB);
    }

    /**
     * A barista takes an order. From the register a customer NPC is spawned (if there is room) and walks up;
     * from a spawn-egg customer (npc != null) that very customer orders. Without room the order is just a ticket.
     */
    public static void issueOrder(ServerPlayer player, ServerLevel level, BlockPos soundPos,
                                  @Nullable BlockPos registerPos, @Nullable Direction registerFacing,
                                  @Nullable CafeCustomerEntity npc) {
        if (!isCafeWorker(player)) {
            player.displayClientMessage(Component.translatable("cafe.register.need_job"), true);
            return;
        }
        if (Jobs.REQUIRE_SHIFT_FOR_WORK && !Shift.isOnShift(player.server, player.getUUID())) {
            player.displayClientMessage(Component.translatable("cafe.register.need_shift"), true);
            return;
        }
        if (!findTicket(player).isEmpty()) {
            player.displayClientMessage(Component.translatable("cafe.register.have_ticket"), true);
            return;
        }
        Shift.touch(player);
        int customer = npc != null ? Math.floorMod(npc.getVariant(), Order.CUSTOMERS) : level.random.nextInt(Order.CUSTOMERS);
        Personality person = Personality.of(customer);                        // the order depends on who is asking
        Drink drink = pickDrink(person, level.random);
        int dessert = level.random.nextFloat() < person.dessertChance() ? pickDessert(person, drink, level.random) : -1;
        long now = level.getGameTime();

        if (npc != null) {
            npc.beginOrder(player.getUUID(), drink.ordinal(), dessert, now, null, null, false);
        } else if (registerPos != null && registerFacing != null) {
            CafeCustomerEntity.spawnFor(level, registerPos, registerFacing, player.getUUID(), customer, drink.ordinal(), dessert, now);
        }

        ItemStack ticket = new ItemStack(ModItems.ORDER_TICKET.get());
        ticket.set(ModComponents.ORDER.get(), new Order(drink.ordinal(), customer, now, dessert));
        player.getInventory().placeItemBackInInventory(ticket);
        level.playSound(null, soundPos, SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.BLOCKS, 1.0F, 1.2F);
        Component who = Component.translatable("customer.aestheticjobs." + customer);
        Dessert extra = Dessert.byIndex(dessert);
        if (extra != null) {
            player.sendSystemMessage(Component.translatable("cafe.register.new_order_dessert", who, drink.displayName(), extra.displayName()));
        } else {
            player.sendSystemMessage(Component.translatable("cafe.register.new_order", who, drink.displayName()));
        }
    }

    /**
     * Hands a finished cup over: checks the ticket, pays (commission + tips), gives xp.
     * If the customer NPC is there, it takes the cup and shows the drawing (see CafeCustomerEntity).
     */
    public static void serve(ServerPlayer player, ServerLevel level, BlockPos pos, ItemStack cupStack, CupData cup,
                             @Nullable CafeCustomerEntity npc) {
        Shift.touch(player);
        ItemStack ticket = findTicket(player);
        if (ticket.isEmpty()) {
            player.displayClientMessage(Component.translatable("cafe.register.no_order"), true);
            return;
        }
        Order order = ticket.get(ModComponents.ORDER.get());
        Drink wanted = Drink.byIndex(order.drink());
        if (wanted == null || order.drink() != cup.drink()) {
            Component name = wanted == null ? Component.empty() : wanted.displayName();
            player.displayClientMessage(Component.translatable("cafe.register.wrong", name), true);
            if (npc != null) npc.say(Personality.Say.WRONG);
            return;
        }

        Personality who = Personality.of(order.customer());
        Dessert ordered = Dessert.byIndex(order.dessert());
        Dessert dessert = ordered;                                            // the dessert that is really served
        boolean substituted = false;
        if (ordered != null && count(player, ordered.item()) <= 0) {          // the barista hands the dessert over from the inventory
            Dessert stand = findSubstitute(player, wanted, who);              // a classic pair of the drink can stand in for it
            if (stand == null) {
                player.displayClientMessage(Component.translatable("cafe.register.need_dessert", ordered.displayName()), true);
                if (npc != null) npc.say(Personality.Say.WRONG);
                return;
            }
            if (!who.acceptsSubstitute()) {                                   // picky and grumpy customers want exactly what they ordered
                player.displayClientMessage(Component.translatable("cafe.register.no_substitute", ordered.displayName()), true);
                if (npc != null) npc.say(Personality.Say.WRONG);
                return;
            }
            dessert = stand;
            substituted = true;
        }
        boolean pair = dessert != null && Pairing.isPair(wanted.id(), dessert.id());
        boolean favourite = who.likesDrink(wanted.id());
        long elapsed = level.getGameTime() - order.created();
        long fast = fastTicks(wanted, order.dessert(), order.customer());
        long ok = okTicks(wanted, order.dessert(), order.customer());
        double speed = elapsed <= fast ? 0.30 : elapsed <= ok ? 0.10 : 0.0;
        int stars = cup.stars();
        long price = wanted.priceCents() + (dessert != null ? dessert.priceCents() : 0L);
        long base = Math.round(price * 0.6);
        // the tip: quality and speed as before, then the generosity of this customer, the cafe's reputation and a favourite drink
        double reputation = CafeReputation.get(player.server).tipMultiplier(player.getUUID());
        long tip = Math.round(price * (stars * 0.08 + speed) * who.tip() * reputation * (favourite ? 1.1 : 1.0) * (pair ? 1.1 : 1.0));
        long total = base + tip;

        Bank.Result paid = Bank.deposit(player.server, player.getUUID(), total, Transaction.Type.WAGE, "cafe");
        if (paid != Bank.Result.OK) {
            player.displayClientMessage(Component.translatable("cafe.register.bank_full"), true);
            return;
        }
        cupStack.shrink(1);
        if (dessert != null) takeOne(player, dessert.item());
        ticket.shrink(1);

        // the review: what this particular customer thinks of the cup (counts towards the cafe's rating, /cafe rating)
        int reaction = who.reaction(stars, favourite, elapsed > fast);
        if (pair && stars >= 3) reaction++;                                   // a good pair made the day
        if (substituted && !who.likesDessert(dessert.id())) reaction--;       // "this is not what I wanted"
        reaction = Math.max(1, Math.min(5, reaction));
        CafeReputation.get(player.server).add(player.getUUID(),
                new ReviewLog.Review(Math.floorMod(order.customer(), Order.CUSTOMERS), reaction, order.drink(), level.getGameTime()));

        Jobs.XpResult xp = Jobs.addXp(player.server, player.getUUID(), 4L + stars * 2L);
        if (npc != null) {
            npc.receiveCup(player, cup, reaction);
        } else {
            level.playSound(null, pos, SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.BLOCKS, 0.9F, 1.3F);
            level.sendParticles(ParticleTypes.HEART, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 4, 0.25, 0.1, 0.25, 0.0);
        }
        player.sendSystemMessage(Component.translatable("cafe.register.paid",
                Component.translatable("customer.aestheticjobs." + Math.floorMod(order.customer(), Order.CUSTOMERS)),
                CupData.starText(stars), Money.format(total), Money.format(tip)));
        if (substituted) {
            player.sendSystemMessage(Component.translatable("cafe.register.substituted", dessert.displayName(), ordered.displayName()));
        } else if (pair) {
            player.sendSystemMessage(Component.translatable("cafe.register.pairing", wanted.displayName(), dessert.displayName()));
        }
        if (xp.employed() && xp.newRank() > xp.oldRank() && xp.profession() != null) {
            player.sendSystemMessage(Component.translatable("cafe.rank_up", xp.profession().rankName(xp.newRank())));
        }
    }
}
