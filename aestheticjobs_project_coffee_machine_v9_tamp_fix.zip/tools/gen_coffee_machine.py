#!/usr/bin/env python3
"""Generates the espresso machine: block models + ONE hand-painted 32 px/block texture atlas.

    python3 tools/gen_coffee_machine.py                    # writes textures/block/coffee_machine.png + both models
    python3 tools/gen_coffee_machine.py --preview out.png  # also renders a rough preview (iso views + the atlas)

Every face is painted at 2 texture pixels per model unit (= 32 px for a full block side, square pixels, the old
atlas stretched 8x5 px per unit). The model keeps the old envelope and anchor points, because CoffeeMachineRenderer
and LiveMachine draw the live parts (cup, streams, portafilter, gauge, lamp, steam pitcher) at fixed coordinates:
    body front face z = 4, gauge x 10.8..13.2 y 7.4..9.8, lamp x 3.2..4.4 y 9.4..10.3, cup x 6.6..9.4 z 1.2..3.95 on y = 2,
    group head x 5.5..10.5 y 5..9 z 2.5..4, portafilter y 4.2..5, wand tip (15.3, 2.6, 5.5).
`coffee_machine_brewing` is the same machine without the cup and the portafilter (the renderer draws those itself).
"""
import json
import math
import os
import sys

import numpy as np
from PIL import Image

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "aestheticjobs")
S = 2            # texture pixels per model unit  ->  32 px per block side
GUTTER = 2

# ------------------------------------------------------------------------------------------------ palette
# Soft pastel cafe palette. Rules of the style: flat colour fields (no dithering, no noise), a 1 px light edge on the
# top/left and a 1 px shade edge on the bottom/right of every face, brass only as small jewellery, details are hand-placed.
def C(h):
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 255)

CREAM = [C(x) for x in ("FFFCF4", "FBF3E0", "EFE2C8", "DAC8A4", "B49E78")]     # light, base, shade, deep, line
MINT = [C(x) for x in ("DDF3E8", "B9E2CE", "93CBB1", "6BAE92")]
BRASS = [C(x) for x in ("FFF1BE", "F2D182", "D9AC55", "A87D33", "6E4F1E")]
CHROME = [C(x) for x in ("FFFFFF", "E3E9ED", "BFC9D0", "94A0A9", "69747D", "424C54")]
WOOD = [C(x) for x in ("9A6E55", "7C5441", "60402F", "45291C", "2E1B12")]
ROSE = [C(x) for x in ("FDDDE3", "F2B0C0", "DD7F97")]
BEAN = [C(x) for x in ("9A6F58", "6F4837", "4A2E22", "2E1B13")]
GLASS = [C(x) for x in ("F6FBFC", "DDEDF1", "BDD6DE", "98B6C1")]
PORC = [C(x) for x in ("FFFFFF", "F7F1EB", "DDD3CC", "BFB3AD")]
CREMA = [C(x) for x in ("DDAA72", "BB8452", "8F5D38", "5A3826")]
RED, BLUE, AMBER, DARK = C("E2574C"), C("6FA8DC"), C("F6C453"), C("2E1D16")
CLEAR = (0, 0, 0, 0)

# ------------------------------------------------------------------------------------------------ pixel helpers
def canvas(w, h, col=CLEAR):
    im = np.zeros((h, w, 4), np.uint8)
    im[:, :] = col
    return im


def put(im, x, y, col):
    h, w = im.shape[:2]
    if 0 <= x < w and 0 <= y < h:
        im[y, x] = col


def rect(im, x0, y0, x1, y1, col):
    """[x0, x1) x [y0, y1)"""
    h, w = im.shape[:2]
    x0, y0, x1, y1 = max(0, x0), max(0, y0), min(w, x1), min(h, y1)
    if x1 > x0 and y1 > y0:
        im[y0:y1, x0:x1] = col


def frame(im, x0, y0, x1, y1, col):
    rect(im, x0, y0, x1, y0 + 1, col)
    rect(im, x0, y1 - 1, x1, y1, col)
    rect(im, x0, y0, x0 + 1, y1, col)
    rect(im, x1 - 1, y0, x1, y1, col)


def disc(im, cx, cy, r, col):
    h, w = im.shape[:2]
    for y in range(h):
        for x in range(w):
            if (x + 0.5 - cx) ** 2 + (y + 0.5 - cy) ** 2 <= r * r:
                im[y, x] = col


def gradient(w, h, ramp, t0=0.0, t1=1.0, diag=0.0):
    """Hard bands, no dithering."""
    im = canvas(w, h)
    for y in range(h):
        t = min(max(t0 + (t1 - t0) * (y / max(h - 1, 1)), 0.0), 0.999)
        im[y, :] = ramp[int(t * len(ramp))]
    return im


def bevel(im, hi, lo):
    h, w = im.shape[:2]
    if w < 3 or h < 3:
        if h >= 2:
            rect(im, 0, h - 1, w, h, lo)
        return
    rect(im, 0, 0, w, 1, hi)
    rect(im, 0, 0, 1, h, hi)
    rect(im, 0, h - 1, w, h, lo)
    rect(im, w - 1, 0, w, h, lo)


def enamel(w, h):
    im = canvas(w, h, CREAM[1])
    rect(im, 0, h * 2 // 3, w, h, CREAM[1])
    bevel(im, CREAM[0], CREAM[3])
    return im


def skirt(im):
    """Mint stripe along the foot of the cabinet."""
    h, w = im.shape[:2]
    rect(im, 1, h - 3, w - 1, h - 2, MINT[1])
    rect(im, 1, h - 2, w - 1, h - 1, MINT[2])


def banded(w, h, ramp, horizontal):
    """A polished tube: hard bands, highlight near the top (or left), dark edge opposite."""
    n = h if horizontal else w
    seq = {1: [2], 2: [1, 3], 3: [1, 2, 4]}.get(n)
    if seq is None:
        seq = []
        for i in range(n):
            t = i / (n - 1)
            seq.append(0 if t < 0.14 else 1 if t < 0.34 else 2 if t < 0.62 else 3 if t < 0.86 else 4)
    im = canvas(w, h)
    for i, k in enumerate(seq):
        if horizontal:
            im[i, :] = ramp[k]
        else:
            im[:, i] = ramp[k]
    return im


def chrome_h(w, h):
    return banded(w, h, CHROME, True)


def chrome_v(w, h):
    return banded(w, h, CHROME, False)


def brass_h(w, h):
    return banded(w, h, BRASS, True)


def brass_v(w, h):
    return banded(w, h, BRASS, False)


def wood(w, h, horizontal=True, seed=1):
    im = canvas(w, h, WOOD[2])
    n = h if horizontal else w
    for k in range(1, n - 1, 3):                                   # regular grain, no random speckle
        a = (seed + k * 2) % 4
        if horizontal:
            rect(im, a, k, max(a + 1, w - 2 - a), k + 1, WOOD[3])
        else:
            rect(im, k, a, k + 1, max(a + 1, h - 2 - a), WOOD[3])
    bevel(im, WOOD[0], WOOD[4])
    return im


def porcelain(w, h):
    im = canvas(w, h, PORC[1])
    bevel(im, PORC[0], PORC[2])
    return im


def dark_steel(w, h):
    im = canvas(w, h, CHROME[4])
    bevel(im, CHROME[3], CHROME[5])
    return im


# ------------------------------------------------------------------------------------------------ the painted faces
def button(im, cx, cy, col):
    """A tiny round button: a plus-shaped brass ring around a coloured centre."""
    for dx, dy in ((0, -1), (-1, 0), (1, 0), (0, 1)):
        put(im, cx + dx, cy + dy, BRASS[2])
    put(im, cx, cy, col)
    put(im, cx - 1, cy - 1, CREAM[3])                                   # a soft shadow in the corners
    put(im, cx + 1, cy + 1, CREAM[3])


def body_front(w, h, f):
    """24 x 18 px. Seen from the front the +x side of the model is on the LEFT of the picture."""
    im = enamel(w, h)
    skirt(im)
    # pressure gauge seat (the renderer puts the dial on it): centre x = 4, y = 5
    disc(im, 4.0, 5.0, 4.0, BRASS[3])
    disc(im, 4.0, 5.0, 3.4, BRASS[1])
    disc(im, 4.0, 5.0, 2.9, CREAM[0])
    # status lamp bezel (the lamp itself is x 19..21, y 1..3)
    rect(im, 17, 1, 23, 5, BRASS[3])
    rect(im, 18, 2, 22, 4, DARK)
    # little brass nameplate above the group head
    rect(im, 7, 1, 17, 4, BRASS[3])
    rect(im, 7, 1, 17, 2, BRASS[0])
    rect(im, 8, 2, 16, 3, BRASS[2])
    for x in (9, 11, 12, 14):
        put(im, x, 2, BRASS[4])
    # three buttons to the right of the group head
    button(im, 20, 7, MINT[3])
    button(im, 20, 10, AMBER)
    button(im, 20, 13, ROSE[2])
    # cooling slots under the gauge
    for y in (11, 13):
        rect(im, 1, y, 7, y + 1, CREAM[4])
    return im


def body_back(w, h, f):
    im = enamel(w, h)
    skirt(im)
    frame(im, 4, 3, 20, 13, CREAM[4])
    rect(im, 5, 4, 19, 12, CREAM[3])
    for x in range(6, 19, 2):
        rect(im, x, 5, x + 1, 11, CREAM[4])
    return im


def body_side(w, h, f):
    """18 x 18 px, the same on both sides."""
    im = enamel(w, h)
    skirt(im)
    frame(im, 2, 3, 16, 13, CREAM[4])
    rect(im, 3, 4, 15, 12, MINT[2])
    rect(im, 3, 4, 15, 5, MINT[1])
    for y in (6, 8, 10):                                                # louvres
        rect(im, 4, y, 14, y + 1, MINT[3])
        rect(im, 4, y + 1, 14, y + 2, MINT[0])
    rect(im, 3, 4, 4, 12, MINT[1])
    return im


def tray_top(w, h, f):
    """20 x 6 px: a drip grate, slats run along x."""
    im = canvas(w, h, CHROME[5])
    for y in (1, 3):
        rect(im, 1, y, w - 1, y + 1, CHROME[1])
    rect(im, 1, 2, w - 1, 3, CHROME[3])
    rect(im, 1, 4, w - 1, 5, CHROME[3])
    rect(im, 0, 0, w, 1, CHROME[0])
    rect(im, 0, h - 1, w, h, CHROME[4])
    return im


def tray_front(w, h, f):
    im = chrome_h(w, h)
    for x in (3, 13):                                                   # finger slots
        rect(im, x, 2, x + 4, 3, CHROME[5])
    return im


def shelf_front(w, h, f):
    im = canvas(w, h)
    rect(im, 0, 0, w, 1, CREAM[0])
    rect(im, 0, 1, w, 2, CREAM[3])
    return im


def warmer_top(w, h, f):
    """26 x 19: cup warmer plate: clean steel, three slim vents, two cup rings."""
    im = canvas(w, h, CHROME[1])
    for y in range(2, h - 1, 4):
        rect(im, 1, y, w - 1, y + 1, CHROME[2])
    for y in (4, 8, 12):
        rect(im, 3, y, 13, y + 1, CHROME[3])
    for y0 in (4, 11):
        frame(im, 17, y0, 24, y0 + 6, CHROME[3])
    bevel(im, CHROME[0], CHROME[4])
    return im


def glass(w, h, f):
    """The bean hopper: pale glass with a neat heap of beans."""
    im = canvas(w, h, GLASS[1])
    rect(im, 0, 0, w, 1, GLASS[0])
    rect(im, w - 1, 0, w, h, GLASS[3])

    def bean(x, y):
        for dx, c in ((0, BEAN[1]), (1, BEAN[0]), (2, BEAN[1])):
            put(im, x + dx, y, c)
        for dx in range(3):
            put(im, x + dx, y + 1, BEAN[2])

    if h >= 4:
        for x in range(2, w - 2, 3):
            bean(x, h - 3)
        for x in range(0, w - 2, 3):
            bean(x, h - 2)
    else:
        for x in range(0, w - 2, 3):
            bean(x, h - 2)
    rect(im, 0, 0, 1, h, GLASS[0])
    return im


def lid_top(w, h, f):
    im = canvas(w, h, BRASS[1])
    bevel(im, BRASS[0], BRASS[3])
    cx, cy = w // 2, h // 2
    rect(im, cx - 1, cy - 1, cx + 2, cy + 2, BRASS[3])                 # the knob
    rect(im, cx - 1, cy - 1, cx + 1, cy + 1, BRASS[2])
    put(im, cx - 1, cy - 1, BRASS[0])
    return im


def group_front(w, h, f):
    im = chrome_h(w, h)
    rect(im, 3, 1, 7, 4, BRASS[3])                                      # brass medallion
    rect(im, 4, 2, 6, 3, BRASS[0])
    put(im, 3, 1, CHROME[1])
    put(im, 6, 3, CHROME[1])
    return im


def ring_front(w, h, f):
    im = dark_steel(w, h)
    put(im, 1, 1, CHROME[2])
    put(im, w - 2, 1, CHROME[2])
    return im


def shower_screen(w, h, f):
    im = canvas(w, h, CHROME[5])
    for y in range(h):
        for x in range(w):
            if (x + y) % 2 == 0:
                put(im, x, y, CHROME[3])
    return im


def cup_top(w, h, f):
    im = porcelain(w, h)
    if w >= 5 and h >= 3:
        rect(im, 1, 1, w - 1, h - 1, CREMA[1])
        if h >= 4:
            rect(im, 2, 2, w - 2, h - 2, CREMA[0])
    return im


def warm_cup_top(w, h, f):
    im = porcelain(w, h)
    if w >= 4 and h >= 4:
        rect(im, 1, 1, w - 1, h - 1, PORC[3])
        rect(im, 2, 2, w - 2, h - 2, PORC[2])
    return im


def knob_end(col):
    def g(w, h, f):
        im = brass_h(w, h)
        put(im, w // 2, h // 2, col)
        return im
    return g


def grate_down(w, h, f):
    im = canvas(w, h, CHROME[5])
    for x in range(1, w - 1, 2):
        rect(im, x, 1, x + 1, h - 1, CHROME[4])
    return im


# ------------------------------------------------------------------------------------------------ the model
# name, from, to, faces, painter {face -> fn(w, h, face) | "*" -> fn}, static: only in the idle model
def P(fn):
    return {"*": fn}


def faces_of(**kw):
    return kw


ELEMENTS = [
    # --- drip tray with the grate (the cup stands on y = 2)
    dict(name="tray", f=(3, 0, 1), t=(13, 2, 4), faces="nsewu",
         paint={"n": tray_front, "s": lambda w, h, f: chrome_h(w, h), "e": lambda w, h, f: chrome_h(w, h),
                "w": lambda w, h, f: chrome_h(w, h), "u": tray_top}),
    # --- walnut plinth
    dict(name="base", f=(2, 0, 4), t=(14, 2, 13), faces="nsew",
         paint={"*": lambda w, h, f: (lambda im: (rect(im, 0, 0, w, 1, BRASS[2]), im)[1])(wood(w, h, True, w + h))}),
    # --- cream enamel body
    dict(name="body", f=(2, 2, 4), t=(14, 11, 13), faces="nsew",
         paint={"n": body_front, "s": body_back, "e": body_side, "w": body_side}),
    # --- shelf: enamel lip + steel cup-warmer plate with a rail
    dict(name="shelf_base", f=(2, 11, 4), t=(14, 12, 13), faces="nsew", paint={"*": shelf_front}),
    dict(name="shelf_plate", f=(1.6, 12, 3.6), t=(14.4, 13, 13.2), faces="nsewud",
         paint={"u": warmer_top, "d": lambda w, h, f: dark_steel(w, h), "*": lambda w, h, f: chrome_h(w, h)}),
    dict(name="post_fl", f=(2.2, 13, 4.2), t=(2.7, 14.2, 4.7), faces="nsew", paint=P(lambda w, h, f: chrome_v(w, h))),
    dict(name="post_fr", f=(13.3, 13, 4.2), t=(13.8, 14.2, 4.7), faces="nsew", paint=P(lambda w, h, f: chrome_v(w, h))),
    dict(name="post_bl", f=(2.2, 13, 12.2), t=(2.7, 14.2, 12.7), faces="nsew", paint=P(lambda w, h, f: chrome_v(w, h))),
    dict(name="post_br", f=(13.3, 13, 12.2), t=(13.8, 14.2, 12.7), faces="nsew", paint=P(lambda w, h, f: chrome_v(w, h))),
    dict(name="rail_f", f=(2.2, 14.2, 4.2), t=(13.8, 14.7, 4.7), faces="nsewu", paint=P(lambda w, h, f: chrome_h(w, h))),
    dict(name="rail_b", f=(2.2, 14.2, 12.2), t=(13.8, 14.7, 12.7), faces="nsewu", paint=P(lambda w, h, f: chrome_h(w, h))),
    # --- two warming cups
    dict(name="warm_cup_1", f=(10.8, 13, 6), t=(12.8, 14.4, 8), faces="nsewu",
         paint={"u": warm_cup_top, "*": lambda w, h, f: porcelain(w, h)}),
    dict(name="warm_cup_2", f=(10.8, 13, 9.2), t=(12.8, 14.4, 11.2), faces="nsewu",
         paint={"u": warm_cup_top, "*": lambda w, h, f: porcelain(w, h)}),
    # --- bean hopper
    dict(name="collar", f=(4.5, 13, 6.5), t=(9.5, 13.6, 10.5), faces="nsew", paint=P(lambda w, h, f: brass_h(w, h))),
    dict(name="glass", f=(4, 13.6, 6), t=(10, 15.4, 11), faces="nsewu", paint={"u": lambda w, h, f: gradient(w, h, GLASS, 0.3, 0.9), "*": glass}),
    dict(name="lid", f=(4.3, 15.4, 6.3), t=(9.7, 15.95, 10.7), faces="nsewu", paint={"u": lid_top, "*": lambda w, h, f: brass_h(w, h)}),
    # --- group head
    dict(name="group", f=(5.5, 6.4, 2.5), t=(10.5, 9, 4), faces="nsewud",
         paint={"n": group_front, "u": lambda w, h, f: chrome_h(w, h), "d": lambda w, h, f: dark_steel(w, h),
                "e": lambda w, h, f: chrome_v(w, h), "w": lambda w, h, f: chrome_v(w, h),
                "*": lambda w, h, f: chrome_h(w, h)}),
    dict(name="group_ring", f=(6, 5, 2.8), t=(10, 6.4, 3.9), faces="nsewd",
         paint={"d": shower_screen, "*": ring_front}),
    dict(name="group_knob_l", f=(4.9, 7.2, 3.0), t=(5.5, 8.2, 3.5), faces="nswu", paint=P(lambda w, h, f: brass_v(w, h))),
    dict(name="group_knob_r", f=(10.5, 7.2, 3.0), t=(11.1, 8.2, 3.5), faces="nseu", paint=P(lambda w, h, f: brass_v(w, h))),
    # --- steam wand and the two valves on the right (east) side
    dict(name="wand_arm", f=(14, 9, 5.2), t=(15.5, 9.6, 5.8), faces="nsue", paint=P(lambda w, h, f: chrome_h(w, h))),
    dict(name="wand_pipe", f=(14.9, 3.6, 5.2), t=(15.5, 9.6, 5.8), faces="nsew", paint=P(lambda w, h, f: chrome_v(w, h))),
    dict(name="wand_tip", f=(14.95, 2.6, 5.25), t=(15.45, 3.6, 5.75), faces="nsewd", paint=P(lambda w, h, f: dark_steel(w, h))),
    dict(name="valve_steam", f=(14, 7.6, 8.0), t=(15, 9.0, 9.4), faces="nsue", paint={"e": knob_end(RED), "*": lambda w, h, f: brass_h(w, h)}),
    dict(name="valve_water", f=(14, 7.6, 10.0), t=(15, 9.0, 11.4), faces="nsue", paint={"e": knob_end(BLUE), "*": lambda w, h, f: brass_h(w, h)}),
    # --- idle only: a cup on its saucer and the portafilter docked in the group head
    dict(name="saucer", f=(6, 2, 1.6), t=(10, 2.4, 3.8), faces="nsewu", static=True,
         paint={"*": lambda w, h, f: porcelain(w, h)}),
    dict(name="cup", f=(6.8, 2.4, 2.0), t=(9.2, 4.0, 3.6), faces="nsewu", static=True,
         paint={"u": cup_top, "*": lambda w, h, f: porcelain(w, h)}),
    dict(name="cup_handle", f=(9.2, 2.9, 2.6), t=(9.8, 3.6, 3.0), faces="nsue", static=True,
         paint=P(lambda w, h, f: porcelain(w, h))),
    dict(name="basket", f=(6.4, 4.2, 2.5), t=(9.6, 5.0, 4.0), faces="nsewd", static=True,
         paint={"d": grate_down, "*": lambda w, h, f: chrome_h(w, h)}),
    dict(name="pf_handle", f=(7.55, 4.35, 0.7), t=(8.45, 4.95, 2.5), faces="nsewud", static=True,
         paint=P(lambda w, h, f: wood(w, h, h > w, 7))),
    dict(name="pf_cap", f=(7.55, 4.35, 0.5), t=(8.45, 4.95, 0.7), faces="nsewud", static=True,
         paint=P(lambda w, h, f: brass_h(w, h))),
]

DISPLAY = {
    "gui": {"rotation": [30, 225, 0], "translation": [0, 0, 0], "scale": [0.62, 0.62, 0.62]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.25, 0.25, 0.25]},
    "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [0.5, 0.5, 0.5]},
    "thirdperson_righthand": {"rotation": [75, 45, 0], "translation": [0, 2.5, 0], "scale": [0.375, 0.375, 0.375]},
    "firstperson_righthand": {"rotation": [0, 45, 0], "translation": [0, 0, 0], "scale": [0.4, 0.4, 0.4]},
}

DIRS = {"n": "north", "s": "south", "e": "east", "w": "west", "u": "up", "d": "down"}


def face_size(el, d):
    (x0, y0, z0), (x1, y1, z1) = el["f"], el["t"]
    dx, dy, dz = x1 - x0, y1 - y0, z1 - z0
    w, h = {"n": (dx, dy), "s": (dx, dy), "e": (dz, dy), "w": (dz, dy), "u": (dx, dz), "d": (dx, dz)}[d]
    return max(1, int(round(w * S))), max(1, int(round(h * S)))


def paint_face(el, d, w, h):
    fn = el["paint"].get(d) or el["paint"].get("*")
    im = fn(w, h, d)
    assert im.shape[0] == h and im.shape[1] == w, (el["name"], d, im.shape, w, h)
    return im


# ------------------------------------------------------------------------------------------------ atlas + models
def build():
    jobs = []
    for el in ELEMENTS:
        for d in el["faces"]:
            w, h = face_size(el, d)
            jobs.append((el["name"], d, w, h, paint_face(el, d, w, h)))
    jobs.sort(key=lambda j: (-j[3], -j[2]))

    atlas_w = 128
    x = y = row_h = 0
    place = {}
    for name, d, w, h, im in jobs:
        if x + w + GUTTER * 2 > atlas_w:
            x = 0
            y += row_h
            row_h = 0
        place[(name, d)] = (x + GUTTER, y + GUTTER, w, h, im)
        x += w + GUTTER * 2
        row_h = max(row_h, h + GUTTER * 2)
    atlas_h = 1
    while atlas_h < y + row_h:
        atlas_h *= 2
    atlas_h = max(atlas_h, 32)

    atlas = np.zeros((atlas_h, atlas_w, 4), np.uint8)
    for (name, d), (px, py, w, h, im) in place.items():
        atlas[py:py + h, px:px + w] = im
        for g in range(1, GUTTER + 1):                                          # extrude the edges into the gutter
            atlas[py - g, px:px + w] = im[0]
            atlas[py + h - 1 + g, px:px + w] = im[-1]
            atlas[py:py + h, px - g] = im[:, 0]
            atlas[py:py + h, px + w - 1 + g] = im[:, -1]
    return atlas, place, atlas_w, atlas_h


def model(place, aw, ah, static):
    elements = []
    for el in ELEMENTS:
        if el.get("static") and not static:
            continue
        faces = {}
        for d in el["faces"]:
            px, py, w, h, _ = place[(el["name"], d)]
            faces[DIRS[d]] = {"uv": [round(px / aw * 16, 4), round(py / ah * 16, 4),
                                     round((px + w) / aw * 16, 4), round((py + h) / ah * 16, 4)], "texture": "#t"}
        elements.append({"name": el["name"], "from": list(el["f"]), "to": list(el["t"]), "faces": faces})
    return {"texture_size": [aw, ah],
            "textures": {"particle": "aestheticjobs:block/coffee_machine", "t": "aestheticjobs:block/coffee_machine"},
            "elements": elements, "display": DISPLAY}


# ------------------------------------------------------------------------------------------------ preview
def corners(el, d):
    (x0, y0, z0), (x1, y1, z1) = el["f"], el["t"]
    return {
        "n": ((x1, y1, z0), (x0, y1, z0), (x1, y0, z0)),
        "s": ((x0, y1, z1), (x1, y1, z1), (x0, y0, z1)),
        "e": ((x1, y1, z1), (x1, y1, z0), (x1, y0, z1)),
        "w": ((x0, y1, z0), (x0, y1, z1), (x0, y0, z0)),
        "u": ((x0, y1, z0), (x1, y1, z0), (x0, y1, z1)),
        "d": ((x0, y0, z1), (x1, y0, z1), (x0, y0, z0)),
    }[d]


def preview(place, path, static, yaw_deg, pitch_deg=26.0, scale=34.0, size=(760, 700)):
    yaw, pit = math.radians(yaw_deg), math.radians(pitch_deg)
    cy_, sy_, cp, sp = math.cos(yaw), math.sin(yaw), math.cos(pit), math.sin(pit)

    def proj(p):
        x, y, z = p[0] - 8, p[1] - 6, p[2] - 8
        x2, z2 = x * cy_ + z * sy_, -x * sy_ + z * cy_          # yaw around y
        y3 = y * cp + z2 * sp                                    # screen up
        d = -y * sp + z2 * cp                                    # depth along the view (bigger = farther)
        return (size[0] / 2 - x2 * scale, size[1] * 0.58 - y3 * scale, d)

    shade = {"n": 0.82, "s": 0.82, "e": 0.64, "w": 0.64, "u": 1.0, "d": 0.5}
    todo = []
    for el in ELEMENTS:
        if el.get("static") and not static:
            continue
        for d in el["faces"]:
            tl, tr, bl = (proj(c) for c in corners(el, d))
            # visible if the face normal points to the camera: cross product sign of the 2D parallelogram
            cross = (tr[0] - tl[0]) * (bl[1] - tl[1]) - (tr[1] - tl[1]) * (bl[0] - tl[0])
            if cross <= 0:
                continue
            depth = (tl[2] + tr[2] + bl[2] + (tr[2] + bl[2] - tl[2])) / 4
            todo.append((-depth, el, d, tl, tr, bl))
    todo.sort(key=lambda t: t[0])
    out = Image.new("RGBA", size, (58, 44, 38, 255))
    for _, el, d, tl, tr, bl in todo:
        px, py, w, h, im = place[(el["name"], d)]
        img = Image.fromarray(im, "RGBA")
        ax, ay = tr[0] - tl[0], tr[1] - tl[1]
        bx, by = bl[0] - tl[0], bl[1] - tl[1]
        det = ax * by - bx * ay
        if abs(det) < 1e-6:
            continue
        # output (X, Y) -> (u, v) -> source pixel
        ia, ib = by / det, -bx / det
        ic, id_ = -ay / det, ax / det
        coeffs = (ia * w, ib * w, -(ia * tl[0] + ib * tl[1]) * w, ic * h, id_ * h, -(ic * tl[0] + id_ * tl[1]) * h)
        layer = img.transform(size, Image.AFFINE, coeffs, resample=Image.NEAREST)
        arr = np.array(layer).astype(np.float32)
        arr[..., :3] *= shade[d]
        out.alpha_composite(Image.fromarray(arr.clip(0, 255).astype(np.uint8), "RGBA"))
    out.save(path)


def main():
    atlas, place, aw, ah = build()
    os.makedirs(os.path.join(ROOT, "textures", "block"), exist_ok=True)
    Image.fromarray(atlas, "RGBA").save(os.path.join(ROOT, "textures", "block", "coffee_machine.png"))
    for fname, static in (("coffee_machine.json", True), ("coffee_machine_brewing.json", False)):
        with open(os.path.join(ROOT, "models", "block", fname), "w") as f:
            json.dump(model(place, aw, ah, static), f, indent=2)
    print("atlas", aw, "x", ah, "faces", len(place))
    if "--preview" in sys.argv:
        out = sys.argv[sys.argv.index("--preview") + 1]
        base = out.rsplit(".", 1)[0]
        preview(place, base + "_a.png", True, 35.0)
        preview(place, base + "_b.png", True, -35.0)
        preview(place, base + "_c.png", False, 160.0)
        Image.fromarray(atlas, "RGBA").resize((aw * 6, ah * 6), Image.NEAREST).save(base + "_atlas.png")


if __name__ == "__main__":
    main()
