# Кафе: настоящий процесс бариста

Кофемашина больше не «выбери рисунок». У каждого напитка свой **рецепт из этапов**, каждый этап это отдельная мини-игра.
Меню (8 напитков) и рецепты описаны в `cafe/Drink.java`, этапы в `cafe/Step.java`, мини-игры в `client/barista/`.

## Меню и рецепты
| напиток | этапы | продукты |
|---|---|---|
| Эспрессо $3.50 | помол, темпер, шот | зёрна |
| Американо $4.00 | помол, темпер, шот, **горячая вода** | зёрна |
| Латте $4.50 | помол, темпер, шот, вспенивание, **латте-арт** | зёрна, молоко |
| Капучино $4.50 | ... вспенивание (много пены), латте-арт, **какао по контуру** | зёрна, молоко |
| Флэт уайт $5.00 | помол, темпер, **рестретто**, вспенивание (шёлк), латте-арт | зёрна, молоко |
| Раф $5.50 | ... шот, **ваниль и сливки (размешать)**, вспенивание, латте-арт | зёрна, сливки, ванильный сироп |
| Мокка $6.00 | ... шот, **шоколад (размешать)**, вспенивание, латте-арт, **взбитые сливки спиралью** | зёрна, молоко, шоколад |
| Карамельный макиато $6.50 | **вспенивание первым**, помол, темпер, шот, **слой эспрессо через ложку**, **карамельная сетка** | зёрна, молоко, ваниль, карамель |

Каждая чашка тратит ещё одну пустую чашку. Продукты крафтятся: молоко (ведро молока + бумага), сливки (2 молока + сахар), ванильный сироп
(бутылка + 2 сахара + одуванчик), карамельный сироп (бутылка мёда + 2 сахара), шоколад (3 какао-боба + сахар). Зёрна как раньше: какао-бобы в печи.

## Десерты в заказах
Помимо напитка клиент с шансом 45% (`CafeLogic.DESSERT_CHANCE`) заказывает **десерт** (32 вида, `item/Dessert.java`, текстуры `tools/gen_desserts.py`).
- В пузыре над клиентом слева чашка, справа десерт. На чеке отдельная строка «Десерт» с ценой.
- Десерт нужно иметь **в инвентаре**: при выдаче напитка бариста автоматически отдаёт его клиенту. Нет десерта: напиток не принимается, подсказка в экшн-баре.
- Цена заказа = напиток + десерт (чаевые и базовая выплата считаются от суммы). Клиенту даётся ещё +30 секунд терпения и окна быстрой подачи (`DESSERT_EXTRA_TICKS`).
- Заказ хранит десерт в поле `dessert` (-1 = без десерта), старые чеки читаются как «без десерта».
- Десертов пока нет в рецептах крафта: достаются из креатива (вкладка Aesthetic Jobs).

## Доставка заготовок и десертов
**Терминал поставщика** (`supplier_terminal`, крафт: бумага, железо, сундук, редстоун) продаёт всё, что нужно кафе, упаковками.
- ПКМ по блоку: каталог с двумя вкладками (заготовки для кофе / 32 десерта). ЛКМ +1 упаковка, ПКМ -1, Shift по 5. Каталог и цены: `cafe/SupplyCatalog.java`.
- Упаковка: 8 шт. зёрен, молока, сливок, сиропов и шоколада; 16 пустых чашек; 4 десерта. Заготовки 0.08-0.30 $ за штуку, десерт стоит 40% от цены, по которой его купит клиент.
- «Заказать» шлёт список на сервер (`DeliveryOrderPayload`). Сервер проверяет блок, расстояние, лимиты (до 16 упаковок на позицию, до 64 в заказе, до 3 доставок в пути) и **списывает деньги со счёта** (тип транзакции `PURCHASE`).
- Заказ хранится в `DeliveryData` (world/data/aestheticjobs_deliveries.dat), переживает перезапуск. Через 2 минуты (`DeliveryService.DELAY_TICKS`), когда терминал загружен, появляется **курьер** (скин `customer_8`), несёт ящик в руке, идёт к терминалу и кладёт `delivery_box` сверху. Владельцу приходит сообщение.
- ПКМ по ящику распаковывает всё в инвентарь (лишнее выпадает под ноги).
- Если рядом нет места для курьера, ящик просто появляется на терминале. Если терминал сломали, деньги возвращаются на счёт.
- Текстуры: `tools/gen_delivery_textures.py`.

## Мини-игры
- **Помол.** Колесо мыши: тонкость (для эспрессо нужно около 7). ЛКМ и круги мышью вокруг ручки: крутишь кофемолку, доза 18 г. Тонкость остаётся: крупный помол даёт быстрый шот, тонкий медленный.
- **Темпер.** Темпер сам кренится (пузырьковый уровень). Гаси крен мышью и жми ЛКМ. Нажал криво: шот «каналит», струя бьёт жетами.
- **Шот.** Держишь ЛКМ или пробел, отпускаешь вовремя. Читай струю: тёмная = рано, золотая = пора, бледная = перелив. Время зависит от помола.
- **Горячая вода.** Лей по стенке стакана до линии: в центре струя убивает крему.
- **Вспенивание.** Мышь это паровая трубка. У самой поверхности (ровное шипение): растёт пена, но только пока молоко холодное. Слишком высоко: визг и крупные пузыри. Глубже и в сторону: вихрь, пена становится шёлковой микропеной. Стоп на нужной температуре: выше 72 градусов молоко сожжено.
- **Латте-арт.** Вид сверху. ЛКМ льёт молоко: стоишь на месте, растёт белое пятно; ведёшь медленно, толстая линия; быстро, тонкая. Пока ведёшь, каждая «волна» оставляет тёмную линию крема (розетка). ПКМ: зубочистка, протяни её через пену и вытянешь сердечко или листик. Пена из этапа вспенивания влияет: шёлковое молоко течёт, пузырчатое оставляет крапинки.
- **Размешать.** Круги мышью ровным темпом: медленно комочки, быстро брызги.
- **Слой эспрессо.** Ложка качается из стороны в сторону, лей эспрессо точно на неё, иначе слои смешаются.
- **Какао, сливки, карамель.** Повторяй подсказку: сердечко из какао, спираль из сливок, карамельная сетка.

## Оценка
Качество чашки это средневзвешенная оценка этапов. Рисунок на пенке оценивает **сервер** по самой картинке: симметрия, достаточно пены,
по центру, и детали (длинная граница на небольшое количество пены: пятно получит средний балл, сердечко и розетка высокий).
Остальные этапы считает клиент (как и раньше с шотом), сервер проверяет продукты и длину рецепта.
Чашка выглядит как свой напиток (отдельная текстура 32x32), называется им, в подсказке картинка пенки и результат каждого этапа.

## Посетитель-NPC (`cafe_customer`)
Клиент живой: 8 скинов 32x32 (Эмма, Лиам, София, Ной, Миа, Оливер, Лили, Макс).

1. ПКМ пустой рукой по кассе (нужна **смена**, см. `docs/professions.md`): появляется клиент, идёт к стойке и встаёт напротив кассы.
2. Над головой облачко: **картинка напитка** (тот самый стакан со слоями) и полоска терпения. Терпение зависит от сложности напитка
   (`Drink.okTicks`): зелёная = бонус за скорость, жёлтая = обычное время, красная = скоро уйдёт. Ушёл обиженным: чек пропал.
3. Отдай чашку: ПКМ готовой чашкой по клиенту или по кассе. Клиент берёт её в руку (видно настоящий напиток) и пьёт.
4. Шоу: твоя настоящая пенка всплывает над головой, потом рассыпается пикселями в цветах напитка (какао, карамель, сливки). Реакция по звёздам.
5. Оплата, чаевые и опыт: `CafeLogic.serve`. Цена и скорость обслуживания зависят от напитка.

Яйцо призыва создаёт постоянного клиента: ПКМ пустой рукой принять заказ, ПКМ чашкой отдать.

## Текстуры (все 32x32, пастель)
`python3 tools/gen_cafe_items.py` (продукты и 8 стаканов), `tools/gen_customer_textures.py` (скины и облачко), `tools/gen_badge_textures.py`.
Звуки: `python3 tools/gen_cafe_sounds.py`.

## The machine works in the world (3D, visible to everybody)

The brewing screen is client-side, so the machine reports the phase of the recipe it is in
(`MachineStatePayload`: grind, tamp, shot, water, steam, stir, layer, pour, finish, done) and the server keeps it in
`CoffeeMachineBlockEntity`, synced to every client nearby. The screen pings every 2 s; with no ping for 6 s the
machine falls back to idle (screen closed, player left). Another barista cannot take over a busy machine.

`client/CoffeeMachineRenderer` draws the live parts from that phase (boxes on one white texel, no extra textures):
- a cup that fills up (espresso -> water / milk), the surface turns into crema / foam, and when the drink is ready
  the finished 16x16 latte art lies on the cup until it is served;
- coffee streams from the portafilter (two spouts), water, and the milk stream of a pitcher that sways like a hand
  drawing the art; a steam pitcher by the wand whose milk rises;
- a portafilter that docks while tamping / pulling, a pressure gauge (idle / shot / steam), a status lamp
  (green idle, amber working, bright green ready);
- particles: ground coffee, steam, rising vapour from a finished cup, and a sound for the others at each phase.

The block state `brewing` switches the model with the built-in cup (`coffee_machine`) to the one without it
(`coffee_machine_brewing`), because the renderer draws its own cup.

## The bar scene around the brewing screen (level 2)

`client/barista/BarScene` draws a whole bar behind the work panel instead of the dark veil: a tiled wall with a
flickering pendant lamp, a shelf with the supplies and sweets, a wooden counter and a wooden frame for the panel
(which slides up into place). On wide enough screens (side margin >= 70 px, height >= 230 px):
- left: the REAL 3D block model of the coffee machine, rendered by the game itself, leaning toward the mouse,
  with steam while a drink is brewed;
- right top: the order ticket of the customer on a pin (drink, dessert, a patience bar that turns green / yellow /
  red with the mark where the speed bonus ends);
- right bottom: the cup of the drink on a coaster: a dark silhouette that is revealed step by step while brewing,
  a turntable with confetti (4-5 stars) in the summary.

## Item pictures

All 47 item pictures (8 drinks, 32 desserts, 7 supplies) were cut from the isometric reference sheet by
`tools/slice_reference_sheet.py` (sharpened, 48-colour palette, 1 px soft outline, 32x32). Run it again with a new
sheet to re-cut them: `python3 tools/slice_reference_sheet.py <output dir>` (edit SRC at the top of the file).

### The mini-games stand on the counter

While a drink is brewed there is no beige panel any more. The stage canvas (virtual 284x138, every stage draws
relative to the rectangle it is given and reads the mouse only from what it is passed) stands in a wooden frame on
the counter, with a chalkboard above it (drink, step, step dots) and the hint and buttons below. On large screens
(width >= 736 and height >= 426 in GUI pixels, e.g. 1440p at GUI scale 3 or 1080p at scale 2) the canvas is drawn
exactly 2x bigger by scaling the pose (crisp pixels); the mouse is divided by the same factor before it reaches the
stage. The menu and the summary keep the panel. To add a stage nothing changes: `Stage.layout(0, 0, w, h)` is called
with virtual coordinates.

## New mini-game mechanics

**Dial-in (GrindStage).** The right fineness is different every day (hash of the Minecraft day) and drifts a
little from cup to cup; nobody tells the number. Turn the knob (wheel, +/-), pull a TEST SHOT and read the taste
needle: sour = grind finer, bitter = grind coarser. The grinder crank (18 g dose) stays. The machine remembers
the last setting that was right (within 0.6), so a good barista only fine-tunes. Score = 55% closeness of the
setting to the right one + 45% dose. `Brew.idealFineness` is carried on: the shot runs at normal speed with a
dialed-in grind, slower with a finer, faster with a coarser one.

**Parallel espresso shot (PullStage).** When the next step is steaming or stirring (latte, cappuccino, flat white,
raf, mocha) pressing BREW starts a REAL ~22 s shot (15 s ristretto) that runs in the background while the barista
steams the milk. A strip at the bottom of the canvas shows the glass, the stream colour and the golden window with a
STOP button (also the R key); too early is sour, too late is bitter, 36 s and it over-extracts by itself. The
first following step that needs the espresso (water, layer, pour, finishing, the summary) waits ("Stop the shot
first!"). The placeholder score of the PULL step is filled in when the shot stops, so the score list sent to the
server is unchanged (one score per step, in order). Espresso, americano and macchiato (the espresso is needed
right away) keep the quick hold-to-pull shot. While a shot runs the machine in the world shows the shot phase.
The `Stage` base class got the hooks for it: `wantsBackground`, `updateBackground`, `backgroundDone`,
`renderStrip`, `clickStrip`, `requestStop`.

**Latte art tilt (PourArtStage).** The mouse wheel tilts the pitcher: tilted far = strong flow (fat line, the
milk runs out fast), barely tilted = a thin precise flow for details (and the milk lasts).

## 3D-предметы
Все 47 предметов кафе (8 напитков, 32 десерта, 7 продуктов) и `coffee_cup` имеют настоящие 3D-модели из пастельных кубиков.
Они используют одну палитру `textures/item/palette_3d.png`; 2D-иконки остались для интерфейса (чек, меню).
Правка цветов/форм: `tools/gen_3d_models.py` (PALETTE и функции предметов), затем `python3 tools/gen_3d_models.py`.

## Кофемашина: модель и текстура (32 px на блок)
Модель и текстура генерируются: `python3 tools/gen_coffee_machine.py` (`--preview out.png` рисует превью). Все грани нарисованы квадратными
пикселями, 2 px на единицу модели (32 px на сторону блока). Размеры и якоря (чашка, группа, палочка, манометр, лампа) совпадают со старой
моделью, потому что живые детали рисует `CoffeeMachineRenderer` по тем же координатам. Модель `coffee_machine_brewing` без чашки и портафильтра.

## Латте-арт в мире: видно, что рисуешь
Кувшин над чашкой и чайники этапов рисуются полупрозрачными (`GHOST` в рендерере), на пенке стоит кольцо там, куда льётся молоко,
камера `CameraRig.ART` смотрит почти сверху, а в углу экрана есть увеличенная копия рисунка (`PourArtStage.drawPreview`).
