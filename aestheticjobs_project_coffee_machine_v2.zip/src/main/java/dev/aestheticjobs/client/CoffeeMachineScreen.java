package dev.aestheticjobs.client;

import dev.aestheticjobs.block.CoffeeMachineBlockEntity;
import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.CupData;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.cafe.Order;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.client.barista.BarScene;
import dev.aestheticjobs.client.barista.Brew;
import dev.aestheticjobs.client.barista.CameraRig;
import dev.aestheticjobs.client.barista.LiveMachine;
import dev.aestheticjobs.client.barista.DecorStage;
import dev.aestheticjobs.client.barista.GrindStage;
import dev.aestheticjobs.client.barista.LayerStage;
import dev.aestheticjobs.client.barista.PourArtStage;
import dev.aestheticjobs.client.barista.CustomerPortrait;
import dev.aestheticjobs.client.barista.PullStage;
import dev.aestheticjobs.client.barista.SceneFx;
import dev.aestheticjobs.client.barista.Stage;
import dev.aestheticjobs.client.barista.SteamStage;
import dev.aestheticjobs.client.barista.StirStage;
import dev.aestheticjobs.client.barista.TampStage;
import dev.aestheticjobs.client.barista.Ui;
import dev.aestheticjobs.client.barista.WaterStage;
import dev.aestheticjobs.network.BrewPayload;
import dev.aestheticjobs.network.MachineStatePayload;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.registry.ModItems;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

/**
 * The barista table. MENU: pick a drink (each one is a different recipe). BREW: one mini-game per step of the
 * recipe (grind, tamp, pull the shot, steam the milk, pour the art ...). SUMMARY: how every step went; serve the cup.
 */
public class CoffeeMachineScreen extends Screen {
    private static final int W = 300, H = 214;
    private enum Mode { MENU, BREW, SUMMARY }

    private static int lastDrink = Drink.LATTE.ordinal();

    private final BlockPos pos;
    private Mode mode = Mode.MENU;
    private Drink selected = Drink.byIndex(lastDrink) == null ? Drink.LATTE : Drink.byIndex(lastDrink);
    private Brew brew;
    private int stepIndex;
    private Stage stage;
    private long lastNanos = Util.getNanos();
    private double doneTimer = -1;
    private int left, top;
    private int pingTimer;
    // the bar scene
    private int baseTop;
    private float anim, open, summaryT, shownProgress;
    private ItemStack machineStack;
    // the mini-game canvas on the counter (virtual 284x138, drawn bScale times bigger when the screen is large)
    private int bScale = 1, bx, by;
    // the shot that runs in the background while the next step is played (see PullStage)
    private Stage bg;
    private int bgIndex;
    // the bar answers to the grades of the steps (lamp, machine, customer)
    private final SceneFx fx = SceneFx.get();
    // world mode: the step is played ON the real machine (the camera flies to it, see CameraRig), a short black dip hides the cuts
    private boolean world;
    private float fade;
    private static final float FADE_TIME = 0.35F;
    // the drink is chosen on the order ticket; only without a ticket (or with Shift held) the small picker is shown
    private boolean autoChecked, pickerLocked;
    private int starsShown;

    public CoffeeMachineScreen(BlockPos pos) {
        super(Component.translatable("block.aestheticjobs.coffee_machine"));
        this.pos = pos;
        fx.reset();
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        baseTop = (height - H) / 2;
        top = baseTop + 26;
        if (machineStack == null) machineStack = new ItemStack(ModItems.COFFEE_MACHINE.get());
        if (!autoChecked) {
            autoChecked = true;
            Drink wanted = CameraRig.ENABLED ? ticketDrink() : null;
            pickerLocked = wanted != null && !hasShiftDown();
            if (pickerLocked) {
                selected = wanted;
                if (hasSupplies(selected)) start();                      // the ticket says what to make: no menu
            }
        }
    }

    /** The drink on the order ticket in the inventory, or null. */
    private Drink ticketDrink() {
        var p = Minecraft.getInstance().player;
        if (p == null) return null;
        Order o = CafeLogic.findTicket(p).get(ModComponents.ORDER.get());
        return o == null ? null : Drink.byIndex(o.drink());
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    // ------------------------------------------------------------------ the machine in the world
    /** Tells the server what the machine is doing, so that everybody around sees it work (see CoffeeMachineBlockEntity). */
    private void reportState() {
        if (brew == null) return;
        int phase;
        String art = "";
        if (mode == Mode.SUMMARY) {
            phase = CoffeeMachineBlockEntity.DONE;
            art = brew.art();
        } else if (mode == Mode.BREW && stage != null) {
            phase = bg != null ? CoffeeMachineBlockEntity.PULL : CoffeeMachineBlockEntity.phaseOf(stage.step.kind());
        } else {
            return;
        }
        PacketDistributor.sendToServer(new MachineStatePayload(pos, phase, brew.drink.ordinal(), art));
        pingTimer = 0;
    }

    @Override
    public void tick() {
        super.tick();
        if (mode != Mode.MENU && ++pingTimer >= 40) reportState();      // heartbeat: the machine is idle again 6 s after the last one
    }

    @Override
    public void removed() {
        super.removed();
        CameraRig.release();
        LiveMachine.clear();
        if (brew != null && mode != Mode.MENU) {
            PacketDistributor.sendToServer(new MachineStatePayload(pos, CoffeeMachineBlockEntity.IDLE, brew.drink.ordinal(), ""));
        }
    }

    // ------------------------------------------------------------------ helpers
    private static ResourceLocation itemIcon(Item item) {
        ResourceLocation key = BuiltInRegistries.ITEM.getKey(item);
        return ResourceLocation.fromNamespaceAndPath(key.getNamespace(), "textures/item/" + key.getPath() + ".png");
    }

    private static int have(Item item) {
        var player = Minecraft.getInstance().player;
        return player == null ? 0 : CafeLogic.count(player, item);
    }

    private boolean hasSupplies(Drink d) {
        if (have(ModItems.EMPTY_CUP.get()) < 1) return false;
        for (Drink.Supply s : d.supplies()) if (have(s.item()) < 1) return false;
        return true;
    }

    private Stage create(Step s) {
        return switch (s.kind()) {
            case GRIND -> new GrindStage(brew, s);
            case TAMP -> new TampStage(brew, s);
            case PULL -> new PullStage(brew, s, shotRunsInParallel());
            case WATER -> new WaterStage(brew, s);
            case LAYER -> new LayerStage(brew, s);
            case STIR -> new StirStage(brew, s);
            case STEAM -> new SteamStage(brew, s);
            case POUR -> new PourArtStage(brew, s);
            case COCOA, WHIP, CARAMEL -> new DecorStage(brew, s);
        };
    }

    private void start() {
        if (!hasSupplies(selected)) return;
        lastDrink = selected.ordinal();
        brew = new Brew(selected, pos);
        LiveMachine.clear();
        bg = null;
        stepIndex = 0;
        stage = create(selected.steps()[0]);
        doneTimer = -1;
        mode = Mode.BREW;
        open = 0.2F;
        reportState();
    }

    private int stageW() { return W - 16; }
    private int stageH() { return 138; }

    private static Component grade(int score) {
        int g = score >= 90 ? 5 : score >= 75 ? 4 : score >= 60 ? 3 : score >= 40 ? 2 : 1;
        return Component.translatable("gui.aestheticjobs.cafe.grade." + g);
    }

    private static int gradeColor(int score) {
        return score >= 75 ? Ui.GOOD_D : score >= 50 ? Ui.WARN_D : Ui.BAD_D;
    }

    /** The shot runs by itself when the next step (steam, stir) does not need the espresso. */
    private boolean shotRunsInParallel() {
        Step[] steps = brew.drink.steps();
        if (stepIndex + 1 >= steps.length) return false;
        Step.Kind next = steps[stepIndex + 1].kind();
        return next == Step.Kind.STEAM || next == Step.Kind.STIR;
    }

    /** Does the step with this index need the finished espresso (in the cup)? The end of the recipe does too. */
    private boolean needsShot(int index) {
        Step[] steps = brew.drink.steps();
        if (index >= steps.length) return true;
        return switch (steps[index].kind()) {
            case WATER, LAYER, POUR, COCOA, WHIP, CARAMEL -> true;
            default -> false;
        };
    }

    /** The shot was started: it goes on in the background, the barista moves on to the next step. */
    private void sendToBackground() {
        bg = stage;
        bgIndex = stepIndex;
        brew.scores.add(0);                                   // filled in when the shot is stopped
        Ui.sound(net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK.value(), 1.0F, 0.7F);
        next();
    }

    private void advance() {
        brew.scores.add(stage.score());
        next();
    }

    private void next() {
        stepIndex++;
        if (stepIndex >= brew.drink.steps().length) {
            mode = Mode.SUMMARY;
            summaryT = 0.0F;
            starsShown = 0;
            LiveMachine.showArt(pos, brew.art());
            open = 0.2F;
            fx.finalReaction(brew.stars(brew.estimate()));
        } else {
            stage = create(brew.drink.steps()[stepIndex]);
        }
        doneTimer = -1;
        reportState();
    }

    private void serve() {
        PacketDistributor.sendToServer(new BrewPayload(pos, brew.drink.ordinal(), java.util.List.copyOf(brew.scores), brew.art()));
        onClose();
    }

    // ------------------------------------------------------------------ input
    private int cardX(int i) { return left + 12 + (i % 4) * 71; }
    private int cardY(int i) { return top + 32 + (i / 4) * 58; }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (mode == Mode.MENU && CameraRig.ENABLED) {
            return clickPicker(mx, my) || super.mouseClicked(mx, my, button);
        }
        if (mode == Mode.SUMMARY && CameraRig.ENABLED) {
            if (Ui.in(mx, my, 12, height - 28, 70, 18)) {
                onClose();
                return true;
            }
            if (Ui.in(mx, my, width - 134, height - 32, 122, 22)) {
                serve();
                return true;
            }
            return super.mouseClicked(mx, my, button);
        }
        if (mode == Mode.MENU) {
            for (int i = 0; i < Drink.values().length; i++) {
                if (Ui.in(mx, my, cardX(i), cardY(i), 68, 54)) {
                    selected = Drink.values()[i];
                    Ui.sound(net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK.value(), 1.0F, 0.6F);
                    return true;
                }
            }
            if (Ui.in(mx, my, left + W - 100, top + 170, 88, 22)) {
                start();
                return true;
            }
        } else if (mode == Mode.BREW) {
            if (world) {                                                  // no panel: gui coordinates all the way
                int byBtn = height - 28;
                if (Ui.in(mx, my, 12, byBtn, 70, 18)) {
                    onClose();
                    return true;
                }
                if (stage != null && !stage.isDone() && stage.canFinish() && Ui.in(mx, my, width - 112, byBtn, 100, 18)) {
                    stage.finish();
                    return true;
                }
                if (stage != null && stage.click(mx, my, button)) return true;
                return super.mouseClicked(mx, my, button);
            }
            int cw = stageW() * bScale, ch = stageH() * bScale, byBtn = by + ch + 24;
            if (Ui.in(mx, my, bx, byBtn, 70, 18)) {
                onClose();
                return true;
            }
            if (stage != null && !stage.isDone() && stage.canFinish() && Ui.in(mx, my, bx + cw - 100, byBtn, 100, 18)) {
                stage.finish();
                return true;
            }
            double vx = Math.floor((mx - bx) / (double) bScale), vy = Math.floor((my - by) / (double) bScale);
            if (bg != null && bg.clickStrip(vx, vy, 4, stageH() - 22, stageW() - 8, 20)) return true;
            if (stage != null && stage.click(vx, vy, button)) return true;
        } else {
            if (Ui.in(mx, my, left + W - 124, top + H - 28, 112, 20)) {
                serve();
                return true;
            }
            if (Ui.in(mx, my, left + 12, top + H - 28, 70, 20)) {
                onClose();
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (mode == Mode.BREW && bg != null && key == GLFW.GLFW_KEY_R) {      // R stops the shot that runs in the background
            bg.requestStop();
            return true;
        }
        if (mode == Mode.SUMMARY && CameraRig.ENABLED
                && (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER || key == GLFW.GLFW_KEY_SPACE)) {
            serve();
            return true;
        }
        if (mode == Mode.MENU && CameraRig.ENABLED) {
            if (!pickerLocked && (key == GLFW.GLFW_KEY_LEFT || key == GLFW.GLFW_KEY_A)) {
                cycle(-1);
                return true;
            }
            if (!pickerLocked && (key == GLFW.GLFW_KEY_RIGHT || key == GLFW.GLFW_KEY_D)) {
                cycle(1);
                return true;
            }
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER || key == GLFW.GLFW_KEY_SPACE) {
                start();
                return true;
            }
        }
        return super.keyPressed(key, scanCode, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double scrollX, double scrollY) {
        if (mode == Mode.MENU && CameraRig.ENABLED && !pickerLocked) {
            cycle(scrollY > 0 ? -1 : 1);
            return true;
        }
        if (mode == Mode.BREW && stage != null) {
            stage.scroll(scrollY);
            return true;
        }
        return super.mouseScrolled(mx, my, scrollX, scrollY);
    }

    // ------------------------------------------------------------------ drawing
    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        long now = Util.getNanos();
        float dt = Math.min(0.05F, (now - lastNanos) / 1.0E9F);
        lastNanos = now;

        anim += dt;
        fx.tick(dt);
        open = Math.min(1.0F, open + dt / 0.35F);
        float inv = 1.0F - open;
        top = baseTop + Math.round(inv * inv * inv * 26.0F);          // the panel slides up into place (clicks use the same top)

        boolean wantWorld = (mode == Mode.BREW && stage != null && stage.worldMode())
                || ((mode == Mode.MENU || mode == Mode.SUMMARY) && CameraRig.ENABLED);
        if (wantWorld != world) {
            world = wantWorld;
            fade = FADE_TIME;
        }
        CameraRig.update(dt, pos, !world ? null
                : mode == Mode.MENU ? CameraRig.OVERVIEW : mode == Mode.SUMMARY ? CameraRig.SERVE : stage.shot());
        fade = Math.max(0.0F, fade - dt);
        if (world) {                                                   // the real machine fills the screen, only the HUD is ours
            if (mode == Mode.MENU) renderPicker(g, mx, my);
            else if (mode == Mode.SUMMARY) renderWorldSummary(g, mx, my, dt);
            else renderWorldBrew(g, mx, my, dt);
            fx.render(g, font);
            fx.endFrame();
            drawFade(g);
            return;
        }

        BarScene.background(g, width, height, anim);
        if (mode == Mode.BREW) brewLayout(inv);
        renderSide(g, mx, dt);
        if (mode == Mode.BREW) {                                       // the mini-game stands right on the counter
            renderBrew(g, mx, my, dt);
            fx.render(g, font);
            fx.endFrame();
            drawFade(g);
            return;
        }
        BarScene.frame(g, left, top, W, H);
        Ui.box(g, left, top, W, H, Ui.KHAKI, Ui.BG);
        g.renderOutline(left + 3, top + 3, W - 6, H - 6, 0x66FFFFFF);

        if (mode == Mode.MENU) renderMenu(g, mx, my);
        else renderSummary(g, mx, my);
        fx.render(g, font);
        fx.endFrame();
        drawFade(g);
    }

    // ------------------------------------------------------------------ the summary: the finished cup in the world, the stars over it

    /** The cup stands on the machine (the picture of the art on it), the stars pop up one by one, the steps are listed on the left. */
    private void renderWorldSummary(GuiGraphics g, int mx, int my, float dt) {
        Step[] steps = brew.drink.steps();
        int q = brew.estimate(), stars = brew.stars(q);
        summaryT += dt;
        // a star after another: each rings a little higher, the last one punches the camera
        while (starsShown < 5 && summaryT >= 0.5F + starsShown * 0.28F) {
            if (starsShown < stars) {
                Ui.sound(dev.aestheticjobs.registry.ModSounds.BARISTA_DING.get(), 0.9F + starsShown * 0.14F, 0.5F);
                if (starsShown == stars - 1) {
                    CameraRig.kick(stars >= 4 ? 1.0F : 0.4F);
                }
            }
            starsShown++;
        }

        // the chalkboard: the drink and that it is ready
        int hw = Math.min(300, width - 24), hx = (width - hw) / 2, hy = 8;
        g.fill(hx + 3, hy + 5, hx + hw + 3, hy + 37, 0x55000000);
        Ui.box(g, hx, hy, hw, 34, 0xFF2A1A13, 0xFF6A4A3A);
        g.fill(hx + 3, hy + 3, hx + hw - 3, hy + 31, 0xFF2F3B36);
        g.renderOutline(hx + 3, hy + 3, hw - 6, 28, 0x33FFFFFF);
        Ui.icon(g, brew.drink.iconTexture(), hx + 7, hy + 5, 24);
        Ui.text(g, font, brew.drink.displayName(), hx + 36, hy + 8, 0xFFFFF6E2);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.cafe.ready"), hx + 36, hy + 19, 0xFFB9C9BC);

        // the stars
        for (int i = 0; i < 5; i++) {
            float t = summaryT - (0.5F + i * 0.28F);
            int sx = width / 2 + (i - 2) * 36, sy = 66;
            boolean full = i < stars;
            if (t < 0) {
                g.drawString(font, "\u2606", sx - 4, sy - 4, 0x55FFFFFF, false);
                continue;
            }
            float k = t < 0.18F ? t / 0.18F * 1.45F : 1.45F - 0.45F * Math.min(1.0F, (t - 0.18F) / 0.14F);
            var ps = g.pose();
            ps.pushPose();
            ps.translate(sx, sy, 0.0F);
            ps.scale(3.0F * k, 3.0F * k, 1.0F);
            g.drawString(font, full ? "\u2605" : "\u2606", -font.width("\u2605") / 2, -4, full ? 0xFFFFD35A : 0xFF8A8F8C, true);
            ps.popPose();
        }
        if (summaryT > 0.5F + stars * 0.28F) {
            var ps = g.pose();
            ps.pushPose();
            ps.translate(width / 2.0F, 92.0F, 0.0F);
            ps.scale(2.0F, 2.0F, 1.0F);
            String qt = q + "%";
            g.drawString(font, qt, -font.width(qt) / 2, 0, 0xFFFFF6E2, true);
            ps.popPose();
        }
        if (stars >= 4 && summaryT > 0.5F + stars * 0.28F) BarScene.confetti(g, width / 2, width, height, summaryT);

        // how every step went, on the left, one after another
        int n = Math.min(steps.length, brew.scores.size());
        int px = 14, py = height / 2 - n * 8 - 8, pw = 176;
        g.fill(px - 8, py - 12, px + pw + 8, py + n * 16 + 8, 0x66000000);
        for (int i = 0; i < n; i++) {
            if (summaryT < 0.3F + i * 0.12F) continue;
            int y = py + i * 16, sc = brew.scores.get(i);
            Ui.text(g, font, steps[i].title(), px, y, 0xFFB9C9BC);
            Ui.bar(g, px + 82, y + 1, 52, 6, sc / 100.0, sc >= 75 ? Ui.GOOD : sc >= 50 ? Ui.WARN : Ui.BAD);
            Ui.text(g, font, Component.literal(String.valueOf(sc)), px + 140, y, 0xFFFFF6E2);
        }

        Ui.button(g, font, 12, height - 28, 70, 18, Component.translatable("gui.aestheticjobs.cafe.cancel"),
                Ui.in(mx, my, 12, height - 28, 70, 18), true, 0);
        Ui.button(g, font, width - 134, height - 32, 122, 22, Component.translatable("gui.aestheticjobs.cafe.serve"),
                Ui.in(mx, my, width - 134, height - 32, 122, 22), true, 1);
    }

    // ------------------------------------------------------------------ the picker: a thin strip over the machine, no screen

    private int pickW() { return Math.min(width - 24, Math.max(300, Drink.values().length * 30 + 24)); }
    private int pickX() { return (width - pickW()) / 2; }
    private int pickY() { return height - 128; }
    private int slotX(int i) { return pickX() + (pickW() - Drink.values().length * 30) / 2 + i * 30; }

    private void cycle(int dir) {
        int n = Drink.values().length;
        selected = Drink.values()[Math.floorMod(selected.ordinal() + dir, n)];
        Ui.sound(net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK.value(), 1.0F, 0.6F);
    }

    private boolean clickPicker(double mx, double my) {
        int px = pickX(), py = pickY(), pw = pickW();
        if (Ui.in(mx, my, 12, height - 28, 70, 18)) {
            onClose();
            return true;
        }
        if (!pickerLocked) {
            for (int i = 0; i < Drink.values().length; i++) {
                if (Ui.in(mx, my, slotX(i), py + 8, 28, 28)) {
                    selected = Drink.values()[i];
                    Ui.sound(net.minecraft.sounds.SoundEvents.UI_BUTTON_CLICK.value(), 1.0F, 0.6F);
                    return true;
                }
            }
        }
        if (Ui.in(mx, my, px + pw - 100, py + 66, 88, 22)) {
            start();
            return true;
        }
        return false;
    }

    private void renderPicker(GuiGraphics g, int mx, int my) {
        int px = pickX(), py = pickY(), pw = pickW();
        g.fill(px + 3, py + 5, px + pw + 3, py + 105, 0x55000000);
        Ui.box(g, px, py, pw, 100, 0xFF2A1A13, 0xFF6A4A3A);
        g.fill(px + 3, py + 3, px + pw - 3, py + 97, 0xFF2F3B36);
        g.renderOutline(px + 3, py + 3, pw - 6, 94, 0x33FFFFFF);
        Drink[] ds = Drink.values();
        if (pickerLocked) {                                            // the ticket tells which drink
            Ui.icon(g, selected.iconTexture(), px + pw / 2 - 14, py + 8, 28);
        } else {
            for (int i = 0; i < ds.length; i++) {
                int sx = slotX(i);
                boolean sel = ds[i] == selected, hov = Ui.in(mx, my, sx, py + 8, 28, 28);
                Ui.box(g, sx, py + 8, 28, 28, sel ? Ui.BAD_D : 0xFF55635C, sel ? 0xFFFBE3D8 : hov ? 0xFF4A5C55 : 0xFF3A4A44);
                Ui.icon(g, ds[i].iconTexture(), sx + 2, py + 10, 24);
            }
        }
        Ui.centered(g, font, selected.displayName(), px + pw / 2, py + 40, 0xFFFFF6E2);
        Ui.centered(g, font, Component.literal(dev.aestheticjobs.economy.Money.format(selected.priceCents())), px + pw / 2, py + 51, 0xFFB9C9BC);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.cafe.needs"), px + 12, py + 56, 0xFFB9C9BC);
        int ix = px + 12;
        ix = supplyIcon(g, ModItems.EMPTY_CUP.get(), ix, py + 68);
        for (Drink.Supply s : selected.supplies()) ix = supplyIcon(g, s.item(), ix, py + 68);
        boolean ok = hasSupplies(selected);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.cafe.steps", selected.steps().length), px + pw - 100, py + 55, 0xFFB9C9BC);
        Ui.button(g, font, px + pw - 100, py + 66, 88, 22, Component.translatable("gui.aestheticjobs.cafe.start"),
                Ui.in(mx, my, px + pw - 100, py + 66, 88, 22), ok, 1);
        if (!ok) Ui.centered(g, font, Component.translatable("gui.aestheticjobs.cafe.supplies_missing"), px + pw - 56, py + 89, 0xFFE3A08C);
        Ui.button(g, font, 12, height - 28, 70, 18, Component.translatable("gui.aestheticjobs.cafe.cancel"),
                Ui.in(mx, my, 12, height - 28, 70, 18), true, 0);
    }

    /** A black dip over the cut between the flat bar and the machine in the world. */
    private void drawFade(GuiGraphics g) {
        if (fade <= 0.0F) return;
        int a = (int) (Math.min(1.0F, fade / FADE_TIME) * 190.0F);
        g.fill(0, 0, width, height, a << 24);
    }

    /** A step played ON the machine: no panel, no bar scene; the chalkboard on top, the stage's own HUD, the hint and the buttons below. */
    private void renderWorldBrew(GuiGraphics g, int mx, int my, float dt) {
        Step[] steps = brew.drink.steps();
        Stage s = stage;
        if (bg != null) {
            bg.updateBackground(dt);
            if (bg.backgroundDone()) {
                brew.scores.set(bgIndex, bg.score());
                fx.grade(bg.score());
                bg = null;
                reportState();
            }
        }

        int hw = Math.min(300, width - 24), hx = (width - hw) / 2, hy = 8;
        g.fill(hx + 3, hy + 5, hx + hw + 3, hy + 37, 0x55000000);
        Ui.box(g, hx, hy, hw, 34, 0xFF2A1A13, 0xFF6A4A3A);
        g.fill(hx + 3, hy + 3, hx + hw - 3, hy + 31, 0xFF2F3B36);
        g.renderOutline(hx + 3, hy + 3, hw - 6, 28, 0x33FFFFFF);
        Ui.icon(g, brew.drink.iconTexture(), hx + 7, hy + 5, 24);
        Ui.text(g, font, s.step.title(), hx + 36, hy + 8, 0xFFFFF6E2);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.cafe.of", stepIndex + 1, steps.length), hx + 36, hy + 19, 0xFFB9C9BC);
        int dotsX = hx + hw - 10 - steps.length * 14;
        for (int i = 0; i < steps.length; i++) {
            int c = i < stepIndex ? gradeColorFor(i) : i == stepIndex ? Ui.BAD_D : 0xFF55635C;
            Ui.disc(g, dotsX + i * 14 + 5, hy + 17, i == stepIndex ? 5 : 4, c);
        }

        s.layoutWorld(width, height);
        if (!s.isDone()) s.update(dt, mx, my);
        boolean toBackground = !s.isDone() && s.wantsBackground();
        s.renderWorld(g, font, mx, my);

        if (s.isDone()) {
            if (doneTimer < 0) {
                doneTimer = 0;
                fx.grade(s.score());
            }
            doneTimer += dt;
            int sc = s.score();
            int pw = 150, ph = 34, px = width / 2 - pw / 2, py = height / 3 - ph / 2;
            Ui.box(g, px, py, pw, ph, gradeColor(sc), 0xEEFFF6E2);
            Ui.centered(g, font, grade(sc), px + pw / 2, py + 7, gradeColor(sc));
            Ui.centered(g, font, Component.literal(sc + "%"), px + pw / 2, py + 19, Ui.INK);
        }
        if (toBackground) {
            sendToBackground();
            return;
        }
        if (s.isDone() && doneTimer > 1.1 && (bg == null || !needsShot(stepIndex + 1))) advance();

        int btnY = height - 28;
        String hint = s.status().getString();
        int tw = font.width(hint);
        g.fill(width / 2 - tw / 2 - 5, btnY - 19, width / 2 + tw / 2 + 5, btnY - 5, 0x77000000);
        Ui.centered(g, font, s.status(), width / 2, btnY - 16, 0xFFFFF6E2);
        Ui.button(g, font, 12, btnY, 70, 18, Component.translatable("gui.aestheticjobs.cafe.cancel"),
                Ui.in(mx, my, 12, btnY, 70, 18), true, 0);
        boolean can = !s.isDone() && s.canFinish();
        Ui.button(g, font, width - 112, btnY, 100, 18, s.finishLabel(),
                Ui.in(mx, my, width - 112, btnY, 100, 18), can, 1);
    }

    /** The bar around the panel: the real 3D machine on the counter, the order ticket and the cup that fills up. */
    private void renderSide(GuiGraphics g, int mx, float dt) {
        int rightX = mode == Mode.BREW ? bx + stageW() * bScale + 6 : left + W;
        int sideW = Math.min(mode == Mode.BREW ? bx - 6 : left, width - rightX);
        if (sideW < 70 || height < 230) return;
        int counter = BarScene.counterTop(height);
        int baseY = counter + (height - counter) * 55 / 100;

        // the machine (leans toward the mouse)
        float s = Math.min(Math.min((sideW - 12) / 16.0F, height * 0.5F / 16.0F), 7.0F);
        int mcx = sideW / 2;
        float tilt = Math.max(-14.0F, Math.min(14.0F, (mx - mcx) / (float) width * 26.0F));
        fx.machineBack(g, mcx, baseY, s);
        BarScene.machine(g, machineStack, mcx, baseY, s * (1.0F + 0.07F * fx.kick()), tilt + fx.wobble(), anim, mode == Mode.BREW);

        // the ticket of the customer
        int rw = Math.min(96, sideW - 12);
        int rcx = rightX + sideW / 2;
        var player = Minecraft.getInstance().player;
        var level = Minecraft.getInstance().level;
        if (player != null && level != null) {
            Order order = CafeLogic.findTicket(player).get(ModComponents.ORDER.get());
            if (order != null) {
                BarScene.ticket(g, font, rcx - rw / 2, 10, rw, order, level.getGameTime());
                int ticketBottom = 10 + (Dessert.byIndex(order.dessert()) != null ? 128 : 92) + 8;
                drawCustomer(g, order, level.getGameTime(), rcx, sideW, ticketBottom, counter);
            } else {
                BarScene.noTicket(g, font, rcx - rw / 2, 10, rw);
            }
        }

        // the cup stand
        Drink drink = brew != null && mode != Mode.MENU ? brew.drink : selected;
        int size = Math.min(64, rw - 8);
        int cupY = baseY - size;
        BarScene.coaster(g, rcx, baseY, size);
        if (mode == Mode.MENU) {
            Ui.icon(g, drink.iconTexture(), rcx - size / 2, cupY + Math.round((float) Math.sin(anim * 2.0F) * 2.0F), size);
        } else if (mode == Mode.BREW) {
            float target = stepIndex / (float) brew.drink.steps().length;
            shownProgress += (target - shownProgress) * Math.min(1.0F, dt * 5.0F);
            BarScene.reveal(g, drink.iconTexture(), rcx - size / 2, cupY, size, shownProgress);
        } else {
            summaryT += dt;
            shownProgress = 1.0F;
            int stars = brew.stars(brew.estimate());
            if (stars >= 4) BarScene.confetti(g, rcx, rw, height, summaryT);
            BarScene.spin(g, drink.iconTexture(), rcx, cupY, size, summaryT);
        }
        if (mode != Mode.BREW) shownProgress = mode == Mode.MENU ? 0.0F : shownProgress;
        Ui.centered(g, font, drink.displayName(), rcx, baseY + 9, 0xFFFFF6E2);
    }

    /** The customer of the ticket waits behind the counter on the right; the face shows how patient it still is. */
    private void drawCustomer(GuiGraphics g, Order o, long now, int rcx, int sideW, int ticketBottom, int counter) {
        int cell = Math.min(8, Math.min((counter - ticketBottom - 22) / 13, (sideW - 4) / 12));
        if (cell < 3) return;
        Drink drink = Drink.byIndex(o.drink());
        if (drink == null) return;
        long elapsed = Math.max(0L, now - o.created());
        long fast = CafeLogic.fastTicks(drink, o.dessert()), ok = CafeLogic.okTicks(drink, o.dessert());
        int who = Math.floorMod(o.customer(), Order.CUSTOMERS);
        CustomerPortrait.draw(g, font, fx, who, Component.translatable("customer.aestheticjobs." + who),
                CustomerPortrait.moodFor(elapsed, fast, ok), rcx, counter, cell, anim);
    }

    private void renderMenu(GuiGraphics g, int mx, int my) {
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.cafe.menu"), left + 12, top + 10, Ui.INK);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.cafe.menu.hint"), left + 12, top + 21, Ui.LABEL);
        for (int i = 0; i < Drink.values().length; i++) {
            Drink d = Drink.values()[i];
            int x = cardX(i), y = cardY(i);
            boolean sel = d == selected, hov = Ui.in(mx, my, x, y, 68, 54);
            Ui.box(g, x, y, 68, 54, sel ? Ui.BAD_D : Ui.KHAKI, sel ? 0xFFFBE3D8 : hov ? 0xFFFFFBEE : Ui.INNER);
            Ui.icon(g, d.iconTexture(), x + 18, y + 3, 32);
            Ui.centered(g, font, d.displayName(), x + 34, y + 37, Ui.INK);
            Ui.centered(g, font, Component.literal(dev.aestheticjobs.economy.Money.format(d.priceCents())), x + 34, y + 46 - 1, Ui.LABEL);
        }
        // the selected recipe
        int y0 = top + 150;
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.cafe.needs"), left + 12, y0, Ui.LABEL);
        int ix = left + 12;
        ix = supplyIcon(g, ModItems.EMPTY_CUP.get(), ix, y0 + 11);
        for (Drink.Supply s : selected.supplies()) ix = supplyIcon(g, s.item(), ix, y0 + 11);
        boolean ok = hasSupplies(selected);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.cafe.steps", selected.steps().length), left + 12, y0 + 32, Ui.LABEL);
        Ui.button(g, font, left + W - 100, top + 170, 88, 22, Component.translatable("gui.aestheticjobs.cafe.start"),
                Ui.in(mx, my, left + W - 100, top + 170, 88, 22), ok, 1);
        if (!ok) Ui.centered(g, font, Component.translatable("gui.aestheticjobs.cafe.supplies_missing"), left + W - 56, top + 195, Ui.BAD_D);
    }

    private int supplyIcon(GuiGraphics g, Item item, int x, int y) {
        boolean ok = have(item) > 0;
        Ui.box(g, x, y, 20, 20, ok ? Ui.GOOD_D : Ui.BAD_D, ok ? 0xFFF2F8EC : 0xFFFBE3D8);
        Ui.icon(g, itemIcon(item), x + 2, y + 2, 16);
        return x + 23;
    }

    /** Where the mini-game canvas stands: centred, with a chalkboard above and the buttons below. */
    private void brewLayout(float inv) {
        int sw = stageW(), sh = stageH();
        bScale = (width >= 2 * sw + 2 * 76 + 16 && height >= 2 * sh + 150) ? 2 : 1;      // crisp 2x on large screens
        int ch = sh * bScale;
        bx = (width - sw * bScale) / 2;
        by = Math.max(50, Math.min((height - ch) / 2 + 4, height - ch - 48));
        by += Math.round(inv * inv * inv * 26.0F);                                          // slides up with the panel
    }

    private void renderBrew(GuiGraphics g, int mx, int my, float dt) {
        Step[] steps = brew.drink.steps();
        int sw = stageW(), sh = stageH(), cw = sw * bScale, ch = sh * bScale;
        Stage s = stage;
        if (bg != null) {                                              // the shot goes on while the barista does the next step
            bg.updateBackground(dt);
            if (bg.backgroundDone()) {
                brew.scores.set(bgIndex, bg.score());
                fx.grade(bg.score());
                bg = null;
                reportState();
            }
        }

        // the chalkboard above the canvas: the drink, the step and the steps as dots
        int hx = bx - 6, hy = by - 46, hw = cw + 12;
        g.fill(hx + 3, hy + 5, hx + hw + 3, hy + 37, 0x55000000);
        Ui.box(g, hx, hy, hw, 34, 0xFF2A1A13, 0xFF6A4A3A);
        g.fill(hx + 3, hy + 3, hx + hw - 3, hy + 31, 0xFF2F3B36);
        g.renderOutline(hx + 3, hy + 3, hw - 6, 28, 0x33FFFFFF);
        Ui.icon(g, brew.drink.iconTexture(), hx + 7, hy + 5, 24);
        Ui.text(g, font, s.step.title(), hx + 36, hy + 8, 0xFFFFF6E2);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.cafe.of", stepIndex + 1, steps.length), hx + 36, hy + 19, 0xFFB9C9BC);
        int dotsX = hx + hw - 10 - steps.length * 14;
        for (int i = 0; i < steps.length; i++) {
            int c = i < stepIndex ? gradeColorFor(i) : i == stepIndex ? Ui.BAD_D : 0xFF55635C;
            Ui.disc(g, dotsX + i * 14 + 5, hy + 17, i == stepIndex ? 5 : 4, c);
        }

        // the canvas: virtual 284x138 coordinates, scaled by whole numbers
        BarScene.frame(g, bx, by, cw, ch);
        int vmx = Math.floorDiv(mx - bx, bScale), vmy = Math.floorDiv(my - by, bScale);
        var ps = g.pose();
        ps.pushPose();
        ps.translate(bx, by, 0.0F);
        ps.scale(bScale, bScale, 1.0F);
        s.layout(0, 0, sw, bg != null ? sh - 24 : sh);                 // a strip at the bottom is for the shot
        Ui.box(g, -1, -1, sw + 2, sh + 2, Ui.KHAKI, Ui.INNER);
        if (!s.isDone()) s.update(dt, vmx, vmy);
        boolean toBackground = !s.isDone() && s.wantsBackground();
        s.render(g, font, vmx, vmy);
        if (bg != null) bg.renderStrip(g, font, 4, sh - 22, sw - 8, 20, vmx, vmy);

        // finished: show the grade for a moment, then go on
        if (s.isDone()) {
            if (doneTimer < 0) {
                doneTimer = 0;
                fx.grade(s.score());
            }
            doneTimer += dt;
            int sc = s.score();
            int pw = 150, ph = 34, px = sw / 2 - pw / 2, py = sh / 2 - ph / 2;
            Ui.box(g, px, py, pw, ph, gradeColor(sc), 0xEEFFF6E2);
            Ui.centered(g, font, grade(sc), px + pw / 2, py + 7, gradeColor(sc));
            Ui.centered(g, font, Component.literal(sc + "%"), px + pw / 2, py + 19, Ui.INK);
            if (doneTimer > 1.1 && bg != null && needsShot(stepIndex + 1)) {       // the espresso is still running: stop it first
                int blink = ((int) (anim * 4.0F)) % 2 == 0 ? Ui.BAD_D : Ui.INK;
                Ui.centered(g, font, Component.translatable("step.aestheticjobs.pull.hold"), sw / 2, py + ph + 5, blink);
            }
        }
        ps.popPose();
        if (toBackground) {
            sendToBackground();
            return;
        }
        if (s.isDone() && doneTimer > 1.1 && (bg == null || !needsShot(stepIndex + 1))) advance();

        // the hint on the counter and the buttons
        int ty = by + ch + 9;
        String hint = s.status().getString();
        int tw = font.width(hint);
        g.fill(width / 2 - tw / 2 - 5, ty - 3, width / 2 + tw / 2 + 5, ty + 11, 0x77000000);
        Ui.centered(g, font, s.status(), width / 2, ty, 0xFFFFF6E2);
        int byBtn = by + ch + 24;
        Ui.button(g, font, bx, byBtn, 70, 18, Component.translatable("gui.aestheticjobs.cafe.cancel"),
                Ui.in(mx, my, bx, byBtn, 70, 18), true, 0);
        boolean can = !s.isDone() && s.canFinish();
        Ui.button(g, font, bx + cw - 100, byBtn, 100, 18, s.finishLabel(),
                Ui.in(mx, my, bx + cw - 100, byBtn, 100, 18), can, 1);
    }

    private int gradeColorFor(int i) {
        return i < brew.scores.size() ? (brew.scores.get(i) >= 75 ? Ui.GOOD_D : brew.scores.get(i) >= 50 ? Ui.WARN_D : Ui.BAD_D) : Ui.TAN;
    }

    private void renderSummary(GuiGraphics g, int mx, int my) {
        Step[] steps = brew.drink.steps();
        int q = brew.estimate();
        int stars = brew.stars(q);
        Ui.icon(g, brew.drink.iconTexture(), left + 8, top + 4, 24);
        Ui.text(g, font, brew.drink.displayName(), left + 36, top + 8, Ui.INK);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.cafe.ready"), left + 36, top + 19, Ui.LABEL);

        // the cup from above
        int cell = 7, cx = left + 14, cy = top + 40;
        Ui.disc(g, cx + 8 * cell, cy + 8 * cell, 8 * cell + 9, 0xFFE6D9BA);
        Ui.disc(g, cx + 8 * cell, cy + 8 * cell, 8 * cell + 5, 0xFFFFF6E2);
        CupRenderer.draw(g, cx, cy, cell, brew.art(), brew.drink);
        Ui.ring(g, cx + 8 * cell, cy + 8 * cell, 8 * cell + 1, 2, 0xFFD9CBA8);

        // the result
        int rx = left + 150;
        Ui.text(g, font, Component.literal(CupData.starText(stars)), rx, top + 36, 0xFFD9A850);
        Ui.text(g, font, Component.literal(q + "%"), rx + 62, top + 36, Ui.INK);
        for (int i = 0; i < steps.length && i < brew.scores.size(); i++) {
            int y = top + 54 + i * 15, sc = brew.scores.get(i);
            Ui.text(g, font, steps[i].title(), rx, y, Ui.LABEL);
            Ui.bar(g, rx + 78, y + 1, 52, 6, sc / 100.0, sc >= 75 ? Ui.GOOD : sc >= 50 ? Ui.WARN : Ui.BAD);
            Ui.text(g, font, Component.literal(String.valueOf(sc)), rx + 134, y, Ui.INK);
        }
        Ui.button(g, font, left + 12, top + H - 28, 70, 20, Component.translatable("gui.aestheticjobs.cafe.cancel"),
                Ui.in(mx, my, left + 12, top + H - 28, 70, 20), true, 0);
        Ui.button(g, font, left + W - 124, top + H - 28, 112, 20, Component.translatable("gui.aestheticjobs.cafe.serve"),
                Ui.in(mx, my, left + W - 124, top + H - 28, 112, 20), true, 1);
    }
}
