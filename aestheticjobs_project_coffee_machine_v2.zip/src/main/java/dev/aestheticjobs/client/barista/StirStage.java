package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModSounds;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Stir the syrup / chocolate into the base: hold the left button and move the mouse in circles around the cup.
 * Keep a steady speed: too slow leaves lumps, too fast splashes. The swirl melts into one colour.
 */
public class StirStage extends Stage {
    private static final double LO = 3.4, HI = 7.5;
    private final boolean chocolate;
    private double mix, omega, lastAngle, angleOffset, bandTime, totalTime;
    private boolean hasLast;
    private float soundTimer;

    // world mode: the mouse is mapped onto the surface of the real cup (see WorldMap)
    private static final double SCS = 1.05 / 52.0;                 // machine pixels per canvas pixel
    private final WorldMap map;
    private double toolU, toolV;

    public StirStage(Brew brew, Step step) {
        super(brew, step);
        this.chocolate = step.p1() >= 1;
        this.map = new WorldMap(brew.pos, LiveMachine.CUP_X, 3.0, LiveMachine.CUP_Z, new double[]{1, 0, 0}, new double[]{0, 0, 1});
    }

    private boolean world() { return CameraRig.ENABLED; }

    private int cx() { return rx + rw / 2 - 30; }
    private int cy() { return ry + rh / 2 - 4; }

    @Override
    public void update(float dt, int mx, int my) {
        if (done) return;
        if (world()) {                                              // gui coordinates -> the canvas of the game
            LiveMachine.Top t = LiveMachine.claimTop(brew.pos, LiveMachine.Top.STIR);
            map.setY(t.surfaceY);
            if (map.refresh()) {
                double[] uv = map.toUV(mx, my);
                toolU = uv[0];
                toolV = uv[1];
                mx = cx() + (int) Math.round(uv[0] / SCS);
                my = cy() + (int) Math.round(uv[1] / SCS);
            } else {
                toolU = 0.0;
                toolV = 0.0;
                mx = cx();
                my = cy();
            }
        }
        double dx = mx - cx(), dy = my - cy(), dist = Math.sqrt(dx * dx + dy * dy);
        double w = 0;
        if (Ui.lmb() && dist > 8 && dist < 74) {
            double a = Math.atan2(dy, dx);
            if (hasLast) {
                double d = a - lastAngle;
                while (d > Math.PI) d -= 2 * Math.PI;
                while (d < -Math.PI) d += 2 * Math.PI;
                w = Math.abs(d) / Math.max(dt, 1e-3);
                angleOffset += d;
            }
            lastAngle = a;
            hasLast = true;
        } else {
            hasLast = false;
        }
        omega += (Math.min(w, 14.0) - omega) * Math.min(1.0, dt * 8);
        if (omega > 0.8) {
            totalTime += dt;
            boolean inBand = omega >= LO && omega <= HI;
            if (inBand) bandTime += dt;
            mix = Math.min(1.0, mix + dt * (inBand ? 0.2 : omega > HI ? 0.07 : 0.09));
            soundTimer += dt;
            if (soundTimer > 0.22) {
                soundTimer = 0;
                Ui.sound(ModSounds.BARISTA_POUR.get(), inBand ? 1.3F : 0.9F, 0.22F);
            }
        }
        if (mix >= 1.0) {
            done = true;
            Ui.sound(ModSounds.BARISTA_DING.get(), 1.2F, 0.5F);
        }
        if (world()) feed();
    }

    /** Hands the swirl and the spoon to the real cup (see LiveMachine). */
    private void feed() {
        LiveMachine.Top t = LiveMachine.claimTop(brew.pos, LiveMachine.Top.STIR);
        t.a = angleOffset;
        t.b = mix;
        t.omega = omega;
        t.flag = chocolate;
        t.active = Ui.lmb() && !done;
        double r = Math.hypot(toolU, toolV), k = r > 1.0 ? 1.0 / r : 1.0;           // the spoon stays inside the cup
        double[] o = map.offset(toolU * k, toolV * k);
        t.toolX = o[0];
        t.toolZ = o[2];
        t.dir = map.offset(1.0, 0.0)[0] >= 0.0 ? 1 : -1;
        if (t.active) {
            CameraRig.shake(0.03F);
            if (omega > HI && Math.random() < 0.4) {
                CameraRig.puff(brew.pos, net.minecraft.core.particles.ParticleTypes.SPLASH, LiveMachine.CUP_X + o[0], t.surfaceY + 0.3, LiveMachine.CUP_Z + o[2], 0.02);
            }
        }
    }

    // ------------------------------------------------------------------ world mode: the HUD over the real cup

    @Override
    public boolean worldMode() { return world(); }

    @Override
    public CameraRig.Shot shot() { return CameraRig.ART; }

    @Override
    public void layoutWorld(int screenW, int screenH) {
        sw = screenW;
        sh = screenH;
        layout(0, 0, 284, 138);                                     // the game runs on its own canvas
    }

    @Override
    public void renderWorld(GuiGraphics g, Font font, int mx, int my) {
        int gx = sw - 60, gy = sh / 2 - 60, gh = 120;
        g.fill(gx - 14, gy - 12, gx + 30, gy + gh + 12, 0x66000000);
        g.fill(gx - 1, gy - 1, gx + 13, gy + gh + 1, Ui.KHAKI);
        g.fill(gx, gy, gx + 12, gy + gh, Ui.TAN);
        g.fill(gx, gy + gh - (int) (gh * HI / 14.0), gx + 12, gy + gh - (int) (gh * LO / 14.0), Ui.GOOD);
        int ny = gy + gh - (int) (gh * Math.min(1.0, omega / 14.0));
        g.fill(gx - 3, ny, gx + 15, ny + 2, Ui.INK);
        g.fill(sw / 2 - 108, sh - 80, sw / 2 + 108, sh - 52, 0x66000000);
        Ui.bar(g, sw / 2 - 100, sh - 64, 200, 7, mix, Ui.GOOD);
    }

    @Override
    public int score() {
        return totalTime <= 0 ? 0 : (int) Math.round(Math.max(30, Math.min(100, 100 * bandTime / totalTime * 1.05)));
    }

    @Override
    public Component status() {
        if (omega < 0.8) return step.hint();
        return Component.translatable(omega < LO ? "step.aestheticjobs.stir.slow" : omega > HI ? "step.aestheticjobs.stir.fast" : "step.aestheticjobs.stir.good");
    }

    @Override
    public void render(GuiGraphics g, Font font, int mx, int my) {
        int cx = cx(), cy = cy(), R = 52;
        int a = 0xFF52332A;
        int b = chocolate ? 0xFFB98A70 : 0xFFFBECCB;
        Ui.disc(g, cx, cy, R + 5, 0xFFE6D9BA);
        Ui.disc(g, cx, cy, R + 2, 0xFFFFF6E2);
        for (int y = -R; y <= R; y += 3) {
            for (int x = -R; x <= R; x += 3) {
                double r = Math.sqrt(x * x + y * y);
                if (r > R) continue;
                double ang = Math.atan2(y, x);
                double t = 0.5 + 0.5 * Math.sin(ang * 3 + r * 0.16 - angleOffset * 2.2);
                double wgt = t * (1 - mix) + 0.5 * mix;
                int c = Ui.lerp(a, b, wgt);
                if (mix < 0.55 && omega < LO && ((x * 7 + y * 13) % 11 == 0)) c = b;      // lumps when stirred too slowly
                g.fill(cx + x, cy + y, cx + x + 3, cy + y + 3, c);
            }
        }
        if (omega > HI) {
            for (int i = 0; i < 6; i++) {
                double an = Math.random() * Math.PI * 2;
                g.fill(cx + (int) (Math.cos(an) * (R + 4)), cy + (int) (Math.sin(an) * (R + 4)), cx + (int) (Math.cos(an) * (R + 4)) + 2, cy + (int) (Math.sin(an) * (R + 4)) + 2, 0xFFE3A08C);
            }
        }
        // the spoon follows the mouse
        if (Ui.lmb()) Ui.line(g, cx, cy, Math.max(cx - R, Math.min(cx + R, mx)), Math.max(cy - R, Math.min(cy + R, my)), 3, Ui.STEEL_D);
        // speed gauge on the right
        int gx = rx + rw - 40, gy = ry + 14, gh = rh - 40;
        g.fill(gx - 1, gy - 1, gx + 13, gy + gh + 1, Ui.KHAKI);
        g.fill(gx, gy, gx + 12, gy + gh, Ui.TAN);
        int z0 = gy + gh - (int) (gh * HI / 14.0), z1 = gy + gh - (int) (gh * LO / 14.0);
        g.fill(gx, z0, gx + 12, z1, Ui.GOOD);
        int ny = gy + gh - (int) (gh * Math.min(1.0, omega / 14.0));
        g.fill(gx - 3, ny, gx + 15, ny + 2, Ui.INK);
        Ui.bar(g, rx + 10, ry + rh - 14, rw - 20, 7, mix, Ui.GOOD);
    }
}
