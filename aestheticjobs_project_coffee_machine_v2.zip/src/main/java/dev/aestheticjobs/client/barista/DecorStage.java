package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.cafe.Art;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModSounds;
import java.util.Random;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * The finishing touch, drawn on the 16x16 picture of the cup by following a faint guide:
 *   COCOA    shake cocoa over the foam in the shape of a heart (hold the left button, dust falls round the cursor)
 *   WHIP     pipe a whipped cream swirl: trace the spiral from the outside to the middle
 *   CARAMEL  drizzle a caramel lattice across the foam
 * The score is the share of the guide you covered, minus what you spilled outside it.
 */
public class DecorStage extends Stage {
    private static final int N = Brew.GRID, CELL = 4, DC = 8;
    private static final String[] HEART = {
            "................", "................", "................", "...###....###...",
            "..#####..#####..", ".##############.", ".##############.", ".##############.",
            "..############..", "...##########...", "....########....", ".....######.....",
            "......####......", ".......##.......", "................", "................"};

    private final Step.Kind kind;
    private final boolean[] guide = new boolean[Drink.CELLS];
    private final double[][] guidePts;
    private final Random rnd = new Random();
    private double lastX, lastY;
    private boolean haveLast;
    private float soundTimer;
    private int finalScore;

    // world mode: the mouse is mapped onto the surface of the real cup (see WorldMap), then onto a cell of the 16x16 picture
    private static final double CW16 = 2.2 / 16.0, CD16 = 2.15 / 16.0;
    private final WorldMap map;
    private double toolX, toolZ;

    public DecorStage(Brew brew, Step step) {
        super(brew, step);
        this.kind = step.kind();
        java.util.List<double[]> pts = new java.util.ArrayList<>();
        if (kind == Step.Kind.COCOA) {
            for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) if (HEART[y].charAt(x) == '#') guide[y * 16 + x] = true;
        } else if (kind == Step.Kind.WHIP) {
            for (int i = 0; i <= 90; i++) {
                double t = i / 90.0, a = t * Math.PI * 2 * 2.3, rad = 6.3 * (1 - t) + 0.8;
                pts.add(new double[]{7.5 + Math.cos(a) * rad, 7.5 + Math.sin(a) * rad});
            }
        } else {
            final double k = 0.7071;
            for (int dir = 0; dir < 2; dir++) {
                double ux = k, uy = dir == 0 ? k : -k;            // direction of the lines
                double nx = -uy, ny = ux;                         // their normal
                for (int line = -2; line <= 2; line++) {
                    double d = line * 2.6;
                    for (double t = -9; t <= 9; t += 0.5) {
                        double x = 7.5 + nx * d + ux * t, y = 7.5 + ny * d + uy * t;
                        if (Math.hypot(x - 7.5, y - 7.5) < 6.6) pts.add(new double[]{x, y});
                    }
                }
            }
        }
        this.map = new WorldMap(brew.pos, LiveMachine.CUP_X, 3.0, LiveMachine.CUP_Z, new double[]{1, 0, 0}, new double[]{0, 0, 1});
        this.guidePts = pts.toArray(new double[0][]);
        for (double[] p : guidePts) {
            int x = (int) Math.round(p[0]), y = (int) Math.round(p[1]);
            if (x >= 0 && y >= 0 && x < 16 && y < 16) guide[y * 16 + x] = true;
        }
    }

    private boolean world() { return CameraRig.ENABLED; }

    private int ox() { return rx + 12; }
    private int oy() { return ry + (rh - N * CELL) / 2; }

    private char brush() {
        return kind == Step.Kind.COCOA ? '2' : kind == Step.Kind.WHIP ? '4' : '3';
    }

    private void set(int x, int y) {
        if (x < 0 || y < 0 || x >= 16 || y >= 16 || !Drink.inCup(x, y)) return;
        brew.deco[y * 16 + x] = brush();
    }

    @Override
    public void update(float dt, int mx, int my) {
        if (done) return;
        if (world()) {                                              // gui coordinates -> a cell of the picture -> the canvas of the game
            LiveMachine.Top t = LiveMachine.claimTop(brew.pos, LiveMachine.Top.DECOR);
            map.setY(t.surfaceY);
            if (map.refresh()) {
                double[] uv = map.toUV(mx, my);
                double[] o = map.offset(uv[0], uv[1]);
                toolX = o[0];
                toolZ = o[2];
                mx = ox() + (int) Math.round((7.5 - o[0] / CW16 + 0.5) * DC);
                my = oy() + (int) Math.round((7.5 - o[2] / CD16 + 0.5) * DC);
            } else {
                toolX = 0.0;
                toolZ = 0.0;
                mx = ox() + 8 * DC;
                my = oy() + 8 * DC;
            }
            feed();
        }
        double cx = (mx - ox()) / (double) DC - 0.5, cy = (my - oy()) / (double) DC - 0.5;
        if (!Ui.lmb()) {
            haveLast = false;
            return;
        }
        soundTimer += dt;
        if (soundTimer > (kind == Step.Kind.COCOA ? 0.1F : 0.3F)) {
            soundTimer = 0;
            Ui.sound(kind == Step.Kind.COCOA ? ModSounds.BARISTA_SPRINKLE.get() : ModSounds.BARISTA_POUR.get(),
                    kind == Step.Kind.COCOA ? 1.0F : 1.3F, 0.3F);
        }
        if (kind == Step.Kind.COCOA) {
            int n = (int) (dt * 110) + 1;
            for (int i = 0; i < n; i++) {
                set((int) Math.round(cx + rnd.nextGaussian() * 1.1), (int) Math.round(cy + rnd.nextGaussian() * 1.1));
            }
        } else {
            double rad = kind == Step.Kind.WHIP ? 1.45 : 0.62;
            if (haveLast) {
                double dist = Math.hypot(cx - lastX, cy - lastY);
                int steps = Math.max(1, (int) Math.ceil(dist / 0.3));
                for (int s = 1; s <= steps; s++) stamp(lastX + (cx - lastX) * s / steps, lastY + (cy - lastY) * s / steps, rad);
            } else {
                stamp(cx, cy, rad);
            }
        }
        lastX = cx;
        lastY = cy;
        haveLast = true;
    }

    private void stamp(double px, double py, double rad) {
        for (int y = (int) Math.floor(py - rad - 1); y <= (int) Math.ceil(py + rad + 1); y++) {
            for (int x = (int) Math.floor(px - rad - 1); x <= (int) Math.ceil(px + rad + 1); x++) {
                if (Math.hypot(x - px, y - py) <= rad) set(x, y);
            }
        }
    }

    private int painted() {
        int n = 0;
        for (char c : brew.deco) if (c != '0') n++;
        return n;
    }

    @Override
    public boolean canFinish() {
        return !done && painted() > 4;
    }

    @Override
    public void finish() {
        finalScore = compute();
        done = true;
        if (world()) feed();
        Ui.sound(ModSounds.BARISTA_DING.get(), 1.2F, 0.5F);
    }

    /** Hands the picture, the guide and the tool to the real cup (see LiveMachine). */
    private void feed() {
        LiveMachine.Top t = LiveMachine.claimTop(brew.pos, LiveMachine.Top.DECOR);
        t.milk = brew.milk;
        t.deco = brew.deco;
        t.guide = guide;
        t.a = kind == Step.Kind.COCOA ? 0 : kind == Step.Kind.WHIP ? 1 : 2;
        t.color = Art.rgb(brush(), brew.drink);
        t.toolX = toolX;
        t.toolZ = toolZ;
        t.active = Ui.lmb() && !done;
        t.dir = map.offset(1.0, 0.0)[0] >= 0.0 ? 1 : -1;
        if (t.active) CameraRig.shake(0.03F);
    }

    // ------------------------------------------------------------------ world mode: the HUD over the real cup

    @Override
    public boolean worldMode() { return world(); }

    @Override
    public CameraRig.Shot shot() { return CameraRig.ART; }

    @Override
    public void layoutWorld(int screenW, int screenH) {
        sw = screenW;
        sh = screenH;
        layout(0, 0, 284, 138);                                     // the game runs on its own canvas
    }

    @Override
    public void renderWorld(GuiGraphics g, Font font, int mx, int my) {
        int x = sw - 130, y = sh / 2 - 40, w = 110;
        g.fill(x - 8, y - 12, x + w + 8, y + 62, 0x66000000);
        Ui.text(g, font, Component.translatable("step.aestheticjobs.decor.guide"), x, y, 0xFFFFF6E2);
        int sc = score();
        Ui.bar(g, x, y + 12, w, 7, sc / 100.0, sc >= 75 ? Ui.GOOD : sc >= 50 ? Ui.WARN : Ui.BAD);
        Ui.text(g, font, Component.translatable("step.aestheticjobs.decor.score", sc), x, y + 24, 0xFFFFF6E2);
        Ui.text(g, font, Component.translatable("step.aestheticjobs.decor." + (kind == Step.Kind.COCOA ? "cocoa" : kind == Step.Kind.WHIP ? "whip" : "caramel")), x, y + 44, 0xFFB9C9BC);
    }

    private int compute() {
        int guideCells = 0, covered = 0, spill = 0;
        for (int i = 0; i < Drink.CELLS; i++) {
            if (guide[i]) {
                guideCells++;
                if (brew.deco[i] != '0') covered++;
            }
        }
        for (int y = 0; y < 16; y++) {
            for (int x = 0; x < 16; x++) {
                if (brew.deco[y * 16 + x] == '0') continue;
                boolean near = false;
                for (int dy = -1; dy <= 1 && !near; dy++) {
                    for (int dx = -1; dx <= 1 && !near; dx++) {
                        int nx = x + dx, ny = y + dy;
                        if (nx >= 0 && ny >= 0 && nx < 16 && ny < 16 && guide[ny * 16 + nx]) near = true;
                    }
                }
                if (!near) spill++;
            }
        }
        if (guideCells == 0) return 50;
        double cov = (double) covered / guideCells, sp = (double) spill / guideCells;
        return (int) Math.round(Math.max(0, Math.min(100, 100 * Math.min(1.0, cov / 0.85) - 55 * sp)));
    }

    @Override
    public int score() {
        return done ? finalScore : compute();
    }

    @Override
    public Component status() {
        return Component.translatable("step.aestheticjobs.decor.cover", compute());
    }

    @Override
    public void render(GuiGraphics g, Font font, int mx, int my) {
        int ox = ox(), oy = oy();
        int ccx = ox + N * CELL / 2, ccy = oy + N * CELL / 2;
        Ui.disc(g, ccx, ccy, N * CELL / 2 + 9, 0xFFE6D9BA);
        Ui.disc(g, ccx, ccy, N * CELL / 2 + 5, 0xFFFFF6E2);
        int base = Art.rgb('0', brew.drink);
        double C = (N - 1) / 2.0;
        for (int y = 0; y < N; y++) {
            for (int x = 0; x < N; x++) {
                double dx = x - C, dy = y - C;
                if (dx * dx + dy * dy > 15.2 * 15.2) continue;
                g.fill(ox + x * CELL, oy + y * CELL, ox + x * CELL + CELL, oy + y * CELL + CELL, Ui.lerp(base, Ui.MILK, brew.milk[y * N + x]));
            }
        }
        // the guide
        if (kind == Step.Kind.COCOA) {
            for (int i = 0; i < Drink.CELLS; i++) {
                if (guide[i] && brew.deco[i] == '0') g.fill(ox + (i % 16) * DC, oy + (i / 16) * DC, ox + (i % 16) * DC + DC, oy + (i / 16) * DC + DC, 0x22A8946C);
            }
        } else {
            for (double[] p : guidePts) {
                int gx = ox + (int) Math.round((p[0] + 0.5) * DC) - 1, gy = oy + (int) Math.round((p[1] + 0.5) * DC) - 1;
                g.fill(gx, gy, gx + 2, gy + 2, 0x88C98468);
            }
        }
        // the decoration itself
        for (int y = 0; y < 16; y++) {
            for (int x = 0; x < 16; x++) {
                char c = brew.deco[y * 16 + x];
                if (c == '0') continue;
                g.fill(ox + x * DC, oy + y * DC, ox + x * DC + DC, oy + y * DC + DC, Art.rgb(c, brew.drink));
            }
        }
        Ui.ring(g, ccx, ccy, N * CELL / 2 + 1, 2, 0xFFD9CBA8);
        // the tool
        if (!done) {
            int tc = kind == Step.Kind.COCOA ? 0xFF8A5E40 : kind == Step.Kind.WHIP ? 0xFFFFF9EC : 0xFFE2A85A;
            Ui.box(g, mx + 2, my - 26, 18, 22, Ui.STEEL_D, tc);
            g.fill(mx + 6, my - 4, mx + 12, my, Ui.STEEL_D);
        }
        int sx = ox + N * CELL + 16, w = rx + rw - sx - 6;
        Ui.text(g, font, Component.translatable("step.aestheticjobs.decor.guide"), sx, ry + 8, Ui.LABEL);
        int sc = score();
        Ui.bar(g, sx, ry + 22, w, 7, sc / 100.0, sc >= 75 ? Ui.GOOD : sc >= 50 ? Ui.WARN : Ui.BAD);
        Ui.text(g, font, Component.translatable("step.aestheticjobs.decor.score", sc), sx, ry + 34, Ui.INK);
        Ui.text(g, font, Component.translatable("step.aestheticjobs.decor." + (kind == Step.Kind.COCOA ? "cocoa" : kind == Step.Kind.WHIP ? "whip" : "caramel")), sx, ry + 54, Ui.LABEL);
    }
}
