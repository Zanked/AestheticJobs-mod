package dev.aestheticjobs.client.barista;

import net.minecraft.core.BlockPos;

/**
 * A flat plane of the machine seen through the camera: turns the mouse (gui coordinates) into a point of that plane
 * and back. The mini-games keep their own canvas coordinates; this is the bridge between the screen and the real machine.
 *
 * The plane is given by an origin and two directions in machine pixels. The (u, v) axes are the two directions with
 * their signs chosen so that u grows to the RIGHT and v grows DOWN on the screen, like the canvas of the 2D game.
 * Refresh it once per frame (the camera moves), then use toUV / toScreen / offset.
 */
public final class WorldMap {
    private final BlockPos pos;
    private final double ox, oz;
    private double oy;
    private final double[] a, b;
    private float cx, cy, ex, ey, fx, fy;          // screen: the origin, and one machine pixel along u and along v
    private int sa = 1, sb = 1;
    private boolean ok;

    public WorldMap(BlockPos pos, double ox, double oy, double oz, double[] a, double[] b) {
        this.pos = pos;
        this.ox = ox;
        this.oy = oy;
        this.oz = oz;
        this.a = a;
        this.b = b;
    }

    /** The plane can follow a surface that moves (the milk rises in the cup). */
    public void setY(double y) { this.oy = y; }

    public boolean refresh() {
        ok = false;
        float[] c = CameraRig.projectLocal(pos, ox, oy, oz);
        float[] p = CameraRig.projectLocal(pos, ox + a[0], oy + a[1], oz + a[2]);
        float[] q = CameraRig.projectLocal(pos, ox + b[0], oy + b[1], oz + b[2]);
        if (c == null || p == null || q == null) return false;
        sa = p[0] - c[0] >= 0 ? 1 : -1;
        sb = q[1] - c[1] >= 0 ? 1 : -1;
        cx = c[0];
        cy = c[1];
        ex = sa * (p[0] - c[0]);
        ey = sa * (p[1] - c[1]);
        fx = sb * (q[0] - c[0]);
        fy = sb * (q[1] - c[1]);
        ok = Math.abs(ex * fy - fx * ey) > 1.0E-3F;
        return ok;
    }

    public boolean ok() { return ok; }

    /** Gui coordinates -> machine pixels along u and v from the origin. */
    public double[] toUV(float sx, float sy) {
        double dx = sx - cx, dy = sy - cy, det = (double) ex * fy - (double) fx * ey;
        return new double[]{(dx * fy - fx * dy) / det, (ex * dy - dx * ey) / det};
    }

    /** Machine pixels along u and v -> gui coordinates. */
    public float[] toScreen(double u, double v) {
        return new float[]{(float) (cx + u * ex + v * fx), (float) (cy + u * ey + v * fy)};
    }

    /** The same (u, v) as a vector in machine space (x, y, z), the signs of the axes included. */
    public double[] offset(double u, double v) {
        return new double[]{
                u * sa * a[0] + v * sb * b[0],
                u * sa * a[1] + v * sb * b[1],
                u * sa * a[2] + v * sb * b[2]};
    }
}
