package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModSounds;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Macchiato: pour the espresso OVER A SPOON onto the foam so that it floats as a layer.
 * The spoon swings from side to side: hold the left button and keep the stream on the spoon.
 * Pouring beside it digs into the foam and mixes the layers.
 */
public class LayerStage extends Stage {
    private double progress, mix, time;
    private float soundTimer;

    // world mode: the mouse is mapped onto the surface of the real cup (see WorldMap); the spoon swings over the foam
    private static final double SCL = 0.72 / 24.0;                  // machine pixels per canvas pixel
    private final WorldMap map;
    private boolean pouringNow, aimedNow;
    private double toolU;

    public LayerStage(Brew brew, Step step) {
        super(brew, step);
        this.map = new WorldMap(brew.pos, LiveMachine.CUP_X, 3.0, LiveMachine.CUP_Z, new double[]{1, 0, 0}, new double[]{0, 0, 1});
    }

    private boolean world() { return CameraRig.ENABLED; }

    private int gx() { return rx + rw / 2 - 40; }
    private int gy() { return ry + 40; }
    private double spoonX() { return gx() + 40 + Math.sin(time * 1.5) * 24; }

    @Override
    public void update(float dt, int mx, int my) {
        if (done) return;
        if (world()) {                                              // gui coordinates -> the canvas of the game
            LiveMachine.Top t = LiveMachine.claimTop(brew.pos, LiveMachine.Top.LAYER);
            map.setY(t.surfaceY);
            if (map.refresh()) {
                double[] uv = map.toUV(mx, my);
                toolU = uv[0];
                mx = (int) Math.round(gx() + 40 + uv[0] / SCL);
            } else {
                toolU = 0.0;
                mx = gx() + 40;
            }
        }
        time += dt;
        pouringNow = Ui.lmb() || Ui.space();
        aimedNow = false;
        if (Ui.lmb() || Ui.space()) {
            boolean aimed = Math.abs(mx - spoonX()) < 15;
            aimedNow = aimed;
            if (aimed) progress = Math.min(1.0, progress + dt / 3.6);
            else {
                mix += dt * 0.7;
                progress = Math.min(1.0, progress + dt / 7.0);
            }
            soundTimer += dt;
            if (soundTimer > 0.28) {
                soundTimer = 0;
                Ui.sound(ModSounds.BARISTA_POUR.get(), aimed ? 1.15F : 0.8F, 0.5F);
            }
            if (progress >= 1.0) {
                done = true;
                Ui.sound(ModSounds.BARISTA_DING.get(), 1.2F, 0.5F);
            }
        }
        if (world()) {
            if (pouringNow) CameraRig.shake(0.03F);
            feed();
        }
    }

    /** Hands the layer, the spoon and the jug to the real cup (see LiveMachine). */
    private void feed() {
        LiveMachine.Top t = LiveMachine.claimTop(brew.pos, LiveMachine.Top.LAYER);
        t.a = progress;
        t.b = mix;
        t.spoonX = map.offset((spoonX() - (gx() + 40)) * SCL, 0.0)[0];
        t.toolX = map.offset(Math.max(-0.9, Math.min(0.9, toolU)), 0.0)[0];
        t.active = pouringNow && !done;
        t.aimed = aimedNow;
        t.dir = map.offset(1.0, 0.0)[0] >= 0.0 ? 1 : -1;
    }

    // ------------------------------------------------------------------ world mode: the HUD over the real cup

    @Override
    public boolean worldMode() { return world(); }

    @Override
    public CameraRig.Shot shot() { return CameraRig.ART; }

    @Override
    public void layoutWorld(int screenW, int screenH) {
        sw = screenW;
        sh = screenH;
        layout(0, 0, 284, 138);                                     // the game runs on its own canvas
    }

    @Override
    public void renderWorld(GuiGraphics g, Font font, int mx, int my) {
        g.fill(sw / 2 - 108, sh - 80, sw / 2 + 108, sh - 52, 0x66000000);
        Ui.bar(g, sw / 2 - 100, sh - 64, 200, 7, progress, Ui.GOOD);
    }

    @Override
    public int score() {
        return (int) Math.round(Math.max(20, 100 * (1.0 - Math.min(1.0, mix / 1.6))));
    }

    @Override
    public Component status() {
        return Component.translatable(mix > 0.5 ? "step.aestheticjobs.layer.mixed" : "step.aestheticjobs.layer.hint");
    }

    @Override
    public void render(GuiGraphics g, Font font, int mx, int my) {
        int gx = gx(), gy = gy(), gw = 80, gh = 84;
        Ui.box(g, gx - 3, gy - 3, gw + 6, gh + 6, 0xFFBDD7DC, 0xFFE6F2F4);
        int milkH = (int) (gh * 0.62), foamH = (int) (gh * 0.22);
        g.fill(gx, gy + gh - milkH, gx + gw, gy + gh, 0xFFF4E2B0);                   // vanilla milk
        g.fill(gx, gy + gh - milkH - foamH, gx + gw, gy + gh - milkH, 0xFFFFFAEC);   // foam
        int espH = (int) (foamH * 0.9 * progress);
        int top = gy + gh - milkH - foamH;
        double blur = Math.min(1.0, mix / 1.6);
        for (int y = 0; y < espH; y++) {                                              // the espresso layer, smeared if mixed
            int c = Ui.lerp(0xFF52332A, 0xFFB98A60, blur * (y / (double) Math.max(1, espH)));
            g.fill(gx, top + y, gx + gw, top + y + 1, c);
        }
        if (blur > 0.2) {
            for (int i = 0; i < blur * 40; i++) {
                int x = gx + (int) ((i * 37) % gw), y = top + espH + (int) ((i * 17) % 14);
                g.fill(x, y, x + 3, y + 2, 0x88B98A60);
            }
        }
        g.fill(gx + 4, gy + 3, gx + 8, gy + gh - 3, 0x66FFFFFF);
        // the spoon and the stream
        int sx = (int) spoonX();
        Ui.disc(g, sx, top - 3, 9, Ui.STEEL_D);
        Ui.disc(g, sx, top - 4, 8, Ui.STEEL);
        boolean pour = !done && (Ui.lmb() || Ui.space());
        int jx = Math.max(gx + 4, Math.min(gx + gw - 4, mx));
        Ui.box(g, jx - 10, gy - 30, 20, 12, 0xFF6A4A3A, 0xFF8A6A58);
        if (pour) {
            boolean aimed = Math.abs(mx - spoonX()) < 15;
            g.fill(jx - 1, gy - 18, jx + 2, aimed ? top - 12 : top + espH, 0xFF52332A);
        }
        Ui.bar(g, rx + 10, ry + rh - 14, rw - 20, 7, progress, Ui.GOOD);
    }
}
