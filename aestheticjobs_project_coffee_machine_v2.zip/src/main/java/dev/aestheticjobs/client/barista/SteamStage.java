package dev.aestheticjobs.client.barista;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModSounds;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Steam the milk with a real pitcher. The steam wand is fixed; YOU move the PITCHER (the mouse holds it by the handle,
 * it has weight: it lags behind, overshoots, and the milk SLOSHES inside, spilling over the rim if you are rough).
 * Raising the pitcher sinks the tip deeper into the milk, moving it sideways brings the tip closer to the wall.
 * Hold LMB / Space to open the valve. Mouse wheel tilts the pitcher.
 *
 *   1. STRETCH: tip right under the surface: a steady "tss" pulls air in and the foam grows, but only while the
 *      milk is cold. Tip in the air: it screams and spits, tip a little deeper: finer bubbles.
 *   2. WHIRL: tip a bit deeper and near the wall (a tilted pitcher helps): the milk starts to spin, the surface
 *      dips in the middle like a funnel, and the whirlpool shears the big bubbles into silky microfoam. The spin has
 *      inertia: it goes on after you close the valve.
 *   3. HEAT: the milk heats all the time the steam runs. Let go at the right temperature. Above 66 C the milk starts
 *      to scorch (yellow, flecks, a smell) and when it is burnt it is burnt.
 *
 * The bubbles you see in the pitcher and in the top view ARE the microfoam score: their size is the quality.
 */
public class SteamStage extends Stage {
    private static final int PH = 62, HWT = 30, HWB = 22;           // the pitcher, in canvas pixels
    private static final double SURFACE0 = 0.50;                     // depth of the still milk under the rim (share of PH)
    private static final int MAXB = 40;

    private final double foamTarget, tempTarget;

    // world mode: the canvas is virtual, the mouse is mapped onto the plane of the wand (see WorldMap)
    private static final double SC = 3.4 / PH;                       // machine pixels per canvas pixel
    private final WorldMap map;

    // the pitcher: position of the centre line and of the rim, speed, slosh and tilt
    private double px, ty, pvx, pvy, slosh, sloshV, tilt, tiltTarget;
    private boolean placed;

    // the milk
    private double temp = 6.0, foam, burn, lost, omega, spin, time, foamAcc;
    private boolean started, scalded, valve;
    private double rel, off;                                         // where the tip is: under the surface / sideways (-1..1 = wall to wall)

    private final float[] bAng = new float[MAXB], bRad = new float[MAXB], bSize = new float[MAXB];
    private int bn;

    private float soundTimer, spillSound;
    private final List<float[]> puffs = new ArrayList<>();           // x, y, life, kind (0 steam, 1 burnt)
    private final List<float[]> drops = new ArrayList<>();           // x, y, vx, vy, life: spat milk

    public SteamStage(Brew brew, Step step) {
        super(brew, step);
        this.foamTarget = step.p1();
        this.tempTarget = step.p2();
        this.map = new WorldMap(brew.pos, LiveMachine.WAND_X, LiveMachine.WAND_Y, LiveMachine.WAND_Z,
                new double[]{1, 0, 0}, new double[]{0, 1, 0});
    }

    private boolean world() { return CameraRig.ENABLED; }

    // ------------------------------------------------------------------ geometry

    private int wandX() { return rx + 97; }

    private int wandY() { return ry + (int) (rh * 0.40); }

    private int tyMin() { return ry + 2; }

    private int tyMax() { return ry + rh - 30 - PH; }

    private double surfaceDepth() { return SURFACE0 - 0.22 * foam; }

    private static double bell(double x, double c, double w) {
        double z = (x - c) / w;
        return Math.exp(-z * z);
    }

    private static double clamp(double v, double a, double b) { return Math.max(a, Math.min(b, v)); }

    // ------------------------------------------------------------------ physics

    @Override
    public void update(float dt, int mx, int my) {
        if (done) return;
        if (world()) {                                               // gui coordinates -> the canvas of the game
            if (map.refresh()) {
                double[] uv = map.toUV(mx, my);
                mx = (int) Math.round(wandX() + uv[0] / SC);
                my = (int) Math.round(wandY() + uv[1] / SC);
            } else {
                mx = wandX();
                my = wandY() + 20;
            }
        }
        time += dt;
        if (!placed) {
            px = clamp(mx, rx + 44, rx + 150);
            ty = clamp(my - 14, tyMin(), tyMax());
            placed = true;
        }
        valve = (Ui.lmb() || Ui.space()) && !scalded;
        int steps = Math.max(1, (int) Math.ceil(dt / 0.016));
        double h = dt / steps;
        for (int i = 0; i < steps; i++) physics(h, mx, my);
        tilt += (tiltTarget - tilt) * Math.min(1.0, dt * 10.0);

        // the world around: sound, steam, spat milk
        SceneFx fx = SceneFx.get();
        if (valve) {
            started = true;
            fx.hiss(rel < -0.02 ? 1.0F : 0.6F);
            soundTimer += dt;
            if (soundTimer > 0.3F) {
                soundTimer = 0;
                float pitch = rel < -0.02 ? 1.5F : rel <= 0.10 ? 1.1F : omega > 2.0 ? 0.65F : 0.8F;
                Ui.sound(ModSounds.BARISTA_STEAM.get(), pitch, rel < -0.02 ? 0.6F : 0.45F);
            }
            double yW = ty + surfaceDepth() * PH;
            if (Math.random() < (rel < -0.02 ? 0.9 : 0.3)) {
                puffs.add(new float[]{wandX() + (float) (Math.random() * 8 - 4), (float) (rel < -0.02 ? wandY() - 4 : yW - 2), 1.0F, 0.0F});
            }
        }
        if (scalded && Math.random() < 0.35) {
            puffs.add(new float[]{(float) (px + Math.random() * 30 - 15), (float) ty - 2, 1.0F, 1.0F});
        }
        for (int i = puffs.size() - 1; i >= 0; i--) {
            float[] p = puffs.get(i);
            p[1] -= (p[3] > 0 ? 18 : 34) * dt;
            p[0] += (float) (Math.sin(time * 4 + i) * 6 * dt);
            p[2] -= dt * (p[3] > 0 ? 0.7F : 1.2F);
            if (p[2] <= 0) puffs.remove(i);
        }
        for (int i = drops.size() - 1; i >= 0; i--) {
            float[] d = drops.get(i);
            d[3] += 230 * dt;
            d[0] += d[2] * dt;
            d[1] += d[3] * dt;
            d[4] -= dt;
            if (d[4] <= 0 || d[1] > ry + rh) drops.remove(i);
        }
        if (world()) {
            if (valve) {
                CameraRig.shake(0.05F);
                if (Math.random() < dt * (rel < -0.02 ? 30.0 : 8.0)) {
                    CameraRig.steam(brew.pos, LiveMachine.WAND_X, LiveMachine.WAND_Y + (rel < -0.02 ? 0.4 : 1.2), LiveMachine.WAND_Z);
                }
            }
            feed();
            if (scalded && Math.random() < dt * 12.0) {
                LiveMachine.Steam s = LiveMachine.claimSteam(brew.pos);
                CameraRig.puff(brew.pos, net.minecraft.core.particles.ParticleTypes.SMOKE, s.x, s.y, s.z, 0.01);
            }
        }
    }

    /** Hands the pitcher to the real machine (see LiveMachine): its place comes from the same physics as before. */
    private void feed() {
        LiveMachine.Steam s = LiveMachine.claimSteam(brew.pos);
        double[] o = map.offset((px - wandX()) * SC, (ty - wandY()) * SC);
        s.active = !done;
        s.x = LiveMachine.WAND_X + o[0];
        s.y = LiveMachine.WAND_Y + o[1];
        s.z = LiveMachine.WAND_Z + o[2];
        s.tilt = (wandX() >= px ? 1.0 : -1.0) * tilt + clamp(pvx * 0.012, -6.0, 6.0);
        s.slosh = slosh;
        s.depth = surfaceDepth() * PH * SC;
        s.foam = foam;
        s.burn = burn;
        s.valve = valve;
        s.inAir = rel < -0.02;
        s.scalded = scalded;
    }

    private void physics(double h, int mx, int my) {
        // ---- the pitcher hangs on the mouse by a spring
        double tx = clamp(mx, rx + 44, rx + 150);
        double tyT = clamp(my - 14, tyMin(), tyMax());
        double ax = 120.0 * (tx - px) - 15.0 * pvx;
        double ay = 120.0 * (tyT - ty) - 15.0 * pvy;
        pvx += ax * h;
        pvy += ay * h;
        px = clamp(px + pvx * h, rx + 40, rx + 154);
        ty = clamp(ty + pvy * h, tyMin(), tyMax());
        // the milk sloshes: a damped pendulum pushed by the sideways acceleration
        double w0 = 7.0;
        sloshV += (-w0 * w0 * slosh - 2 * 0.14 * w0 * sloshV - ax * 0.0012) * h;
        slosh = clamp(slosh + sloshV * h, -0.65, 0.65);

        // ---- where the tip is in the milk
        double d = (wandY() - ty) / PH;                               // depth of the tip under the rim
        off = (wandX() - px) / HWT;
        double sd = surfaceDepth() + slosh * (off * HWT) / PH;         // the surface right at the tip
        rel = d - sd;

        // spilling over the rim
        double sdPx = surfaceDepth() * PH;
        if (Math.abs(slosh) * HWT > sdPx * 0.8 && lost < 1.0) {
            lost += 0.12 * h;
            spillSound += (float) h;
            if (Math.random() < 14 * h) {
                float sgn = slosh > 0 ? 1 : -1;
                drops.add(new float[]{(float) (px + sgn * HWT), (float) ty, sgn * (10 + (float) Math.random() * 25), -(20 + (float) Math.random() * 30), 0.9F});
            }
            if (spillSound > 0.35F) {
                spillSound = 0;
                Ui.sound(ModSounds.BARISTA_POUR.get(), 1.7F, 0.25F);
            }
        }

        // ---- the whirlpool: spins up when the tip is a little deeper and near the wall; it has inertia
        double tiltK = 0.70 + 0.30 * Math.min(1.0, tilt / 14.0);
        double wt = valve ? 6.8 * bell(rel, 0.22, 0.14) * bell(Math.abs(off), 0.58, 0.24) * tiltK : 0.0;
        omega += (wt - omega) * Math.min(1.0, h * (wt > omega ? 1.7 : 0.30));
        spin += omega * h;

        // ---- heat
        if (valve) {
            double rate = rel < -0.02 ? 1.3 : rel < 0.05 ? 4.6 : 6.2;
            temp += rate * (1.0 - 0.35 * foam) * h;
        } else {
            temp = Math.max(6.0, temp - 0.10 * h);
        }
        if (temp > 66) {
            burn = Math.min(1.4, burn + (temp - 66) * 0.045 * h * (valve ? 1.0 : 0.3));
        }
        if (!scalded && (burn >= 1.0 || temp >= 80)) {
            scalded = true;
            valve = false;
            omega *= 0.5;
            Ui.sound(ModSounds.CUSTOMER_GRUMBLE.get(), 0.6F, 0.6F);
        }

        // ---- air in: stretching (only in cold milk, only with the tip right under the surface)
        double aer = valve ? Math.max(0.0, 1.0 - Math.abs(rel - 0.04) / 0.075) : 0.0;
        double cold = clamp((52.0 - temp) / 40.0, 0.0, 1.0);
        double gain = 0.085 * aer * cold * h;
        if (valve && rel < -0.02) {                                   // in the air: spitting and screaming
            gain += 0.005 * h;
            lost += 0.01 * h;
            if (Math.random() < 24 * h) {
                drops.add(new float[]{wandX(), wandY(), (float) (Math.random() * 80 - 40), -(40 + (float) Math.random() * 70), 0.9F});
            }
        }
        double before = foam;
        foam = Math.min(0.8, foam + gain);
        foamAcc += foam - before;
        while (foamAcc >= 0.021 && bn < MAXB) {
            foamAcc -= 0.021;
            float shallow = rel < 0.02 ? 1.0F : 0.3F;                // a gentler stretch makes finer bubbles
            bAng[bn] = (float) (Math.random() * Math.PI * 2);
            bRad[bn] = 0.15F + (float) Math.random() * 0.8F;
            bSize[bn] = 1.2F + (float) Math.random() * 0.8F + 2.0F * shallow * (float) Math.random();
            bn++;
        }

        // ---- the bubbles: carried round by the whirlpool, sheared into microfoam, popped when the milk is calm
        for (int i = bn - 1; i >= 0; i--) {
            bAng[i] += (float) (omega * h * (1.35 - 0.7 * bRad[i]));
            bRad[i] += (float) ((0.55 - bRad[i]) * h * 0.2 * omega / 6.8);
            if (bSize[i] > 0.95F) {
                float shear = (float) (0.12 * omega * h * (bSize[i] > 2.0F ? 1.5 : 0.7));
                bSize[i] = Math.max(0.9F, bSize[i] - shear);
            }
            if (omega < 0.8 && bSize[i] > 3.2F && Math.random() < h * 0.25) {
                bn--;                                                  // a big bubble pops
                bAng[i] = bAng[bn];
                bRad[i] = bRad[bn];
                bSize[i] = bSize[bn];
                foam = Math.max(0.0, foam - 0.012);
                foamAcc = 0.0;
            }
        }
    }

    // ------------------------------------------------------------------ result

    private double smoothness() {
        if (bn == 0) return 0.0;
        double sum = 0.0;
        for (int i = 0; i < bn; i++) sum += bSize[i];
        double avg = sum / bn;
        return clamp(1.0 - (avg - 1.0) / 2.2, 0.0, 1.0);
    }

    /** 0..1: how silky the milk is. Needs some foam to be judged, and a scorched milk is spoiled. */
    private double micro01() {
        double need = clamp(foam / Math.max(0.05, foamTarget * 0.7), 0.0, 1.0);
        return clamp(smoothness() * need * (1.0 - 0.6 * Math.min(1.0, burn)), 0.0, 1.0);
    }

    @Override
    public boolean canFinish() {
        return !done && started && temp > 20;
    }

    @Override
    public void finish() {
        done = true;
        LiveMachine.claimSteam(brew.pos).active = false;
        brew.foam = foam;
        brew.micro = micro01();
        brew.milkTemp = temp;
        Ui.sound(ModSounds.BARISTA_DING.get(), 1.2F, 0.5F);
    }

    @Override
    public int score() {
        double fs = Math.max(0, 100 - Math.abs(foam - foamTarget) * 260);
        double ts = Math.max(0, 100 - Math.abs(temp - tempTarget) * 8);
        double total = 0.30 * fs + 0.30 * ts + 0.40 * micro01() * 100.0;
        total -= Math.min(1.0, lost) * 30.0;                          // spilled and spat milk
        if (burn > 0.25) total *= 1.0 - 0.45 * Math.min(1.0, burn);
        if (scalded) total = Math.min(total, 25);
        return (int) Math.round(Math.max(0, total));
    }

    @Override
    public void scroll(double amount) {
        tiltTarget = clamp(tiltTarget + amount * 3.5, 0.0, 26.0);
    }

    // ------------------------------------------------------------------ status line

    @Override
    public Component status() {
        if (scalded) return Component.translatable("step.aestheticjobs.steam.scalded");
        if (!started) {
            return ((int) (time / 4.0)) % 2 == 0 ? Component.translatable("step.aestheticjobs.steam.howto") : step.hint();
        }
        if (Math.abs(slosh) * HWT > surfaceDepth() * PH * 0.8) return Component.translatable("step.aestheticjobs.steam.spill");
        if (valve && temp >= tempTarget + 2) return Component.translatable("step.aestheticjobs.steam.hot");
        if (!valve) return Component.translatable(omega > 1.5 ? "step.aestheticjobs.steam.coasting" : "step.aestheticjobs.steam.paused");
        if (rel < -0.02) return Component.translatable("step.aestheticjobs.steam.air");
        if (rel <= 0.10) return Component.translatable(temp < 50 ? "step.aestheticjobs.steam.aerate" : "step.aestheticjobs.steam.cold_late");
        if (omega > 2.5) return Component.translatable("step.aestheticjobs.steam.whirl");
        return Component.translatable(Math.abs(off) < 0.3 ? "step.aestheticjobs.steam.centre" : "step.aestheticjobs.steam.offcentre");
    }

    // ------------------------------------------------------------------ world mode: the HUD over the real machine

    @Override
    public boolean worldMode() { return world(); }

    @Override
    public CameraRig.Shot shot() { return CameraRig.STEAM; }

    @Override
    public void layoutWorld(int screenW, int screenH) {
        sw = screenW;
        sh = screenH;
        layout(0, 0, 284, 138);                                      // the game runs on its own canvas
    }

    @Override
    public void renderWorld(GuiGraphics g, Font font, int mx, int my) {
        // the thermometer on the right: the green zone at the target, red above the scorch line, the burn next to it
        int tx = sw - 44, ty0 = sh / 2 - 70, th = 140;
        boolean hot = valve && temp >= tempTarget + 2 && ((int) (time * 6)) % 2 == 0;
        g.fill(tx - 14, ty0 - 12, tx + 24, ty0 + th + 20, 0x66000000);
        g.fill(tx - 1, ty0 - 1, tx + 13, ty0 + th + 1, hot ? Ui.BAD_D : Ui.KHAKI);
        g.fill(tx, ty0, tx + 12, ty0 + th, Ui.TAN);
        g.fill(tx, ty0 + th - (int) (th * (tempTarget + 2) / 80.0), tx + 12, ty0 + th - (int) (th * (tempTarget - 2) / 80.0), Ui.GOOD);
        g.fill(tx, ty0, tx + 12, ty0 + th - (int) (th * 66 / 80.0), Ui.BAD);
        int tyn = ty0 + th - (int) (th * Math.min(1.0, temp / 80.0));
        g.fill(tx + 3, tyn, tx + 9, ty0 + th, Ui.lerp(0xFF8FB8D8, 0xFFD9604C, temp / 80.0));
        g.fill(tx - 3, tyn, tx + 15, tyn + 2, Ui.INK);
        g.fill(tx - 7, ty0, tx - 3, ty0 + th, Ui.TAN);
        int bh = (int) (th * Math.min(1.0, burn));
        if (bh > 0) g.fill(tx - 7, ty0 + th - bh, tx - 3, ty0 + th, Ui.BAD_D);
        Ui.text(g, font, Component.literal((int) temp + "\u00B0"), tx - 2, ty0 + th + 5, scalded ? Ui.BAD_D : 0xFFFFF6E2);
        Ui.text(g, font, Component.translatable("step.aestheticjobs.steam.tilt", (int) Math.round(tilt)), tx - 12, ty0 - 24, 0xFFFFF6E2);
        // the foam and the silkiness of the milk, bottom centre
        int bw = 100, bx = sw / 2 - bw - 6, by = sh - 70;
        g.fill(bx - 8, by - 16, bx + 2 * bw + 20, by + 14, 0x66000000);
        Ui.text(g, font, Component.translatable("step.aestheticjobs.steam.foam", (int) Math.round(foam * 100)), bx, by - 12, 0xFFFFF6E2);
        Ui.bar(g, bx, by, bw, 7, foam / 0.8, Ui.WARN);
        int tick = bx + (int) (bw * foamTarget / 0.8);
        g.fill(tick, by - 3, tick + 2, by + 10, Ui.GOOD_D);
        int mx2 = bx + bw + 12;
        Ui.text(g, font, Component.translatable("step.aestheticjobs.steam.micro", (int) Math.round(micro01() * 100)), mx2, by - 12, 0xFFFFF6E2);
        Ui.bar(g, mx2, by, bw, 7, micro01(), Ui.GOOD);
    }

    // ------------------------------------------------------------------ drawing

    private int milkColor() { return Ui.lerp(0xFFF8EBD0, 0xFFD6A55A, Math.min(1.0, burn)); }

    private int foamColor(double k) {
        int c = Ui.lerp(0xFFFFFAEC, 0xFFFCF0D6, k);
        return Ui.lerp(c, 0xFFE6C080, Math.min(1.0, burn));
    }

    @Override
    public void render(GuiGraphics g, Font font, int mx, int my) {
        if (!placed) {
            px = clamp(mx, rx + 44, rx + 150);
            ty = clamp(my - 14, tyMin(), tyMax());
            placed = true;
        }
        int cx = (int) Math.round(px), top = (int) Math.round(ty);
        int wx = wandX(), wy = wandY();
        PoseStack ps = g.pose();

        // a soft shadow under the pitcher
        g.fill(cx - HWB, top + PH + 3, cx + HWB, top + PH + 5, 0x22000000);

        // ---- the pitcher (drawn in its own, tilted, coordinates: the origin is its centre)
        float dir = wx >= px ? 1.0F : -1.0F;
        float angle = (float) (dir * tilt + clamp(pvx * 0.012, -6.0, 6.0));
        ps.pushPose();
        ps.translate(cx, top + PH / 2.0F, 0.0F);
        ps.mulPose(Axis.ZP.rotationDegrees(angle));
        drawPitcher(g);
        ps.popPose();

        // ---- the steam wand (fixed) and the jet under the tip
        drawWand(g, wx, wy);
        if (valve && !done && rel >= -0.02) {
            double jet = clamp(wy - (ty + surfaceDepth() * PH), 3.0, 30.0);
            for (int i = 0; i < 8; i++) {
                double ph = (time * 1.8 + i / 8.0) % 1.0;
                int bx = wx + (int) (Math.sin(time * 7 + i * 2.1) * 3), by = (int) (wy - ph * jet);
                int a = (int) ((1.0 - ph) * 200);
                g.fill(bx, by, bx + 2, by + 2, a << 24 | 0xFFFFFF);
            }
        }
        for (float[] d : drops) g.fill((int) d[0], (int) d[1], (int) d[0] + 2, (int) d[1] + 2, 0xFFFFFAEC);
        for (float[] p : puffs) {
            int a = (int) (Math.max(0, p[2]) * (p[3] > 0 ? 110 : 150));
            int col = p[3] > 0 ? 0x8A6A44 : 0xFFFFFF;
            g.fill((int) p[0], (int) p[1], (int) p[0] + 4, (int) p[1] + 4, a << 24 | col);
        }

        drawChips(g, font);
        drawTopView(g, font);
        drawThermometer(g, font);
        drawGauges(g, font);
    }

    private void drawPitcher(GuiGraphics g) {
        int hp = PH / 2;
        // steel body and the empty inside
        for (int y = -hp; y < hp; y++) {
            double k = (y + hp) / (double) PH;
            int half = (int) Math.round(HWT + (HWB - HWT) * k);
            g.fill(-half - 2, y, -half, y + 1, Ui.STEEL_D);
            g.fill(half, y, half + 2, y + 1, Ui.STEEL_D);
            g.fill(-half, y, half, y + 1, 0xFFE9EEF0);
        }
        g.fill(-HWB - 2, hp, HWB + 2, hp + 3, Ui.STEEL_D);
        g.fill(-HWT - 9, -hp - 1, -HWT, -hp + 2, Ui.STEEL_D);                 // spout
        g.fill(-HWT - 6, -hp + 2, -HWT + 1, -hp + 4, Ui.STEEL_D);
        g.fill(HWT - 4, -hp + 6, HWT + 14, -hp + 9, Ui.STEEL_D);              // handle
        g.fill(HWT + 11, -hp + 6, HWT + 14, -hp + 27, Ui.STEEL_D);
        g.fill(HWT - 7, -hp + 24, HWT + 14, -hp + 27, Ui.STEEL_D);
        g.fill(HWT - 3, -hp + 7, HWT + 12, -hp + 8, 0xFFF4F7F8);

        // the milk, column by column: it sloshes and dips into a funnel when it whirls
        double sdPx = surfaceDepth() * PH;
        double foamPx = Math.min(PH * 0.45, foam * 26.0);
        int milk = milkColor();
        for (int x = -HWT; x < HWT; x += 2) {
            double xc = x + 1.0;
            double bottomK = Math.abs(xc) <= HWB ? 1.0 : Math.max(0.0, (HWT - Math.abs(xc)) / (double) (HWT - HWB));
            int yBot = (int) Math.round(-hp + PH * bottomK);
            if (yBot <= -hp + 1) continue;
            int ysI = surfaceY(xc, hp, sdPx, yBot);
            int foamEnd = (int) Math.min(yBot, ysI + Math.round(foamPx));
            g.fill(x, foamEnd, x + 2, yBot, milk);
            if (foamEnd > ysI) g.fill(x, ysI, x + 2, foamEnd, foamColor((foamEnd - ysI) / Math.max(1.0, foamPx)));
            g.fill(x, ysI, x + 2, ysI + 1, 0x99FFFFFF);
        }
        // streaks of the whirl in the milk
        if (omega > 0.4) {
            for (int i = 0; i < 5; i++) {
                int y = (int) (-hp + sdPx + foamPx + 5 + i * 6);
                if (y > hp - 3) continue;
                int x = (int) (Math.sin(spin * 0.9 + i * 1.3) * HWB * 0.7);
                int a = (int) Math.min(120, omega * 22);
                g.fill(x - 4, y, x + 5, y + 1, a << 24 | 0xFFFFFF);
            }
        }
        // scorch flecks
        if (burn > 0.4) {
            int n = (int) (burn * 10);
            for (int i = 0; i < n; i++) {
                int x = ((i * 37) % 44) - 22;
                int y = (int) (-hp + sdPx + 2 + (i * 13) % 12);
                g.fill(x, y, x + 2, y + 1, 0xFF8A5A30);
            }
        }
        // big and small bubbles on the foam
        for (int i = 0; i < bn; i++) {
            double xl = Math.cos(bAng[i]) * bRad[i] * (HWB - 4);
            double depthK = 0.5 + 0.5 * Math.sin(bAng[i]);
            int ysI = surfaceY(xl, hp, sdPx, hp);
            int by = ysI + 1 + (int) (depthK * Math.max(1.0, foamPx - 3));
            int bx = (int) Math.round(xl);
            boolean back = Math.sin(bAng[i]) < 0;
            int r = Math.round(bSize[i] * 0.8F);
            if (r <= 1) {
                g.fill(bx, by, bx + 2, by + 2, back ? 0xAAFFFAEC : 0xFFFFFFFF);
            } else {
                Ui.ring(g, bx, by, r, 1, back ? 0xAAFFFFFF : 0xFFFFFFFF);
            }
        }
    }

    private int surfaceY(double xc, int hp, double sdPx, int yBot) {
        double dipK = 1.0 - (xc / HWT) * (xc / HWT);
        double ripple = Math.sin(xc * 0.35 + time * 9.0) * Math.min(1.2, omega * 0.25 + (valve ? 0.4 : 0.0));
        double ys = -hp + sdPx + slosh * xc + dipK * omega * 1.1 + ripple;
        return (int) Math.round(clamp(ys, -hp, yBot - 1));
    }

    private void drawWand(GuiGraphics g, int wx, int wy) {
        int wp = wx + 16;
        g.fill(wp - 1, ry, wp + 2, wy - 24, Ui.STEEL_D);
        g.fill(wp, ry, wp + 1, wy - 24, 0xFFF4F7F8);
        Ui.line(g, wp, wy - 24, wx, wy, 3, Ui.STEEL_D);
        Ui.line(g, wp, wy - 25, wx, wy - 1, 1, 0xFFF4F7F8);
        g.fill(wx - 2, wy - 2, wx + 3, wy + 3, Ui.STEEL);
        g.fill(wx - 1, wy + 1, wx + 2, wy + 3, 0xFF7A8488);
        Ui.disc(g, wp, ry + 11, 4, valve ? Ui.GOOD_D : Ui.BAD_D);              // the valve knob
        Ui.disc(g, wp - 1, ry + 10, 1, 0xFFFFFFFF);
    }

    private void chip(GuiGraphics g, Font font, int i, String key, boolean ok, boolean active) {
        int x = rx + 198, y = ry + 4 + i * 12;
        int border = ok ? Ui.GOOD_D : active ? Ui.WARN_D : Ui.KHAKI;
        int fill = ok ? 0xFFE3F0DA : active ? 0xFFFBF1D0 : Ui.TAN;
        Ui.box(g, x, y, 56, 11, border, fill);
        Ui.disc(g, x + 6, y + 5, 2, ok ? Ui.GOOD_D : active ? Ui.WARN_D : Ui.KHAKI);
        Ui.text(g, font, Component.translatable(key), x + 12, y + 2, Ui.INK);
    }

    private void drawChips(GuiGraphics g, Font font) {
        boolean stretch = foam >= foamTarget * 0.85;
        boolean whirl = foam > 0.02 && smoothness() >= 0.72;
        boolean heat = Math.abs(temp - tempTarget) <= 3.0;
        chip(g, font, 0, "step.aestheticjobs.steam.chip.stretch", stretch, !stretch);
        chip(g, font, 1, "step.aestheticjobs.steam.chip.whirl", whirl, stretch && !whirl);
        chip(g, font, 2, "step.aestheticjobs.steam.chip.heat", heat, temp > tempTarget - 14 && !heat);
    }

    /** The milk from above: spiral arms turn with the whirlpool, the bubbles go round, the tip is a ring. */
    private void drawTopView(GuiGraphics g, Font font) {
        int cx = rx + 224, cy = ry + 72, R = 20;
        Ui.disc(g, cx, cy, R + 3, Ui.KHAKI);
        Ui.disc(g, cx, cy, R + 1, Ui.STEEL_D);
        Ui.disc(g, cx, cy, R, milkColor());
        Ui.ring(g, cx, cy, 15, 1, 0x88A9C79A);                                   // where the tip should be for a whirl
        Ui.ring(g, cx, cy, 8, 1, 0x88A9C79A);
        int a = (int) Math.min(150, 30 + omega * 20);
        for (int arm = 0; arm < 3; arm++) {
            for (int j = 1; j < 11; j++) {
                double t = j / 10.0, ang = spin * 0.8 + arm * 2.094 + t * 2.2;
                int x = cx + (int) Math.round(Math.cos(ang) * t * R * 0.92), y = cy + (int) Math.round(Math.sin(ang) * t * R * 0.92);
                if (omega > 0.15) g.fill(x, y, x + 1, y + 1, a << 24 | 0xFFFFFF);
            }
        }
        for (int i = 0; i < bn; i++) {
            int x = cx + (int) Math.round(Math.cos(bAng[i]) * bRad[i] * (R - 3)), y = cy + (int) Math.round(Math.sin(bAng[i]) * bRad[i] * (R - 3));
            if (bSize[i] > 2.2F) Ui.disc(g, x, y, 1, 0xFFFFFFFF);
            else g.fill(x, y, x + 1, y + 1, 0xFFFFFAEC);
        }
        int mx2 = cx + (int) Math.round(clamp(off, -1.0, 1.0) * (R - 3));
        boolean inZone = Math.abs(off) > 0.34 && Math.abs(off) < 0.82;
        Ui.ring(g, mx2, cy, 3, 1, inZone ? Ui.GOOD_D : Ui.INK);
        g.fill(mx2, cy, mx2 + 1, cy + 1, valve ? 0xFFFFFFFF : Ui.STEEL_D);
        Ui.centered(g, font, Component.translatable("step.aestheticjobs.steam.tilt", (int) Math.round(tilt)), cx, cy + R + 5, Ui.LABEL);
    }

    private void drawThermometer(GuiGraphics g, Font font) {
        int tx = rx + rw - 26, ty0 = ry + 6, th = rh - 40;
        boolean hot = valve && temp >= tempTarget + 2 && ((int) (time * 6)) % 2 == 0;
        g.fill(tx - 1, ty0 - 1, tx + 13, ty0 + th + 1, hot ? Ui.BAD_D : Ui.KHAKI);
        g.fill(tx, ty0, tx + 12, ty0 + th, Ui.TAN);
        int z0 = ty0 + th - (int) (th * (tempTarget + 2) / 80.0), z1 = ty0 + th - (int) (th * (tempTarget - 2) / 80.0);
        g.fill(tx, z0, tx + 12, z1, Ui.GOOD);
        g.fill(tx, ty0, tx + 12, ty0 + th - (int) (th * 66 / 80.0), Ui.BAD);
        int tyn = ty0 + th - (int) (th * Math.min(1.0, temp / 80.0));
        g.fill(tx + 3, tyn, tx + 9, ty0 + th, Ui.lerp(0xFF8FB8D8, 0xFFD9604C, temp / 80.0));
        g.fill(tx - 3, tyn, tx + 15, tyn + 2, Ui.INK);
        // the scorch of the milk next to it
        g.fill(tx - 7, ty0, tx - 3, ty0 + th, Ui.TAN);
        int bh = (int) (th * Math.min(1.0, burn));
        if (bh > 0) g.fill(tx - 7, ty0 + th - bh, tx - 3, ty0 + th, Ui.BAD_D);
        Ui.text(g, font, Component.literal((int) temp + "\u00B0"), tx - 2, ty0 + th + 4, scalded ? Ui.BAD_D : Ui.INK);
    }

    private void drawGauges(GuiGraphics g, Font font) {
        int by = ry + rh - 18;
        int bx = rx + 8, bw = 88;
        Ui.text(g, font, Component.translatable("step.aestheticjobs.steam.foam", (int) Math.round(foam * 100)), bx, by - 10, Ui.LABEL);
        Ui.bar(g, bx, by, bw, 7, foam / 0.8, Ui.WARN);
        int tick = bx + (int) (bw * foamTarget / 0.8);
        g.fill(tick, by - 3, tick + 2, by + 10, Ui.GOOD_D);
        int mx = rx + 104;
        Ui.text(g, font, Component.translatable("step.aestheticjobs.steam.micro", (int) Math.round(micro01() * 100)), mx, by - 10, Ui.LABEL);
        Ui.bar(g, mx, by, bw, 7, micro01(), Ui.GOOD);
    }
}
