#!/usr/bin/env python3
"""Writes plain 2D item models (minecraft:item/generated + the 32x32 sprite) for the 8 drinks, 32 desserts, 7 supplies and the
generic coffee_cup. The 3D "voxel" models were dropped: everything in the cafe is drawn with its 2D sprite now.

    python3 tools/flat_item_models.py
"""
import json
import os

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "aestheticjobs")
NAMES = ["cup_espresso", "cup_americano", "cup_latte", "cup_cappuccino", "cup_flat_white", "cup_raf", "cup_mocha", "cup_macchiato",
         "croissant", "donut_pink", "donut_choc", "cupcake_pink", "cupcake_choc", "muffin_blueberry", "cream_puff", "eclair",
         "cinnamon_roll", "cookie_choc", "cookie_heart", "gingerbread_man", "macaron_pink", "macaron_mint", "macaron_lemon", "cake_pop",
         "cheesecake", "cake_strawberry", "cake_choc", "tiramisu", "apple_pie", "medovik", "brownie", "waffle",
         "pancakes", "ice_cream_cone", "sundae", "creme_brulee", "panna_cotta", "flan", "fruit_tart", "baklava",
         "empty_cup", "coffee_beans", "milk_carton", "cream_carton", "syrup_vanilla", "syrup_caramel", "chocolate", "coffee_cup"]

for n in NAMES:
    path = os.path.join(ROOT, "models", "item", n + ".json")
    assert os.path.exists(os.path.join(ROOT, "textures", "item", n + ".png")), "no sprite for " + n
    data = {"parent": "minecraft:item/generated", "textures": {"layer0": "aestheticjobs:item/" + n}}
    if n == "coffee_cup":                                      # keeps the overrides that pick the drink's model (custom_model_data 1..8)
        old = json.load(open(path))
        data["overrides"] = old.get("overrides", [])
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
        f.write("\n")
print("wrote", len(NAMES), "flat item models")

# the dessert plate: one model per dessert (the plate sprite under the dessert sprite), picked by custom_model_data = dessert index + 1
DESSERTS = NAMES[8:40]
overrides = []
for i, n in enumerate(DESSERTS):
    with open(os.path.join(ROOT, "models", "item", "dessert_plate_" + n + ".json"), "w") as f:
        json.dump({"parent": "minecraft:item/generated",
                   "textures": {"layer0": "aestheticjobs:item/dessert_plate", "layer1": "aestheticjobs:item/" + n}}, f, indent=2)
        f.write("\n")
    overrides.append({"predicate": {"custom_model_data": i + 1}, "model": "aestheticjobs:item/dessert_plate_" + n})
with open(os.path.join(ROOT, "models", "item", "dessert_plate.json"), "w") as f:
    json.dump({"parent": "minecraft:item/generated", "textures": {"layer0": "aestheticjobs:item/dessert_plate"}, "overrides": overrides}, f, indent=2)
    f.write("\n")
print("wrote the dessert plate models")
