package dev.aestheticjobs.command;

import com.mojang.brigadier.CommandDispatcher;
import dev.aestheticjobs.cafe.CafeReputation;
import dev.aestheticjobs.cafe.CupData;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.Order;
import dev.aestheticjobs.cafe.ReviewLog;
import java.util.List;
import java.util.Locale;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * /cafe rating - the rating of your cafe: the average of the last reviews the customers left, and the last few reviews.
 */
public final class CafeCommands {
    private static final int SHOWN = 6;

    private CafeCommands() {}

    public static void register(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("cafe")
                .then(Commands.literal("rating").executes(c -> rating(c.getSource(), c.getSource().getPlayerOrException()))));
    }

    private static int rating(CommandSourceStack src, ServerPlayer player) {
        ReviewLog log = CafeReputation.get(src.getServer()).peek(player.getUUID());
        if (log == null || log.reviews().isEmpty()) {
            src.sendSuccess(() -> Component.translatable("cafe.rating.none"), false);
            return 0;
        }
        String avg = String.format(Locale.ROOT, "%.1f", log.average());
        String tip = String.format(Locale.ROOT, "%d", Math.round((log.tipMultiplier() - 1.0) * 100.0));
        src.sendSuccess(() -> Component.translatable("cafe.rating.header", avg, CupData.starText(Math.round((float) log.average())),
                log.total(), (log.tipMultiplier() >= 1.0 ? "+" : "") + tip), false);
        List<ReviewLog.Review> all = log.reviews();
        for (int i = all.size() - 1; i >= Math.max(0, all.size() - SHOWN); i--) {
            ReviewLog.Review r = all.get(i);
            Drink d = Drink.byIndex(r.drink());
            Component who = r.customer() < 0 ? Component.translatable("cafe.rating.fraud")
                    : Component.translatable("customer.aestheticjobs." + Math.floorMod(r.customer(), Order.CUSTOMERS));
            Component what = d == null ? Component.empty() : d.displayName();
            src.sendSuccess(() -> Component.translatable("cafe.rating.line", who, CupData.starText(r.stars()), what), false);
        }
        return 1;
    }
}
