package dev.aestheticjobs.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.entity.CafePerson;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.joml.Quaternionf;

/** Draws a cafe NPC with the player-like model: skin and face (blink / mood) by the entity, the held item in the right hand. */
public class CafePersonRenderer<T extends Mob & CafePerson> extends MobRenderer<T, CafePersonModel<T>> {
    public static final int SKINS = 10;
    private static final ResourceLocation[] TEXTURES = new ResourceLocation[SKINS * 4];

    static {
        for (int s = 0; s < SKINS; s++) {
            for (int f = 0; f < 4; f++) {
                TEXTURES[s * 4 + f] = ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID,
                        "textures/entity/person_" + s + "_" + f + ".png");
            }
        }
    }

    public CafePersonRenderer(EntityRendererProvider.Context context, ModelLayerLocation layer) {
        super(context, new CafePersonModel<T>(context.bakeLayer(layer)), 0.4F);
        addLayer(new HeldItemLayer<T>(this, context.getItemRenderer()));
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        int skin = Math.floorMod(entity.personSkin(), SKINS);
        int face = Math.floorMod(entity.faceIndex(entity.tickCount), 4);
        return TEXTURES[skin * 4 + face];
    }

    @Override
    protected void scale(T entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.9375F, 0.9375F, 0.9375F);          // like the player: 1.8 blocks tall
    }

    /** The item in the right hand (the cup or the plate): at the palm, upright however the arm and the forearm are turned. */
    private static final class HeldItemLayer<T extends Mob & CafePerson> extends RenderLayer<T, CafePersonModel<T>> {
        private final ItemRenderer itemRenderer;

        HeldItemLayer(RenderLayerParent<T, CafePersonModel<T>> parent, ItemRenderer itemRenderer) {
            super(parent);
            this.itemRenderer = itemRenderer;
        }

        @Override
        public void render(PoseStack ps, MultiBufferSource buffer, int packedLight, T entity, float limbSwing,
                           float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
            ItemStack stack = entity.getMainHandItem();
            if (stack.isEmpty()) return;
            CafePersonModel<T> m = getParentModel();
            ps.pushPose();
            m.rightArm.translateAndRotate(ps);
            m.rightForearm.translateAndRotate(ps);
            ps.translate(0.0F, 5.5F / 16.0F, 0.0F);                       // down to the palm
            Quaternionf total = new Quaternionf().rotationZYX(m.rightArm.zRot, m.rightArm.yRot, m.rightArm.xRot)
                    .mul(new Quaternionf().rotationZYX(m.rightForearm.zRot, m.rightForearm.yRot, m.rightForearm.xRot));
            ps.mulPose(total.conjugate());                                // undo the arm tilt: the cup stays upright
            ps.mulPose(Axis.ZP.rotationDegrees(180.0F));                  // the model space is upside down
            ps.translate(0.0F, 0.02F, -0.08F);
            ps.scale(0.6F, 0.6F, 0.6F);
            itemRenderer.renderStatic(stack, ItemDisplayContext.GROUND, packedLight, OverlayTexture.NO_OVERLAY,
                    ps, buffer, entity.level(), entity.getId());
            ps.popPose();
        }
    }
}
