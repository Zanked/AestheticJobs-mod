package dev.aestheticjobs.client;

import dev.aestheticjobs.network.OpenOrderPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

/** Client-only helpers called from common code behind an isClientSide check. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openOrder(OpenOrderPayload payload) {
        Minecraft.getInstance().setScreen(new OrderScreen(payload));
    }

    public static void openCoffeeMachine(BlockPos pos) {
        Minecraft.getInstance().setScreen(new CoffeeMachineScreen(pos));
    }
}
