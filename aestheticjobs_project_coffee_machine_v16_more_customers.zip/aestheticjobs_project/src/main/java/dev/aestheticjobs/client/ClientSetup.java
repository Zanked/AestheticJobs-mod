package dev.aestheticjobs.client;

import dev.aestheticjobs.registry.ModBlockEntities;
import dev.aestheticjobs.registry.ModEntities;
import dev.aestheticjobs.registry.ModMenus;
import dev.aestheticjobs.cafe.CupArtTooltip;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.RegisterClientTooltipComponentFactoriesEvent;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

/** Client-only registrations. Only touched when running on the client. */
public final class ClientSetup {
    private ClientSetup() {}

    public static void registerTooltips(RegisterClientTooltipComponentFactoriesEvent event) {
        event.register(CupArtTooltip.class, ClientCupArtTooltip::new);
    }

    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.CAFE_CUSTOMER.get(), CafeCustomerRenderer::new);
        event.registerEntityRenderer(ModEntities.CAFE_CHEF.get(), CafeStaffRenderer::chef);
        event.registerEntityRenderer(ModEntities.CAFE_BARISTA.get(), CafeStaffRenderer::barista);
        event.registerBlockEntityRenderer(ModBlockEntities.COFFEE_MACHINE.get(), CoffeeMachineRenderer::new);
    }

    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(CafePersonModel.LAYER, () -> CafePersonModel.createLayer(false));
        event.registerLayerDefinition(CafePersonModel.CHEF_LAYER, () -> CafePersonModel.createLayer(true));
    }

    public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(ModMenus.ATM.get(), AtmScreen::new);
    }
}
