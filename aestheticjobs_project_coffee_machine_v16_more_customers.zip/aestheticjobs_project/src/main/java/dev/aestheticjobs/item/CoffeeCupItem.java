package dev.aestheticjobs.item;

import dev.aestheticjobs.cafe.CupArtTooltip;
import dev.aestheticjobs.cafe.CupData;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.Step;
import dev.aestheticjobs.registry.ModComponents;
import java.util.List;
import java.util.Optional;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

/**
 * A finished drink. It looks like the drink (custom_model_data selects the texture), is named after it, and its
 * tooltip shows the picture on the surface and how every step of the recipe went.
 */
public class CoffeeCupItem extends Item {
    public CoffeeCupItem(Item.Properties properties) {
        super(properties);
    }

    private static Drink drinkOf(ItemStack stack) {
        CupData data = stack.get(ModComponents.CUP.get());
        return data == null ? null : Drink.byIndex(data.drink());
    }

    /** A finished drink can be drunk: a short burst of speed. (A barista on shift is fined for it, see CafeFraud.) */
    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.DRINK;
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return 32;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return ItemUtils.startUsingInstantly(level, player, hand);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide) {
            entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 45, 0));
        }
        if (!(entity instanceof Player p) || !p.getAbilities().instabuild) {
            stack.shrink(1);
        }
        return stack;
    }

    @Override
    public Component getName(ItemStack stack) {
        Drink drink = drinkOf(stack);
        return drink != null ? drink.displayName() : super.getName(stack);
    }

    @Override
    public Optional<TooltipComponent> getTooltipImage(ItemStack stack) {
        CupData data = stack.get(ModComponents.CUP.get());
        return data == null ? Optional.empty() : Optional.of(new CupArtTooltip(data.art(), data.drink()));
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        CupData data = stack.get(ModComponents.CUP.get());
        if (data == null) return;
        tooltip.add(Component.literal(CupData.starText(data.stars())).withStyle(ChatFormatting.GOLD)
                .append(Component.literal("  " + data.quality() + "%").withStyle(ChatFormatting.DARK_GRAY)));
        Drink drink = Drink.byIndex(data.drink());
        if (drink == null) return;
        Step[] steps = drink.steps();
        for (int i = 0; i < steps.length && i < data.scores().size(); i++) {
            int s = data.scores().get(i);
            ChatFormatting color = s >= 85 ? ChatFormatting.GREEN : s >= 60 ? ChatFormatting.YELLOW : ChatFormatting.RED;
            tooltip.add(Component.empty().append(steps[i].title().copy().withStyle(ChatFormatting.GRAY))
                    .append(Component.literal("  " + s + "%").withStyle(color)));
        }
    }
}
