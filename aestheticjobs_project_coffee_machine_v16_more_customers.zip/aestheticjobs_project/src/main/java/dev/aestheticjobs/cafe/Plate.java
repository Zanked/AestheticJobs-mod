package dev.aestheticjobs.cafe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;

/**
 * A plate with a dessert on it (item dessert_plate): which dessert (index in item/Dessert) and the game time when it
 * gets cold and is thrown away. A plate is not food: it can only be served to a customer (CafeLogic.serve).
 */
public record Plate(int dessert, long expires) {
    public static final Codec<Plate> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            Codec.INT.fieldOf("dessert").forGetter(Plate::dessert),
            Codec.LONG.fieldOf("expires").forGetter(Plate::expires)
    ).apply(instance, Plate::new));

    public static final StreamCodec<ByteBuf, Plate> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, Plate::dessert,
            ByteBufCodecs.VAR_LONG, Plate::expires,
            Plate::new);

    public boolean fresh(long now) {
        return now < expires;
    }
}
