package dev.aestheticjobs.cafe;

import dev.aestheticjobs.economy.Bank;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.economy.Transaction;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.entity.CafeStaffEntity;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

/** Server-wide events of the cafe: open orders that nobody served are refunded; a barista hands a paid order to the buyer. */
public final class CafeServer {
    private CafeServer() {}

    /** Every 5 seconds: an order that was not served in time, or a ready one that the buyer did not collect, is refunded. */
    public static void onServerTick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        if (server.getTickCount() % 100 != 0) return;
        CafeOrders orders = CafeOrders.get(server);
        if (orders.all().isEmpty()) return;
        long now = server.overworld().getGameTime();
        List<CafeOrders.Entry> expired = new ArrayList<>();
        for (CafeOrders.Entry e : orders.all()) {
            boolean old;
            if (e.status == CafeOrders.READY) {
                old = now - e.readyAt > CafeStaffEntity.READY_LIFE;
            } else if (e.status == CafeOrders.COOKING) {
                old = now - e.created > CafeLogic.ORDER_LIFE_TICKS;
            } else {
                old = now - e.created > (e.status == CafeOrders.CLAIMED ? CafeLogic.ORDER_LIFE_TICKS : 18000L);
            }
            if (old) expired.add(e);
        }
        for (CafeOrders.Entry e : expired) {
            orders.remove(e);
            Bank.deposit(server, e.buyer, e.price, Transaction.Type.REFUND, "cafe");
            ServerPlayer buyer = server.getPlayerList().getPlayer(e.buyer);
            if (buyer != null) {
                buyer.sendSystemMessage(Component.translatable("cafe.order.refunded", Money.format(e.price)));
            }
        }
    }

    /** Right-click on a player with a cup in the main hand: the barista serves the buyer of the order (CafeLogic.servePlayer). */
    public static void onInteractPlayer(PlayerInteractEvent.EntityInteract event) {
        if (event.getHand() != net.minecraft.world.InteractionHand.MAIN_HAND) return;
        if (!(event.getTarget() instanceof Player target)) return;
        Player me = event.getEntity();
        ItemStack held = me.getItemInHand(event.getHand());
        CupData cup = held.get(ModComponents.CUP.get());
        if (cup == null) return;
        ItemStack ticket = CafeLogic.findTicket(me);
        Order order = ticket.isEmpty() ? null : ticket.get(ModComponents.ORDER.get());
        if (order == null || !order.buyer().equals(target.getUUID().toString())) return;
        event.setCancellationResult(InteractionResult.sidedSuccess(me.level().isClientSide));
        event.setCanceled(true);
        if (!me.level().isClientSide && me instanceof ServerPlayer barista && target instanceof ServerPlayer buyer) {
            CafeLogic.servePlayer(barista, buyer, held, cup);
        }
    }
}
