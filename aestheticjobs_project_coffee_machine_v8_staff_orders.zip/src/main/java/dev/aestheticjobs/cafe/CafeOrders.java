package dev.aestheticjobs.cafe;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/**
 * The orders that real players placed at a register (world/data/aestheticjobs_orders.dat). The money was already taken
 * from the buyer's account; if nobody serves the order in time, the money goes back (CafeServer).
 * All times are game ticks of the overworld clock (it is the same in every dimension).
 */
public class CafeOrders extends SavedData {
    public static final String NAME = "aestheticjobs_orders";

    /** Waits for a barista. */
    public static final int PENDING = 0;
    /** A player barista took it (has the ticket and the plate). */
    public static final int CLAIMED = 1;
    /** An NPC barista is making it. */
    public static final int COOKING = 2;
    /** The NPC barista has it ready, the buyer has to come and take it. */
    public static final int READY = 3;

    public static final class Entry {
        public final UUID buyer;
        public final String buyerName;
        public final String dim;
        public final long register;
        public final int drink;
        public final int dessert;
        public final long price;
        public final long created;
        public int status = PENDING;
        @Nullable public UUID worker;
        /** COOKING: when the NPC is done; READY: when it was done. */
        public long readyAt;

        public Entry(UUID buyer, String buyerName, String dim, long register, int drink, int dessert, long price, long created) {
            this.buyer = buyer;
            this.buyerName = buyerName;
            this.dim = dim;
            this.register = register;
            this.drink = drink;
            this.dessert = dessert;
            this.price = price;
            this.created = created;
        }
    }

    private final List<Entry> entries = new ArrayList<>();

    public static CafeOrders get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(factory(), NAME);
    }

    public static SavedData.Factory<CafeOrders> factory() {
        return new SavedData.Factory<>(CafeOrders::new, CafeOrders::load, null);
    }

    public List<Entry> all() {
        return entries;
    }

    public void add(Entry e) {
        entries.add(e);
        setDirty();
    }

    public void remove(Entry e) {
        entries.remove(e);
        setDirty();
    }

    public void changed() {
        setDirty();
    }

    /** The order of this buyer (a buyer has at most one open order). */
    @Nullable
    public Entry ofBuyer(UUID buyer) {
        for (Entry e : entries) if (e.buyer.equals(buyer)) return e;
        return null;
    }

    @Nullable
    public Entry find(UUID buyer, long created) {
        for (Entry e : entries) if (e.buyer.equals(buyer) && e.created == created) return e;
        return null;
    }

    /** The oldest order that waits for a barista near this register (same dimension, within radius blocks). */
    @Nullable
    public Entry nextPending(String dim, BlockPos at, double radius) {
        Entry best = null;
        for (Entry e : entries) {
            if (e.status != PENDING || !e.dim.equals(dim)) continue;
            BlockPos p = BlockPos.of(e.register);
            if (p.distSqr(at) > radius * radius) continue;
            if (best == null || e.created < best.created) best = e;
        }
        return best;
    }

    public static CafeOrders load(CompoundTag tag, HolderLookup.Provider registries) {
        CafeOrders data = new CafeOrders();
        ListTag list = tag.getList("orders", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            Entry e = new Entry(t.getUUID("buyer"), t.getString("name"), t.getString("dim"), t.getLong("reg"),
                    t.getInt("drink"), t.getInt("dessert"), t.getLong("price"), t.getLong("created"));
            e.status = t.getInt("status");
            e.worker = t.hasUUID("worker") ? t.getUUID("worker") : null;
            e.readyAt = t.getLong("readyAt");
            data.entries.add(e);
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        for (Entry e : entries) {
            CompoundTag t = new CompoundTag();
            t.putUUID("buyer", e.buyer);
            t.putString("name", e.buyerName);
            t.putString("dim", e.dim);
            t.putLong("reg", e.register);
            t.putInt("drink", e.drink);
            t.putInt("dessert", e.dessert);
            t.putLong("price", e.price);
            t.putLong("created", e.created);
            t.putInt("status", e.status);
            if (e.worker != null) t.putUUID("worker", e.worker);
            t.putLong("readyAt", e.readyAt);
            list.add(t);
        }
        tag.put("orders", list);
        return tag;
    }
}
