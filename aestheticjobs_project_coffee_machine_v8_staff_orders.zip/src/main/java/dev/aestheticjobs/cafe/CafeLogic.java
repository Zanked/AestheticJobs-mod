package dev.aestheticjobs.cafe;

import dev.aestheticjobs.economy.Bank;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.economy.Transaction;
import dev.aestheticjobs.entity.CafeCustomerEntity;
import dev.aestheticjobs.entity.CafeStaffEntity;
import dev.aestheticjobs.network.OpenOrderPayload;
import dev.aestheticjobs.job.Jobs;
import dev.aestheticjobs.job.Profession;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.job.Shift;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.registry.ModItems;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomModelData;
import net.neoforged.neoforge.network.PacketDistributor;

public final class CafeLogic {
    public static final String CAFE_JOB = "cafe_worker";
    /** The average chance that a customer orders a dessert (every customer has its own, see Personality), and the extra patience / speed-bonus time a dessert gives. */
    public static final float DESSERT_CHANCE = 0.45F;
    public static final long DESSERT_EXTRA_TICKS = 600L;
    /** Staff (chef, NPC barista) work for a register when they stand within this many blocks of it. */
    public static final double STAFF_RADIUS = 16.0D;
    /** A player's order is cancelled and refunded when it is still open after this long (the plate of a claimed order lasts as long). */
    public static final long ORDER_LIFE_TICKS = 36000L;
    /** What a barista earns from a player's order (share of the price; the rest stays in the register, out of the economy). */
    public static final double PLAYER_ORDER_SHARE = 0.6;

    private CafeLogic() {}

    public static int count(Player player, Item item) {
        int n = 0;
        for (ItemStack s : player.getInventory().items) {
            if (s.is(item)) n += s.getCount();
        }
        return n;
    }

    public static boolean takeOne(Player player, Item item) {
        for (ItemStack s : player.getInventory().items) {
            if (s.is(item)) {
                s.shrink(1);
                return true;
            }
        }
        return false;
    }

    public static ItemStack findTicket(Player player) {
        for (ItemStack s : player.getInventory().items) {
            if (s.get(ModComponents.ORDER.get()) != null) return s;
        }
        return ItemStack.EMPTY;
    }

    /** Removes the ticket of an order that was never served (the customer lost patience). */
    public static void voidTicket(ServerPlayer player, long created) {
        for (ItemStack s : player.getInventory().items) {
            Order o = s.get(ModComponents.ORDER.get());
            if (o != null && o.created() == created) {
                s.shrink(1);
                return;
            }
        }
    }

    /** Speed-bonus window of a drink, longer when a dessert has to be fetched too. */
    public static long fastTicks(Drink drink, int dessert) {
        return drink.fastTicks() + (Dessert.byIndex(dessert) != null ? DESSERT_EXTRA_TICKS : 0L);
    }

    /** How long the customer waits in total. */
    public static long okTicks(Drink drink, int dessert) {
        return drink.okTicks() + (Dessert.byIndex(dessert) != null ? DESSERT_EXTRA_TICKS : 0L);
    }

    /** The same windows for a particular customer: a patient one waits longer, a hasty one shorter (see Personality). */
    public static long fastTicks(Drink drink, int dessert, int customer) {
        return Math.round(fastTicks(drink, dessert) * Personality.of(customer).patience());
    }

    public static long okTicks(Drink drink, int dessert, int customer) {
        return Math.round(okTicks(drink, dessert) * Personality.of(customer).patience());
    }

    /** A random drink for this customer: its favourites are ordered much more often than the rest. */
    public static Drink pickDrink(Personality who, RandomSource random) {
        Drink[] all = Drink.values();
        int[] w = new int[all.length];
        for (int i = 0; i < all.length; i++) w[i] = who.drinkWeight(all[i].id());
        return all[Personality.weightedPick(w, random::nextInt)];
    }

    /** Index of a random dessert for this customer and drink: its favourites and the classic pairs of the drink come up more often. */
    public static int pickDessert(Personality who, Drink drink, RandomSource random) {
        Dessert[] all = Dessert.values();
        int[] w = new int[all.length];
        for (int i = 0; i < all.length; i++) w[i] = Pairing.dessertWeight(who, drink.id(), all[i].id());
        return Personality.weightedPick(w, random::nextInt);
    }

    /** A fresh plate of this dessert from the inventory (EMPTY if there is none). */
    public static ItemStack findPlate(Player player, Dessert dessert, long now) {
        for (ItemStack s : player.getInventory().items) {
            Plate plate = s.get(ModComponents.PLATE.get());
            if (plate != null && plate.dessert() == dessert.ordinal() && plate.fresh(now)) return s;
        }
        return ItemStack.EMPTY;
    }

    /** A new plate with a dessert on it. */
    public static ItemStack makePlate(int dessert, long expires) {
        ItemStack plate = new ItemStack(ModItems.DESSERT_PLATE.get());
        plate.set(ModComponents.PLATE.get(), new Plate(dessert, expires));
        plate.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(dessert + 1));
        return plate;
    }

    /** A plate in the inventory with a classic pair of the drink can stand in for the missing ordered dessert (liked ones first). */
    @Nullable
    public static Dessert findSubstitute(Player player, Drink drink, Personality who, long now) {
        Dessert found = null;
        for (Dessert d : Dessert.values()) {
            if (!Pairing.isPair(drink.id(), d.id()) || findPlate(player, d, now).isEmpty()) continue;
            if (who.likesDessert(d.id())) return d;
            if (found == null) found = d;
        }
        return found;
    }

    /** Quality 0..100 from the art score and the espresso shot. */
    public static int quality(int artScore, int extraction) {
        return (int) Math.round(0.7 * artScore + 0.3 * extraction);
    }

    public static boolean isCafeWorker(ServerPlayer player) {
        Optional<Profession> job = Jobs.currentProfession(player.server, player.getUUID());
        return job.isPresent() && job.get().id().getPath().equals(CAFE_JOB);
    }

    /** A barista who is at work now: at the register he takes orders, everybody else orders as a customer. */
    public static boolean isWorking(ServerPlayer player) {
        return isCafeWorker(player) && (!Jobs.REQUIRE_SHIFT_FOR_WORK || Shift.isOnShift(player.server, player.getUUID()));
    }

    /** Somebody who can make a drink for a customer: a barista at work not too far away, or an NPC barista at this register. */
    private static boolean someoneServes(ServerLevel level, BlockPos register) {
        for (ServerPlayer p : level.getServer().getPlayerList().getPlayers()) {
            if (p.level() == level && isWorking(p) && p.blockPosition().distSqr(register) < 64.0D * 64.0D) return true;
        }
        return CafeStaffEntity.baristaNear(level, register) != null;
    }

    // ------------------------------------------------------------------ orders of real players

    /** The customer's menu at the register: the drinks and the desserts the chefs have on their trays right now. */
    public static void openOrderMenu(ServerPlayer player, ServerLevel level, BlockPos register) {
        List<Integer> available = CafeStaffEntity.availableDesserts(level, register);
        PacketDistributor.sendToPlayer(player, new OpenOrderPayload(register, available, Bank.balance(player.server, player.getUUID())));
    }

    /** A player orders at the register: the price goes from his account into the register, a plate is taken from a chef's tray. */
    public static void placeOrder(ServerPlayer buyer, ServerLevel level, BlockPos register, int drinkIdx, int dessertIdx) {
        Drink drink = Drink.byIndex(drinkIdx);
        Dessert dessert = Dessert.byIndex(dessertIdx);
        if (drink == null || (dessertIdx >= 0 && dessert == null)) return;
        CafeOrders orders = CafeOrders.get(buyer.server);
        if (orders.ofBuyer(buyer.getUUID()) != null) {
            buyer.displayClientMessage(Component.translatable("cafe.order.have_order"), true);
            return;
        }
        if (!someoneServes(level, register)) {
            buyer.displayClientMessage(Component.translatable("cafe.order.nobody"), true);
            return;
        }
        long price = drink.priceCents() + (dessert != null ? dessert.priceCents() : 0L);
        if (Bank.balance(buyer.server, buyer.getUUID()) < price) {
            buyer.displayClientMessage(Component.translatable("cafe.order.no_money", Money.format(price)), true);
            return;
        }
        if (dessert != null && !CafeStaffEntity.takePlate(level, register, dessertIdx)) {      // somebody was faster or it went cold
            buyer.displayClientMessage(Component.translatable("cafe.order.no_dessert", dessert.displayName()), true);
            return;
        }
        if (Bank.withdraw(buyer.server, buyer.getUUID(), price, Transaction.Type.PURCHASE, "cafe") != Bank.Result.OK) {
            buyer.displayClientMessage(Component.translatable("cafe.order.no_money", Money.format(price)), true);
            return;
        }
        orders.add(new CafeOrders.Entry(buyer.getUUID(), buyer.getGameProfile().getName(), level.dimension().location().toString(),
                register.asLong(), drinkIdx, dessertIdx, price, level.getGameTime()));
        level.playSound(null, register, SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.BLOCKS, 1.0F, 1.4F);
        Component what = dessert == null ? drink.displayName()
                : Component.empty().append(drink.displayName()).append(" + ").append(dessert.displayName());
        buyer.sendSystemMessage(Component.translatable("cafe.order.placed", what, Money.format(price)));
    }

    /** A barista at the register takes the oldest paid order of a real player, with its plate. Returns false if there is none. */
    private static boolean claimPlayerOrder(ServerPlayer player, ServerLevel level, BlockPos register) {
        CafeOrders orders = CafeOrders.get(player.server);
        CafeOrders.Entry e = orders.nextPending(level.dimension().location().toString(), register, STAFF_RADIUS);
        if (e == null) return false;
        e.status = CafeOrders.CLAIMED;
        e.worker = player.getUUID();
        orders.changed();

        ItemStack ticket = new ItemStack(ModItems.ORDER_TICKET.get());
        ticket.set(ModComponents.ORDER.get(), new Order(e.drink, Math.floorMod(e.buyer.hashCode(), Order.CUSTOMERS), e.created,
                e.dessert, e.buyer.toString(), e.buyerName));
        player.getInventory().placeItemBackInInventory(ticket);
        if (e.dessert >= 0) {
            player.getInventory().placeItemBackInInventory(makePlate(e.dessert, e.created + ORDER_LIFE_TICKS));
        }
        level.playSound(null, register, SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.BLOCKS, 1.0F, 1.2F);
        Drink drink = Drink.byIndex(e.drink);
        Dessert dessert = Dessert.byIndex(e.dessert);
        Component what = dessert == null ? drink.displayName()
                : Component.empty().append(drink.displayName()).append(" + ").append(dessert.displayName());
        player.sendSystemMessage(Component.translatable("cafe.register.player_order", e.buyerName, what));
        return true;
    }

    /** The cup and the dessert of a paid order as the items the buyer takes away: both remember who bought them. */
    public static List<ItemStack> purchaseItems(CafeOrders.Entry e, ItemStack cup) {
        Drink drink = Drink.byIndex(e.drink);
        Dessert dessert = Dessert.byIndex(e.dessert);
        List<ItemStack> out = new java.util.ArrayList<>();
        ItemStack drinkOut = cup.copyWithCount(1);
        drinkOut.set(ModComponents.PURCHASE.get(), new Purchase(e.buyer.toString(), drink == null ? 0L : drink.priceCents()));
        out.add(drinkOut);
        if (dessert != null) {
            ItemStack food = new ItemStack(dessert.item());
            food.set(ModComponents.PURCHASE.get(), new Purchase(e.buyer.toString(), dessert.priceCents()));
            out.add(food);
        }
        return out;
    }

    /** The plain 3-star cup an NPC barista makes (no drawing). */
    public static ItemStack npcCup(Drink drink) {
        ItemStack cup = new ItemStack(ModItems.COFFEE_CUP.get());
        java.util.List<Integer> scores = new java.util.ArrayList<>();
        for (int i = 0; i < drink.steps().length; i++) scores.add(70);
        cup.set(ModComponents.CUP.get(), new CupData("0".repeat(Drink.CELLS), drink.ordinal(), 70, scores));
        cup.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(drink.modelData()));
        return cup;
    }

    /**
     * The barista right-clicks the buyer with the finished cup: the buyer gets the cup and the dessert in his inventory,
     * the barista earns his share. Called from the interaction event (CafeEvents).
     */
    public static void servePlayer(ServerPlayer barista, ServerPlayer buyer, ItemStack cupStack, CupData cup) {
        ServerLevel level = barista.serverLevel();
        Shift.touch(barista);
        ItemStack ticket = findTicket(barista);
        Order order = ticket.isEmpty() ? null : ticket.get(ModComponents.ORDER.get());
        if (order == null || !order.buyer().equals(buyer.getUUID().toString())) {
            barista.displayClientMessage(Component.translatable("cafe.register.not_his", buyer.getDisplayName()), true);
            return;
        }
        CafeOrders orders = CafeOrders.get(barista.server);
        CafeOrders.Entry e = orders.find(buyer.getUUID(), order.created());
        if (e == null || e.status != CafeOrders.CLAIMED || !barista.getUUID().equals(e.worker)) {
            ticket.shrink(1);
            barista.displayClientMessage(Component.translatable("cafe.register.order_gone"), true);
            return;
        }
        Drink wanted = Drink.byIndex(e.drink);
        if (wanted == null || e.drink != cup.drink()) {
            barista.displayClientMessage(Component.translatable("cafe.register.wrong", wanted == null ? Component.empty() : wanted.displayName()), true);
            return;
        }
        Dessert dessert = Dessert.byIndex(e.dessert);
        ItemStack plate = dessert == null ? ItemStack.EMPTY : findPlate(barista, dessert, level.getGameTime());
        if (dessert != null && plate.isEmpty()) {
            barista.displayClientMessage(Component.translatable("cafe.register.need_dessert", dessert.displayName()), true);
            return;
        }
        long pay = Math.round(e.price * PLAYER_ORDER_SHARE);
        if (Bank.deposit(barista.server, barista.getUUID(), pay, Transaction.Type.WAGE, "cafe") != Bank.Result.OK) {
            barista.displayClientMessage(Component.translatable("cafe.register.bank_full"), true);
            return;
        }
        for (ItemStack out : purchaseItems(e, cupStack)) buyer.getInventory().placeItemBackInInventory(out);
        cupStack.shrink(1);
        plate.shrink(1);
        ticket.shrink(1);
        orders.remove(e);

        int stars = cup.stars();
        CafeReputation.get(barista.server).add(barista.getUUID(),
                new ReviewLog.Review(Math.floorMod(e.buyer.hashCode(), Order.CUSTOMERS), stars, e.drink, level.getGameTime()));
        Jobs.XpResult xp = Jobs.addXp(barista.server, barista.getUUID(), 4L + stars * 2L);
        level.playSound(null, buyer.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 0.9F, 1.3F);
        barista.sendSystemMessage(Component.translatable("cafe.register.served_player", buyer.getDisplayName(), CupData.starText(stars), Money.format(pay)));
        buyer.sendSystemMessage(Component.translatable("cafe.order.received", barista.getDisplayName()));
        if (xp.employed() && xp.newRank() > xp.oldRank() && xp.profession() != null) {
            barista.sendSystemMessage(Component.translatable("cafe.rank_up", xp.profession().rankName(xp.newRank())));
        }
    }

    /**
     * A barista takes an order. From the register a customer NPC is spawned (if there is room) and walks up;
     * from a spawn-egg customer (npc != null) that very customer orders. Without room the order is just a ticket.
     */
    public static void issueOrder(ServerPlayer player, ServerLevel level, BlockPos soundPos,
                                  @Nullable BlockPos registerPos, @Nullable Direction registerFacing,
                                  @Nullable CafeCustomerEntity npc) {
        if (!isCafeWorker(player)) {
            player.displayClientMessage(Component.translatable("cafe.register.need_job"), true);
            return;
        }
        if (Jobs.REQUIRE_SHIFT_FOR_WORK && !Shift.isOnShift(player.server, player.getUUID())) {
            player.displayClientMessage(Component.translatable("cafe.register.need_shift"), true);
            return;
        }
        if (!findTicket(player).isEmpty()) {
            player.displayClientMessage(Component.translatable("cafe.register.have_ticket"), true);
            return;
        }
        Shift.touch(player);
        if (npc == null && registerPos != null && claimPlayerOrder(player, level, registerPos)) {
            return;                                                           // a customer who already paid comes first
        }
        int customer = npc != null ? Math.floorMod(npc.getVariant(), Order.CUSTOMERS) : level.random.nextInt(Order.CUSTOMERS);
        Personality person = Personality.of(customer);                        // the order depends on who is asking
        Drink drink = pickDrink(person, level.random);
        int dessert = level.random.nextFloat() < person.dessertChance() ? pickDessert(person, drink, level.random) : -1;
        long now = level.getGameTime();

        if (npc != null) {
            npc.beginOrder(player.getUUID(), drink.ordinal(), dessert, now, null, null, false);
        } else if (registerPos != null && registerFacing != null) {
            CafeCustomerEntity.spawnFor(level, registerPos, registerFacing, player.getUUID(), customer, drink.ordinal(), dessert, now);
        }

        ItemStack ticket = new ItemStack(ModItems.ORDER_TICKET.get());
        ticket.set(ModComponents.ORDER.get(), new Order(drink.ordinal(), customer, now, dessert));
        player.getInventory().placeItemBackInInventory(ticket);
        level.playSound(null, soundPos, SoundEvents.NOTE_BLOCK_BELL.value(), SoundSource.BLOCKS, 1.0F, 1.2F);
        Component who = Component.translatable("customer.aestheticjobs." + customer);
        Dessert extra = Dessert.byIndex(dessert);
        if (extra != null) {
            player.sendSystemMessage(Component.translatable("cafe.register.new_order_dessert", who, drink.displayName(), extra.displayName()));
        } else {
            player.sendSystemMessage(Component.translatable("cafe.register.new_order", who, drink.displayName()));
        }
    }

    /**
     * Hands a finished cup over: checks the ticket, pays (commission + tips), gives xp.
     * If the customer NPC is there, it takes the cup and shows the drawing (see CafeCustomerEntity).
     */
    public static void serve(ServerPlayer player, ServerLevel level, BlockPos pos, ItemStack cupStack, CupData cup,
                             @Nullable CafeCustomerEntity npc) {
        Shift.touch(player);
        ItemStack ticket = findTicket(player);
        if (ticket.isEmpty()) {
            player.displayClientMessage(Component.translatable("cafe.register.no_order"), true);
            return;
        }
        Order order = ticket.get(ModComponents.ORDER.get());
        if (order.isPlayerOrder()) {                                          // a paying player gets the cup from the barista's hands
            player.displayClientMessage(Component.translatable("cafe.register.hand_to_player", order.buyerName()), true);
            return;
        }
        Drink wanted = Drink.byIndex(order.drink());
        if (wanted == null || order.drink() != cup.drink()) {
            Component name = wanted == null ? Component.empty() : wanted.displayName();
            player.displayClientMessage(Component.translatable("cafe.register.wrong", name), true);
            if (npc != null) npc.say(Personality.Say.WRONG);
            return;
        }

        Personality who = Personality.of(order.customer());
        Dessert ordered = Dessert.byIndex(order.dessert());
        Dessert dessert = ordered;                                            // the dessert that is really served
        boolean substituted = false;
        long now = level.getGameTime();
        if (ordered != null && findPlate(player, ordered, now).isEmpty()) {   // the barista hands the plate over from the inventory (from the chef)
            Dessert stand = findSubstitute(player, wanted, who, now);         // a plate with a classic pair of the drink can stand in for it
            if (stand == null) {
                player.displayClientMessage(Component.translatable("cafe.register.need_dessert", ordered.displayName()), true);
                if (npc != null) npc.say(Personality.Say.WRONG);
                return;
            }
            if (!who.acceptsSubstitute()) {                                   // picky and grumpy customers want exactly what they ordered
                player.displayClientMessage(Component.translatable("cafe.register.no_substitute", ordered.displayName()), true);
                if (npc != null) npc.say(Personality.Say.WRONG);
                return;
            }
            dessert = stand;
            substituted = true;
        }
        boolean pair = dessert != null && Pairing.isPair(wanted.id(), dessert.id());
        boolean favourite = who.likesDrink(wanted.id());
        long elapsed = level.getGameTime() - order.created();
        long fast = fastTicks(wanted, order.dessert(), order.customer());
        long ok = okTicks(wanted, order.dessert(), order.customer());
        double speed = elapsed <= fast ? 0.15 : elapsed <= ok ? 0.05 : 0.0;
        int stars = cup.stars();
        long price = wanted.priceCents() + (dessert != null ? dessert.priceCents() : 0L);
        long base = Math.round(price * 0.6);
        // the tip: quality and speed as before, then the generosity of this customer, the cafe's reputation and a favourite drink
        double reputation = CafeReputation.get(player.server).tipMultiplier(player.getUUID());
        long tip = Math.round(price * (stars * 0.05 + speed) * who.tip() * reputation * (favourite ? 1.1 : 1.0) * (pair ? 1.1 : 1.0));
        tip = Math.min(tip, Math.round(price * 0.6));                          // never more than 1.2x the price in total
        long total = base + tip;

        Bank.Result paid = Bank.deposit(player.server, player.getUUID(), total, Transaction.Type.WAGE, "cafe");
        if (paid != Bank.Result.OK) {
            player.displayClientMessage(Component.translatable("cafe.register.bank_full"), true);
            return;
        }
        cupStack.shrink(1);
        if (dessert != null) findPlate(player, dessert, now).shrink(1);
        ticket.shrink(1);

        // the review: what this particular customer thinks of the cup (counts towards the cafe's rating, /cafe rating)
        int reaction = who.reaction(stars, favourite, elapsed > fast);
        if (pair && stars >= 3) reaction++;                                   // a good pair made the day
        if (substituted && !who.likesDessert(dessert.id())) reaction--;       // "this is not what I wanted"
        reaction = Math.max(1, Math.min(5, reaction));
        CafeReputation.get(player.server).add(player.getUUID(),
                new ReviewLog.Review(Math.floorMod(order.customer(), Order.CUSTOMERS), reaction, order.drink(), level.getGameTime()));

        Jobs.XpResult xp = Jobs.addXp(player.server, player.getUUID(), 4L + stars * 2L);
        if (npc != null) {
            npc.receiveCup(player, cup, reaction);
        } else {
            level.playSound(null, pos, SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.BLOCKS, 0.9F, 1.3F);
            level.sendParticles(ParticleTypes.HEART, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 4, 0.25, 0.1, 0.25, 0.0);
        }
        player.sendSystemMessage(Component.translatable("cafe.register.paid",
                Component.translatable("customer.aestheticjobs." + Math.floorMod(order.customer(), Order.CUSTOMERS)),
                CupData.starText(stars), Money.format(total), Money.format(tip)));
        if (substituted) {
            player.sendSystemMessage(Component.translatable("cafe.register.substituted", dessert.displayName(), ordered.displayName()));
        } else if (pair) {
            player.sendSystemMessage(Component.translatable("cafe.register.pairing", wanted.displayName(), dessert.displayName()));
        }
        if (xp.employed() && xp.newRank() > xp.oldRank() && xp.profession() != null) {
            player.sendSystemMessage(Component.translatable("cafe.rank_up", xp.profession().rankName(xp.newRank())));
        }
    }
}
