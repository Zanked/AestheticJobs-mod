package dev.aestheticjobs.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.entity.CafeStaffEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** The same little chibi body as the customers (CafeCustomerModel.createBodyLayer), with a calm idle animation. */
public class CafeStaffModel extends EntityModel<CafeStaffEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "cafe_staff"), "main");

    private static final float DEG = (float) (Math.PI / 180.0);

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart rightArm;
    private final ModelPart leftArm;
    private final ModelPart rightLeg;
    private final ModelPart leftLeg;

    public CafeStaffModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
        this.rightLeg = root.getChild("right_leg");
        this.leftLeg = root.getChild("left_leg");
    }

    public static LayerDefinition createBodyLayer() {
        return CafeCustomerModel.createBodyLayer();
    }

    @Override
    public void setupAnim(CafeStaffEntity e, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        head.xRot = headPitch * DEG;
        head.yRot = netHeadYaw * DEG;
        float sway = Mth.cos(ageInTicks * 0.09F) * 0.04F;
        rightArm.xRot = 0.0F;
        leftArm.xRot = 0.0F;
        rightArm.zRot = 0.06F + sway;
        leftArm.zRot = -0.06F - sway;
        rightLeg.xRot = 0.0F;
        leftLeg.xRot = 0.0F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, int color) {
        root.render(poseStack, buffer, packedLight, packedOverlay, color);
    }
}
