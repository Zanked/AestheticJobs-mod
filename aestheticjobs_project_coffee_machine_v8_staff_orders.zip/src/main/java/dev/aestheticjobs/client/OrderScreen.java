package dev.aestheticjobs.client;

import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.client.barista.Ui;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.network.OpenOrderPayload;
import dev.aestheticjobs.network.PlaceOrderPayload;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The customer's menu of a register: pick a drink, optionally one of the desserts the chefs have ready, and pay from the
 * bank account. A barista then makes it (or the NPC barista) and the order is handed over / collected.
 */
public class OrderScreen extends Screen {
    private static final int W = 300, H = 248;

    private final BlockPos pos;
    private final List<Integer> desserts;
    private final long balance;
    private int drink = -1;
    private int dessert = -1;
    private int left, top;

    public OrderScreen(OpenOrderPayload p) {
        super(Component.translatable("gui.aestheticjobs.order.title"));
        this.pos = p.pos();
        this.desserts = p.desserts();
        this.balance = p.balance();
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private int drinkX(int i) { return left + 12 + (i % 4) * 71; }
    private int drinkY(int i) { return top + 38 + (i / 4) * 52; }
    private int dessX(int k) { return left + 12 + (k % 8) * 34; }
    private int dessY(int k) { return top + 158 + (k / 8) * 30; }
    private int buyX() { return left + W - 100; }
    private int buyY() { return top + H - 28; }

    private long total() {
        Drink d = Drink.byIndex(drink);
        Dessert s = Dessert.byIndex(dessert);
        return (d == null ? 0L : d.priceCents()) + (s == null ? 0L : s.priceCents());
    }

    private boolean canBuy() {
        return drink >= 0 && total() <= balance;
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        renderBackground(g, mx, my, partial);
        Ui.box(g, left - 3, top - 3, W + 6, H + 6, Ui.BORDER, Ui.BORDER);
        Ui.box(g, left, top, W, H, Ui.KHAKI, Ui.BG);
        g.renderOutline(left + 3, top + 3, W - 6, H - 6, 0x66FFFFFF);

        Ui.text(g, font, Component.translatable("gui.aestheticjobs.order.title"), left + 12, top + 10, Ui.INK);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.order.balance", Money.format(balance)), left + 12, top + 22, Ui.LABEL);

        Drink[] all = Drink.values();
        Component tip = null;
        for (int i = 0; i < all.length; i++) {
            int x = drinkX(i), y = drinkY(i);
            boolean hov = Ui.in(mx, my, x, y, 68, 50);
            boolean sel = i == drink;
            Ui.box(g, x, y, 68, 50, sel ? Ui.GOOD_D : Ui.KHAKI, sel ? 0xFFF2F8EC : hov ? 0xFFFFFBEE : Ui.INNER);
            Ui.icon(g, all[i].iconTexture(), x + 18, y + 1, 32);
            Ui.centered(g, font, all[i].displayName(), x + 34, y + 33, Ui.INK);
            Ui.centered(g, font, Component.literal(Money.format(all[i].priceCents())), x + 34, y + 41, Ui.LABEL);
        }

        Ui.text(g, font, Component.translatable("gui.aestheticjobs.order.dessert"), left + 12, top + 146, Ui.LABEL);
        if (desserts.isEmpty()) {
            Ui.text(g, font, Component.translatable("gui.aestheticjobs.order.no_desserts"), left + 12, top + 158, Ui.LABEL);
        }
        for (int k = 0; k < desserts.size(); k++) {
            Dessert d = Dessert.byIndex(desserts.get(k));
            if (d == null) continue;
            int x = dessX(k), y = dessY(k);
            boolean hov = Ui.in(mx, my, x, y, 32, 28);
            boolean sel = desserts.get(k) == dessert;
            Ui.box(g, x, y, 32, 28, sel ? Ui.GOOD_D : Ui.KHAKI, sel ? 0xFFF2F8EC : hov ? 0xFFFFFBEE : Ui.INNER);
            Ui.icon(g, d.iconTexture(), x + 4, y + 2, 24);
            if (hov) tip = Component.empty().append(d.displayName()).append("  " + Money.format(d.priceCents()));
        }

        long total = total();
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.order.total", Money.format(total)), left + 12, buyY() + 2, Ui.INK);
        if (drink >= 0 && total > balance) {
            Ui.text(g, font, Component.translatable("gui.aestheticjobs.order.too_expensive"), left + 12, buyY() + 12, 0xFFB5543A);
        }
        Ui.button(g, font, buyX(), buyY(), 88, 22, Component.translatable("gui.aestheticjobs.order.buy"),
                Ui.in(mx, my, buyX(), buyY(), 88, 22), canBuy(), 1);
        if (tip != null) g.renderTooltip(font, tip, mx, my);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        Drink[] all = Drink.values();
        for (int i = 0; i < all.length; i++) {
            if (Ui.in(mx, my, drinkX(i), drinkY(i), 68, 50)) {
                drink = i;
                return true;
            }
        }
        for (int k = 0; k < desserts.size(); k++) {
            if (Ui.in(mx, my, dessX(k), dessY(k), 32, 28)) {
                dessert = desserts.get(k) == dessert ? -1 : desserts.get(k);       // click again: no dessert
                return true;
            }
        }
        if (Ui.in(mx, my, buyX(), buyY(), 88, 22) && canBuy()) {
            PacketDistributor.sendToServer(new PlaceOrderPayload(pos, drink, dessert));
            onClose();
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }
}
