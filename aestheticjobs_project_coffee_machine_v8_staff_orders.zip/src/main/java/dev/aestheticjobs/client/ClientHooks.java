package dev.aestheticjobs.client;

import dev.aestheticjobs.network.OpenChefPayload;
import dev.aestheticjobs.network.OpenOrderPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;

/** Client-only helpers called from common code behind an isClientSide check. */
public final class ClientHooks {
    private ClientHooks() {}

    /** The chef menu: refreshes the open one (after a click) or opens a new one. */
    public static void openChef(OpenChefPayload payload) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof ChefScreen open && open.entity() == payload.entity()) {
            open.update(payload);
        } else {
            mc.setScreen(new ChefScreen(payload));
        }
    }

    public static void openOrder(OpenOrderPayload payload) {
        Minecraft.getInstance().setScreen(new OrderScreen(payload));
    }

    public static void openCoffeeMachine(BlockPos pos) {
        Minecraft.getInstance().setScreen(new CoffeeMachineScreen(pos));
    }
}
