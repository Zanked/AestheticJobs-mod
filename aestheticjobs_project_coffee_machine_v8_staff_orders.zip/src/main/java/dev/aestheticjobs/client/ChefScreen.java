package dev.aestheticjobs.client;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.client.barista.Ui;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.entity.CafeStaffEntity;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.network.ChefActionPayload;
import dev.aestheticjobs.network.OpenChefPayload;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The menu of a pastry chef: the tray with the plates that are ready (click = take it) and the list of all desserts
 * (click = the chef bakes this one from now on). The state comes from the server after every click.
 */
public class ChefScreen extends Screen {
    private static final int W = 292, H = 240;
    private static final ResourceLocation PLATE =
            ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "textures/item/dessert_plate.png");

    private int entity;
    private int selected;
    private List<Integer> plates = new ArrayList<>();
    private List<Integer> seconds = new ArrayList<>();
    private int bakePercent;
    private boolean furnace;
    private int left, top;

    public ChefScreen(OpenChefPayload p) {
        super(Component.translatable("staff.chef.title"));
        update(p);
    }

    public int entity() {
        return entity;
    }

    public void update(OpenChefPayload p) {
        entity = p.entity();
        selected = p.selected();
        plates = new ArrayList<>(p.plates());
        seconds = new ArrayList<>(p.seconds());
        bakePercent = p.bakePercent();
        furnace = p.furnace();
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private int trayX(int i) { return left + 12 + i * 42; }
    private int trayY() { return top + 44; }
    private int cellX(int i) { return left + 12 + (i % 8) * 34; }
    private int cellY(int i) { return top + 110 + (i / 8) * 30; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        renderBackground(g, mx, my, partial);
        Ui.box(g, left - 3, top - 3, W + 6, H + 6, Ui.BORDER, Ui.BORDER);
        Ui.box(g, left, top, W, H, Ui.KHAKI, Ui.BG);
        g.renderOutline(left + 3, top + 3, W - 6, H - 6, 0x66FFFFFF);

        Ui.text(g, font, Component.translatable("staff.chef.title"), left + 12, top + 10, Ui.INK);
        Ui.text(g, font, Component.translatable(furnace ? "staff.chef.hint" : "staff.chef.need_furnace"), left + 12, top + 22,
                furnace ? Ui.LABEL : 0xFFB5543A);

        // the tray
        Ui.text(g, font, Component.translatable("staff.chef.tray", plates.size(), CafeStaffEntity.TRAY), left + 12, top + 34, Ui.LABEL);
        Component tip = null;
        for (int i = 0; i < CafeStaffEntity.TRAY; i++) {
            int x = trayX(i), y = trayY();
            boolean has = i < plates.size();
            boolean hov = has && Ui.in(mx, my, x, y, 38, 44);
            Ui.box(g, x, y, 38, 44, has ? Ui.GOOD_D : Ui.KHAKI, hov ? 0xFFFFFBEE : Ui.INNER);
            if (has) {
                Dessert d = Dessert.byIndex(plates.get(i));
                Ui.icon(g, PLATE, x + 3, y + 2, 32);
                if (d != null) Ui.icon(g, d.iconTexture(), x + 3, y + 2, 32);
                Ui.centered(g, font, Component.literal(seconds.get(i) + "s"), x + 19, y + 35, Ui.LABEL);
                if (hov && d != null) tip = Component.translatable("staff.chef.take", d.displayName());
            }
        }
        // progress of the next plate
        Dessert baking = Dessert.byIndex(selected);
        int bx = trayX(CafeStaffEntity.TRAY) + 6;
        if (baking != null) {
            Ui.text(g, font, Component.translatable("staff.chef.baking_now", baking.displayName()), bx, trayY() + 6, Ui.INK);
            if (plates.size() >= CafeStaffEntity.TRAY) {
                Ui.text(g, font, Component.translatable("staff.chef.tray_full"), bx, trayY() + 20, Ui.LABEL);
            } else {
                Ui.bar(g, bx, trayY() + 20, 120, 8, bakePercent / 100.0, Ui.GOOD_D);
            }
        } else {
            Ui.text(g, font, Component.translatable("staff.chef.choose"), bx, trayY() + 6, Ui.LABEL);
        }

        // the list of desserts
        Ui.text(g, font, Component.translatable("staff.chef.menu"), left + 12, top + 98, Ui.LABEL);
        Dessert[] all = Dessert.values();
        for (int i = 0; i < all.length; i++) {
            int x = cellX(i), y = cellY(i);
            boolean hov = Ui.in(mx, my, x, y, 32, 28);
            boolean sel = i == selected;
            Ui.box(g, x, y, 32, 28, sel ? Ui.GOOD_D : Ui.KHAKI, sel ? 0xFFF2F8EC : hov ? 0xFFFFFBEE : Ui.INNER);
            Ui.icon(g, all[i].iconTexture(), x + 4, y + 2, 24);
            if (hov) tip = Component.empty().append(all[i].displayName()).append("  " + Money.format(all[i].priceCents()));
        }
        if (tip != null) g.renderTooltip(font, tip, mx, my);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (int i = 0; i < plates.size(); i++) {
            if (Ui.in(mx, my, trayX(i), trayY(), 38, 44)) {
                PacketDistributor.sendToServer(new ChefActionPayload(entity, 1, i));
                return true;
            }
        }
        Dessert[] all = Dessert.values();
        for (int i = 0; i < all.length; i++) {
            if (Ui.in(mx, my, cellX(i), cellY(i), 32, 28)) {
                PacketDistributor.sendToServer(new ChefActionPayload(entity, 0, i));
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }
}
