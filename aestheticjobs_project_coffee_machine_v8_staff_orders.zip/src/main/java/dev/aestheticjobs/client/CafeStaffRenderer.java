package dev.aestheticjobs.client;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.entity.CafeStaffEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Draws the pastry chef and the NPC barista. What they are doing is written in their name tag (server side). */
public class CafeStaffRenderer extends MobRenderer<CafeStaffEntity, CafeStaffModel> {
    private static final ResourceLocation CHEF =
            ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "textures/entity/staff_chef.png");
    private static final ResourceLocation BARISTA =
            ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "textures/entity/staff_barista.png");

    public CafeStaffRenderer(EntityRendererProvider.Context context) {
        super(context, new CafeStaffModel(context.bakeLayer(CafeStaffModel.LAYER)), 0.3F);
    }

    @Override
    public ResourceLocation getTextureLocation(CafeStaffEntity entity) {
        return entity.role() == CafeStaffEntity.Role.CHEF ? CHEF : BARISTA;
    }
}
