package dev.aestheticjobs.entity;

import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.CafeOrders;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.Pairing;
import dev.aestheticjobs.cafe.Personality;
import dev.aestheticjobs.cafe.Plate;
import dev.aestheticjobs.cafe.Order;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.network.OpenChefPayload;
import dev.aestheticjobs.registry.ModBlocks;
import dev.aestheticjobs.registry.ModItems;
import dev.aestheticjobs.registry.ModSounds;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.AbstractFurnaceBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The staff of the cafe, two roles (two entity types, the same class):
 *
 * CHEF: a pastry chef. Nothing is given to him and he is not paid. Right-click: a menu of all desserts; the chosen one
 * is baked again and again in a regular furnace next to him (the furnace lights up while he bakes) onto a tray of
 * {@link #TRAY} plates, every plate goes cold after {@link #PLATE_LIFE} ticks. A barista takes the plates from the tray.
 *
 * BARISTA: an NPC barista. He serves the NPC customers (nobody gets any money for it: it is not printed) and the paid
 * orders of real players when no player barista takes them. The buyer collects the order from him by right-click.
 */
public class CafeStaffEntity extends PathfinderMob {
    public enum Role { CHEF, BARISTA }

    public static final int TRAY = 3;
    public static final long PLATE_LIFE = 6000L;          // 5 minutes
    public static final int BAKE_TICKS = 600;             // 30 seconds a plate
    public static final int MAX_CHEFS = 4;
    public static final int MAX_BARISTAS = 2;
    /** The NPC barista makes a paid order of a player in this time (a player barista is faster). */
    public static final long COOK_TICKS = 600L;
    /** A paid order waits this long for a player barista before the NPC barista takes it (when nobody takes it earlier). */
    public static final long NPC_TAKES_AFTER = 800L;
    /** A ready order is kept this long for the buyer. */
    public static final long READY_LIFE = 6000L;
    private static final long CUSTOMER_WORK_TICKS = 800L;

    private final Role role;

    // ---- chef ----
    private final List<Plate> tray = new ArrayList<>();
    private int selected = -1;
    private int bake;
    @Nullable private BlockPos furnace;
    @Nullable private BlockPos lit;

    // ---- barista ----
    @Nullable private BlockPos register;
    @Nullable private UUID customer;
    private long customerWorkUntil;
    private int customerCooldown = 600;

    private boolean limitChecked;
    private String shownName = "";

    public CafeStaffEntity(EntityType<? extends CafeStaffEntity> type, Level level, Role role) {
        super(type, level);
        this.role = role;
        setInvulnerable(true);
        setPersistenceRequired();
        setCustomNameVisible(true);
    }

    public Role role() {
        return role;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6.0F));
        goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    // ------------------------------------------------------------------ helpers for the register (chefs and baristas near it)

    private static List<CafeStaffEntity> staffNear(ServerLevel level, BlockPos at, Role role) {
        double r = CafeLogic.STAFF_RADIUS;
        return level.getEntitiesOfClass(CafeStaffEntity.class, new AABB(at).inflate(r), e -> e.role == role && e.isAlive());
    }

    /** The desserts that lie on the trays of the chefs near the register (without repeats). */
    public static List<Integer> availableDesserts(ServerLevel level, BlockPos register) {
        long now = level.getGameTime();
        Set<Integer> set = new LinkedHashSet<>();
        for (CafeStaffEntity chef : staffNear(level, register, Role.CHEF)) {
            for (Plate p : chef.tray) if (p.fresh(now)) set.add(p.dessert());
        }
        return new ArrayList<>(set);
    }

    /** Takes one plate of this dessert off a tray near the register. False if there is none. */
    public static boolean takePlate(ServerLevel level, BlockPos register, int dessert) {
        long now = level.getGameTime();
        for (CafeStaffEntity chef : staffNear(level, register, Role.CHEF)) {
            for (int i = 0; i < chef.tray.size(); i++) {
                Plate p = chef.tray.get(i);
                if (p.dessert() == dessert && p.fresh(now)) {
                    chef.tray.remove(i);
                    return true;
                }
            }
        }
        return false;
    }

    @Nullable
    public static CafeStaffEntity baristaNear(ServerLevel level, BlockPos register) {
        List<CafeStaffEntity> list = staffNear(level, register, Role.BARISTA);
        return list.isEmpty() ? null : list.get(0);
    }

    // ------------------------------------------------------------------ chef: the menu

    public int selected() {
        return selected;
    }

    public List<Plate> tray() {
        return tray;
    }

    public void sendMenu(ServerPlayer player) {
        long now = level().getGameTime();
        List<Integer> dessert = new ArrayList<>();
        List<Integer> seconds = new ArrayList<>();
        for (Plate p : tray) {
            dessert.add(p.dessert());
            seconds.add((int) Math.max(0L, (p.expires() - now) / 20L));
        }
        findFurnace();
        PacketDistributor.sendToPlayer(player, new OpenChefPayload(getId(), selected, dessert, seconds,
                bake * 100 / BAKE_TICKS, furnace != null));
    }

    public void select(int dessert) {
        selected = Dessert.byIndex(dessert) == null ? -1 : dessert;
        bake = 0;
    }

    /** A player takes the plate in this tray slot. */
    public void giveTo(ServerPlayer player, int slot) {
        if (slot < 0 || slot >= tray.size()) return;
        Plate p = tray.get(slot);
        if (!p.fresh(level().getGameTime())) return;
        tray.remove(slot);
        player.getInventory().placeItemBackInInventory(CafeLogic.makePlate(p.dessert(), p.expires()));
        level().playSound(null, blockPosition(), SoundEvents.ITEM_PICKUP, SoundSource.NEUTRAL, 0.6F, 1.2F);
    }

    // ------------------------------------------------------------------ interaction

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.PASS;
        if (!level().isClientSide && player instanceof ServerPlayer sp) {
            if (role == Role.CHEF) {
                sendMenu(sp);
            } else {
                baristaInteract(sp);
            }
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    private void baristaInteract(ServerPlayer player) {
        CafeOrders orders = CafeOrders.get(player.server);
        CafeOrders.Entry e = orders.ofBuyer(player.getUUID());
        if (e == null) {
            player.displayClientMessage(Component.translatable("staff.barista.hint"), true);
            return;
        }
        if (e.status != CafeOrders.READY) {
            player.displayClientMessage(Component.translatable("staff.barista.not_ready"), true);
            return;
        }
        Drink drink = Drink.byIndex(e.drink);
        if (drink == null) {
            orders.remove(e);
            return;
        }
        for (ItemStack out : CafeLogic.purchaseItems(e, CafeLogic.npcCup(drink))) {
            player.getInventory().placeItemBackInInventory(out);
        }
        orders.remove(e);
        level().playSound(null, blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.NEUTRAL, 0.9F, 1.3F);
        player.sendSystemMessage(Component.translatable("cafe.order.received", getDisplayName()));
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (!limitChecked && tickCount > 2) {
            limitChecked = true;
            if (overLimit()) return;
        }
        if (role == Role.CHEF) {
            tickChef();
        } else {
            tickBarista();
        }
        if (tickCount % 20 == 0) refreshName();
    }

    /** Too many staff of this role around: the newest one is taken back as a spawn egg. */
    private boolean overLimit() {
        ServerLevel sl = (ServerLevel) level();
        int limit = role == Role.CHEF ? MAX_CHEFS : MAX_BARISTAS;
        int older = 0;
        for (CafeStaffEntity e : sl.getEntitiesOfClass(CafeStaffEntity.class, getBoundingBox().inflate(CafeLogic.STAFF_RADIUS),
                x -> x != this && x.role == role && x.tickCount > tickCount)) {
            older++;
        }
        if (older < limit) return false;
        ItemStack egg = new ItemStack(role == Role.CHEF ? ModItems.CAFE_CHEF_SPAWN_EGG.get() : ModItems.CAFE_BARISTA_SPAWN_EGG.get());
        spawnAtLocation(egg);
        Player p = sl.getNearestPlayer(this, 8.0D);
        if (p != null) {
            p.displayClientMessage(Component.translatable("staff.limit", limit), true);
        }
        discard();
        return true;
    }

    private void refreshName() {
        Component name;
        if (role == Role.CHEF) {
            Dessert d = Dessert.byIndex(selected);
            if (furnace == null && d != null) {
                name = Component.translatable("staff.chef.no_furnace");
            } else if (d == null) {
                name = Component.translatable("staff.chef.idle");
            } else if (tray.size() >= TRAY) {
                name = Component.translatable("staff.chef.full", d.displayName());
            } else {
                name = Component.translatable("staff.chef.baking", d.displayName(), bake * 100 / BAKE_TICKS);
            }
        } else {
            name = Component.translatable("staff.barista.name");
        }
        String key = name.getString();
        if (!key.equals(shownName)) {
            shownName = key;
            setCustomName(name);
        }
    }

    // ---- chef ----

    private void findFurnace() {
        if (furnace != null && level().getBlockState(furnace).is(Blocks.FURNACE)) return;
        furnace = null;
        BlockPos c = blockPosition();
        double best = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-4, -2, -4), c.offset(4, 2, 4))) {
            if (!level().getBlockState(p).is(Blocks.FURNACE)) continue;
            double d = p.distSqr(c);
            if (d < best) {
                best = d;
                furnace = p.immutable();
            }
        }
    }

    private void light(boolean on) {
        if (on) {
            if (furnace == null) return;
            BlockState st = level().getBlockState(furnace);
            if (st.is(Blocks.FURNACE) && !st.getValue(AbstractFurnaceBlock.LIT)) {
                level().setBlock(furnace, st.setValue(AbstractFurnaceBlock.LIT, true), 3);
            }
            lit = furnace;
        } else if (lit != null) {
            BlockState st = level().getBlockState(lit);
            if (st.is(Blocks.FURNACE) && st.getValue(AbstractFurnaceBlock.LIT)) {
                level().setBlock(lit, st.setValue(AbstractFurnaceBlock.LIT, false), 3);
            }
            lit = null;
        }
    }

    private void tickChef() {
        ServerLevel sl = (ServerLevel) level();
        long now = sl.getGameTime();
        tray.removeIf(p -> !p.fresh(now));
        if (tickCount % 40 == 1) findFurnace();

        Dessert d = Dessert.byIndex(selected);
        boolean baking = d != null && tray.size() < TRAY && furnace != null;
        if (!baking) {
            if (lit != null) light(false);
            return;
        }
        if (lit == null || !lit.equals(furnace)) {
            light(false);
            light(true);
        }
        bake++;
        if (bake % 30 == 0) {
            sl.sendParticles(ParticleTypes.SMOKE, furnace.getX() + 0.5D, furnace.getY() + 1.1D, furnace.getZ() + 0.5D, 2, 0.15D, 0.05D, 0.15D, 0.01D);
        }
        if (bake >= BAKE_TICKS) {
            bake = 0;
            tray.add(new Plate(selected, now + PLATE_LIFE));
            sl.playSound(null, blockPosition(), SoundEvents.NOTE_BLOCK_CHIME.value(), SoundSource.NEUTRAL, 0.8F, 1.5F);
            sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, getX(), getY() + 1.4D, getZ(), 4, 0.25D, 0.2D, 0.25D, 0.0D);
        }
    }

    @Override
    public void remove(RemovalReason reason) {
        if (!level().isClientSide && lit != null) light(false);       // do not leave a furnace burning for nothing
        super.remove(reason);
    }

    // ---- barista ----

    private void findRegister() {
        if (register != null && level().getBlockState(register).is(ModBlocks.CAFE_REGISTER.get())) return;
        register = null;
        BlockPos c = blockPosition();
        double best = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-8, -3, -8), c.offset(8, 3, 8))) {
            if (!level().getBlockState(p).is(ModBlocks.CAFE_REGISTER.get())) continue;
            double d = p.distSqr(c);
            if (d < best) {
                best = d;
                register = p.immutable();
            }
        }
    }

    private void tickBarista() {
        if (tickCount % 20 != 0) return;
        ServerLevel sl = (ServerLevel) level();
        if (tickCount % 100 == 0 || register == null) findRegister();
        if (register == null) return;
        long now = sl.getGameTime();
        CafeOrders orders = CafeOrders.get(sl.getServer());

        // 1. a paid order of a player that I am making
        for (CafeOrders.Entry e : orders.all()) {
            if (e.status == CafeOrders.COOKING && getUUID().equals(e.worker)) {
                if (now >= e.readyAt) {
                    e.status = CafeOrders.READY;
                    e.readyAt = now;
                    orders.changed();
                    sl.playSound(null, blockPosition(), ModSounds.BARISTA_DING.get(), SoundSource.NEUTRAL, 1.0F, 1.0F);
                    sl.sendParticles(ParticleTypes.CLOUD, getX(), getY() + 1.2D, getZ(), 6, 0.2D, 0.1D, 0.2D, 0.01D);
                    ServerPlayer buyer = sl.getServer().getPlayerList().getPlayer(e.buyer);
                    if (buyer != null) buyer.sendSystemMessage(Component.translatable("cafe.order.ready"));
                }
                return;                                                   // busy with it
            }
        }

        // 2. a paid order of a player that waits for a barista for too long (or nobody else is at work)
        CafeOrders.Entry open = orders.nextPending(sl.dimension().location().toString(), register, CafeLogic.STAFF_RADIUS);
        if (open != null && (now - open.created >= NPC_TAKES_AFTER || !playerBaristaAtWork(sl))) {
            open.status = CafeOrders.COOKING;
            open.worker = getUUID();
            open.readyAt = now + COOK_TICKS;
            orders.changed();
            return;
        }

        // 3. a customer NPC: wait for one to come, make its drink, no money for anybody
        serveCustomer(sl, now);
    }

    private static boolean playerBaristaAtWork(ServerLevel sl) {
        for (ServerPlayer p : sl.getServer().getPlayerList().getPlayers()) {
            if (CafeLogic.isWorking(p)) return true;
        }
        return false;
    }

    private void serveCustomer(ServerLevel sl, long now) {
        CafeCustomerEntity current = null;
        if (customer != null) {
            net.minecraft.world.entity.Entity e = sl.getEntity(customer);
            if (e instanceof CafeCustomerEntity c && c.isAlive()) current = c;
            else customer = null;
        }
        if (current != null) {
            if (current.getState() == CafeCustomerEntity.STATE_WAITING) {
                if (customerWorkUntil == 0L) customerWorkUntil = now + CUSTOMER_WORK_TICKS;
                if (now >= customerWorkUntil) {
                    current.receiveByNpc(position());
                    sl.playSound(null, blockPosition(), ModSounds.BARISTA_DING.get(), SoundSource.NEUTRAL, 0.8F, 1.1F);
                    customer = null;
                    customerWorkUntil = 0L;
                    customerCooldown = 1200 + random.nextInt(1200);
                }
            }
            return;
        }
        customerCooldown -= 20;
        if (customerCooldown > 0) return;
        if (sl.getNearestPlayer(this, 48.0D) == null) {                   // nobody to watch: do not spawn anything
            customerCooldown = 600;
            return;
        }
        BlockState rs = sl.getBlockState(register);
        Direction facing = rs.hasProperty(net.minecraft.world.level.block.HorizontalDirectionalBlock.FACING)
                ? rs.getValue(net.minecraft.world.level.block.HorizontalDirectionalBlock.FACING) : Direction.NORTH;
        int variant = random.nextInt(Order.CUSTOMERS);
        Personality person = Personality.of(variant);
        Drink drink = CafeLogic.pickDrink(person, random);
        int dessert = -1;
        if (random.nextFloat() < person.dessertChance()) {                  // only a dessert the chef really has on the tray
            List<Integer> have = availableDesserts(sl, register);
            if (!have.isEmpty()) {
                int[] w = new int[have.size()];
                for (int i = 0; i < w.length; i++) {
                    Dessert d = Dessert.byIndex(have.get(i));
                    w[i] = Pairing.dessertWeight(person, drink.id(), d.id());
                }
                int pick = have.get(Personality.weightedPick(w, random::nextInt));
                if (takePlate(sl, register, pick)) dessert = pick;
            }
        }
        CafeCustomerEntity npc = CafeCustomerEntity.spawnFor(sl, register, facing, getUUID(), variant, drink.ordinal(), dessert, now, true);
        if (npc == null) {
            customerCooldown = 600;
            return;
        }
        customer = npc.getUUID();
        customerWorkUntil = 0L;
    }

    // ------------------------------------------------------------------ save / load

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Selected", selected);
        tag.putInt("Bake", bake);
        ListTag list = new ListTag();
        for (Plate p : tray) {
            CompoundTag t = new CompoundTag();
            t.putInt("d", p.dessert());
            t.putLong("e", p.expires());
            list.add(t);
        }
        tag.put("Tray", list);
        if (lit != null) tag.putLong("Lit", lit.asLong());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        selected = tag.contains("Selected") ? tag.getInt("Selected") : -1;
        bake = tag.getInt("Bake");
        tray.clear();
        ListTag list = tag.getList("Tray", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size() && i < TRAY; i++) {
            CompoundTag t = list.getCompound(i);
            tray.add(new Plate(t.getInt("d"), t.getLong("e")));
        }
        lit = tag.contains("Lit") ? BlockPos.of(tag.getLong("Lit")) : null;     // put out on the first tick if nothing is baking
    }
}
