package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import java.util.List;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Server -> client: opens the menu of a chef: what he bakes now, the plates on his tray (dessert + seconds before they go cold), the progress of the next plate. */
public record OpenChefPayload(int entity, int selected, List<Integer> plates, List<Integer> seconds, int bakePercent, boolean furnace) implements CustomPacketPayload {
    public static final Type<OpenChefPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "open_chef"));

    public static final StreamCodec<RegistryFriendlyByteBuf, OpenChefPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, OpenChefPayload::entity,
            ByteBufCodecs.INT, OpenChefPayload::selected,
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(64)), OpenChefPayload::plates,
            ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list(64)), OpenChefPayload::seconds,
            ByteBufCodecs.VAR_INT, OpenChefPayload::bakePercent,
            ByteBufCodecs.BOOL, OpenChefPayload::furnace,
            OpenChefPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
