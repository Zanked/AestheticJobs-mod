package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client -> server: a click in the chef menu. action 0 = bake this dessert (value = index), 1 = take the plate in this tray slot. */
public record ChefActionPayload(int entity, int action, int value) implements CustomPacketPayload {
    public static final Type<ChefActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "chef_action"));

    public static final StreamCodec<RegistryFriendlyByteBuf, ChefActionPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, ChefActionPayload::entity,
            ByteBufCodecs.VAR_INT, ChefActionPayload::action,
            ByteBufCodecs.INT, ChefActionPayload::value,
            ChefActionPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
