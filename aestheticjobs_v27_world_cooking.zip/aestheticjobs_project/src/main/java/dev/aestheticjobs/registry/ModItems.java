package dev.aestheticjobs.registry;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.economy.Denomination;
import dev.aestheticjobs.item.BankCardItem;
import dev.aestheticjobs.item.CoffeeCupItem;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.item.DessertPlateItem;
import dev.aestheticjobs.item.DoughItem;
import dev.aestheticjobs.item.PortafilterItem;
import dev.aestheticjobs.item.RecipeBookItem;
import dev.aestheticjobs.item.OrderTicketItem;
import dev.aestheticjobs.item.ResumeItem;
import dev.aestheticjobs.item.WorkBadgeItem;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(AestheticJobs.MODID);

    public static final DeferredItem<BlockItem> ATM = ITEMS.registerSimpleBlockItem("atm", ModBlocks.ATM);
    public static final DeferredItem<BankCardItem> BANK_CARD = ITEMS.registerItem("bank_card", BankCardItem::new, new Item.Properties().stacksTo(1));

    /** Right-click: start / end the shift. Glows green while on shift (custom_model_data 1). */
    public static final DeferredItem<WorkBadgeItem> WORK_BADGE = ITEMS.registerItem("work_badge", WorkBadgeItem::new, new Item.Properties().stacksTo(1));

    /** The resume: right-click to fill it in, hand it to the manager of a job (custom_model_data 1 = filled). */
    public static final DeferredItem<ResumeItem> RESUME = ITEMS.registerItem("resume", ResumeItem::new, new Item.Properties().stacksTo(1));
    public static final DeferredItem<DeferredSpawnEggItem> CAFE_MANAGER_SPAWN_EGG = ITEMS.register("cafe_manager_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.CAFE_MANAGER, 0xFBF3E4, 0x8A5A3A, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> OFFICE_MANAGER_SPAWN_EGG = ITEMS.register("office_manager_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.OFFICE_MANAGER, 0xE8EEF6, 0x3D4458, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> SHOP_MANAGER_SPAWN_EGG = ITEMS.register("shop_manager_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.SHOP_MANAGER, 0x7FB59A, 0xD9A86A, new Item.Properties()));

    public static final DeferredItem<BlockItem> COFFEE_MACHINE = ITEMS.registerSimpleBlockItem("coffee_machine", ModBlocks.COFFEE_MACHINE);
    public static final DeferredItem<BlockItem> PASTRY_OVEN = ITEMS.registerSimpleBlockItem("pastry_oven", ModBlocks.PASTRY_OVEN);
    public static final DeferredItem<BlockItem> CAFE_REGISTER = ITEMS.registerSimpleBlockItem("cafe_register", ModBlocks.CAFE_REGISTER);
    public static final DeferredItem<BlockItem> PENDANT_LAMP = ITEMS.registerSimpleBlockItem("pendant_lamp", ModBlocks.PENDANT_LAMP);
    public static final DeferredItem<BlockItem> PLANTER = ITEMS.registerSimpleBlockItem("cafe_planter", ModBlocks.PLANTER);
    public static final DeferredItem<BlockItem> MENU_BOARD = ITEMS.registerSimpleBlockItem("menu_board", ModBlocks.MENU_BOARD);
    public static final DeferredItem<BlockItem> TIP_JAR = ITEMS.registerSimpleBlockItem("tip_jar", ModBlocks.TIP_JAR);
    public static final DeferredItem<BlockItem> COFFEE_GRINDER = ITEMS.registerSimpleBlockItem("coffee_grinder", ModBlocks.COFFEE_GRINDER);
    public static final DeferredItem<BlockItem> MIXING_BOWL = ITEMS.registerSimpleBlockItem("mixing_bowl", ModBlocks.MIXING_BOWL);
    public static final DeferredItem<PortafilterItem> PORTAFILTER = ITEMS.registerItem("portafilter", PortafilterItem::new, new Item.Properties().stacksTo(1));
    public static final DeferredItem<Item> WHISK = ITEMS.registerSimpleItem("whisk", new Item.Properties().stacksTo(1));
    public static final DeferredItem<DoughItem> DOUGH = ITEMS.registerItem("dough", DoughItem::new, new Item.Properties().stacksTo(1));
    public static final DeferredItem<RecipeBookItem> RECIPE_BOOK = ITEMS.registerItem("recipe_book", RecipeBookItem::new, new Item.Properties().stacksTo(1));
    public static final DeferredItem<BlockItem> CAKE_STAND = ITEMS.registerSimpleBlockItem("cake_stand", ModBlocks.CAKE_STAND);
    public static final DeferredItem<BlockItem> CUP_STACK = ITEMS.registerSimpleBlockItem("cup_stack", ModBlocks.CUP_STACK);
    public static final DeferredItem<BlockItem> BEAN_SACK = ITEMS.registerSimpleBlockItem("bean_sack", ModBlocks.BEAN_SACK);
    public static final DeferredItem<BlockItem> FRUIT_BASKET = ITEMS.registerSimpleBlockItem("fruit_basket", ModBlocks.FRUIT_BASKET);
    public static final DeferredItem<BlockItem> GREENS_BASKET = ITEMS.registerSimpleBlockItem("greens_basket", ModBlocks.GREENS_BASKET);
    public static final DeferredItem<BlockItem> PLATE_STACK = ITEMS.registerSimpleBlockItem("plate_stack", ModBlocks.PLATE_STACK);
    public static final DeferredItem<BlockItem> DRINK_BOTTLES = ITEMS.registerSimpleBlockItem("drink_bottles", ModBlocks.DRINK_BOTTLES);
    public static final DeferredItem<BlockItem> TABLE_GLASSES = ITEMS.registerSimpleBlockItem("table_glasses", ModBlocks.TABLE_GLASSES);
    public static final DeferredItem<BlockItem> PLACE_SETTING = ITEMS.registerSimpleBlockItem("place_setting", ModBlocks.PLACE_SETTING);
    public static final DeferredItem<BlockItem> PIZZA_PLATE = ITEMS.registerSimpleBlockItem("pizza_plate", ModBlocks.PIZZA_PLATE);
    public static final DeferredItem<BlockItem> ROAST_PLATTER = ITEMS.registerSimpleBlockItem("roast_platter", ModBlocks.ROAST_PLATTER);
    public static final DeferredItem<BlockItem> SUSHI_BOARD = ITEMS.registerSimpleBlockItem("sushi_board", ModBlocks.SUSHI_BOARD);
    public static final DeferredItem<Item> EMPTY_CUP = ITEMS.registerSimpleItem("empty_cup", new Item.Properties().stacksTo(16));
    public static final DeferredItem<Item> COFFEE_BEANS = ITEMS.registerSimpleItem("coffee_beans", new Item.Properties());
    // supplies of the recipes (see cafe/Drink)
    public static final DeferredItem<Item> MILK_CARTON = ITEMS.registerSimpleItem("milk_carton", new Item.Properties());
    public static final DeferredItem<Item> CREAM_CARTON = ITEMS.registerSimpleItem("cream_carton", new Item.Properties());
    public static final DeferredItem<Item> SYRUP_VANILLA = ITEMS.registerSimpleItem("syrup_vanilla", new Item.Properties());
    public static final DeferredItem<Item> SYRUP_CARAMEL = ITEMS.registerSimpleItem("syrup_caramel", new Item.Properties());
    public static final DeferredItem<Item> CHOCOLATE = ITEMS.registerSimpleItem("chocolate", new Item.Properties());
    public static final DeferredItem<CoffeeCupItem> COFFEE_CUP = ITEMS.registerItem("coffee_cup", CoffeeCupItem::new, new Item.Properties().stacksTo(1));
    public static final DeferredItem<OrderTicketItem> ORDER_TICKET = ITEMS.registerItem("order_ticket", OrderTicketItem::new, new Item.Properties().stacksTo(1));

    /** A plate with a dessert from the chef: not food, only for serving (CafeLogic). custom_model_data = dessert index + 1. */
    public static final DeferredItem<DessertPlateItem> DESSERT_PLATE = ITEMS.registerItem("dessert_plate", DessertPlateItem::new, new Item.Properties().stacksTo(1));

    /** Spawn eggs of the staff: put a pastry chef next to a furnace, an NPC barista next to a register. */
    public static final DeferredItem<DeferredSpawnEggItem> CAFE_CHEF_SPAWN_EGG = ITEMS.register("cafe_chef_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.CAFE_CHEF, 0xFFFAF0, 0xE3A08C, new Item.Properties()));
    public static final DeferredItem<DeferredSpawnEggItem> CAFE_BARISTA_SPAWN_EGG = ITEMS.register("cafe_barista_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.CAFE_BARISTA, 0xA47A5E, 0xFFF6E2, new Item.Properties()));

    /** Spawn egg of the cafe customer (cream and coffee colours, like the mod). */
    public static final DeferredItem<DeferredSpawnEggItem> CAFE_CUSTOMER_SPAWN_EGG = ITEMS.register("cafe_customer_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.CAFE_CUSTOMER, 0xE9D9B0, 0x7A5238, new Item.Properties()));

    /** Coins and bills, one item per denomination (ids: coin_penny ... bill_100). */
    public static final Map<Denomination, DeferredItem<Item>> MONEY = new EnumMap<>(Denomination.class);

    /** Edible desserts of the cafe (a customer gets them from the barista after paying; they remember who bought them), one item per {@link Dessert} (ids = Dessert.id()). */
    public static final Map<Dessert, DeferredItem<Item>> DESSERTS = new LinkedHashMap<>();

    static {
        for (Dessert d : Dessert.values()) {
            DESSERTS.put(d, ITEMS.registerSimpleItem(d.id(), new Item.Properties().food(d.food())));
        }
        for (Denomination d : Denomination.values()) {
            MONEY.put(d, ITEMS.registerSimpleItem(d.id(), new Item.Properties()));
        }
    }

    private ModItems() {}
}
