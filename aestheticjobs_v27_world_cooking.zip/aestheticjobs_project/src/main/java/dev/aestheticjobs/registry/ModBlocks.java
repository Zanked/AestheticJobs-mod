package dev.aestheticjobs.registry;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.block.AtmBlock;
import dev.aestheticjobs.block.CafeDecorBlock;
import dev.aestheticjobs.block.CafeRegisterBlock;
import dev.aestheticjobs.block.CafeStationBlock;
import dev.aestheticjobs.block.CoffeeMachineBlock;
import dev.aestheticjobs.block.PastryOvenBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(AestheticJobs.MODID);

    public static final DeferredBlock<AtmBlock> ATM = BLOCKS.registerBlock("atm", AtmBlock::new,
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_YELLOW)
                    .strength(3.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()
                    .pushReaction(PushReaction.BLOCK));

    public static final DeferredBlock<CoffeeMachineBlock> COFFEE_MACHINE = BLOCKS.registerBlock("coffee_machine", CoffeeMachineBlock::new,
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.SAND)
                    .strength(2.0F, 4.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()
                    .pushReaction(PushReaction.DESTROY));

    public static final DeferredBlock<PastryOvenBlock> PASTRY_OVEN = BLOCKS.registerBlock("pastry_oven", PastryOvenBlock::new,
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PINK)
                    .strength(2.0F, 4.0F)
                    .sound(SoundType.METAL)
                    .lightLevel(state -> state.getValue(PastryOvenBlock.LOOK) > 0 ? 9 : 0)
                    .noOcclusion()
                    .pushReaction(PushReaction.BLOCK));

    public static final DeferredBlock<CafeRegisterBlock> CAFE_REGISTER = BLOCKS.registerBlock("cafe_register", CafeRegisterBlock::new,
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_BROWN)
                    .strength(2.0F, 4.0F)
                    .sound(SoundType.METAL)
                    .noOcclusion()
                    .pushReaction(PushReaction.DESTROY));

    // ------------------------------------------------------------------ decorations (a cosy cafe gets better tips)
    public static final DeferredBlock<CafeDecorBlock> PENDANT_LAMP = decor("pendant_lamp", CafeDecorBlock.Kind.PENDANT_LAMP, SoundType.METAL, 14);
    public static final DeferredBlock<CafeDecorBlock> PLANTER = decor("cafe_planter", CafeDecorBlock.Kind.PLANTER, SoundType.WOOD, 0);
    public static final DeferredBlock<CafeDecorBlock> MENU_BOARD = decor("menu_board", CafeDecorBlock.Kind.MENU_BOARD, SoundType.WOOD, 0);
    public static final DeferredBlock<CafeDecorBlock> TIP_JAR = decor("tip_jar", CafeDecorBlock.Kind.TIP_JAR, SoundType.GLASS, 0);
    public static final DeferredBlock<CafeStationBlock> COFFEE_GRINDER = station("coffee_grinder", CafeDecorBlock.Kind.COFFEE_GRINDER);
    public static final DeferredBlock<CafeStationBlock> MIXING_BOWL = station("mixing_bowl", CafeDecorBlock.Kind.MIXING_BOWL);
    public static final DeferredBlock<CafeDecorBlock> CAKE_STAND = decor("cake_stand", CafeDecorBlock.Kind.CAKE_STAND, SoundType.GLASS, 0);
    public static final DeferredBlock<CafeDecorBlock> CUP_STACK = decor("cup_stack", CafeDecorBlock.Kind.CUP_STACK, SoundType.GLASS, 0);
    public static final DeferredBlock<CafeDecorBlock> BEAN_SACK = decor("bean_sack", CafeDecorBlock.Kind.BEAN_SACK, SoundType.WOOL, 0);
    // the table setting
    public static final DeferredBlock<CafeDecorBlock> FRUIT_BASKET = decor("fruit_basket", CafeDecorBlock.Kind.FRUIT_BASKET, SoundType.WOOD, 0);
    public static final DeferredBlock<CafeDecorBlock> GREENS_BASKET = decor("greens_basket", CafeDecorBlock.Kind.GREENS_BASKET, SoundType.WOOD, 0);
    public static final DeferredBlock<CafeDecorBlock> PLATE_STACK = decor("plate_stack", CafeDecorBlock.Kind.PLATE_STACK, SoundType.GLASS, 0);
    public static final DeferredBlock<CafeDecorBlock> DRINK_BOTTLES = decor("drink_bottles", CafeDecorBlock.Kind.DRINK_BOTTLES, SoundType.GLASS, 0);
    public static final DeferredBlock<CafeDecorBlock> TABLE_GLASSES = decor("table_glasses", CafeDecorBlock.Kind.TABLE_GLASSES, SoundType.GLASS, 0);
    public static final DeferredBlock<CafeDecorBlock> PLACE_SETTING = decor("place_setting", CafeDecorBlock.Kind.PLACE_SETTING, SoundType.METAL, 0);
    public static final DeferredBlock<CafeDecorBlock> PIZZA_PLATE = decor("pizza_plate", CafeDecorBlock.Kind.PIZZA_PLATE, SoundType.WOOL, 0);
    public static final DeferredBlock<CafeDecorBlock> ROAST_PLATTER = decor("roast_platter", CafeDecorBlock.Kind.ROAST_PLATTER, SoundType.WOOL, 0);
    public static final DeferredBlock<CafeDecorBlock> SUSHI_BOARD = decor("sushi_board", CafeDecorBlock.Kind.SUSHI_BOARD, SoundType.WOOD, 0);

    private static DeferredBlock<CafeStationBlock> station(String id, CafeDecorBlock.Kind kind) {
        return BLOCKS.registerBlock(id, p -> new CafeStationBlock(kind, p),
                BlockBehaviour.Properties.of()
                        .mapColor(MapColor.WOOD)
                        .strength(0.8F, 1.5F)
                        .sound(SoundType.WOOD)
                        .noOcclusion()
                        .pushReaction(PushReaction.DESTROY));
    }

    private static DeferredBlock<CafeDecorBlock> decor(String id, CafeDecorBlock.Kind kind, SoundType sound, int light) {
        return BLOCKS.registerBlock(id, p -> new CafeDecorBlock(kind, p),
                BlockBehaviour.Properties.of()
                        .mapColor(MapColor.WOOD)
                        .strength(0.8F, 1.5F)
                        .sound(sound)
                        .lightLevel(state -> light)
                        .noOcclusion()
                        .pushReaction(PushReaction.DESTROY));
    }

    private ModBlocks() {}
}
