package dev.aestheticjobs.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.job.Jobs;
import dev.aestheticjobs.job.Profession;
import dev.aestheticjobs.job.ProfessionManager;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/**
 * /job list                         - all professions
 * /job info [player]                - current job, rank, wage (other players: ops only)
 * /job join <profession>            - ops, test tool until the employment center exists (normal rules apply)
 * /job quit                         - ops, same
 * /job set <player> <profession>    - ops: force a job, no checks
 * /job clear <player>               - ops: remove the job, no cooldown
 * /job xp <player> <amount>         - ops: add experience to the current job
 */
public final class JobCommands {
    private static final SuggestionProvider<CommandSourceStack> PROFESSIONS =
            (context, builder) -> SharedSuggestionProvider.suggestResource(ProfessionManager.ids(), builder);

    private JobCommands() {}

    public static void register(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("job")
                .then(Commands.literal("list")
                        .executes(c -> list(c.getSource())))
                .then(Commands.literal("info")
                        .executes(c -> info(c.getSource(), c.getSource().getPlayerOrException()))
                        .then(Commands.argument("player", EntityArgument.player())
                                .requires(s -> s.hasPermission(2))
                                .executes(c -> info(c.getSource(), EntityArgument.getPlayer(c, "player")))))
                .then(Commands.literal("join")
                        .requires(s -> s.hasPermission(2))
                        .then(Commands.argument("profession", ResourceLocationArgument.id())
                                .suggests(PROFESSIONS)
                                .executes(c -> hire(c.getSource(), c.getSource().getPlayerOrException(),
                                        ResourceLocationArgument.getId(c, "profession"), false))))
                .then(Commands.literal("quit")
                        .requires(s -> s.hasPermission(2))
                        .executes(c -> quit(c.getSource(), c.getSource().getPlayerOrException(), false)))
                .then(Commands.literal("set")
                        .requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("profession", ResourceLocationArgument.id())
                                        .suggests(PROFESSIONS)
                                        .executes(c -> hire(c.getSource(), EntityArgument.getPlayer(c, "player"),
                                                ResourceLocationArgument.getId(c, "profession"), true)))))
                .then(Commands.literal("clear")
                        .requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .executes(c -> quit(c.getSource(), EntityArgument.getPlayer(c, "player"), true))))
                .then(Commands.literal("xp")
                        .requires(s -> s.hasPermission(2))
                        .then(Commands.argument("player", EntityArgument.player())
                                .then(Commands.argument("amount", IntegerArgumentType.integer(1, 1_000_000))
                                        .executes(c -> xp(c.getSource(), EntityArgument.getPlayer(c, "player"),
                                                IntegerArgumentType.getInteger(c, "amount")))))));
    }

    private static int list(CommandSourceStack src) {
        List<Profession> all = ProfessionManager.all().stream()
                .sorted(Comparator.comparing(p -> p.id().toString())).toList();
        if (all.isEmpty()) {
            src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.job.list.empty"), false);
            return 0;
        }
        src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.job.list.header"), false);
        for (Profession p : all) {
            src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.job.list.entry",
                    p.displayName(), Money.format(p.baseWageCents()), p.ranks().size()), false);
        }
        return all.size();
    }

    private static int info(CommandSourceStack src, ServerPlayer target) throws CommandSyntaxException {
        Optional<Jobs.Status> status = Jobs.status(src.getServer(), target.getUUID());
        if (status.isEmpty()) {
            src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.job.info.none", target.getDisplayName()), false);
            return 0;
        }
        Jobs.Status s = status.get();
        Profession p = s.profession();
        src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.job.info.job",
                target.getDisplayName(), p.displayName()), false);
        if (s.nextRankXp() < 0) {
            src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.job.info.rank_max",
                    p.rankName(s.rank()), s.xp()), false);
        } else {
            src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.job.info.rank",
                    p.rankName(s.rank()), s.xp(), s.nextRankXp()), false);
        }
        src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.job.info.wage",
                Money.format(s.wageCentsPerHour())), false);
        return 1;
    }

    private static int hire(CommandSourceStack src, ServerPlayer target, ResourceLocation id, boolean force) {
        Jobs.Result r = Jobs.hire(src.getServer(), target.getUUID(), id, force);
        switch (r) {
            case OK -> {
                Component name = ProfessionManager.get(id).map(Profession::displayName).orElse(Component.literal(id.toString()));
                src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.job.join.ok",
                        target.getDisplayName(), name), true);
                return 1;
            }
            case UNKNOWN_PROFESSION -> src.sendFailure(Component.translatable("commands.aestheticjobs.job.error.unknown", id.toString()));
            case ALREADY_EMPLOYED -> src.sendFailure(Component.translatable("commands.aestheticjobs.job.error.employed"));
            case COOLDOWN -> src.sendFailure(Component.translatable("commands.aestheticjobs.job.error.cooldown"));
            case REQUIREMENTS_NOT_MET -> src.sendFailure(Component.translatable("commands.aestheticjobs.job.error.requirements"));
            default -> src.sendFailure(Component.translatable("commands.aestheticjobs.job.error.not_employed"));
        }
        return 0;
    }

    private static int quit(CommandSourceStack src, ServerPlayer target, boolean force) {
        Jobs.Result r = Jobs.quit(src.getServer(), target.getUUID(), force);
        if (r == Jobs.Result.OK) {
            src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.job.quit.ok", target.getDisplayName()), true);
            return 1;
        }
        src.sendFailure(Component.translatable("commands.aestheticjobs.job.error.not_employed"));
        return 0;
    }

    private static int xp(CommandSourceStack src, ServerPlayer target, int amount) {
        Jobs.XpResult r = Jobs.addXp(src.getServer(), target.getUUID(), amount);
        if (!r.employed()) {
            src.sendFailure(Component.translatable("commands.aestheticjobs.job.error.not_employed"));
            return 0;
        }
        src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.job.xp.ok", amount, target.getDisplayName()), true);
        if (r.newRank() > r.oldRank()) {
            src.sendSuccess(() -> Component.translatable("commands.aestheticjobs.job.rankup",
                    target.getDisplayName(), r.profession().rankName(r.newRank())), true);
        }
        return 1;
    }
}
