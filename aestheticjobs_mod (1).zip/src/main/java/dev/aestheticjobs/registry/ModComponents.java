package dev.aestheticjobs.registry;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.item.CardOwner;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModComponents {
    public static final DeferredRegister.DataComponents COMPONENTS =
            DeferredRegister.createDataComponents(Registries.DATA_COMPONENT_TYPE, AestheticJobs.MODID);

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<CardOwner>> CARD_OWNER =
            COMPONENTS.registerComponentType("card_owner",
                    builder -> builder.persistent(CardOwner.CODEC).networkSynchronized(CardOwner.STREAM_CODEC));

    private ModComponents() {}
}
