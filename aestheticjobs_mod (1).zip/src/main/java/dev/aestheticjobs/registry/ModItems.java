package dev.aestheticjobs.registry;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.economy.Denomination;
import dev.aestheticjobs.item.BankCardItem;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(AestheticJobs.MODID);

    public static final DeferredItem<BlockItem> ATM = ITEMS.registerSimpleBlockItem("atm", ModBlocks.ATM);
    public static final DeferredItem<BankCardItem> BANK_CARD = ITEMS.registerItem("bank_card", BankCardItem::new, new Item.Properties().stacksTo(1));

    /** Coins and bills, one item per denomination (ids: coin_penny ... bill_100). */
    public static final Map<Denomination, DeferredItem<Item>> MONEY = new EnumMap<>(Denomination.class);

    static {
        for (Denomination d : Denomination.values()) {
            MONEY.put(d, ITEMS.registerSimpleItem(d.id(), new Item.Properties()));
        }
    }

    private ModItems() {}
}
