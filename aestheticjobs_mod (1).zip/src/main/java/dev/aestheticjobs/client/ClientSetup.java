package dev.aestheticjobs.client;

import dev.aestheticjobs.registry.ModMenus;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

/** Client-only registrations. Only touched when running on the client. */
public final class ClientSetup {
    private ClientSetup() {}

    public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(ModMenus.ATM.get(), AtmScreen::new);
    }
}
