package dev.aestheticjobs.job;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Persistent job records of all players (world/data/aestheticjobs_jobs.dat). Server side only. */
public class JobData extends SavedData {
    public static final String NAME = "aestheticjobs_jobs";

    /** What a player has achieved in one profession. Kept after quitting, so careers are not lost. */
    static final class Progress {
        long xp;
        long workedSeconds;
    }

    static final class PlayerJob {
        @Nullable ResourceLocation current;
        long hiredAt;
        long lastQuit;
        final Map<ResourceLocation, Progress> progress = new HashMap<>();
    }

    private final Map<UUID, PlayerJob> players = new HashMap<>();

    public static JobData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(factory(), NAME);
    }

    public static SavedData.Factory<JobData> factory() {
        return new SavedData.Factory<>(JobData::new, JobData::load, null);
    }

    PlayerJob player(UUID id) {
        return players.computeIfAbsent(id, k -> new PlayerJob());
    }

    public static JobData load(CompoundTag tag, HolderLookup.Provider registries) {
        JobData data = new JobData();
        ListTag list = tag.getList("players", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            PlayerJob job = new PlayerJob();
            if (t.contains("current")) job.current = ResourceLocation.tryParse(t.getString("current"));
            job.hiredAt = t.getLong("hiredAt");
            job.lastQuit = t.getLong("lastQuit");
            ListTag progress = t.getList("progress", Tag.TAG_COMPOUND);
            for (int j = 0; j < progress.size(); j++) {
                CompoundTag p = progress.getCompound(j);
                ResourceLocation id = ResourceLocation.tryParse(p.getString("profession"));
                if (id == null) continue;
                Progress pr = new Progress();
                pr.xp = p.getLong("xp");
                pr.workedSeconds = p.getLong("worked");
                job.progress.put(id, pr);
            }
            data.players.put(t.getUUID("id"), job);
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        ListTag list = new ListTag();
        for (Map.Entry<UUID, PlayerJob> e : players.entrySet()) {
            PlayerJob job = e.getValue();
            CompoundTag t = new CompoundTag();
            t.putUUID("id", e.getKey());
            if (job.current != null) t.putString("current", job.current.toString());
            t.putLong("hiredAt", job.hiredAt);
            t.putLong("lastQuit", job.lastQuit);
            ListTag progress = new ListTag();
            for (Map.Entry<ResourceLocation, Progress> pe : job.progress.entrySet()) {
                CompoundTag p = new CompoundTag();
                p.putString("profession", pe.getKey().toString());
                p.putLong("xp", pe.getValue().xp);
                p.putLong("worked", pe.getValue().workedSeconds);
                progress.add(p);
            }
            t.put("progress", progress);
            list.add(t);
        }
        tag.put("players", list);
        return tag;
    }
}
