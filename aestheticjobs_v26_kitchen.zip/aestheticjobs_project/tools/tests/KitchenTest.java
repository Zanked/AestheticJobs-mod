import dev.aestheticjobs.cafe.career.Wish;
import dev.aestheticjobs.cafe.kitchen.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.regex.Pattern;

/**
 * javac -d /tmp/t src/main/java/dev/aestheticjobs/cafe/kitchen/*.java src/main/java/dev/aestheticjobs/cafe/career/Wish.java \
 *   tools/tests/KitchenTest.java && java -cp /tmp/t KitchenTest     (from the project folder)
 */
public class KitchenTest {
    static void check(boolean ok, String what) {
        if (!ok) throw new AssertionError(what);
    }

    static List<String> ids(String file, String regex) throws Exception {
        var m = Pattern.compile(regex, Pattern.MULTILINE).matcher(Files.readString(Path.of(file)));
        List<String> out = new ArrayList<>();
        while (m.find()) out.add(m.group(1));
        return out;
    }

    public static void main(String[] args) throws Exception {
        List<String> drinks = ids("src/main/java/dev/aestheticjobs/cafe/Drink.java", "^    [A-Z_]+\\(\"([a-z_]+)\",");
        List<String> desserts = ids("src/main/java/dev/aestheticjobs/item/Dessert.java", "^    [A-Z_]+\\(\"([a-z_]+)\",");
        check(drinks.size() == Menu.DRINKS && desserts.size() == Menu.DESSERTS && Menu.size() == 40, "sizes " + drinks + desserts);
        for (int i = 0; i < 8; i++) check(Menu.get(i).id().equals(drinks.get(i)) && Menu.get(i).isDrink(), "drink order " + i);
        for (int i = 0; i < 32; i++) check(Menu.get(8 + i).id().equals(desserts.get(i)) && !Menu.get(8 + i).isDrink(), "dessert order " + i);

        Set<String> sig = new HashSet<>();
        check(Signature.values().length <= 64, "bits");
        for (Signature s : Signature.values()) {
            check(s.base() >= 0 && Integer.bitCount(s.mask()) == 2 && sig.add(s.base() + ":" + s.mask()), "signature " + s);
            check(Cooking.quality(s.base(), s.mask()) == 100, "signature quality " + s);
        }
        for (int b = 0; b < Menu.size(); b++) {
            Menu.Base base = Menu.get(b);
            check((base.likes() & base.dislikes()) == 0, "both " + base.id());
            check(Integer.bitCount(base.likes()) >= 3 && base.dislikes() != 0, "choice " + base.id());
            check(Cooking.stars(Cooking.quality(b, 0)) == 3, "plain is three stars " + base.id());
            int best = 0, fiveStar = 0, combos = 0;
            for (int m = 0; m <= Cooking.ALL_EXTRAS; m++) {
                if (!Cooking.valid(b, m)) {
                    check(Cooking.quality(b, m) == 0, "invalid");
                    continue;
                }
                int q = Cooking.quality(b, m);
                check(q >= 0 && q <= 100, "range");
                if (q > best) best = q;
                if (Cooking.stars(q) == 5) fiveStar++;
                combos++;
            }
            check(combos == 130 && best >= 90 && fiveStar >= 3 && fiveStar < combos / 3, base.id() + " 5*: " + fiveStar + "/" + combos);
            for (Wish w : Wish.values()) {                                      // every wish can be granted on every base
                if (w == Wish.NONE) continue;
                boolean possible = false;
                for (int m = 0; m <= Cooking.ALL_EXTRAS && !possible; m++) possible = Cooking.valid(b, m) && w.granted(b, m);
                check(possible, "wish " + w + " " + base.id());
            }
            Random r = new Random(b);
            for (int i = 0; i < 200; i++) {
                Wish w = Wish.pick(r, b);
                check(w != Wish.NONE && (w == Wish.PLAIN || !w.granted(b, 0)), "pick");
            }
        }

        Knowledge k = new Knowledge();
        Signature s = Signature.HONEY_LATTE;
        check(!k.knows(s.base(), s.mask()) && k.knows(s.base(), 0), "unknown");
        check(k.learn(s.base(), Extra.HONEY.bit()) == null && k.tried(s.base(), Extra.HONEY), "tried");
        k.learn(s.base(), Extra.VANILLA.bit());
        check(!k.knows(s.base(), s.mask()), "a signature stays secret until cooked");
        check(k.learn(s.base(), s.mask()) == s && k.learn(s.base(), s.mask()) == null && k.foundCount() == 1, "found once");
        Knowledge copy = new Knowledge();
        copy.load(k.triedCopy(), k.foundBits());
        check(copy.knows(s) && copy.tried(s.base(), Extra.VANILLA), "reload");
        copy.load(new int[]{-1}, -1L);
        check(copy.foundCount() == Signature.values().length, "garbage is masked");

        Job j = new Job();
        check(j.state(0) == Job.State.IDLE && !j.begin(99, 0, 0, "a", 0, true) && !j.begin(0, 15, 0, "a", 0, true), "bad");
        check(j.begin(2, Extra.HONEY.bit(), 1, "a", 100, true) && !j.begin(2, 0, 0, "b", 101, true), "one at a time");
        int t = Menu.get(2).ticks();
        check(j.state(100 + t - 1) == Job.State.WORKING && !j.mayCollect("a", 100 + t - 1), "working");
        check(j.mayCollect("a", 100 + t) && !j.mayCollect("b", 100 + t) && j.mayCollect("b", 100 + t + Job.OWNER_TICKS), "owner");
        check(j.progress(100, 0) == 0 && j.progress(100 + t, 0.5F) == 1, "progress");
        j.clear();
        check(j.state(5) == Job.State.IDLE && !j.paid(), "clear");
        j.load(2, 0, 0, 0, 999999, "a", true);
        check(j.state(5) == Job.State.IDLE, "bad save");
        j.load(2, 0, -4, 0, t, "a", true);
        check(j.state(t) == Job.State.READY && j.art() == 0, "good save");

        for (int b = 0; b < 8; b++) {
            for (int style = 0; style < LatteArt.STYLES.length; style++) {
                for (int m : new int[]{0, Extra.CREAM.bit() | Extra.CARAMEL.bit() | Extra.COCOA.bit()}) {
                    String p = LatteArt.picture(b, m, style);
                    check(p.length() == 256 && p.matches("[0-6]+"), "art");
                }
            }
        }
        for (int a = 0; a < 6; a++) {
            for (int c = a + 1; c < 6; c++) check(!LatteArt.picture(2, 0, a).equals(LatteArt.picture(2, 0, c)), "styles differ " + a + c);
        }
        if (args.length > 0) {
            for (int style = 0; style < 6; style++) System.out.println(LatteArt.picture(2, 0, style).replaceAll("(.{16})", "$1\n").replace('0', ' ').replace('5', '.').replace('1', '#'));
        }
        System.out.println("Kitchen ok");
    }
}
