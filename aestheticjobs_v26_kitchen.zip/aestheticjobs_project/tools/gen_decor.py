#!/usr/bin/env python3
"""The vintage miniature look of the cafe: the cash register (5 paints), the paints of the coffee machine and the
8 decorations. Writes textures, block and item models, blockstates, loot tables, recipes and the pickaxe-free tags.

    python3 tools/gen_decor.py          # run after gen_coffee_machine.py has been changed, too

Every face is painted at 2 texture pixels per model unit into one atlas per block (front of a block = north).
"""
import json
import math
import os
import sys
import zlib

import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import gen_coffee_machine as cm  # noqa: E402

RES = os.path.join(HERE, "..", "src", "main", "resources")
ASSETS = os.path.join(RES, "assets", "aestheticjobs")
DATA = os.path.join(RES, "data", "aestheticjobs")
S, GUTTER = 2, 2
C = cm.C
STYLES = ["cream", "mint", "rose", "noir", "cherry"]

# ------------------------------------------------------------------------------------------ palettes (light -> dark)
def ramp(*h):
    return [C(x) for x in h]


BODY = {
    "cream": ramp("FFFBF0", "F8EDD2", "EEDDB8", "DCC596", "BFA273", "96794F"),
    "mint": ramp("E6F7EE", "C9EBDC", "ADDBC8", "8DC3AE", "6BA18E", "4B7C6C"),
    "rose": ramp("FFEDF0", "FAD3DA", "F0B8C4", "DB98A9", "BA7589", "90546A"),
    "noir": ramp("77706E", "5B5453", "474140", "36302F", "27222A", "191519"),
    "cherry": ramp("F29C8E", "DC6A5E", "C34B45", "A33838", "7E282D", "581B22"),
}
ACCENT = {
    "cream": ramp("D6F2E4", "B4E2CC", "92CDB2", "6FB195", "4F8F76"),
    "mint": ramp("FFF6E4", "FBE9C8", "EFD6A8", "D5B681", "B09060"),
    "rose": ramp("FFF8EE", "FBEBD8", "EFD7BF", "D5B79C", "AE8F77"),
    "noir": ramp("F4E6BC", "DEC785", "C0A358", "99803C", "705A28"),
    "cherry": ramp("FFF6E4", "FBE9C8", "EFD6A8", "D5B681", "B09060"),
}
BRASS = ramp("FFF4CC", "F2D78E", "D9B25E", "B1873A", "7C5A22")
WALNUT = ramp("A97C5A", "8C6244", "704B34", "553726", "38231A")
OAK = ramp("E8C698", "D4AC78", "BC9060", "99714A", "745334")
WHITE = ramp("FFFFFF", "F7F3EE", "E8E1DA", "CFC5BD", "ADA29B")
LEAF = ramp("B7D98A", "8FBE68", "689C4C", "4B7A3A", "33572A")
TERRA = ramp("F0B795", "DB9672", "C27958", "9E5D43", "744030")
BURLAP = ramp("E6D0A4", "D3B885", "BC9E6C", "9C8054", "76603E")
SLATE = ramp("55665E", "46564F", "394842", "2E3B36", "222C28")
BEAN = ramp("A8744F", "815338", "603A27", "42261A", "281610")
IRON = ramp("8C8F94", "6C7075", "52555B", "3C3F45", "292B30")


def seed_of(*parts):
    return zlib.crc32("/".join(str(p) for p in parts).encode())


def shaded(w, h, r, lo=0.18, hi=0.55, noise=0.05, seed=0, edge=True):
    """A soft material: vertical light, a little grain, a light top edge and a dark bottom edge."""
    rng = np.random.RandomState(seed + w * 131 + h)
    im = cm.canvas(w, h)
    n = len(r) - 1
    for y in range(h):
        for x in range(w):
            t = lo + (hi - lo) * (y / max(h - 1, 1)) + 0.07 * (x / max(w - 1, 1)) + (rng.rand() - 0.5) * noise
            im[y, x] = cm.dpick(r, min(max(t, 0), 1), x, y) if noise > 0.08 else r[int(round(min(max(t, 0), 1) * n))]
    if edge and w >= 3 and h >= 3:
        cm.rect(im, 0, 0, w, 1, r[0])
        cm.rect(im, 0, 0, 1, h - 1, r[1])
        cm.rect(im, 0, h - 1, w, h, r[min(n, 4)])
        cm.rect(im, w - 1, 1, w, h, r[min(n, 3)])
    return im


def mat(r, **kw):
    return lambda w, h, f: shaded(w, h, r, seed=seed_of(r[0], f), **kw)


def metal(r):
    def paint(w, h, f):
        im = cm.canvas(w, h)
        along_x = w >= h
        n = h if along_x else w
        prof = [2, 0, 1, 2, 3, 2, 3, 4]
        for k in range(n):
            c = r[prof[int(round(k / max(n - 1, 1) * (len(prof) - 1)))]] if n > 1 else r[1]
            if along_x:
                cm.rect(im, 0, k, w, k + 1, c)
            else:
                cm.rect(im, k, 0, k + 1, h, c)
        if w >= 6:
            cm.rect(im, 1, 0, 1 + w // 4, 1, r[0])
        return im
    return paint


def wood(r, plank=0):
    def paint(w, h, f):
        rng = np.random.RandomState(seed_of(r[0], w, h, f))
        im = shaded(w, h, r, 0.25, 0.5, 0.0, edge=False)
        for y in range(h):
            if rng.rand() < 0.55 and w > 2:
                a = rng.randint(0, w - 1)
                cm.rect(im, a, y, a + rng.randint(2, max(3, w)), y + 1, r[rng.choice([1, 3])])
            if plank and y % plank == plank - 1:
                cm.rect(im, 0, y, w, y + 1, r[4])
        if w >= 3 and h >= 3:
            cm.rect(im, 0, 0, w, 1, r[0])
            cm.rect(im, 0, h - 1, w, h, r[4])
        return im
    return paint


def solid(col):
    return lambda w, h, f: cm.canvas(w, h, col)


def faces(default, **over):
    d = {"*": default}
    d.update(over)
    return d


def box(name, f, t, paint, which="nsewud"):
    if not isinstance(paint, dict):
        paint = {"*": paint}
    return dict(name=name, f=f, t=t, faces=which, paint=paint)


# ------------------------------------------------------------------------------------------ the cash register
def register(style):
    body, acc = BODY[style], ACCENT[style]
    dark = C("2A1A16")

    def enamel(w, h, f):
        im = shaded(w, h, body, 0.12, 0.5, 0.03, seed_of(style, f))
        return im

    def drawer(w, h, f):
        im = enamel(w, h, f)
        cm.frame(im, 1, 1, w - 1, h - 1, BRASS[3])
        cm.frame(im, 2, 2, w - 2, h - 2, BRASS[1])
        cx = w // 2
        cm.rect(im, cx - 3, h // 2 - 1, cx + 3, h // 2 + 1, BRASS[0])
        cm.rect(im, cx - 3, h // 2 + 1, cx + 3, h // 2 + 2, BRASS[4])
        for x in (4, w - 5):
            cm.put(im, x, h // 2, BRASS[0])
        return im

    def panel(w, h, f):
        """Sides and back of the cabinet: a brass frame with an accent inlay and a little diamond."""
        im = enamel(w, h, f)
        if w >= 8 and h >= 8:
            cm.frame(im, 2, 2, w - 2, h - 2, BRASS[2])
            cm.rect(im, 3, 3, w - 3, h - 3, acc[2])
            cm.rect(im, 3, 3, w - 3, 4, acc[1])
            cx, cy = w // 2, h // 2
            for dy in range(-3, 4):
                k = 3 - abs(dy)
                cm.rect(im, cx - k, cy + dy, cx + k + 1, cy + dy + 1, BRASS[1] if dy <= 0 else BRASS[3])
            cm.put(im, cx, cy - 1, BRASS[0])
        return im

    def window(w, h, f):
        """The price window with little flags."""
        im = metal(BRASS)(w, h, f)
        cm.rect(im, 1, 1, w - 1, h - 1, dark)
        digits = ["111101101101111", "010110010010111", "111001111100111", "111001111001111"]
        x = 3
        for k, d in enumerate((digits[3], None, digits[2], digits[0])):
            if d is None:
                cm.put(im, x, h - 3, C("F8F0DC"))
                x += 2
                continue
            cm.rect(im, x - 1, 1, x + 4, h - 1, C("F6EEDC"))
            for i, bit in enumerate(d):
                if bit == "1":
                    cm.put(im, x + i % 3, (h - 5) // 2 + i // 3, dark)
            x += 6
        return im

    def deck(w, h, f):
        im = shaded(w, h, WALNUT, 0.3, 0.6, 0.0)
        cm.frame(im, 0, 0, w, h, BRASS[2])
        return im

    els = [
        box("foot_fl", (1.5, 0, 2.5), (3, 0.6, 4), metal(BRASS)), box("foot_fr", (13, 0, 2.5), (14.5, 0.6, 4), metal(BRASS)),
        box("foot_bl", (1.5, 0, 12), (3, 0.6, 13.5), metal(BRASS)), box("foot_br", (13, 0, 12), (14.5, 0.6, 13.5), metal(BRASS)),
        box("plinth", (1.5, 0.6, 2.5), (14.5, 1.4, 13.5), wood(WALNUT)),
        box("drawer", (2, 1.4, 3), (14, 4.4, 13), faces(enamel, n=drawer)),
        box("knob", (7, 2.4, 2.3), (9, 3.4, 3), metal(BRASS)),
        box("ledge", (1.7, 4.4, 2.7), (14.3, 5, 13.3), metal(BRASS)),
        # the stepped keyboard
        box("step1", (2.5, 5, 3.3), (13.5, 5.8, 5.2), deck),
        box("step2", (2.5, 5, 5.2), (13.5, 6.8, 7.1), deck),
        box("step3", (2.5, 5, 7.1), (13.5, 7.8, 9), deck),
        # the cabinet behind the keys
        box("cabinet", (2.5, 5, 9), (13.5, 10, 12.7), panel),
        box("rim", (2.2, 10, 8.4), (13.8, 10.6, 13), metal(BRASS)),
        box("head", (3, 10.6, 9), (13, 13.4, 12.4), faces(panel, n=enamel)),
        box("window", (3.8, 10.9, 8.6), (12.2, 13.1, 9), faces(metal(BRASS), n=window), "nsewud"),
        # the stepped crest
        box("crest0", (2.7, 13.4, 8.7), (13.3, 14, 12.7), metal(BRASS)),
        box("crest1", (4, 14, 9.6), (12, 14.8, 11.8), enamel),
        box("crest2", (5.5, 14.8, 9.9), (10.5, 15.4, 11.5), enamel),
        box("finial", (7.2, 15.4, 10.1), (8.8, 16, 11.3), metal(BRASS)),
        # the crank on the right side of the machine (east)
        box("crank_axle", (13.5, 7, 10.2), (14.8, 7.8, 11), metal(BRASS)),
        box("crank_arm", (14.8, 5.4, 10.2), (15.3, 7.8, 11), metal(BRASS)),
        box("crank_knob", (14.6, 4.6, 9.9), (15.8, 5.6, 11.3), wood(WALNUT)),
        # a paper receipt curling out on the left (west)
        box("paper", (0.9, 8, 10), (2.5, 8.3, 12), mat(WHITE, lo=0.0, hi=0.25)),
        box("paper_end", (0.9, 6.2, 10), (1.2, 8, 12), mat(WHITE, lo=0.1, hi=0.45)),
    ]
    keycaps = [WHITE[1], WHITE[1], C("E2685C"), WHITE[1], C("6FA8DC"), WHITE[1], C("F2C14E")]
    for row, (y, z) in enumerate(((5.8, 3.8), (6.8, 5.7), (7.8, 7.6))):
        n = 6 if row % 2 == 0 else 5
        for i in range(n):
            x = 3.3 + i * 1.65 + (0.8 if n == 5 else 0)
            col = keycaps[(i * 2 + row * 3) % len(keycaps)]
            els.append(box(f"stem{row}_{i}", (x + 0.35, y, z + 0.35), (x + 0.75, y + 0.4, z + 0.75), solid(BRASS[3]), "nsew"))

            def cap(w, h, f, col=col):
                im = cm.canvas(w, h, col)
                if f != "u":
                    cm.rect(im, 0, h - 1, w, h, BRASS[3])
                return im
            els.append(box(f"key{row}_{i}", (x, y + 0.4, z), (x + 1.1, y + 0.9, z + 1.1), cap, "nsewu"))
    return els


# ------------------------------------------------------------------------------------------ the decorations
def pendant_lamp():
    glow = ramp("FFFFFF", "FFF8DC", "FFEDB4", "F8D988", "E8BE62")
    return [
        box("ceiling", (6, 15.2, 6), (10, 16, 10), metal(BRASS)),
        box("cord", (7.6, 10, 7.6), (8.4, 15.2, 8.4), solid(IRON[3]), "nsew"),
        box("neck", (7.1, 9.2, 7.1), (8.9, 10.2, 8.9), metal(BRASS)),
        box("disc", (3, 8.6, 3), (13, 9.2, 13), faces(metal(BRASS), u=mat(BRASS, lo=0.15, hi=0.6), d=mat(BRASS, lo=0.0, hi=0.3))),
        box("socket", (6.5, 5.8, 6.5), (9.5, 8.6, 9.5), metal(BRASS)),
        box("ring", (6.3, 5.4, 6.3), (9.7, 5.9, 9.7), metal(BRASS)),
        box("bulb", (6.7, 3.8, 6.7), (9.3, 5.4, 9.3), mat(glow, lo=0.1, hi=0.4)),
        box("bulb_tip", (7.2, 3.2, 7.2), (8.8, 3.8, 8.8), mat(glow, lo=0.0, hi=0.2)),
    ]


def planter():
    def leaves(w, h, f):
        rng = np.random.RandomState(seed_of("leaf", w, h, f))
        im = cm.canvas(w, h)
        x = 0
        while x < w:
            top = rng.randint(0, max(1, h * 2 // 3))
            tone = rng.randint(1, 4)
            for y in range(top, h):
                cm.put(im, x, y, LEAF[tone if y > top + 1 else max(0, tone - 1)])
                if (y + x) % 4 == 0 and x + 1 < w:
                    cm.put(im, x + 1, y, LEAF[min(4, tone + 1)])
            x += 1 if rng.rand() < 0.75 else 2
        return im

    def pot(w, h, f):
        im = shaded(w, h, WHITE, 0.05, 0.5, 0.03, seed_of("pot", f))
        if h >= 6:
            cm.rect(im, 0, h - 3, w, h - 2, BRASS[2])
        return im

    els = []
    for x in (2.2, 13):
        for z in (5.2, 10):
            els.append(box(f"leg{x}{z}", (x, 0, z), (x + 0.8, 5, z + 0.8), metal(BRASS)))
    els += [
        box("brace_f", (3, 1.4, 5.3), (13, 2, 5.8), metal(BRASS)), box("brace_b", (3, 1.4, 10.2), (13, 2, 10.7), metal(BRASS)),
        box("pot", (2, 5, 5), (14, 9, 11), faces(pot, u=mat(ramp("8A6248", "6E4A35", "563827", "402819", "2C1B10"), noise=0.5, edge=False))),
        box("lip", (1.8, 8.6, 4.8), (14.2, 9.2, 5.3), mat(WHITE, lo=0.0, hi=0.2)),
        box("lip_b", (1.8, 8.6, 10.7), (14.2, 9.2, 11.2), mat(WHITE, lo=0.0, hi=0.2)),
    ]
    for i, (x, z, top) in enumerate(((3, 6.2, 14), (6.5, 8.2, 15.5), (9.5, 6.6, 13.5), (11.4, 9, 12.5), (4.6, 9.4, 12))):
        els.append(box(f"leaf_a{i}", (x - 0.7, 9, z + 0.4), (x + 2.7, top, z + 0.4), leaves, "ns"))
        els.append(box(f"leaf_b{i}", (x + 1.0, 9, z - 1.2), (x + 1.0, top - 1, z + 2.0), leaves, "ew"))
    return els


def chalk_text(im, x, y, text, col):
    font = {"M": "101111111101101", "E": "111100110100111", "N": "101111111111101", "U": "101101101101111",
            "C": "111100100100111", "O": "111101101101111", "F": "111100110100100", " ": "000000000000000",
            "L": "100100100100111", "A": "010101111101101", "T": "111010010010010"}
    for ch in text:
        g = font.get(ch, font[" "])
        for i, bit in enumerate(g):
            if bit == "1":
                cm.put(im, x + i % 3, y + i // 3, col)
        x += 4


def menu_board():
    def slate(w, h, f):
        im = shaded(w, h, SLATE, 0.25, 0.65, 0.12, 7, edge=False)
        chalk, pink, gold = C("F2F0E6"), C("F2A8B8"), C("F4D88C")
        chalk_text(im, 2, 2, "MENU", gold)
        cm.rect(im, 4, 8, w - 4, 9, C("A8B4AC"))
        for k, (a, col) in enumerate(((9, chalk), (11, chalk), (7, pink), (10, chalk))):
            y = 11 + k * 3
            cm.rect(im, 3, y, 3 + a, y + 1, col)
            for x in range(4 + a, w - 8, 2):
                cm.put(im, x, y, C("7E8C84"))
            cm.rect(im, w - 7, y, w - 3, y + 1, gold)
        # a cup doodle
        cx, cy = w - 6, 2
        cm.frame(im, cx, cy + 2, cx + 5, cy + 5, chalk)
        cm.put(im, cx + 5, cy + 3, chalk)
        cm.put(im, cx + 1, cy, chalk)
        cm.put(im, cx + 3, cy, chalk)
        return im

    return [
        box("back", (2, 2, 15.2), (14, 14, 16), faces(wood(WALNUT), n=slate)),
        box("top", (1, 14, 14.6), (15, 15, 16), wood(OAK)), box("bottom", (1, 1, 14.6), (15, 2, 16), wood(OAK)),
        box("left", (1, 2, 14.6), (2, 14, 16), wood(OAK)), box("right", (14, 2, 14.6), (15, 14, 16), wood(OAK)),
        box("shelf", (3, 1, 13.8), (13, 1.5, 14.6), wood(OAK)),
        box("chalk", (4, 1.5, 14), (5.8, 2, 14.4), solid(WHITE[0])), box("chalk2", (6.4, 1.5, 14), (8, 2, 14.4), solid(C("F2A8B8"))),
        box("bow", (7, 14.6, 14.2), (9, 15.6, 14.8), metal(BRASS)),
    ]


GLASS = [(235, 248, 250, 55), (255, 255, 255, 150), (200, 230, 236, 90)]


def glass_pane(w, h, f):
    im = cm.canvas(w, h, GLASS[0])
    cm.frame(im, 0, 0, w, h, GLASS[2])
    for k in range(min(w, h) - 2):
        if k < h // 2 + 2:
            cm.put(im, 1 + k // 2, 1 + k, GLASS[1])
    if w > 6:
        cm.rect(im, w - 3, 2, w - 2, h - 3, GLASS[1])
    return im


def tip_jar():
    def coins(w, h, f):
        rng = np.random.RandomState(seed_of("coin", w, h, f))
        im = cm.canvas(w, h, BRASS[3])
        for y in range(h):
            for x in range(w):
                im[y, x] = BRASS[rng.randint(0, 5)] if rng.rand() < 0.9 else WHITE[3]
        return im

    def label(w, h, f):
        im = shaded(w, h, ramp("FFF8E4", "F8EAC8", "EBD7A8", "D3BA84", "A88F5E"), 0.1, 0.4, 0)
        if w >= 7:
            cx = w // 2
            for dx, dy in ((-2, 1), (-1, 1), (1, 1), (2, 1), (-2, 2), (-1, 2), (0, 2), (1, 2), (2, 2), (-1, 3), (0, 3), (1, 3), (0, 4)):
                cm.put(im, cx + dx, dy, C("D9707E"))
        return im

    bill = ramp("D9EFD0", "BADCAE", "9AC490", "769E6E", "547552")
    return [
        box("coins", (5.6, 0.4, 5.6), (10.4, 3, 10.4), coins),
        box("bill", (6.2, 3, 7.6), (9, 6.2, 7.9), mat(bill, lo=0.1, hi=0.5)),
        box("bill2", (7.8, 3, 8.8), (10, 5, 9.1), mat(bill, lo=0.2, hi=0.6)),
        box("label", (6, 3, 4.9), (10, 6, 5), label, "n"),
        box("glass", (5.2, 0, 5.2), (10.8, 7.6, 10.8), faces(glass_pane)),
        box("neck", (5.8, 7.6, 5.8), (10.2, 8.4, 10.2), glass_pane, "nsew"),
        box("lid", (5.5, 8.4, 5.5), (10.5, 9.4, 10.5), metal(BRASS)),
        box("slot", (6.8, 9.4, 7.6), (9.2, 9.5, 8.4), solid(C("3A2A1A")), "u"),
    ]


def coffee_grinder():
    def front(w, h, f):
        im = wood(WALNUT)(w, h, f)
        cm.frame(im, 2, 1, w - 2, h - 1, BRASS[3])
        cm.rect(im, w // 2 - 1, h // 2 - 1, w // 2 + 1, h // 2 + 1, BRASS[0])
        return im

    def beans(w, h, f):
        rng = np.random.RandomState(seed_of("bean", w, h, f))
        im = cm.canvas(w, h, BEAN[3])
        for y in range(h):
            for x in range(w):
                im[y, x] = BEAN[rng.randint(0, 4)]
        return im

    return [
        box("foot", (4, 0, 4), (12, 1, 12), wood(OAK)),
        box("case", (4.5, 1, 4.5), (11.5, 6, 11.5), faces(wood(WALNUT), n=front)),
        box("cap", (4, 6, 4), (12, 7, 12), wood(OAK)),
        box("collar", (5.5, 7, 5.5), (10.5, 8, 10.5), metal(BRASS)),
        box("bowl", (5, 8, 5), (11, 10.4, 11), faces(metal(BRASS), u=beans)),
        box("rim", (4.7, 10.4, 4.7), (11.3, 10.9, 5.3), metal(BRASS)), box("rim_b", (4.7, 10.4, 10.7), (11.3, 10.9, 11.3), metal(BRASS)),
        box("rim_l", (4.7, 10.4, 5.3), (5.3, 10.9, 10.7), metal(BRASS)), box("rim_r", (10.7, 10.4, 5.3), (11.3, 10.9, 10.7), metal(BRASS)),
        box("heap", (6, 10.4, 6), (10, 11.2, 10), beans),
        box("axle", (7.6, 11.2, 7.6), (8.4, 13.6, 8.4), metal(IRON)),
        box("arm", (8.4, 13, 7.7), (12.6, 13.6, 8.3), metal(IRON)),
        box("pin", (11.8, 13.6, 7.7), (12.4, 14.2, 8.3), metal(IRON)),
        box("handle", (11.4, 14.2, 7.3), (12.8, 15.4, 8.7), wood(OAK)),
    ]


def cake_stand():
    sponge = ramp("FBE3B4", "F0CC8E", "DBAE6C", "B98A4E", "8E6536")
    cream = ramp("FFFDF8", "FCEFE8", "F3DCD4", "DFC0B8", "BC9A92")
    pink = ramp("FFD9E2", "F7B4C4", "E8889F", "C76680", "9A4660")

    def side(w, h, f):
        im = shaded(w, h, sponge, 0.15, 0.5, 0.1, 3, edge=False)
        cm.rect(im, 0, h // 2, w, h // 2 + 1, pink[2])
        cm.rect(im, 0, 0, w, 1, cream[0])
        for x in range(0, w, 3):
            cm.put(im, x, 1, cream[1])
        return im

    return [
        box("foot", (5, 0, 5), (11, 0.8, 11), mat(WHITE)),
        box("stem", (6.8, 0.8, 6.8), (9.2, 3.4, 9.2), metal(BRASS)),
        box("plate", (2, 3.4, 2), (14, 4.2, 14), faces(mat(WHITE, lo=0.0, hi=0.3), d=mat(WHITE, lo=0.4, hi=0.7))),
        box("cake", (4.5, 4.2, 4.5), (11.5, 7, 11.5), faces(side, u=mat(cream, lo=0.0, hi=0.3))),
        box("berry1", (5.4, 7, 5.4), (6.8, 8.2, 6.8), mat(ramp("FF9A8C", "E2574C", "C23A38", "96282C", "6A1A20"))),
        box("berry2", (9.2, 7, 9.2), (10.6, 8.2, 10.6), mat(ramp("FF9A8C", "E2574C", "C23A38", "96282C", "6A1A20"))),
        box("berry3", (9.2, 7, 5.4), (10.6, 8, 6.8), mat(pink)), box("berry4", (5.4, 7, 9.2), (6.8, 8, 10.6), mat(pink)),
        box("rose", (7.1, 7, 7.1), (8.9, 8.4, 8.9), mat(cream)),
        box("dome", (3, 4.2, 3), (13, 10.6, 13), glass_pane, "nsew"),
        box("dome_top", (4, 10.6, 4), (12, 11.6, 12), glass_pane, "nsewu"),
        box("dome_cap", (7, 11.6, 7), (9, 13, 9), metal(BRASS)),
    ]


def cup_stack():
    def cup(accent):
        def side(w, h, f):
            im = shaded(w, h, WHITE, 0.0, 0.45, 0, edge=False)
            cm.rect(im, 0, 0, w, 1, WHITE[0])
            if h > 3:
                cm.rect(im, 0, 2, w, 3, accent)
            cm.rect(im, 0, h - 1, w, h, WHITE[3])
            return im

        def top(w, h, f):
            im = cm.canvas(w, h, WHITE[1])
            cm.rect(im, 1, 1, w - 1, h - 1, WHITE[3])
            cm.rect(im, 2, 2, w - 1, h - 1, WHITE[2])
            return im
        return faces(side, u=top)

    els = [box("tray", (2, 0, 4), (14, 0.8, 12), wood(OAK, 4))]
    colors = [ACCENT["cream"][2], BODY["rose"][3], BRASS[2]]
    for col, (x, n) in enumerate(((2.6, 3), (7.0, 2))):
        for i in range(n):
            y = 0.8 + i * 2.7
            c = colors[(col + i) % 3]
            els.append(box(f"cup{col}_{i}", (x, y + 0.2, 5.6), (x + 3.4, y + 2.7, 9), cup(c)))
            els.append(box(f"ear{col}_{i}", (x + 1.2, y + 0.9, 9), (x + 2.2, y + 2.1, 9.8), mat(WHITE)))
    els += [box("saucer", (11, 0.8, 6.5), (13.8, 1.3, 10.5), mat(WHITE)), box("saucer2", (11.2, 1.5, 6.7), (13.6, 2, 10.3), mat(WHITE)),
            box("cube1", (11.7, 2, 7.4), (12.9, 3.2, 8.6), mat(WHITE)), box("cube2", (11.9, 2, 8.8), (13.1, 3.2, 10), mat(WHITE, lo=0.1, hi=0.5)),
            box("spoon", (3, 0.8, 10.4), (8.5, 1.1, 10.9), metal(BRASS)), box("spoon_bowl", (8.5, 0.8, 10.1), (10, 1.2, 11.2), metal(BRASS))]
    return els


def bean_sack():
    def burlap(w, h, f):
        rng = np.random.RandomState(seed_of("sack", w, h, f))
        im = shaded(w, h, BURLAP, 0.15, 0.6, 0.0, edge=False)
        for y in range(h):
            for x in range(w):
                if (x + y) % 2 == 0 and rng.rand() < 0.45:
                    im[y, x] = BURLAP[rng.randint(1, 4)]
        return im

    def front(w, h, f):
        im = burlap(w, h, f)
        cx, cy = w // 2, h // 2
        cm.disc(im, cx, cy, 5.2, BEAN[2])
        cm.disc(im, cx, cy, 4.0, BURLAP[0])
        cm.disc(im, cx, cy, 2.6, BEAN[2])
        for k in range(-2, 3):
            cm.put(im, cx + (1 if k < 0 else -1 if k > 0 else 0), cy + k, BURLAP[0])
        return im

    def beans(w, h, f):
        rng = np.random.RandomState(seed_of("beans", w, h, f))
        im = cm.canvas(w, h, BEAN[3])
        for y in range(0, h, 2):
            for x in range((y // 2) % 2, w, 3):
                cm.rect(im, x, y, x + 2, y + 2, BEAN[rng.randint(0, 3)])
                cm.put(im, x, y + 1, BEAN[4])
        return im

    return [
        box("belly", (3, 0, 3.5), (13, 5, 12.5), faces(burlap, n=front)),
        box("waist", (3.5, 5, 4), (12.5, 8.4, 12), burlap),
        box("roll_f", (3, 8.4, 3.5), (13, 9.8, 5), burlap), box("roll_b", (3, 8.4, 11), (13, 9.8, 12.5), burlap),
        box("roll_l", (3, 8.4, 5), (4.5, 9.8, 11), burlap), box("roll_r", (11.5, 8.4, 5), (13, 9.8, 11), burlap),
        box("beans", (4.5, 8.4, 5), (11.5, 9.4, 11), beans),
        box("heap", (5.8, 9.4, 6.2), (10.2, 10.4, 9.8), beans),
        box("scoop", (8.2, 10, 7), (10.4, 11, 9), metal(BRASS)), box("scoop_h", (10.4, 10.6, 7.6), (13.6, 11.4, 8.4), wood(OAK)),
        box("spill1", (2, 0, 1.8), (3.2, 0.7, 2.8), beans), box("spill2", (4.2, 0, 1.2), (5.2, 0.6, 2.2), beans),
    ]


DECOR = {  # id -> (builder, cutout/translucent, recipe pattern, recipe key)
    "pendant_lamp": (pendant_lamp, None, [" C ", " G ", " T "], {"C": "chain", "G": "gold_ingot", "T": "torch"}),
    "cafe_planter": (planter, "minecraft:cutout", ["S S", "QFQ", "G G"], {"S": "wheat_seeds", "Q": "quartz", "F": "flower_pot", "G": "gold_nugget"}),
    "menu_board": (menu_board, None, ["PPP", "PBP", "PPP"], {"P": "oak_planks", "B": "black_dye"}),
    "tip_jar": (tip_jar, "minecraft:translucent", [" G ", "P P", "PPP"], {"G": "gold_nugget", "P": "glass_pane"}),
    "coffee_grinder": (coffee_grinder, None, [" S ", " G ", "PIP"], {"S": "stick", "G": "gold_ingot", "P": "dark_oak_planks", "I": "iron_ingot"}),
    "cake_stand": (cake_stand, "minecraft:translucent", [" G ", "GCG", " Q "], {"G": "glass_pane", "C": "cake", "Q": "quartz"}),
    "cup_stack": (cup_stack, None, ["B B", "B B", "PPP"], {"B": "brick", "P": "oak_slab"}),
    "bean_sack": (bean_sack, None, ["S S", "WCW", "WWW"], {"S": "string", "W": "wheat", "C": "cocoa_beans"}),
}

DISPLAY = dict(cm.DISPLAY)
DISPLAY["gui"] = {"rotation": [30, 225, 0], "translation": [0, 0, 0], "scale": [0.625, 0.625, 0.625]}


# ------------------------------------------------------------------------------------------ atlas + files
def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)
        f.write("\n")


def atlas_of(elements):
    jobs = []
    for i, el in enumerate(elements):
        for d in el["faces"]:
            w, h = cm.face_size(el, d)
            fn = el["paint"].get(d) or el["paint"]["*"]
            im = fn(w, h, d)
            assert im.shape[:2] == (h, w), (el["name"], d)
            jobs.append((i, d, w, h, im))
    jobs.sort(key=lambda j: (-j[3], -j[2]))
    size = 64
    while True:
        x = y = row = 0
        place = {}
        for i, d, w, h, im in jobs:
            if x + w + GUTTER * 2 > size:
                x, y, row = 0, y + row, 0
            place[(i, d)] = (x + GUTTER, y + GUTTER, w, h, im)
            x += w + GUTTER * 2
            row = max(row, h + GUTTER * 2)
        if y + row <= size:
            break
        size *= 2
    atlas = np.zeros((size, size, 4), np.uint8)
    for px, py, w, h, im in place.values():
        atlas[py - GUTTER:py + h + GUTTER, px - GUTTER:px + w + GUTTER] = np.pad(im, ((GUTTER, GUTTER), (GUTTER, GUTTER), (0, 0)), "edge")
    return atlas, place, size


def write_model(name, elements, render_type=None, particle=None):
    atlas, place, size = atlas_of(elements)
    os.makedirs(os.path.join(ASSETS, "textures", "block"), exist_ok=True)
    Image.fromarray(atlas, "RGBA").save(os.path.join(ASSETS, "textures", "block", name + ".png"))
    out = []
    for i, el in enumerate(elements):
        fs = {}
        for d in el["faces"]:
            px, py, w, h, _ = place[(i, d)]
            k = 16.0 / size
            fs[cm.DIRS[d]] = {"uv": [round(px * k, 5), round(py * k, 5), round((px + w) * k, 5), round((py + h) * k, 5)], "texture": "#t"}
        out.append({"name": el["name"], "from": [round(v, 3) for v in el["f"]], "to": [round(v, 3) for v in el["t"]], "faces": fs})
    model = {"parent": "minecraft:block/block"}
    if render_type:
        model["render_type"] = render_type
    tex = f"aestheticjobs:block/{name}"
    model.update({"texture_size": [size, size], "textures": {"particle": tex, "t": tex}, "elements": out, "display": DISPLAY})
    write_json(os.path.join(ASSETS, "models", "block", name + ".json"), model)


Y = {"north": 0, "east": 90, "south": 180, "west": 270}


def variant(model, facing):
    v = {"model": "aestheticjobs:block/" + model}
    if Y[facing]:
        v["y"] = Y[facing]
    return v


def loot(block, copy=None):
    entry = {"type": "minecraft:item", "name": "aestheticjobs:" + block}
    if copy:
        entry["functions"] = [{"function": "minecraft:copy_state", "block": "aestheticjobs:" + block, "properties": copy}]
    write_json(os.path.join(DATA, "loot_table", "blocks", block + ".json"),
               {"type": "minecraft:block", "pools": [{"rolls": 1, "entries": [entry],
                                                      "conditions": [{"condition": "minecraft:survives_explosion"}]}]})


def main():
    # the register in every paint
    for style in STYLES:
        write_model("cafe_register" if style == "cream" else "cafe_register_" + style, register(style))
    write_json(os.path.join(ASSETS, "blockstates", "cafe_register.json"), {"variants": {
        f"facing={f},style={s}": variant("cafe_register" if s == "cream" else "cafe_register_" + s, f) for f in Y for s in STYLES}})
    loot("cafe_register", ["style"])

    # the coffee machine: same UVs, one texture per paint
    cream, mint = list(cm.CREAM), list(cm.MINT)
    for style in STYLES:
        cm.CREAM[:] = cream if style == "cream" else BODY[style]
        cm.MINT[:] = mint if style == "cream" else ACCENT[style]
        atlas, place, aw, ah = cm.build()
        tex = "coffee_machine" if style == "cream" else "coffee_machine_" + style
        Image.fromarray(atlas, "RGBA").save(os.path.join(ASSETS, "textures", "block", tex + ".png"))
        for suffix, static in (("", True), ("_brewing", False)):
            if style == "cream":
                write_json(os.path.join(ASSETS, "models", "block", "coffee_machine" + suffix + ".json"), cm.model(place, aw, ah, static))
            else:
                t = "aestheticjobs:block/" + tex
                write_json(os.path.join(ASSETS, "models", "block", f"coffee_machine_{style}{suffix}.json"),
                           {"parent": "aestheticjobs:block/coffee_machine" + suffix, "textures": {"particle": t, "t": t}})
    cm.CREAM[:], cm.MINT[:] = cream, mint

    def machine(style, brewing):
        return "coffee_machine" + ("" if style == "cream" else "_" + style) + ("_brewing" if brewing == "true" else "")
    write_json(os.path.join(ASSETS, "blockstates", "coffee_machine.json"), {"variants": {
        f"brewing={b},facing={f},style={s}": variant(machine(s, b), f) for b in ("false", "true") for f in Y for s in STYLES}})
    loot("coffee_machine", ["style"])

    # decorations
    for name, (build, rtype, pattern, key) in DECOR.items():
        write_model(name, build(), rtype)
        write_json(os.path.join(ASSETS, "blockstates", name + ".json"),
                   {"variants": {f"facing={f}": variant(name, f) for f in Y}})
        write_json(os.path.join(ASSETS, "models", "item", name + ".json"), {"parent": "aestheticjobs:block/" + name})
        loot(name)
        write_json(os.path.join(DATA, "recipe", name + ".json"), {
            "type": "minecraft:crafting_shaped", "category": "misc", "pattern": pattern,
            "key": {k: {"item": "minecraft:" + v} for k, v in key.items()},
            "result": {"id": "aestheticjobs:" + name, "count": 1}})

    tag = os.path.join(RES, "data", "minecraft", "tags", "block", "mineable", "axe.json")
    write_json(tag, {"values": ["aestheticjobs:" + n for n in ("cafe_planter", "menu_board", "coffee_grinder", "bean_sack",
                                                           "fruit_basket", "greens_basket", "sushi_board")]})
    print("done:", len(STYLES), "paints,", len(DECOR), "decorations")


if __name__ == "__main__":
    main()
