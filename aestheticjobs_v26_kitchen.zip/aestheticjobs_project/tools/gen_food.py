#!/usr/bin/env python3
"""The 3D food of the cafe: 8 drinks, 32 desserts (also each of them on a plate), the supplies and the empty cup.

    python3 tools/gen_food.py                 # writes models/item/*.json and textures/item/food3d/*.png
    python3 tools/gen_food.py --check         # verifies the written models (no overlaps, no holes, UVs, overrides)

The 2D sprites textures/item/<id>.png stay: the screens of the mod (ticket, menus, bubbles) draw them.
Coordinates are voxels (32 per block side), y is up, the front of the food looks north (small z).
"""
import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from voxel_food import Vox, build, display, grain, mix, rgb, rnd  # noqa: E402
from smooth import fighting_faces  # noqa: E402

ASSETS = os.path.join(HERE, "..", "src", "main", "resources", "assets", "aestheticjobs")
FOOD = {}


def food(fn):
    FOOD[fn.__name__] = fn
    return fn


# ------------------------------------------------------------------------------------------------ materials
PORC, PORC_D, PORC_DD, GOLD, GOLD_L = "F6F1EC", "E2D9D2", "C9BDB6", "D9B25E", "F2D78E"
ESPRESSO, COFFEE, COFFEE_L, LATTE, LATTE_L = "45281E", "6A4030", "8F5E42", "C4915F", "E0B98A"
MILK, FOAM, FOAM_D, CREMA = "FFF8EC", "FBEFD6", "EEDCB6", "C98F58"
CHOC, CHOC_D, CHOC_L = "62392A", "47271C", "855540"
CREAM, CREAM_D = "FFF4E0", "F2E0C0"
PINK, PINK_D, PINK_L = "F4ABC0", "DF7F9C", "FCD3DE"
RED, RED_D, RED_L = "D8434F", "A92E3C", "F0767A"
CARAMEL, CARAMEL_D, CARAMEL_L = "D8923C", "B06E26", "F0B964"

crust = grain("D89A55", "E8B26C", "BC7C3E", 1)
dough = grain("EBBD78", "F6D396", "D5A05A", 2)
sponge = grain("F3D08E", "FBE0A8", "DFB46C", 3)
sponge_choc = grain("6E4130", "855340", "583022", 4)
honey = grain("D69448", "E8AC5C", "B87830", 5)
cheese = grain("FBE7B0", "FFF0C4", "F0D694", 6, 0.15)
cream = grain(CREAM, "FFFCF4", CREAM_D, 7, 0.15)
choc = grain(CHOC, "6F4332", "583224", 8, 0.18)


def radius(x, z, cx=16.0, cz=16.0):
    return math.hypot(x + 0.5 - cx, z + 0.5 - cz)


def angle(x, z, cx=16.0, cz=16.0):
    return math.atan2(z + 0.5 - cz, x + 0.5 - cx)


def strawberry(v, cx, y, cz, big=True):
    r = 2.6 if big else 1.8

    def skin(x, yy, z):
        return "F6D86A" if rnd(x, yy, z, 31) < 0.12 else RED if yy < y + r else RED_L
    v.ball(cx, y + r * 0.9, cz, r, skin, ry=r * 1.1, ymin=y)
    top = int(y + r * 2)
    for dx, dz in ((0, 0), (1, 0), (-1, 0), (0, 1)):
        v.put(int(cx) + dx, top, int(cz) + dz, "5E9A48" if (dx, dz) != (0, 0) else "77B45A")


def blueberry(v, x, y, z):
    v.box(x, y, z, x + 2, y + 2, z + 2, "4C5496")
    v.put(x, y + 1, z, "8089C8")


def leaf(v, x, y, z):
    for dx, dz in ((0, 0), (1, 0), (1, 1), (2, 1)):
        v.put(x + dx, y, z + dz, "6FAE55" if dx % 2 == 0 else "8DC76E")


def octa(x, z, cx=16.0, cz=16.0):
    """The distance from the centre measured like an octagon."""
    dx, dz = abs(x + 0.5 - cx), abs(z + 0.5 - cz)
    return max(dx, dz, (dx + dz) * 0.7071)


def swirl(v, cx, cz, y, r, col_a, col_b, layers=3):
    """A piped rosette of cream: shrinking octagons in two shades."""
    for i in range(layers):
        rr = r * (1 - i / (layers + 0.35))
        side = col_b if i % 2 else col_a
        v.disc(rr, y + i * 2, y + i * 2 + 2, side, cx, cz,
               top=lambda x, yy, z, side=side, rr=rr: col_b if octa(x, z, cx, cz) > rr - 1.4 else col_a)
    c = int(cx) - 1
    d = int(cz) - 1
    v.box(c, y + layers * 2, d, c + 2, y + layers * 2 + 1, d + 2, col_a)


# ------------------------------------------------------------------------------------------------ cups
def saucer(v):
    v.disc(8.5, 0, 1, PORC_DD)
    flowers = posies(9.6, 8)
    v.disc(12.5, 1, 2, PORC_D, top=lambda x, y, z: flowers.get((x, z)) or (GOLD if 11.0 < octa(x, z) <= 11.8 else PORC))


def handle(v, x0, y0, y1, col=PORC, col_d=PORC_D):
    """A ring handle on the east side."""
    v.slab(x0, y1 - 2, 15, x0 + 4, y1, 17, col)
    v.slab(x0, y0, 15, x0 + 4, y0 + 2, 17, col_d)
    v.slab(x0 + 2, y0 + 2, 15, x0 + 4, y1 - 2, 17, col)


def china_cup(r, y0, h, surface, band=PINK, with_handle=True):
    """A porcelain cup on a saucer; surface(x, z) gives the colour of the drink."""
    v = Vox()
    saucer(v)
    top = y0 + h

    def wall(x, y, z):
        if y == top - 1:
            return GOLD_L
        if y0 + h // 2 - 1 <= y <= y0 + h // 2:
            return band
        return PORC_D if y == y0 else PORC
    v.disc(r - 1.6, y0, y0 + 1, PORC_D)
    v.disc(r - 1.0, y0 + 1, top - 2, PORC_D, top=lambda x, y, z: surface(x, z))
    v.ring(r, 1.2, y0 + 1, top, wall, top=GOLD_L, inner=PORC_D)
    if with_handle:
        handle(v, int(16 + r), y0 + 2, top - 1)
    return v


def rosetta(x, z):
    dx, dz = x + 0.5 - 16, z + 0.5 - 16
    if abs(dx) < 0.8 and -4 < dz < 5:
        return MILK
    leaf_band = (dz + abs(dx) * 0.8) % 2.4 < 1.2
    if (dx / 4.6) ** 2 + ((dz + 0.3) / 5.0) ** 2 <= 1:
        return MILK if leaf_band else LATTE_L
    return CREMA


def heart_art(x, z):
    px, pz = (x + 0.5 - 16) / 4.0, -(z + 0.5 - 16) / 4.0 + 0.15
    if (px * px + pz * pz - 0.8) ** 3 - px * px * pz ** 3 <= 0:
        return MILK
    return CREMA


@food
def cup_espresso():
    return china_cup(6.5, 2, 8, lambda x, z: CREMA if octa(x, z) > 3.2 else "DDA66C" if octa(x, z) > 1.8 else "A86C40", GOLD)


@food
def cup_flat_white():
    return china_cup(8.2, 2, 8, rosetta, "A9CFC0")


@food
def cup_cappuccino():
    v = china_cup(8.4, 2, 9, lambda x, z: FOAM, PINK)
    dust = lambda x, y, z: CHOC_L if rnd(x, 0, z, 11) < 0.3 else FOAM
    v.disc(6.6, 9, 12, FOAM_D, top=FOAM)
    v.disc(4.4, 12, 14, FOAM, top=dust)
    return v


def mug(r, h, layers, surface, col=PORC):
    """A tall glass: layers = [(height share, colour)] seen through it; surface(x, y, z) paints what is on top."""
    v = Vox()
    v.disc(r + 1.6, 0, 1, GOLD, top=lambda x, y, z: GOLD_L if octa(x, z) > r + 0.4 else GOLD)

    def wall(x, y, z):
        t = (y - 1) / float(h)
        acc = 0
        c = layers[-1][1]
        for share, colr in layers:
            acc += share
            if t < acc:
                c = colr
                break
        a = angle(x, z)
        if -2.45 < a < -2.1 and 2 < y < h - 1:
            return mix(rgb(c), (255, 255, 255), 0.55)                 # the shine of the glass
        if y in (1, h):
            return "DCE9EC"
        return c
    v.disc(r, 1, h + 1, wall, top="DCE9EC")
    v.disc(r - 0.9, h + 1, h + 2, "EAF3F5", top=surface)
    return v


@food
def cup_latte():
    return mug(6.4, 19, [(0.2, MILK), (0.18, LATTE_L), (0.34, LATTE), (0.1, LATTE_L), (0.3, FOAM)],
               lambda x, y, z: heart_art(x, z))


@food
def cup_macchiato():
    v = mug(6.4, 19, [(0.4, MILK), (0.1, LATTE_L), (0.22, ESPRESSO), (0.08, LATTE), (0.3, FOAM)],
            lambda x, y, z: CARAMEL if (x % 3 == 0 or z % 3 == 0) else FOAM)
    v.slab(14, 14, 8.6, 16, 21, 9.8, CARAMEL_D)
    v.slab(22.2, 16, 15, 23.2, 21, 17, CARAMEL_D)
    return v


@food
def cup_americano():
    v = mug(6.8, 14, [(0.8, ESPRESSO), (0.08, COFFEE), (0.2, CREMA)],
            lambda x, y, z: CREMA if octa(x, z) > 3 else "E0AE74" if octa(x, z) > 1.5 else CREMA)
    handle(v, 23, 4, 13, "DCE9EC", "C4D6DC")
    return v


@food
def cup_raf():
    v = mug(6.8, 14, [(0.25, COFFEE_L), (0.35, LATTE), (0.3, LATTE_L), (0.2, FOAM)], lambda x, y, z: FOAM)
    swirl(v, 16, 16, 16, 5.4, CREAM, FOAM_D)
    v.sprinkle([CARAMEL, CARAMEL_L, "F6E49D"], 14, 41, lambda x, y, z: y >= 18)
    handle(v, 23, 4, 13, "DCE9EC", "C4D6DC")
    return v


@food
def cup_mocha():
    v = mug(6.8, 14, [(0.3, CHOC_D), (0.35, CHOC), (0.2, CHOC_L), (0.2, FOAM)], lambda x, y, z: FOAM)
    swirl(v, 16, 16, 16, 5.8, CREAM, CREAM_D)
    v.sprinkle([CHOC, CHOC_D], 22, 42, lambda x, y, z: y >= 18)
    handle(v, 23, 4, 13, "DCE9EC", "C4D6DC")
    return v


@food
def empty_cup():
    return china_cup(7.8, 2, 9, lambda x, z: PORC_DD if octa(x, z) < 4.5 else PORC_D, PINK_L)


# ------------------------------------------------------------------------------------------------ pastry
@food
def croissant():
    v = Vox()
    steps = 60
    for i in range(steps + 1):
        t = i / steps * 2 - 1                                          # -1 .. 1 along the crescent
        a = t * 1.25
        cx, cz = 16 + math.sin(a) * 10.5, 9.5 + math.cos(a) * 8.5
        r = 1.2 + 4.4 * (1 - abs(t) ** 1.7)

        def col(x, y, z, t=t):
            fold = int((t + 1) * 6.0 + y * 0.25) % 2
            if y >= 5:
                return "E9A84F" if fold else "C77F32"
            return "F2C373" if fold else "DD9F4C"
        v.ball(cx, r * 0.82, cz, r, col, ry=r * 0.82)
    return v


def donut(glaze, glaze_l, sprinkles):
    v = Vox()
    R, r = 7.4, 4.2

    def inside(x, y, z):
        q = math.hypot(x - 16, z - 16) - R
        return q * q + ((y - 4.0) / 0.92) ** 2 <= r * r

    def col(x, y, z):
        drip = 4 + int(1.6 * math.sin(angle(x, z) * 7)) if True else 4
        if y >= drip:
            return glaze_l if rnd(x, y, z, 12) < 0.1 else glaze
        if y == 3:
            return "F6D9A0"
        return dough(x, y, z)
    v.fill(inside, col, 0, 10)
    v.sprinkle(sprinkles, 26, 13, lambda x, y, z: y >= 6)
    return v


@food
def donut_pink():
    return donut(PINK, PINK_L, [MILK, "8FD3C0", "F6E27A", "A9B4F0", MILK])


@food
def donut_choc():
    return donut(CHOC, CHOC_L, ["F4ABC0", CREAM, "F6E27A", CARAMEL_L])


def cupcake(paper, paper_d, frosting, frosting_d, base, sprinkles, cherry=True):
    v = Vox()
    pleats = lambda x, yy, z: paper if int((angle(x, z) + math.pi) * 5.1) % 2 else paper_d
    for i, r in enumerate((5.8, 6.8, 7.8)):
        v.disc(r, i * 3, i * 3 + 3, pleats)
    v.disc(8.8, 9, 10, base)
    swirl(v, 16, 16, 10, 8.4, frosting, frosting_d)
    v.sprinkle(sprinkles, 16, 14, lambda x, y, z: 11 <= y)
    if cherry:
        y = v.top(16, 16) + 1
        v.disc(1.8, y, y + 1, RED_D)
        v.disc(2.4, y + 1, y + 3, RED, top=lambda x, yy, z: RED_L if x < 16 and z < 16 else RED)
        v.disc(1.6, y + 3, y + 4, RED)
        v.slab(15.6, y + 4, 15.6, 16.4, y + 7, 16.4, "5E8A3E")
    return v


@food
def cupcake_pink():
    return cupcake("F2A8B8", "DC8298", PINK_L, PINK, sponge, [MILK, "8FD3C0", PINK_D])


@food
def cupcake_choc():
    return cupcake("8A5A44", "6C422F", CHOC_L, CHOC, sponge_choc, [CREAM, CARAMEL_L], True)


@food
def muffin_blueberry():
    v = Vox()
    pleats = lambda x, yy, z: "A993CE" if int((angle(x, z) + math.pi) * 5.1) % 2 else "8B74B4"
    for i, r in enumerate((6.0, 7.0, 8.0)):
        v.disc(r, i * 3, i * 3 + 3, pleats)
    berries = grain("E2AA60", "F0C27C", "C98E48", 15)
    cap = lambda x, y, z: "4E5898" if rnd(x // 2, y // 2, z // 2, 16) < 0.18 else berries(x, y, z)
    v.disc(10.2, 9, 12, cap)
    v.disc(8.6, 12, 14, cap)
    v.disc(5.8, 14, 15, cap)
    v.sprinkle([MILK], 14, 17, lambda x, y, z: y >= 14)
    return v


@food
def cream_puff():
    v = Vox()
    v.disc(8.4, 0, 2, dough)
    v.disc(9.8, 2, 6, dough)
    v.disc(10.4, 6, 9, lambda x, yy, z: MILK if int(angle(x, z) * 4.5) % 2 else CREAM_D, top=CREAM)
    v.disc(9.6, 9, 12, crust)
    v.disc(7.8, 12, 14, crust)
    v.disc(5.0, 14, 15, crust)
    v.sprinkle([MILK, "FFFFFF"], 34, 18, lambda x, y, z: y >= 12)
    return v


@food
def eclair():
    v = Vox()

    def inside(x, y, z):
        px = max(abs(x - 16) - 8.0, 0.0)
        return px * px + ((y - 3.6) / 0.95) ** 2 + (z - 16) ** 2 <= 4.4 ** 2

    def col(x, y, z):
        if y >= 5:
            return CHOC_L if (z == 14 and 8 < x < 23) else CHOC
        if y == 4:
            return CREAM
        return dough(x, y, z)
    v.fill(inside, col, 0, 9)
    v.sprinkle([CREAM, GOLD_L], 9, 19, lambda x, y, z: y >= 7 and 7 < x < 24)
    return v


@food
def cinnamon_roll():
    v = Vox()

    def spiral(x, z):
        a = angle(x, z) / (2 * math.pi)
        return (radius(x, z) / 3.4 - a) % 1.0 < 0.34
    side = lambda x, y, z: "A4602C" if int((angle(x, z) + math.pi) * 3.0) % 3 == 0 else dough(x, y, z)

    def icing(x, y, z):
        if abs(((x + z * 0.35) % 7) - 3.5) < 0.9 or radius(x, z) < 1.8:
            return "FFF9EE"
        return "A4602C" if spiral(x, z) else dough(x, y, z)
    v.disc(10.6, 0, 5, side, top=icing)
    v.disc(7.6, 5, 7, side, top=icing)
    for x, z in ((9, 5.0), (19, 26.2)):
        v.slab(x, 2, z, x + 2, 4.9, z + 0.8, "FFF9EE")
    return v


@food
def cookie_choc():
    v = Vox()
    c = grain("DDA052", "EAB66A", "C28338", 20)
    v.disc(10.8, 0, 3, c)
    v.disc(9.2, 3, 4, c)
    for i, (x, z) in enumerate(((12, 11), (18, 10), (21, 16), (15, 16), (10, 17), (17, 20), (13, 21))):
        v.box(x - 1, 4, z - 1, x + 1 + i % 2, 5, z + 1, choc)
    return v


def turned(v):
    """Turns a model by 180 degrees around the vertical axis."""
    out = Vox()
    out.g = {(31 - x, y, 31 - z): c for (x, y, z), c in v.g.items()}
    return out


def heart_inside(x, z, s):
    px, pz = (x - 16) / s, (z - 17.0) / s                             # the point of the heart faces the front
    return (px * px + pz * pz - 1) ** 3 - px * px * pz ** 3 <= 0


@food
def cookie_heart():
    v = Vox()
    v.fill(lambda x, y, z: heart_inside(x, z, 9.2), dough, 0, 3)
    v.fill(lambda x, y, z: heart_inside(x, z, 7.6), PINK, 3, 4)
    v.fill(lambda x, y, z: heart_inside(x, z, 4.8) and not heart_inside(x, z, 3.4), MILK, 3, 4)
    v.sprinkle([MILK, "F6E27A"], 8, 21, lambda x, y, z: y == 3)
    return v


@food
def gingerbread_man():
    v = Vox()
    g = grain("C47E40", "D49454", "A8662E", 22)

    def man(x, z):
        head = math.hypot(x - 16, z - 8) <= 5.0
        body = abs(x - 16) <= 4.2 and 11 <= z <= 22
        arms = abs(z - 15.5) <= 2.3 and abs(x - 16) <= 10.5
        legs = 21 <= z <= 28 and 1.0 <= abs(x - 16) - (z - 21) * 0.35 <= 5.0
        return head or body or arms or legs
    v.fill(lambda x, y, z: man(x, z), g, 0, 3)
    for x, z, c in ((14, 6, CHOC_D), (17, 6, CHOC_D), (14, 9, MILK), (15, 10, MILK), (16, 10, MILK), (17, 9, MILK),
                    (15, 14, RED), (16, 17, "6FAE55"), (15, 20, RED), (6, 14, MILK), (6, 15, MILK), (6, 16, MILK),
                    (25, 14, MILK), (25, 15, MILK), (25, 16, MILK), (11, 25, MILK), (12, 25, MILK), (13, 25, MILK),
                    (18, 25, MILK), (19, 25, MILK), (20, 25, MILK)):
        v.put(x, 3, z, c)
    return turned(v)                                                   # head away from the viewer


def macaron(shell, shell_l, shell_d, filling):
    v = Vox()
    ruffle = lambda x, y, z: shell_d if (x + z) % 2 else shell
    v.disc(8.4, 0, 1, shell)
    v.disc(9.8, 1, 3, shell)
    v.disc(10.4, 3, 4, ruffle)
    v.disc(9.2, 4, 6, filling)
    v.disc(10.4, 6, 7, ruffle)
    v.disc(9.8, 7, 9, shell)
    v.disc(8.2, 9, 10, shell, top=lambda x, y, z: shell_l if octa(x, z, 13, 13) < 3.4 else shell)
    return v


@food
def macaron_pink():
    return macaron(PINK, PINK_L, PINK_D, "FFF0E4")


@food
def macaron_mint():
    return macaron("A9DCC2", "C9EEDB", "7FBF9F", CHOC_L)


@food
def macaron_lemon():
    return macaron("F6DE78", "FFEFA8", "DDBD4E", "FFF8E4")


@food
def cake_pop():
    v = Vox()
    v.disc(6.0, 0, 2, PORC, top=lambda x, y, z: GOLD if octa(x, z) > 4.4 else PORC)
    v.box(15, 2, 15, 17, 12, 17, "F3E3C4")
    v.box(12, 8, 15, 15, 10, 17, "A9CFC0")
    v.box(17, 8, 15, 20, 10, 17, "A9CFC0")
    v.box(15, 7, 14, 17, 11, 15, "8FBFAC")
    v.ball(16, 18, 16, 7.2, lambda x, y, z: PINK_L if (x < 15 and y > 19 and z < 15) else PINK)
    v.sprinkle([MILK, "8FD3C0", "F6E27A", "A9B4F0"], 30, 23, lambda x, y, z: y >= 19)
    return v


# ------------------------------------------------------------------------------------------------ cake slices
def wedge(v, y0, y1, col, inset=0):
    """A slice of cake: the tip points to the front (north), the crust is at the back."""
    def inside(x, y, z):
        if not 6 + inset <= z <= 26 - inset:
            return False
        half = 1.2 + (z - 6) * 0.46 - inset
        return abs(x - 16) <= half
    v.fill(inside, col, y0, y1)


def layered(layers):
    v = Vox()
    y = 0
    for h, col in layers:
        wedge(v, y, y + h, col)
        y += h
    return v, y


@food
def cheesecake():
    v, y = layered([(2, crust), (7, cheese)])
    wedge(v, y, y + 1, "B8344A")
    for x, z in ((11, 25), (19, 25), (14, 21)):
        for yy in range(y - 3 + x % 3, y):
            v.put(x, yy, z, "B8344A")
    for x, z in ((12, 19), (17, 22), (14, 15)):
        v.ball(x + 1, y + 2.2, z + 1, 1.9, RED, ymin=y + 1)
        v.put(x, y + 3, z, RED_L)
    leaf(v, 17, y + 1, 17)
    return v


@food
def cake_strawberry():
    def fruit_layer(x, y, z):
        return RED if (x // 2 + z // 2) % 3 == 0 else MILK
    v, y = layered([(4, sponge), (2, fruit_layer), (4, sponge), (2, cream)])
    for z in (22, 24):
        for x in (11, 15, 19):
            v.box(x, y, z, x + 2, y + 1, z + 2, MILK)
    strawberry(v, 16.0, y, 17.0)
    return v


@food
def cake_choc():
    v, y = layered([(3, sponge_choc), (1, CHOC_L), (3, sponge_choc), (1, CHOC_L), (3, sponge_choc), (1, CHOC_D)])
    for x, z, d in ((10, 25, 4), (15, 25, 2), (20, 25, 5), (13, 20, 3), (19, 18, 2)):
        for yy in range(y - d, y):
            for xx in (x, x + 1):
                zz = max(k[2] for k in v.g if k[0] == xx and k[1] == yy) if any(k[0] == xx and k[1] == yy for k in v.g) else z
                v.put(xx, yy, zz, CHOC_D)
    swirl(v, 16, 22, y, 3.4, CHOC_L, CHOC)
    v.ball(16, y + 8.4, 22, 1.8, RED, ymin=y + 7)
    v.box(15, y, 12, 17, y + 2, 16, "855540")
    return v


@food
def tiramisu():
    v = Vox()
    y = 0
    savoiardi = grain("8E5A38", "A56E46", "754528", 24, 0.3)
    mascarpone = grain("FFF0D2", "FFF8E6", "F2DDB4", 25, 0.15)
    for h, col in ((3, savoiardi), (3, mascarpone), (3, savoiardi), (3, mascarpone)):
        v.box(7, y, 9, 25, y + h, 23, col)
        y += h
    v.box(7, y, 9, 25, y + 1, 23, grain("6A3A26", "84503A", "52291A", 26, 0.3))
    v.sprinkle(["A86C48"], 30, 27, lambda x, yy, z: yy == y)
    leaf(v, 17, y + 1, 13)
    v.box(10, y + 1, 17, 13, y + 2, 19, "3A1E14")
    return v


@food
def apple_pie():
    def filling(x, y, z):
        return "E8B04E" if rnd(x // 2, y // 2, z // 2, 28) < 0.55 else "C9852F"
    v, y = layered([(2, crust), (6, filling)])
    for z in range(6, 27):
        for x in range(32):
            if (x, y - 1, z) in v.g:
                lattice = (x + z) % 6 < 2 or (x - z) % 6 < 2
                v.put(x, y, z, ("E8AE60" if (x + z) % 6 < 2 else "D69648") if lattice else filling(x, y, z))
    for z in (24, 25):
        for x in range(32):
            if (x, y - 1, z) in v.g:
                v.box(x, y - 1, z, x + 1, y + 2, z + 1, crust)
    return v


@food
def medovik():
    v = Vox()
    y = 0
    for i in range(6):
        wedge(v, y, y + 1, CREAM_D)
        wedge(v, y + 1, y + 2, honey)
        y += 2
    wedge(v, y, y + 1, CREAM)
    v.sprinkle(["C98A40", "E0A856", "B67430"], 55, 29, lambda x, yy, z: yy == y)
    v.ball(16, y + 2.2, 21, 1.8, "F0C15A", ymin=y + 1)
    leaf(v, 17, y + 1, 18)
    return v


@food
def brownie():
    v = Vox()
    c = grain("5A3122", "6C3E2C", "482417", 30, 0.3)
    v.box(6, 0, 7, 22, 7, 23, c)
    v.box(6, 7, 7, 22, 8, 23, grain("6E3F2C", "8A563E", "5A3122", 31, 0.35))
    for x, z in ((8, 10), (15, 9), (18, 17), (10, 18), (13, 14)):
        v.box(x, 8, z, x + 3, 9 + (x % 2), z + 2, grain("C49260", "D8A874", "A87848", 32))
    v.box(23, 0, 17, 27, 4, 21, c)
    v.box(24, 0, 10, 26, 2, 12, c)
    return v


@food
def waffle():
    v = Vox()
    base = grain("E3A44C", "EDB862", "C9883A", 33)
    v.box(5, 0, 5, 27, 3, 27, base)
    for x in range(5, 27):
        for z in range(5, 27):
            if (x - 5) % 5 in (0, 1) or (z - 5) % 5 in (0, 1):
                v.put(x, 3, z, "F2C06A")
            else:
                v.put(x, 2, z, "C27E30")
    v.box(12, 4, 12, 19, 6, 18, grain("FBE48A", "FFF0AC", "EFD06A", 34))
    for x, z in ((8, 9), (22, 19), (20, 8)):
        strawberry(v, x + 0.5, 4, z + 0.5, False)
    for x, z in ((9, 21), (13, 22), (22, 12)):
        blueberry(v, x, 4, z)
    return v


@food
def pancakes():
    v = Vox()
    for i in range(4):
        y = i * 3
        cx, cz = 16 + (0.6 if i % 2 else -0.4), 16 + (-0.5 if i % 2 else 0.5)
        v.disc(10.0, y, y + 2, "F2C478", cx, cz)
        v.disc(10.5, y + 2, y + 3, "C98238", cx, cz, top=lambda x, yy, z: "DC9A48" if octa(x, z) < 8 else "C07830")
    top = 12
    v.disc(7.2, top, top + 1, CARAMEL_D, top=lambda x, y, z: CARAMEL_L if octa(x, z, 13, 13) < 3 else CARAMEL)
    for x, z, d, flat in ((12, 4.88, 5, True), (26.36, 17, 7, False), (17, 26.42, 4, True), (4.92, 13, 3, False)):
        if flat:
            v.slab(x, top - d + 0.1, z, x + 2, top - 0.06, z + 0.7, CARAMEL)
        else:
            v.slab(x, top - d + 0.1, z, x + 0.7, top - 0.06, z + 2, CARAMEL)
    v.box(13, top + 1, 13, 19, top + 3, 18, grain("FBE48A", "FFF0AC", "EFD06A", 35))
    blueberry(v, 20, top + 1, 17)
    blueberry(v, 10, top + 1, 17)
    return v


@food
def ice_cream_cone():
    v = Vox()
    waffle_cone = lambda x, yy, z: "B9772F" if (x + z + yy) % 4 == 0 or (x + z - yy) % 4 == 0 else "E2A857"
    for i, r in enumerate((1.6, 2.7, 3.8, 4.9, 5.9, 6.7)):
        v.disc(r, i * 2, i * 2 + 2 if i < 5 else 13, waffle_cone)
    v.disc(7.3, 13, 15, "EDBA6A")
    v.ball(16, 18.0, 16, 7.4, grain("F7B6C6", "FFCEDA", "E896AC", 36, 0.15), ry=5.4, ymin=14)
    v.ball(16, 24.0, 16, 5.8, grain("FFF2CC", "FFF9E4", "EEDAA8", 37, 0.15), ry=5.0, ymin=21)
    v.sprinkle([RED, "8FD3C0", "A9B4F0", MILK], 16, 38, lambda x, y, z: y >= 23)
    v.box(18, 26, 15, 20, 31, 17, grain(CHOC, CHOC_L, CHOC_D, 39))
    return v


def goblet(v):
    glass, glass_l = "D8ECEF", "F4FCFD"
    v.disc(6.2, 0, 1, glass, top=glass_l)
    v.slab(14.5, 1, 14.5, 17.5, 5, 17.5, glass_l)
    v.disc(4.0, 5, 6, glass)


@food
def sundae():
    v = Vox()
    goblet(v)
    layers = [(6, 8, "FFF2CC"), (8, 9, CHOC), (9, 12, "F7B6C6"), (12, 13, RED_D), (13, 15, "FFF2CC")]
    for y0, y1, c in layers:
        r = min(4.6 + ((y0 + y1) / 2 - 6) * 0.5, 8.2)
        v.disc(r, y0, y1, lambda x, yy, z, c=c: "EAF8FA" if -2.45 < angle(x, z) < -2.05 else c)
    v.disc(8.8, 15, 16, "EAF8FA")
    v.ball(13, 18, 17, 4.6, "FFF2CC", ymin=15)
    v.ball(19, 18, 15, 4.6, "F7B6C6", ymin=15)
    swirl(v, 16, 16, 20, 4.6, MILK, CREAM_D)
    v.sprinkle([CHOC, CHOC_D], 16, 40, lambda x, y, z: 17 <= y < 22)
    y = v.top(16, 16)
    v.ball(16, y + 1.8, 16, 2.1, RED, ymin=y)
    v.box(16, y + 3, 16, 17, y + 6, 17, "5E8A3E")
    for y2 in range(18, 28):
        v.box(22 + (y2 - 18) // 3, y2, 18, 24 + (y2 - 18) // 3, y2 + 1, 20, grain("E3A44C", "F2C06A", "C27E30", 43))
    return v


def ramekin(v, y1, col, col_d, r=10.0):
    v.disc(r - 1.0, 0, 1, col_d)
    v.ring(r, 1.2, 1, y1 + 1, lambda x, y, z: col if y >= y1 else col_d if int((angle(x, z) + math.pi) * 5.0) % 2 else col, top=col)


@food
def creme_brulee():
    v = Vox()
    ramekin(v, 6, PORC, PORC_D)

    def burnt(x, y, z):
        n = rnd(x // 2, 0, z // 2, 44) + radius(x, z) / 22
        return "8A441C" if n > 1.05 else "C46F24" if n > 0.8 else "E89A34" if n > 0.45 else "F6BE52"
    v.disc(8.9, 1, 6, "E89A34", top=burnt)
    v.box(13, 6, 17, 16, 8, 20, RED)
    v.put(13, 8, 17, RED_L)
    v.box(17, 6, 15, 19, 8, 17, "4E5898")
    leaf(v, 16, 6, 20)
    return v


@food
def panna_cotta():
    v = Vox()
    body = lambda x, yy, z: "FFFDF6" if -2.45 < angle(x, z) < -2.0 else "FBEFE0"
    for y0, y1, r in ((0, 4, 8.8), (4, 8, 8.0), (8, 12, 7.0)):
        v.disc(r, y0, y1, body)
    v.disc(7.4, 12, 13, RED_D, top=lambda x, y, z: RED if octa(x, z, 13, 13) < 2.5 else RED_D)
    for x, z, d, flat in ((13, 8.4, 4, True), (23.0, 17, 3, False), (18, 23.0, 5, True), (8.4, 13, 3, False)):
        if flat:
            v.slab(x, 12 - d, z, x + 1.6, 12, z + 0.6, RED_D)
        else:
            v.slab(x, 12 - d, z, x + 0.6, 12, z + 1.6, RED_D)
    strawberry(v, 16.0, 13, 16.0, False)
    leaf(v, 18, 13, 17)
    return v


@food
def flan():
    v = Vox()
    custard = grain("F6C65C", "FFD878", "E4AE44", 45, 0.15)
    for y0, y1, r in ((0, 3, 10.2), (3, 7, 9.2), (7, 10, 8.2)):
        v.disc(r, y0, y1, custard)
    v.disc(8.5, 10, 11, "99480F", top=lambda x, y, z: "C8742A" if octa(x, z, 13, 13) < 2.5 else "99480F")
    v.disc(2.0, 11, 14, RED, top=lambda x, y, z: RED_L if x < 16 and z < 16 else RED)
    v.slab(15.6, 14, 15.6, 16.4, 17, 16.4, "5E8A3E")
    return v


@food
def fruit_tart():
    v = Vox()
    v.disc(9.8, 0, 2, crust)
    v.disc(9.8, 2, 4, "E4A850", top="FCE7A4")
    v.ring(11.0, 1.4, 1, 6, lambda x, y, z: "E8AE60" if int((angle(x, z) + math.pi) * 5.6) % 2 else "C98640", top="EDB866")
    strawberry(v, 12.0, 4, 12.0, False)
    strawberry(v, 20.0, 4, 13.0, False)
    strawberry(v, 15.0, 4, 21.0, False)
    for x, z in ((15, 9), (9, 16), (20, 19), (15, 15)):
        blueberry(v, x, 4, z)
    for cx, cz in ((21.0, 17.0), (11.0, 18.0)):
        v.disc(2.6, 4, 5, "77A838", cx, cz, top=lambda x, y, z, cx=cx, cz=cz: "F4F0C0" if octa(x, z, cx, cz) < 1.0 else
               "9CCB4E" if octa(x, z, cx, cz) < 2.0 else "77A838")
    v.box(17, 4, 8, 19, 6, 10, RED)
    leaf(v, 14, 4, 17)
    return v


@food
def baklava():
    v = Vox()
    filo = lambda x, y, z: "F0B454" if y % 2 == 0 else "C9812E"
    nuts = grain("8DA43E", "AEC25C", "70862C", 46, 0.3)

    def piece(cx, cz, y0, s):
        for y in range(y0, y0 + 8):
            col = nuts if y - y0 in (3, 4) else filo
            v.fill(lambda x, yy, z: abs(x - cx) + abs(z - cz) * 1.15 <= s, col, y, y + 1)
        v.fill(lambda x, yy, z: abs(x - cx) + abs(z - cz) * 1.15 <= s - 1.5, "E69A2C", y0 + 8, y0 + 9)
        v.box(int(cx) - 1, y0 + 9, int(cz) - 1, int(cx) + 1, y0 + 10, int(cz) + 1, nuts)
    piece(11.0, 13.0, 0, 7.4)
    piece(21.0, 14.0, 0, 7.4)
    piece(16.0, 22.0, 0, 7.4)
    return v


# ------------------------------------------------------------------------------------------------ supplies
@food
def coffee_beans():
    v = Vox()
    weave = lambda x, y, z: "D8BA86" if (x + y) % 3 == 0 else "A68650" if (z + y) % 4 == 0 else "C4A26C"
    v.disc(8.8, 0, 8, weave)
    v.disc(8.2, 8, 12, weave)
    v.ring(9.4, 2.2, 12, 14, "E2C894", top="EBD4A4")
    beans = lambda x, y, z: ("8A5638", "5E3422", "432216", "6E3F28")[int(rnd(x // 2, y, z // 2, 48) * 3.99)]
    v.disc(7.2, 12, 13, beans)
    v.disc(4.8, 13, 15, beans)
    v.disc(2.4, 15, 16, beans)
    v.slab(13, 2, 6.7, 19, 7, 7.2, lambda x, y, z: "E2C894" if x == 15 + (y > 4) else "5E3422")
    for x, z in ((4, 5), (25, 5), (8, 2)):
        v.box(x, 0, z, x + 3, 2, z + 2, "5E3422")
        v.put(x + 1, 1, z, "8A5638")
    return v


def carton(body, accent, accent_d, picture):
    v = Vox()
    v.box(10, 0, 10, 22, 17, 22, lambda x, y, z: accent if 3 <= y < 6 else accent_d if y == 6 else body)
    for i, y in enumerate(range(17, 22)):
        v.box(10, y, 11 + i, 22, y + 1, 21 - i, accent)
    v.box(10, 22, 15, 22, 24, 17, accent_d)
    for x, y, c in picture:
        v.put(x, y, 10, c)
    v.box(18, 19, 11, 21, 21, 13, MILK)
    return v


@food
def milk_carton():
    cow = [(x, y, "4A4440") for x, y in ((13, 14), (14, 14), (13, 13), (18, 10), (19, 10), (19, 11), (17, 14))]
    drop = [(x, y, "7FB2DE") for x, y in ((15, 12), (16, 12), (15, 11), (16, 11), (14, 10), (15, 10), (16, 10), (17, 10),
                                          (15, 9), (16, 9), (15, 13))]
    return carton("F8F6F0", "A9CDEB", "7FB2DE", cow + drop)


@food
def cream_carton():
    pic = [(x, y, "E8A6B8") for x, y in ((13, 10), (14, 10), (15, 10), (16, 10), (17, 10), (18, 10), (14, 11), (15, 11),
                                         (16, 11), (17, 11), (15, 12), (16, 12), (15, 13))]
    return carton("FFF2D8", "F4B8C6", "DC8CA0", pic)


def syrup(liquid, liquid_l, label, cap, icon):
    v = Vox()

    def bottle(x, y, z):
        if 4 <= y < 11:
            return liquid if (x, y) in icon and z < 16 else label
        if -2.45 < angle(x, z) < -2.0:
            return liquid_l
        return liquid
    v.disc(6.4, 0, 15, bottle, top=liquid_l)
    v.disc(5.0, 15, 17, liquid)
    v.disc(2.6, 17, 21, liquid_l)
    v.disc(3.4, 21, 23, cap)
    v.slab(15, 23, 15, 17, 25, 17, cap)
    v.slab(11, 25, 15, 17, 27, 17, GOLD)
    return v


@food
def syrup_vanilla():
    return syrup("D9A84E", "F2D084", "FFF6E2", "6A4435",
                 ((15, 9), (16, 9), (13, 8), (14, 8), (17, 8), (18, 8), (15, 7), (16, 7), (15, 5), (15, 6)))


@food
def syrup_caramel():
    return syrup("A85A1E", "D88636", "F6DCA8", "47271C",
                 ((14, 9), (15, 9), (16, 9), (17, 9), (13, 8), (13, 7), (14, 6), (15, 6), (16, 6), (17, 7), (16, 8)))


@food
def chocolate():
    v = Vox()
    v.box(8, 0, 5, 24, 3, 27, choc)
    for i in range(2):
        for j in range(2):
            v.box(9 + i * 8, 3, 6 + j * 6, 15 + i * 8, 4, 11 + j * 6, CHOC_L)
            v.box(10 + i * 8, 4, 7 + j * 6, 14 + i * 8, 5, 10 + j * 6, choc)
    v.box(7, 0, 18, 25, 5, 28, lambda x, y, z: "F4ABC0" if (z in (21, 22)) else "FFF0DC" if z == 20 or z == 23 else "DF7F9C")
    v.box(7, 0, 17, 25, 5, 18, lambda x, y, z: GOLD_L if x % 2 else GOLD)
    return v


# ------------------------------------------------------------------------------------------------ the plate
def posies(ring_r, count=8, cx=16.0, cz=16.0):
    """Tiny painted flowers around a porcelain rim: -> {(x, z): colour}."""
    out = {}
    for k in range(count):
        a = 2 * math.pi * (k + 0.5) / count
        x, z = int(math.floor(cx + math.cos(a) * ring_r)), int(math.floor(cz + math.sin(a) * ring_r))
        petal = ("D9808F", "8DA6C8")[k % 2]
        for dx, dz in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            out[(x + dx, z + dz)] = petal
        out[(x, z)] = "E8B84C"
        tx, tz = int(round(-math.sin(a) * 2.4)), int(round(math.cos(a) * 2.4))
        out[(x + tx, z + tz)] = "86A878"
        out[(x - tx, z - tz)] = "86A878"
    return out


def plate():
    v = Vox()
    flowers = posies(10.6)
    v.disc(10.0, 0, 1, PORC_DD)
    v.disc(14.0, 1, 2, PORC_D, top=lambda x, y, z: flowers.get((x, z)) or (
        GOLD if 12.3 < octa(x, z) <= 13.2 else PORC_D if 7.9 < octa(x, z) <= 8.8 else PORC))
    return v


# ------------------------------------------------------------------------------------------------ files
DRINKS = ["espresso", "americano", "latte", "cappuccino", "flat_white", "raf", "mocha", "macchiato"]
DESSERTS = ["croissant", "donut_pink", "donut_choc", "cupcake_pink", "cupcake_choc", "muffin_blueberry", "cream_puff", "eclair",
            "cinnamon_roll", "cookie_choc", "cookie_heart", "gingerbread_man", "macaron_pink", "macaron_mint", "macaron_lemon",
            "cake_pop", "cheesecake", "cake_strawberry", "cake_choc", "tiramisu", "apple_pie", "medovik", "brownie", "waffle",
            "pancakes", "ice_cream_cone", "sundae", "creme_brulee", "panna_cotta", "flan", "fruit_tart", "baklava"]


def on_plate(name):
    d = FOOD[name]()
    (x0, y0, z0), (x1, y1, z1) = d.bounds()
    dx, dz = int(round(16 - (x0 + x1) / 2)), int(round(16 - (z0 + z1) / 2))
    assert y1 - y0 + 2 <= 48, name + " is too tall for the plate"
    return plate().over(d.moved(dx, 2 - y0, dz))


HANDLED = {"cup_espresso", "cup_americano", "cup_flat_white", "cup_cappuccino", "cup_raf", "cup_mocha", "empty_cup"}


def write(model_id, vox, overrides=None):
    elements, atlas = build(vox)
    os.makedirs(os.path.join(ASSETS, "textures", "item", "food3d"), exist_ok=True)
    atlas.save(os.path.join(ASSETS, "textures", "item", "food3d", model_id + ".png"), optimize=True)
    tex = "aestheticjobs:item/food3d/" + model_id
    # crumbs of an eaten dessert are cut from the flat sprite of the food (the model texture is a sheet of patches)
    sprite = model_id[len("dessert_plate_"):] if model_id.startswith("dessert_plate_") else "cup_latte" if model_id == "coffee_cup" else model_id
    assert os.path.exists(os.path.join(ASSETS, "textures", "item", sprite + ".png")), sprite
    model = {"credit": "tools/gen_food.py", "gui_light": "side", "texture_size": [atlas.width, atlas.height],
             "textures": {"particle": "aestheticjobs:item/" + sprite, "t": tex}, "elements": elements,
             "display": display(vox, model_id in HANDLED)}
    if overrides:
        model["overrides"] = overrides
    with open(os.path.join(ASSETS, "models", "item", model_id + ".json"), "w") as f:
        json.dump(model, f, separators=(",", ":"))
        f.write("\n")
    return len(elements), atlas.width


def cmd(ids, prefix):
    return [{"predicate": {"custom_model_data": i + 1}, "model": "aestheticjobs:item/" + prefix + n} for i, n in enumerate(ids)]


def main():
    stats = {}
    assert set(DESSERTS) <= set(FOOD) and {"cup_" + d for d in DRINKS} <= set(FOOD)
    for name, fn in FOOD.items():
        stats[name] = write(name, fn())
    stats["coffee_cup"] = write("coffee_cup", FOOD["cup_latte"](), cmd(DRINKS, "cup_"))
    stats["dessert_plate"] = write("dessert_plate", plate(), cmd(DESSERTS, "dessert_plate_"))
    for name in DESSERTS:
        stats["dessert_plate_" + name] = write("dessert_plate_" + name, on_plate(name))
    q = [s[0] for s in stats.values()]
    print(f"{len(stats)} models, elements: average {sum(q) // len(q)}, max {max(q)}, textures up to {max(s[1] for s in stats.values())} px")


# ------------------------------------------------------------------------------------------------ verification
def check():
    """Reads the written files back: voxel faces all covered, nothing flickers, nothing floats, UVs and links are fine."""
    from PIL import Image
    ids = list(FOOD) + ["coffee_cup", "dessert_plate"] + ["dessert_plate_" + n for n in DESSERTS]
    axis_of = {"north": (2, -1), "south": (2, 1), "east": (0, 1), "west": (0, -1), "up": (1, 1), "down": (1, -1)}
    for mid in ids:
        m = json.load(open(os.path.join(ASSETS, "models", "item", mid + ".json")))
        vox = FOOD[mid]() if mid in FOOD else FOOD["cup_latte"]() if mid == "coffee_cup" else plate() if mid == "dessert_plate" \
            else on_plate(mid[len("dessert_plate_"):])
        im = Image.open(os.path.join(ASSETS, "textures", m["textures"]["t"].split(":")[1] + ".png"))
        assert im.width == im.height and im.width & (im.width - 1) == 0 and im.width <= 256, (mid, im.size)
        seen = set()
        for e in m["elements"]:
            assert all(-16 <= a <= b <= 32 for a, b in zip(e["from"], e["to"])), (mid, e)
            if "rotation" in e:
                assert e["rotation"]["angle"] in (-45, -22.5, 0, 22.5, 45), (mid, e)
            for data in e["faces"].values():
                assert all(0 <= v <= 16 for v in data["uv"]), (mid, data)
                assert data["uv"][2] > data["uv"][0] and data["uv"][3] > data["uv"][1], (mid, data)
            for face in e["faces"]:
                axis, d = axis_of[face]
                others = [a for a in range(3) if a != axis]
                lo, hi = [v * 2 for v in e["from"]], [v * 2 for v in e["to"]]
                if "rotation" in e or any(abs(v - round(v)) > 1e-3 for v in lo + hi):
                    continue
                lo, hi = [int(round(v)) for v in lo], [int(round(v)) for v in hi]
                plane = lo[axis] - 1 if d > 0 else lo[axis]
                if d < 0:
                    plane = lo[axis]
                for i in range(lo[others[0]], hi[others[0]]):
                    for j in range(lo[others[1]], hi[others[1]]):
                        p = [0, 0, 0]
                        p[axis], p[others[0]], p[others[1]] = (hi[axis] - 1 if d > 0 else lo[axis]), i, j
                        seen.add((face, tuple(p)))
        for p in set(vox.g) - vox.solid:                               # every visible voxel face is drawn
            for face, (axis, d) in axis_of.items():
                q = list(p)
                q[axis] += d
                if tuple(q) not in vox.g and tuple(q) not in vox.solid:
                    assert (face, p) in seen, (mid, "hole", face, p)
        fight = fighting_faces(m["elements"])
        assert not fight, (mid, "flickering faces", len(fight), [(m["elements"][i], m["elements"][j]) for i, j, f, o in fight[:1]])
        for key, tr in m["display"].items():
            assert all(abs(v) <= 80 for v in tr["translation"]) and all(0 < v <= 4 for v in tr["scale"]), (mid, key, tr)
        for o in m.get("overrides", []):
            assert os.path.exists(os.path.join(ASSETS, "models", "item", o["model"].split("/")[-1] + ".json")), (mid, o)
        cells = vox.cells()
        left, groups = set(cells), []
        while left:
            stack = [left.pop()]
            group = [stack[0]]
            while stack:
                x, y, z = stack.pop()
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        for dz in (-1, 0, 1):
                            n = (x + dx, y + dy, z + dz)
                            if n in left:
                                left.remove(n)
                                stack.append(n)
                                group.append(n)
            groups.append(group)
        floating = [g for g in groups if min(p[1] for p in g) > min(p[1] for p in cells)]
        assert not floating, (mid, "floating pieces", [sorted(g)[:3] for g in floating])
    print("checked", len(ids), "models: no flickering faces, no holes, nothing floating, UVs and overrides fine")


if __name__ == "__main__":
    if "--check" in sys.argv:
        check()
    else:
        main()
