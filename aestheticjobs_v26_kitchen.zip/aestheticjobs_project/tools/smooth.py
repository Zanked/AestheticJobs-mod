"""Smooth tableware for item and block models: true octagons made of three straight boxes and four boxes turned by 45
degrees (the only way a vanilla model can draw a clean diagonal edge), plus ordinary boxes.

All units are model units (16 = one block). A "shader" gives the colour of a texture pixel from its place in the model:
shader(x, y, z, face) -> (r, g, b) or (r, g, b, a). Because both halves of an overlapping corner ask the same shader
about the same place, their colours agree.
"""
import math

import numpy as np

import style

DENSITY = 2                       # texture pixels per model unit, as everywhere in the cafe
LIFT = 0.012                      # the turned corner pieces sit this much inside, so their tops never fight with the others
K = math.tan(math.radians(22.5))

# face: axis, direction, u axis, u sign, v axis, v sign (Minecraft's default UV orientation)
FACES = {
    "north": (2, -1, 0, -1, 1, -1), "south": (2, 1, 0, 1, 1, -1),
    "east": (0, 1, 2, -1, 1, -1), "west": (0, -1, 2, 1, 1, -1),
    "up": (1, 1, 0, 1, 2, 1), "down": (1, -1, 0, 1, 2, -1),
}


def turn(x, z, angle, ox, oz):
    """The rotation of a model element around the vertical axis."""
    a = math.radians(angle)
    dx, dz = x - ox, z - oz
    return ox + dx * math.cos(a) + dz * math.sin(a), oz - dx * math.sin(a) + dz * math.cos(a)


def box(f, t, shader, faces=("north", "south", "east", "west", "up", "down"), rot=None):
    """One element. shader may be a dict {face or "*": shader}. rot = (angle, origin x, origin z)."""
    if not isinstance(shader, dict):
        shader = {"*": shader}
    return {"f": list(f), "t": list(t), "faces": {d: shader.get(d, shader.get("*")) for d in faces}, "rot": rot}


def octagon(cx, cz, r, y0, y1, side, top=None, bottom=True):
    """A solid octagonal prism with the radius r to the middle of its straight sides."""
    paint = top or side
    s = r * K

    def top(x, y, z, face):                             # a bright rim around the upper face, the same on all pieces
        c = paint(x, y, z, face)
        dx, dz = abs(x - cx), abs(z - cz)
        if r >= 1.5 and max(dx, dz, (dx + dz) / (1 + K)) > r - 0.5 and (len(c) == 3 or c[3] >= 250):
            return style.shade(c, 1.0, 0.22)
        return c
    ud = ("up", "down") if bottom else ("up",)

    def sh(*sides):
        d = {"up": top, "down": side}
        for k in sides:
            d[k] = side
        return d
    parts = [
        box((cx - r, y0, cz - s), (cx + r, y1, cz + s), sh("east", "west"), ("east", "west") + ud),
        box((cx - s, y0, cz + s), (cx + s, y1, cz + r), sh("south"), ("south",) + ud),
        box((cx - s, y0, cz - r), (cx + s, y1, cz - s), sh("north"), ("north",) + ud),
    ]
    half = (r - s) / math.sqrt(2)                       # half of a diagonal side
    deep = half
    for sx, sz in ((1, 1), (-1, 1), (1, -1), (-1, -1)):
        mx, mz = cx + sx * (r + s) / 2, cz + sz * (r + s) / 2
        face = "east" if sx > 0 else "west"
        angle = -45 if sx == sz else 45
        x0, x1 = (mx - deep, mx) if sx > 0 else (mx, mx + deep)
        parts.append(box((x0, y0 + LIFT, mz - half), (x1, y1 - LIFT, mz + half), sh(face), (face,) + ud, (angle, mx, mz)))
    return parts


def ring(cx, cz, r, thick, y0, y1, outer, inner=None, top=None, bottom=False):
    """A hollow octagonal wall (cups, glasses, baskets)."""
    inner = inner or outer
    top = top or outer
    s = r * K
    parts = []

    def sh(out_face, in_face):
        return {out_face: outer, in_face: inner, "up": top, "down": outer, "*": inner}
    ud = ("up", "down") if bottom else ("up",)
    for face, opp, f, t in (("north", "south", (cx - s, cz - r), (cx + s, cz - r + thick)),
                            ("south", "north", (cx - s, cz + r - thick), (cx + s, cz + r)),
                            ("west", "east", (cx - r, cz - s), (cx - r + thick, cz + s)),
                            ("east", "west", (cx + r - thick, cz - s), (cx + r, cz + s))):
        parts.append(box((f[0], y0, f[1]), (t[0], y1, t[1]), sh(face, opp), (face, opp) + ud))
    half = (r - s) / math.sqrt(2)
    for sx, sz in ((1, 1), (-1, 1), (1, -1), (-1, -1)):
        mx, mz = cx + sx * (r + s) / 2, cz + sz * (r + s) / 2
        face, opp = ("east", "west") if sx > 0 else ("west", "east")
        angle = -45 if sx == sz else 45
        x0, x1 = (mx - thick, mx) if sx > 0 else (mx, mx + thick)
        parts.append(box((x0, y0 + LIFT, mz - half), (x1, y1 - LIFT, mz + half), sh(face, opp), (face, opp) + ud,
                         (angle, mx, mz)))
    return parts


def patches_of(part):
    """-> [(face, RGBA array, texel width, texel height)] of one element, painted by its shaders."""
    f, t = part["f"], part["t"]
    out = []
    for face, shader in part["faces"].items():
        axis, d, ua, us, va, vs = FACES[face]
        du, dv = (t[ua] - f[ua]) * DENSITY, (t[va] - f[va]) * DENSITY
        w, h = max(1, int(math.ceil(du - 1e-6))), max(1, int(math.ceil(dv - 1e-6)))
        im = np.zeros((h, w, 4), np.uint8)
        for j in range(h):
            for i in range(w):
                p = [0.0, 0.0, 0.0]
                p[axis] = t[axis] - 0.02 if d > 0 else f[axis] + 0.02
                a, b = (i + 0.5) / w, (j + 0.5) / h
                p[ua] = f[ua] + a * (t[ua] - f[ua]) if us > 0 else t[ua] - a * (t[ua] - f[ua])
                p[va] = f[va] + b * (t[va] - f[va]) if vs > 0 else t[va] - b * (t[va] - f[va])
                if part["rot"]:
                    p[0], p[2] = turn(p[0], p[2], *part["rot"])
                c = shader(p[0], p[1], p[2], face)
                if len(c) == 4 and c[3] < 250:                         # glass stays clean
                    im[j, i] = c
                    continue
                k = style.mottle(*(int(math.floor(v * DENSITY)) for v in p))
                light = 0.0
                if axis != 1:                                          # sides: lit from above, defined edges
                    if h >= 4:
                        k *= 1.06 - 0.13 * j / (h - 1)
                    if h >= 2 and j == 0:
                        light = 0.20
                    elif h >= 3 and j == h - 1:
                        k *= 0.84
                    if w >= 5 and (i == 0 or i == w - 1):
                        k *= 0.94
                im[j, i] = style.shade(c, k, light) + (255,)
        out.append((face, im, w, h))
    return out


def pack(patches, gutter=1, smallest=32):
    """Shelf packing into a square power-of-two atlas. -> (atlas array, [(x, y)] per patch)."""
    order = sorted(range(len(patches)), key=lambda i: (-patches[i].shape[0], -patches[i].shape[1], i))
    size = smallest
    while True:
        x = y = row = 0
        place, fits = {}, True
        for i in order:
            h, w = patches[i].shape[:2]
            if w + 2 * gutter > size:
                fits = False
                break
            if x + w + 2 * gutter > size:
                x, y, row = 0, y + row, 0
            place[i] = (x + gutter, y + gutter)
            x += w + 2 * gutter
            row = max(row, h + 2 * gutter)
        if fits and y + row <= size:
            break
        size *= 2
    # the unused part gets the average colour (not transparency), so the far mipmaps of the block atlas get no dark fringes
    mean = np.mean([p[:, :, :3].reshape(-1, 3).mean(axis=0) for p in patches], axis=0)
    atlas = np.zeros((size, size, 4), np.uint8)
    atlas[:, :] = [int(v) for v in mean] + [255]
    g = ((gutter, gutter), (gutter, gutter), (0, 0))
    for i, (px, py) in place.items():
        h, w = patches[i].shape[:2]
        atlas[py - gutter:py + h + gutter, px - gutter:px + w + gutter] = np.pad(patches[i], g, "edge")
    return atlas, [place[i] for i in range(len(patches))]


def element(f, t, face_uvs, rot=None):
    """The JSON of one element."""
    e = {"from": [round(v, 4) for v in f], "to": [round(v, 4) for v in t],
         "faces": {d: {"uv": uv, "texture": "#t"} for d, uv in face_uvs.items()}}
    if rot:
        e["rotation"] = {"angle": rot[0], "axis": "y", "origin": [round(rot[1], 4), 0, round(rot[2], 4)]}
    return e


# ---------------------------------------------------------------- verification
def face_polygon(e, face):
    """-> (normal, plane offset, the 4 corners in 2D) of a face of a JSON element."""
    f, t = e["from"], e["to"]
    axis, d, ua, us, va, vs = FACES[face]
    plane = t[axis] if d > 0 else f[axis]
    pts = []
    for a, b in ((f[ua], f[va]), (t[ua], f[va]), (t[ua], t[va]), (f[ua], t[va])):
        p = [0.0] * 3
        p[axis], p[ua], p[va] = plane, a, b
        r = e.get("rotation")
        if r:
            p[0], p[2] = turn(p[0], p[2], r["angle"], r["origin"][0], r["origin"][2])
        pts.append(p)
    n = [0.0] * 3
    n[axis] = d
    if e.get("rotation"):
        n[0], n[2] = turn(n[0], n[2], e["rotation"]["angle"], 0, 0)
    offset = sum(n[i] * pts[0][i] for i in range(3))
    if abs(n[1]) > 0.5:
        flat = [(p[0], p[2]) for p in pts]
    else:
        flat = [(-n[2] * p[0] + n[0] * p[2], p[1]) for p in pts]
    return tuple(round(v, 3) for v in n), round(offset, 3), flat


def _overlap(a, b):
    """Do two convex polygons share some area? (separating axes, touching edges do not count)"""
    for poly in (a, b):
        for i in range(len(poly)):
            x0, y0 = poly[i]
            x1, y1 = poly[(i + 1) % len(poly)]
            nx, ny = y0 - y1, x1 - x0
            ln = math.hypot(nx, ny)
            if ln < 1e-9:
                continue
            pa = [(nx * x + ny * y) / ln for x, y in a]
            pb = [(nx * x + ny * y) / ln for x, y in b]
            if min(max(pa), max(pb)) - max(min(pa), min(pb)) <= 0.01:
                return False
    return True


def fighting_faces(elements):
    """Pairs of faces that lie in the same plane, look the same way and overlap: these flicker in the game."""
    planes, bad = {}, []
    for i, e in enumerate(elements):
        for face in e["faces"]:
            n, off, poly = face_polygon(e, face)
            for j, other in planes.get((n, off), ()):
                if _overlap(poly, other):
                    bad.append((i, j, face, off))
            planes.setdefault((n, off), []).append((i, poly))
    return bad
