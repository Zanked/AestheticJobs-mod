package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Server -> client: what the interview window shows now. Texts are translation keys; an argument is plain text, or
 * "t:key" (one translation) or "T:key1,key2" (several translations joined with commas).
 * phase: 0 question, 1 phone call, 2 offer, 3 hired, 4 rejected, 5 close the window.
 * mood: 0 neutral, 1 happy, 2 angry (the face of the manager). delta: how the last answer changed the impression.
 */
public record InterviewStatePayload(int manager, int phase, String reactKey, List<String> reactArgs, String lineKey,
                                    List<String> lineArgs, List<String> options, int mood, int impression, int delta,
                                    int step, int total, int threshold) implements CustomPacketPayload {
    public static final int Q = 0, CALL = 1, OFFER = 2, HIRED = 3, REJECTED = 4, CLOSE = 5;

    public static final Type<InterviewStatePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "interview_state"));

    /** 13 fields: more than StreamCodec.composite takes, so it is written by hand. */
    public static final StreamCodec<RegistryFriendlyByteBuf, InterviewStatePayload> STREAM_CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeVarInt(p.manager());
                buf.writeVarInt(p.phase());
                buf.writeUtf(p.reactKey());
                buf.writeCollection(p.reactArgs(), (b, s) -> b.writeUtf(s));
                buf.writeUtf(p.lineKey());
                buf.writeCollection(p.lineArgs(), (b, s) -> b.writeUtf(s));
                buf.writeCollection(p.options(), (b, s) -> b.writeUtf(s));
                buf.writeVarInt(p.mood());
                buf.writeVarInt(p.impression());
                buf.writeVarInt(p.delta() + 100);
                buf.writeVarInt(p.step());
                buf.writeVarInt(p.total());
                buf.writeVarInt(p.threshold());
            },
            buf -> new InterviewStatePayload(buf.readVarInt(), buf.readVarInt(), buf.readUtf(),
                    buf.readCollection(ArrayList::new, b -> b.readUtf()), buf.readUtf(),
                    buf.readCollection(ArrayList::new, b -> b.readUtf()), buf.readCollection(ArrayList::new, b -> b.readUtf()),
                    buf.readVarInt(), buf.readVarInt(), buf.readVarInt() - 100, buf.readVarInt(), buf.readVarInt(), buf.readVarInt()));

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
