package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Server -> client: opens (or, with open = false, refreshes) the kitchen screen of a station. tried = per base of the
 * menu the additions this player has tried (bit masks), found = his signature recipes (bits). wanted / wish / customer
 * come from the ticket in his inventory (-1 / 0 / -1 without one).
 */
public record OpenKitchenPayload(BlockPos pos, boolean open, List<Integer> tried, long found, int wanted, int wish,
                                 int customer) implements CustomPacketPayload {
    public static final Type<OpenKitchenPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "open_kitchen"));

    public static final StreamCodec<RegistryFriendlyByteBuf, OpenKitchenPayload> STREAM_CODEC =
            StreamCodec.of(OpenKitchenPayload::write, OpenKitchenPayload::read);

    private static void write(RegistryFriendlyByteBuf buf, OpenKitchenPayload p) {
        buf.writeBlockPos(p.pos);
        buf.writeBoolean(p.open);
        buf.writeVarInt(p.tried.size());
        for (int t : p.tried) buf.writeVarInt(t);
        buf.writeVarLong(p.found);
        buf.writeVarInt(p.wanted);
        buf.writeVarInt(p.wish);
        buf.writeVarInt(p.customer);
    }

    private static OpenKitchenPayload read(RegistryFriendlyByteBuf buf) {
        BlockPos pos = buf.readBlockPos();
        boolean open = buf.readBoolean();
        List<Integer> tried = new ArrayList<>();
        for (int i = 0, n = Math.min(buf.readVarInt(), 64); i < n; i++) tried.add(buf.readVarInt());
        return new OpenKitchenPayload(pos, open, tried, buf.readVarLong(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt());
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
