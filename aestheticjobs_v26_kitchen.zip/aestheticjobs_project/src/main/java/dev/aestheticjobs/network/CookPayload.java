package dev.aestheticjobs.network;

import dev.aestheticjobs.AestheticJobs;
import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Client -> server, from the kitchen screen: start cooking base with the additions mask (art = latte art style), or,
 * with base = COLLECT, take the finished result. The server checks everything.
 */
public record CookPayload(BlockPos pos, int base, int mask, int art) implements CustomPacketPayload {
    public static final int COLLECT = -1;

    public static final Type<CookPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "cook"));

    public static final StreamCodec<RegistryFriendlyByteBuf, CookPayload> STREAM_CODEC = StreamCodec.composite(
            BlockPos.STREAM_CODEC, CookPayload::pos,
            ByteBufCodecs.INT, CookPayload::base,
            ByteBufCodecs.VAR_INT, CookPayload::mask,
            ByteBufCodecs.VAR_INT, CookPayload::art,
            CookPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
