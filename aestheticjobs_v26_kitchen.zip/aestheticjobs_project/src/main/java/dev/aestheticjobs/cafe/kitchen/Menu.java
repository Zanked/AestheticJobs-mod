package dev.aestheticjobs.cafe.kitchen;

import static dev.aestheticjobs.cafe.kitchen.Extra.*;

import java.util.List;

/**
 * Every base that can be cooked: the 8 drinks of the coffee machine (in the order of cafe/Drink) and the 32 desserts of
 * the pastry oven (in the order of item/Dessert). Each knows its own taste, which additions suit it and which spoil it,
 * what it is made of and how long it takes. Pure Java.
 */
public final class Menu {
    public enum Kind {
        DRINK, BUNS, COOKIES, CAKES, PIES, CREAMS;

        public String id() { return name().toLowerCase(java.util.Locale.ROOT); }
    }

    /** One base. likes / dislikes are bit masks of {@link Extra}. */
    public record Base(String id, Kind kind, int sweet, int creamy, int fruity, int choco, int likes, int dislikes,
                       List<String> ingredients, int ticks) {
        public int taste(Flavor f) {
            return switch (f) {
                case SWEET -> sweet;
                case CREAMY -> creamy;
                case FRUITY -> fruity;
                case CHOCO -> choco;
            };
        }

        public boolean isDrink() { return kind == Kind.DRINK; }
    }

    public static final int DRINKS = 8, DESSERTS = 32;

    private static final String CUP = "aestheticjobs:empty_cup", BEANS = "aestheticjobs:coffee_beans",
            MILK = "aestheticjobs:milk_carton", CREAMBOX = "aestheticjobs:cream_carton",
            SYRUP_V = "aestheticjobs:syrup_vanilla", SYRUP_C = "aestheticjobs:syrup_caramel", CHOC = "aestheticjobs:chocolate",
            WHEAT = "minecraft:wheat", EGG = "minecraft:egg", SUGARBAG = "minecraft:sugar", COCOABEANS = "minecraft:cocoa_beans",
            APPLES = "minecraft:apple";

    private static final List<Base> ALL = List.of(
            new Base("espresso", Kind.DRINK, 0, 0, 0, 1, mask(SUGAR, CHOCOLATE, CREAM),
                    mask(APPLE, BERRY), List.of(CUP, BEANS), 80),
            new Base("americano", Kind.DRINK, 0, 0, 0, 0, mask(SUGAR, HONEY, APPLE),
                    mask(CREAM, CARAMEL), List.of(CUP, BEANS), 90),
            new Base("latte", Kind.DRINK, 1, 2, 0, 0, mask(VANILLA, CARAMEL, HONEY),
                    mask(APPLE), List.of(CUP, BEANS, MILK), 100),
            new Base("cappuccino", Kind.DRINK, 0, 2, 0, 0, mask(COCOA, VANILLA, SUGAR),
                    mask(APPLE, HONEY), List.of(CUP, BEANS, MILK), 100),
            new Base("flat_white", Kind.DRINK, 0, 2, 0, 0, mask(CARAMEL, HONEY, COCOA),
                    mask(BERRY, APPLE), List.of(CUP, BEANS, MILK), 100),
            new Base("raf", Kind.DRINK, 1, 3, 0, 0, mask(BERRY, HONEY, CARAMEL),
                    mask(COCOA), List.of(CUP, BEANS, CREAMBOX, SYRUP_V), 120),
            new Base("mocha", Kind.DRINK, 1, 1, 0, 2, mask(CREAM, BERRY, SUGAR),
                    mask(HONEY, APPLE), List.of(CUP, BEANS, MILK, CHOC), 120),
            new Base("macchiato", Kind.DRINK, 2, 2, 0, 0, mask(CHOCOLATE, COCOA, CREAM),
                    mask(APPLE, BERRY), List.of(CUP, BEANS, MILK, SYRUP_V, SYRUP_C), 120),
            new Base("croissant", Kind.BUNS, 0, 1, 0, 0, mask(SUGAR, CARAMEL, CREAM, HONEY),
                    mask(COCOA), List.of(WHEAT, EGG, SUGARBAG), 160),
            new Base("donut_pink", Kind.BUNS, 2, 0, 1, 0, mask(SUGAR, CARAMEL, CREAM, BERRY),
                    mask(COCOA), List.of(WHEAT, EGG, SUGARBAG), 160),
            new Base("donut_choc", Kind.BUNS, 1, 0, 0, 2, mask(SUGAR, CARAMEL, CREAM, CHOCOLATE),
                    mask(COCOA), List.of(WHEAT, EGG, SUGARBAG), 160),
            new Base("cupcake_pink", Kind.CAKES, 2, 1, 0, 0, mask(CREAM, BERRY, VANILLA, SUGAR),
                    mask(HONEY), List.of(WHEAT, EGG, MILK), 200),
            new Base("cupcake_choc", Kind.CAKES, 1, 1, 0, 2, mask(CREAM, BERRY, VANILLA, CHOCOLATE),
                    mask(HONEY), List.of(WHEAT, EGG, MILK), 200),
            new Base("muffin_blueberry", Kind.BUNS, 1, 0, 2, 0, mask(CARAMEL, CREAM, BERRY, VANILLA),
                    mask(COCOA), List.of(WHEAT, EGG, SUGARBAG), 160),
            new Base("cream_puff", Kind.BUNS, 1, 2, 0, 0, mask(SUGAR, CARAMEL, CREAM, VANILLA),
                    mask(COCOA), List.of(WHEAT, EGG, SUGARBAG), 160),
            new Base("eclair", Kind.BUNS, 1, 1, 0, 1, mask(SUGAR, CARAMEL, CREAM, CHOCOLATE),
                    mask(COCOA), List.of(WHEAT, EGG, SUGARBAG), 160),
            new Base("cinnamon_roll", Kind.BUNS, 2, 0, 0, 0, mask(SUGAR, CARAMEL, CREAM, APPLE),
                    mask(COCOA), List.of(WHEAT, EGG, SUGARBAG), 160),
            new Base("cookie_choc", Kind.COOKIES, 1, 0, 0, 2, mask(CHOCOLATE, HONEY, VANILLA, CARAMEL),
                    mask(APPLE), List.of(WHEAT, SUGARBAG, COCOABEANS), 140),
            new Base("cookie_heart", Kind.COOKIES, 2, 0, 0, 0, mask(CHOCOLATE, HONEY, VANILLA, BERRY),
                    mask(APPLE), List.of(WHEAT, SUGARBAG, COCOABEANS), 140),
            new Base("gingerbread_man", Kind.COOKIES, 1, 0, 0, 0, mask(CHOCOLATE, HONEY, VANILLA, SUGAR),
                    mask(APPLE), List.of(WHEAT, SUGARBAG, COCOABEANS), 140),
            new Base("macaron_pink", Kind.COOKIES, 2, 0, 1, 0, mask(HONEY, VANILLA, BERRY, CREAM),
                    mask(APPLE), List.of(WHEAT, SUGARBAG, COCOABEANS), 140),
            new Base("macaron_mint", Kind.COOKIES, 2, 1, 0, 0, mask(CHOCOLATE, HONEY, VANILLA, CREAM),
                    mask(APPLE), List.of(WHEAT, SUGARBAG, COCOABEANS), 140),
            new Base("macaron_lemon", Kind.COOKIES, 1, 0, 2, 0, mask(HONEY, VANILLA, CREAM),
                    mask(APPLE, CHOCOLATE), List.of(WHEAT, SUGARBAG, COCOABEANS), 140),
            new Base("cake_pop", Kind.CAKES, 2, 0, 0, 1, mask(CREAM, BERRY, VANILLA, CHOCOLATE),
                    mask(HONEY), List.of(WHEAT, EGG, MILK), 200),
            new Base("cheesecake", Kind.CAKES, 1, 2, 0, 0, mask(BERRY, VANILLA, CARAMEL, HONEY),
                    mask(COCOA), List.of(WHEAT, EGG, MILK), 200),
            new Base("cake_strawberry", Kind.CAKES, 1, 1, 2, 0, mask(CREAM, BERRY, VANILLA, SUGAR),
                    mask(HONEY), List.of(WHEAT, EGG, MILK), 200),
            new Base("cake_choc", Kind.CAKES, 1, 1, 0, 2, mask(CREAM, BERRY, VANILLA, COCOA),
                    mask(HONEY), List.of(WHEAT, EGG, MILK), 200),
            new Base("tiramisu", Kind.CAKES, 1, 2, 0, 1, mask(CREAM, VANILLA, COCOA),
                    mask(HONEY, BERRY), List.of(WHEAT, EGG, MILK), 200),
            new Base("apple_pie", Kind.PIES, 1, 0, 2, 0, mask(CARAMEL, HONEY, APPLE, VANILLA),
                    mask(COCOA), List.of(WHEAT, APPLES, SUGARBAG), 180),
            new Base("medovik", Kind.CAKES, 2, 1, 0, 0, mask(CREAM, BERRY, VANILLA, HONEY),
                    mask(APPLE), List.of(WHEAT, EGG, MILK), 200),
            new Base("brownie", Kind.PIES, 1, 0, 0, 3, mask(CARAMEL, HONEY, CHOCOLATE, CREAM),
                    mask(APPLE, COCOA), List.of(WHEAT, APPLES, SUGARBAG), 180),
            new Base("waffle", Kind.PIES, 1, 1, 0, 0, mask(HONEY, APPLE, BERRY, CHOCOLATE),
                    mask(COCOA), List.of(WHEAT, APPLES, SUGARBAG), 180),
            new Base("pancakes", Kind.PIES, 1, 1, 0, 0, mask(CARAMEL, HONEY, APPLE, BERRY),
                    mask(COCOA), List.of(WHEAT, APPLES, SUGARBAG), 180),
            new Base("ice_cream_cone", Kind.CREAMS, 2, 2, 0, 0, mask(BERRY, CARAMEL, CHOCOLATE, VANILLA),
                    mask(HONEY), List.of(CREAMBOX, EGG, SUGARBAG), 160),
            new Base("sundae", Kind.CREAMS, 2, 2, 1, 0, mask(BERRY, CARAMEL, CHOCOLATE, APPLE),
                    mask(HONEY), List.of(CREAMBOX, EGG, SUGARBAG), 160),
            new Base("creme_brulee", Kind.CREAMS, 1, 2, 0, 0, mask(CARAMEL, CHOCOLATE, VANILLA, SUGAR),
                    mask(HONEY), List.of(CREAMBOX, EGG, SUGARBAG), 160),
            new Base("panna_cotta", Kind.CREAMS, 0, 2, 0, 0, mask(CARAMEL, CHOCOLATE, VANILLA, HONEY),
                    mask(APPLE), List.of(CREAMBOX, EGG, SUGARBAG), 160),
            new Base("flan", Kind.CREAMS, 1, 2, 0, 0, mask(BERRY, CARAMEL, CHOCOLATE, HONEY),
                    mask(APPLE), List.of(CREAMBOX, EGG, SUGARBAG), 160),
            new Base("fruit_tart", Kind.PIES, 1, 0, 2, 0, mask(HONEY, APPLE, CREAM, BERRY),
                    mask(COCOA, CARAMEL), List.of(WHEAT, APPLES, SUGARBAG), 180),
            new Base("baklava", Kind.PIES, 2, 0, 0, 0, mask(CARAMEL, HONEY, APPLE, SUGAR),
                    mask(COCOA, CREAM), List.of(WHEAT, APPLES, SUGARBAG), 180));

    private Menu() {}

    public static int size() { return ALL.size(); }

    /** The base of an index (drinks first), null outside the menu. */
    public static Base get(int i) {
        return i >= 0 && i < ALL.size() ? ALL.get(i) : null;
    }

    public static int indexOf(String id) {
        for (int i = 0; i < ALL.size(); i++) {
            if (ALL.get(i).id().equals(id)) return i;
        }
        return -1;
    }

    public static int dessertIndex(int dessertOrdinal) {
        return DRINKS + dessertOrdinal;
    }
}
