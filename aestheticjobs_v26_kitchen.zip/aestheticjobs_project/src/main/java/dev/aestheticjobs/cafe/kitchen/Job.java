package dev.aestheticjobs.cafe.kitchen;

/**
 * What one station (coffee machine or pastry oven) is doing: free, cooking by itself, or holding a finished result.
 * Nothing has to tick: the state follows from the game time.
 */
public final class Job {
    public enum State { IDLE, WORKING, READY }

    /** After this long a finished result may be taken by anybody, so a station is never blocked for good. */
    public static final long OWNER_TICKS = 1200L;

    private int base = -1, mask, art;
    private long start, ready;
    private String owner = "";
    private boolean paid;

    public int base() { return base; }
    public int mask() { return mask; }
    public int art() { return art; }
    public long start() { return start; }
    public long ready() { return ready; }
    public String owner() { return owner; }
    /** The ingredients really came out of an inventory (creative mode takes nothing). */
    public boolean paid() { return paid; }

    public State state(long now) {
        return base < 0 ? State.IDLE : now < ready ? State.WORKING : State.READY;
    }

    /** 0..1 of the cooking. */
    public float progress(long now, float partial) {
        if (base < 0 || ready <= start) return 0.0F;
        return Math.max(0.0F, Math.min(1.0F, (now - start + partial) / (ready - start)));
    }

    public boolean begin(int newBase, int newMask, int newArt, String player, long now, boolean takesIngredients) {
        if (base >= 0 || !Cooking.valid(newBase, newMask)) return false;
        base = newBase;
        mask = newMask;
        art = Math.max(0, newArt);
        owner = player;
        paid = takesIngredients;
        start = now;
        ready = now + Menu.get(newBase).ticks();
        return true;
    }

    public boolean mayCollect(String player, long now) {
        return state(now) == State.READY && (owner.equals(player) || now - ready >= OWNER_TICKS);
    }

    public void clear() {
        base = -1;
        mask = art = 0;
        start = ready = 0L;
        owner = "";
        paid = false;
    }

    /** Restores a saved job; anything that does not make sense becomes a free station. */
    public void load(int savedBase, int savedMask, int savedArt, long savedStart, long savedReady, String savedOwner, boolean savedPaid) {
        clear();
        if (!Cooking.valid(savedBase, savedMask) || savedReady < savedStart
                || savedReady - savedStart > Menu.get(savedBase).ticks()) return;
        base = savedBase;
        mask = savedMask;
        art = Math.max(0, savedArt);
        start = savedStart;
        ready = savedReady;
        owner = savedOwner;
        paid = savedPaid;
    }
}
