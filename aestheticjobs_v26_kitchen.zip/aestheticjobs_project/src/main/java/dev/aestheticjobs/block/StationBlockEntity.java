package dev.aestheticjobs.block;

import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.KitchenData;
import dev.aestheticjobs.cafe.Order;
import dev.aestheticjobs.cafe.OrderExtra;
import dev.aestheticjobs.cafe.kitchen.Cooking;
import dev.aestheticjobs.cafe.kitchen.Extra;
import dev.aestheticjobs.cafe.kitchen.Job;
import dev.aestheticjobs.cafe.kitchen.Knowledge;
import dev.aestheticjobs.cafe.kitchen.Menu;
import dev.aestheticjobs.cafe.kitchen.Signature;
import dev.aestheticjobs.job.Shift;
import dev.aestheticjobs.network.OpenKitchenPayload;
import dev.aestheticjobs.registry.ModComponents;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * A cooking station (coffee machine, pastry oven). The player chooses a recipe on the kitchen screen, the server takes
 * the ingredients, the station cooks by itself and keeps the result until it is taken. Every rule is checked here;
 * the client only asks. A free station does nothing in its tick.
 */
public abstract class StationBlockEntity extends BlockEntity {
    private final Job job = new Job();

    protected StationBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    public Job job() {
        return job;
    }

    /** Drinks or desserts? */
    public abstract boolean cooksDrinks();

    /** The block state that shows this stage. */
    protected abstract BlockState shown(BlockState state, Job.State stage);

    /** The finished item(s) for a player; asBarista = he works in the cafe right now. */
    protected abstract ItemStack result(ServerLevel level, boolean asBarista);

    protected abstract SoundEvent startSound();

    // ------------------------------------------------------------------ the player

    /** Right click: take the result if it is there for this player, otherwise open the kitchen screen. */
    public void use(ServerPlayer player) {
        if (level == null) return;
        if (job.mayCollect(player.getUUID().toString(), level.getGameTime())) collect(player);
        else sendScreen(player, true);
    }

    /** Sends what the screen needs to know; open = false only refreshes a screen that is already open. */
    public void sendScreen(ServerPlayer player, boolean open) {
        Knowledge knowledge = KitchenData.get(player.server).of(player.getUUID());
        List<Integer> tried = new ArrayList<>();
        for (int mask : knowledge.triedCopy()) tried.add(mask);
        int wanted = -1, wish = 0, customer = -1;
        ItemStack ticket = CafeLogic.findTicket(player);
        Order order = ticket.isEmpty() ? null : ticket.get(ModComponents.ORDER.get());
        if (order != null) {
            customer = order.isPlayerOrder() ? -2 : order.customer();          // -2: a real player ordered
            if (cooksDrinks()) {
                wanted = order.drink();
                OrderExtra extra = ticket.get(ModComponents.ORDER_EXTRA.get());
                if (extra != null) wish = extra.wish();
            } else if (order.dessert() >= 0) {
                wanted = Menu.dessertIndex(order.dessert());
            }
        }
        PacketDistributor.sendToPlayer(player,
                new OpenKitchenPayload(worldPosition, open, tried, knowledge.foundBits(), wanted, wish, customer));
    }

    public void start(ServerPlayer player, int base, int mask, int art) {
        if (!(level instanceof ServerLevel sl)) return;
        Menu.Base recipe = Menu.get(base);
        if (recipe == null || recipe.isDrink() != cooksDrinks() || !Cooking.valid(base, mask)) return;
        long now = sl.getGameTime();
        if (job.state(now) != Job.State.IDLE) {
            tell(player, Component.translatable("kitchen.aestheticjobs.busy"));
            return;
        }
        boolean free = player.getAbilities().instabuild;
        List<String> shopping = Cooking.shopping(base, mask);
        if (!free) {
            for (String id : shopping) {                                      // the same item may be needed twice
                int need = (int) shopping.stream().filter(id::equals).count();
                if (count(player, item(id)) < need) {
                    tell(player, Component.translatable("kitchen.aestheticjobs.missing", item(id).getDescription()));
                    return;
                }
            }
        }
        if (!job.begin(base, mask, art, player.getUUID().toString(), now, !free)) return;
        if (!free) {
            for (String id : shopping) takeOne(player, item(id));
        }
        if (CafeLogic.isWorking(player)) Shift.touch(player);

        KitchenData data = KitchenData.get(player.server);
        Signature found = data.of(player.getUUID()).learn(base, mask);
        data.setDirty();
        if (found != null) {
            player.sendSystemMessage(Component.translatable("kitchen.aestheticjobs.discovered",
                    Component.translatable("signature.aestheticjobs." + found.id())).withStyle(ChatFormatting.GOLD));
            play(sl, SoundEvents.PLAYER_LEVELUP, 0.7F, 1.4F);
            puff(sl, ParticleTypes.HAPPY_VILLAGER, 16, 1.2);
        }
        play(sl, startSound(), 0.8F, 1.0F);
        changed();
        sendScreen(player, false);
    }

    public void collect(ServerPlayer player) {
        if (!(level instanceof ServerLevel sl)) return;
        if (!job.mayCollect(player.getUUID().toString(), sl.getGameTime())) return;
        boolean working = CafeLogic.isWorking(player);
        ItemStack out = result(sl, working);
        int stars = Cooking.stars(Cooking.quality(job.base(), job.mask()));
        boolean bottle = job.paid() && Extra.HONEY.in(job.mask());
        Component name = recipeName(job.base(), job.mask());
        job.clear();                                                           // first free the station: never twice
        player.getInventory().placeItemBackInInventory(out);
        if (bottle) player.getInventory().placeItemBackInInventory(new ItemStack(Items.GLASS_BOTTLE));
        if (working) Shift.touch(player);
        tell(player, Component.translatable("kitchen.aestheticjobs.done", name, dev.aestheticjobs.cafe.CupData.starText(stars)));
        play(sl, SoundEvents.EXPERIENCE_ORB_PICKUP, 0.8F, 0.8F + stars * 0.12F);
        puff(sl, stars >= 5 ? ParticleTypes.HEART : ParticleTypes.HAPPY_VILLAGER, 2 + stars * 2, 1.15);
        changed();
    }

    /** The name of a recipe: its signature name if it has one. */
    public static Component recipeName(int base, int mask) {
        Signature s = Signature.of(base, mask);
        if (s != null) return Component.translatable("signature.aestheticjobs." + s.id());
        Menu.Base b = Menu.get(base);
        if (b == null) return Component.empty();
        return Component.translatable((b.isDrink() ? "drink." : "item.") + "aestheticjobs." + b.id());
    }

    /** A broken station gives back the ingredients of a running job, or the finished result. */
    public void dropContents() {
        if (!(level instanceof ServerLevel sl)) return;
        Job.State stage = job.state(sl.getGameTime());
        if (stage == Job.State.WORKING && job.paid()) {
            for (String id : Cooking.shopping(job.base(), job.mask())) {
                Block.popResource(sl, worldPosition, new ItemStack(item(id)));
            }
        } else if (stage == Job.State.READY) {
            Block.popResource(sl, worldPosition, result(sl, false));
            if (job.paid() && Extra.HONEY.in(job.mask())) Block.popResource(sl, worldPosition, new ItemStack(Items.GLASS_BOTTLE));
        }
        job.clear();
    }

    // ------------------------------------------------------------------ helpers

    public static Item item(String id) {
        return BuiltInRegistries.ITEM.get(ResourceLocation.parse(id));
    }

    /** Counted over the whole inventory, the off hand included. */
    public static int count(net.minecraft.world.entity.player.Player player, Item item) {
        int n = 0;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack s = player.getInventory().getItem(i);
            if (s.is(item)) n += s.getCount();
        }
        return n;
    }

    private static void takeOne(ServerPlayer player, Item item) {
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack s = player.getInventory().getItem(i);
            if (s.is(item)) {
                s.shrink(1);
                return;
            }
        }
    }

    private static void tell(ServerPlayer player, Component message) {
        player.displayClientMessage(message, true);
    }

    private void play(ServerLevel sl, SoundEvent sound, float volume, float pitch) {
        sl.playSound(null, worldPosition, sound, SoundSource.BLOCKS, volume, pitch);
    }

    private void puff(ServerLevel sl, ParticleOptions particle, int count, double height) {
        sl.sendParticles(particle, worldPosition.getX() + 0.5, worldPosition.getY() + height, worldPosition.getZ() + 0.5,
                count, 0.2, 0.1, 0.2, 0.01);
    }

    private void changed() {
        if (level == null) return;
        setChanged();
        BlockState state = getBlockState();
        BlockState next = shown(state, job.state(level.getGameTime()));
        if (next != state) level.setBlock(worldPosition, next, Block.UPDATE_ALL);
        level.sendBlockUpdated(worldPosition, next, next, Block.UPDATE_CLIENTS);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, StationBlockEntity station) {
        if (station.job.base() < 0 || !(level instanceof ServerLevel sl)) return;
        long now = level.getGameTime();
        if (now % 4 != 0) return;
        Job.State stage = station.job.state(now);
        BlockState next = station.shown(state, stage);
        if (next != state) {
            level.setBlock(pos, next, Block.UPDATE_ALL);
        }
        // one chime, in the first four ticks after the result is ready (works whatever the look of the block is)
        if (stage == Job.State.READY && now - station.job.ready() < 4) {
            station.play(sl, SoundEvents.AMETHYST_BLOCK_CHIME, 1.4F, 1.4F);
            station.puff(sl, ParticleTypes.WAX_ON, 8, 1.0);
        }
    }

    // ------------------------------------------------------------------ saving and syncing

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("base", job.base());
        tag.putInt("mask", job.mask());
        tag.putInt("art", job.art());
        tag.putLong("start", job.start());
        tag.putLong("ready", job.ready());
        tag.putString("owner", job.owner());
        tag.putBoolean("paid", job.paid());
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        job.load(tag.contains("base") ? tag.getInt("base") : -1, tag.getInt("mask"), tag.getInt("art"),
                tag.getLong("start"), tag.getLong("ready"), tag.getString("owner"), tag.getBoolean("paid"));
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
