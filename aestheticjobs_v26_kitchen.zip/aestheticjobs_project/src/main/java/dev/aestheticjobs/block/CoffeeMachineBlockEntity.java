package dev.aestheticjobs.block;

import dev.aestheticjobs.cafe.CupData;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.kitchen.Cooking;
import dev.aestheticjobs.cafe.kitchen.Job;
import dev.aestheticjobs.cafe.kitchen.LatteArt;
import dev.aestheticjobs.registry.ModBlockEntities;
import dev.aestheticjobs.registry.ModComponents;
import dev.aestheticjobs.registry.ModItems;
import dev.aestheticjobs.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** The espresso machine: brews the chosen drink by itself; the renderer shows the cup filling up. */
public class CoffeeMachineBlockEntity extends StationBlockEntity {
    public CoffeeMachineBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.COFFEE_MACHINE.get(), pos, state);
    }

    @Override
    public boolean cooksDrinks() {
        return true;
    }

    /** BREWING switches to the model without the built-in cup: the renderer draws the live one. */
    @Override
    protected BlockState shown(BlockState state, Job.State stage) {
        boolean busy = stage != Job.State.IDLE;
        if (!state.hasProperty(CoffeeMachineBlock.BREWING) || state.getValue(CoffeeMachineBlock.BREWING) == busy) return state;
        return state.setValue(CoffeeMachineBlock.BREWING, busy);
    }

    @Override
    protected ItemStack result(ServerLevel level, boolean asBarista) {
        Drink drink = Drink.byIndex(job().base());
        if (drink == null) return ItemStack.EMPTY;
        ItemStack cup = new ItemStack(ModItems.COFFEE_CUP.get());
        String art = LatteArt.picture(job().base(), job().mask(), job().art());
        cup.set(ModComponents.CUP.get(), new CupData(art, drink.ordinal(), Cooking.quality(job().base(), job().mask()), job().mask()));
        cup.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(drink.modelData()));
        return cup;
    }

    @Override
    protected SoundEvent startSound() {
        return ModSounds.BARISTA_GRIND.get();
    }

    /** Steam from the cup, only while there is one. */
    public static void clientTick(Level level, BlockPos pos, BlockState state, CoffeeMachineBlockEntity be) {
        if (be.job().base() < 0 || level.random.nextInt(5) != 0) return;
        Direction f = state.getValue(CoffeeMachineBlock.FACING);
        double out = 0.32;                                                     // the cup stands in front of the middle
        level.addParticle(ParticleTypes.CLOUD, pos.getX() + 0.5 + f.getStepX() * out, pos.getY() + 0.27,
                pos.getZ() + 0.5 + f.getStepZ() * out, 0.0, 0.012, 0.0);
    }
}
