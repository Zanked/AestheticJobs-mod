package dev.aestheticjobs.block;

import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.Plate;
import dev.aestheticjobs.cafe.kitchen.Cooking;
import dev.aestheticjobs.cafe.kitchen.Job;
import dev.aestheticjobs.cafe.kitchen.Menu;
import dev.aestheticjobs.entity.CafeStaffEntity;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.registry.ModBlockEntities;
import dev.aestheticjobs.registry.ModComponents;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.block.state.BlockState;

/** The pastry oven: bakes the chosen dessert by itself; the renderer shows it in the window and on the counter. */
public class PastryOvenBlockEntity extends StationBlockEntity {
    public PastryOvenBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.PASTRY_OVEN.get(), pos, state);
    }

    @Override
    public boolean cooksDrinks() {
        return false;
    }

    @Override
    protected BlockState shown(BlockState state, Job.State stage) {
        int look = stage.ordinal();
        return state.getValue(PastryOvenBlock.LOOK) == look ? state : state.setValue(PastryOvenBlock.LOOK, look);
    }

    /** The dessert of a base of the menu, null for a drink. */
    public static Dessert dessert(int base) {
        return Dessert.byIndex(base - Menu.DRINKS);
    }

    /**
     * A barista on duty gets a plate for the customer. Everybody else gets desserts to eat: one below three stars, two
     * from three stars on; five stars make them a masterpiece with a short effect (see cafe/CafeTreat).
     */
    @Override
    protected ItemStack result(ServerLevel level, boolean asBarista) {
        Dessert dessert = dessert(job().base());
        if (dessert == null) return ItemStack.EMPTY;
        int stars = Cooking.stars(Cooking.quality(job().base(), job().mask()));
        if (asBarista) {
            return CafeLogic.makePlate(new Plate(dessert.ordinal(), level.getGameTime() + CafeStaffEntity.PLATE_LIFE, stars));
        }
        ItemStack stack = new ItemStack(dessert.item(), stars >= 3 ? 2 : 1);
        if (stars < 5) return stack;
        Menu.Kind kind = Menu.get(job().base()).kind();
        stack.set(ModComponents.MASTERPIECE.get(), kind.ordinal());
        stack.set(DataComponents.LORE, new ItemLore(List.of(
                Component.translatable("kitchen.aestheticjobs.masterpiece").withStyle(ChatFormatting.GOLD),
                Component.translatable("kitchen.aestheticjobs.effect." + kind.id()).withStyle(ChatFormatting.GRAY))));
        return stack;
    }

    @Override
    protected SoundEvent startSound() {
        return SoundEvents.IRON_TRAPDOOR_CLOSE;
    }
}
