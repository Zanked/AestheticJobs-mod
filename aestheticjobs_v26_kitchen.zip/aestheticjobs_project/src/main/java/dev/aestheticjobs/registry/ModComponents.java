package dev.aestheticjobs.registry;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.cafe.CupData;
import dev.aestheticjobs.cafe.Order;
import dev.aestheticjobs.cafe.OrderExtra;
import dev.aestheticjobs.cafe.Plate;
import dev.aestheticjobs.cafe.Purchase;
import dev.aestheticjobs.item.CardOwner;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import com.mojang.serialization.Codec;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModComponents {
    public static final DeferredRegister.DataComponents COMPONENTS =
            DeferredRegister.createDataComponents(Registries.DATA_COMPONENT_TYPE, AestheticJobs.MODID);

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<CardOwner>> CARD_OWNER =
            COMPONENTS.registerComponentType("card_owner",
                    builder -> builder.persistent(CardOwner.CODEC).networkSynchronized(CardOwner.STREAM_CODEC));

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<CupData>> CUP =
            COMPONENTS.registerComponentType("cup",
                    builder -> builder.persistent(CupData.CODEC).networkSynchronized(CupData.STREAM_CODEC));

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Order>> ORDER =
            COMPONENTS.registerComponentType("order",
                    builder -> builder.persistent(Order.CODEC).networkSynchronized(Order.STREAM_CODEC));

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Plate>> PLATE =
            COMPONENTS.registerComponentType("plate",
                    builder -> builder.persistent(Plate.CODEC).networkSynchronized(Plate.STREAM_CODEC));

    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Purchase>> PURCHASE =
            COMPONENTS.registerComponentType("purchase",
                    builder -> builder.persistent(Purchase.CODEC).networkSynchronized(Purchase.STREAM_CODEC));

    /** On a ticket: the special wish and the kind of guest. */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<OrderExtra>> ORDER_EXTRA =
            COMPONENTS.registerComponentType("order_extra",
                    builder -> builder.persistent(OrderExtra.CODEC).networkSynchronized(OrderExtra.STREAM_CODEC));

    /** On a cup: the wish it was brewed for (index in cafe/career/Wish). */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> CUP_WISH =
            COMPONENTS.registerComponentType("cup_wish",
                    builder -> builder.persistent(Codec.INT).networkSynchronized(ByteBufCodecs.VAR_INT));

    /** On a five star dessert from the pastry oven: its family (ordinal of cafe/kitchen/Menu.Kind). */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> MASTERPIECE =
            COMPONENTS.registerComponentType("masterpiece",
                    builder -> builder.persistent(Codec.INT).networkSynchronized(ByteBufCodecs.VAR_INT));

    private ModComponents() {}
}
