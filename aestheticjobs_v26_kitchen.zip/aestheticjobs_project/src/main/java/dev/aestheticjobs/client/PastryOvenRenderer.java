package dev.aestheticjobs.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.aestheticjobs.block.PastryOvenBlock;
import dev.aestheticjobs.block.PastryOvenBlockEntity;
import dev.aestheticjobs.cafe.CafeLogic;
import dev.aestheticjobs.cafe.kitchen.Job;
import dev.aestheticjobs.item.Dessert;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/**
 * Shows the real 3D dessert: inside the window while it bakes and on its plate on the counter when it is ready.
 * The places are the ones of tools/gen_oven.py.
 */
public class PastryOvenRenderer implements BlockEntityRenderer<PastryOvenBlockEntity> {
    private final ItemRenderer items;
    private final ItemStack[] desserts = new ItemStack[Dessert.values().length];
    private final ItemStack[] plates = new ItemStack[Dessert.values().length];

    public PastryOvenRenderer(BlockEntityRendererProvider.Context context) {
        this.items = context.getItemRenderer();
    }

    @Override
    public void render(PastryOvenBlockEntity oven, float pt, PoseStack pose, MultiBufferSource buffers, int light, int overlay) {
        Job job = oven.job();
        Dessert dessert = PastryOvenBlockEntity.dessert(job.base());
        if (dessert == null || oven.getLevel() == null) return;        // a free oven draws nothing
        long now = oven.getLevel().getGameTime();
        float time = (now % 24000L) + pt;

        pose.pushPose();
        pose.translate(0.5, 0.0, 0.5);
        pose.mulPose(Axis.YP.rotationDegrees(180.0F - oven.getBlockState().getValue(PastryOvenBlock.FACING).toYRot()));
        if (job.state(now) == Job.State.WORKING) {                       // it rises in the window
            float grow = 0.7F + 0.3F * job.progress(now, pt);
            draw(oven, pose, buffers, stack(dessert), 0.0, 2.0 / 16.0, -0.27, 0.36F * grow, 180.0F, LightTexture.pack(13, 10), overlay);
        } else {                                                          // ready: on its plate on the counter
            float bob = 0.015F + (float) Math.sin(time * 0.12F) * 0.015F;
            draw(oven, pose, buffers, plate(dessert), 0.0, 12.0 / 16.0 + bob, -0.06, 0.55F, time * 1.5F, light, overlay);
        }
        pose.popPose();
    }

    /** Draws the item model with its bottom at (x, y, z), turned around its own axis. */
    private void draw(PastryOvenBlockEntity oven, PoseStack pose, MultiBufferSource buffers, ItemStack stack,
                      double x, double y, double z, float scale, float turn, int light, int overlay) {
        pose.pushPose();
        pose.translate(x, y + 0.5 * scale, z);
        pose.mulPose(Axis.YP.rotationDegrees(turn));
        pose.scale(scale, scale, scale);
        items.renderStatic(stack, ItemDisplayContext.NONE, light, overlay, pose, buffers, oven.getLevel(), 0);
        pose.popPose();
    }

    private ItemStack stack(Dessert d) {
        ItemStack s = desserts[d.ordinal()];
        if (s == null) desserts[d.ordinal()] = s = new ItemStack(d.item());
        return s;
    }

    private ItemStack plate(Dessert d) {
        ItemStack s = plates[d.ordinal()];
        if (s == null) plates[d.ordinal()] = s = CafeLogic.makePlate(d.ordinal(), Long.MAX_VALUE);
        return s;
    }

    @Override
    public int getViewDistance() {
        return 32;
    }
}
