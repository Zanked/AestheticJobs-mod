package dev.aestheticjobs.client;

import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.career.Career;
import dev.aestheticjobs.cafe.career.Quest;
import dev.aestheticjobs.economy.Money;
import dev.aestheticjobs.network.JournalPayload;
import java.util.List;
import java.util.Locale;
import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * The journal of the barista: an open notebook. Left page: the drink of the day and today's tasks.
 * Right page: the mastery of every drink, the streak, the rating and how cosy the cafe is.
 */
public class JournalScreen extends Screen {
    private static final int W = 372, H = 236, PAGE = 178;
    private static final int[] MEDAL = {0xFFD8CBB0, 0xFFC9844E, 0xFFB9C4CC, 0xFFF2BC38};
    private static final int[] MEDAL_DARK = {0xFFB5A58A, 0xFF8F5A30, 0xFF7E8B94, 0xFFB0801C};

    private final JournalPayload data;
    private final long openedAt = Util.getNanos();
    private int left, top;

    public JournalScreen(JournalPayload data) {
        super(Component.translatable("gui.aestheticjobs.journal.title"));
        this.data = data;
    }

    @Override
    protected void init() {
        left = (width - W) / 2;
        top = (height - H) / 2;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private static String fit(net.minecraft.client.gui.Font font, Component c, int max) {
        String s = c.getString();
        return font.width(s) <= max ? s : font.plainSubstrByWidth(s, max - 6) + "...";
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        renderBackground(g, mx, my, partial);
        float t = (Util.getNanos() - openedAt) / 1.0E9F;
        float grow = Math.min(1.0F, t / 0.35F);

        // the leather cover, the two pages, the stitches and the ribbon
        Ui.box(g, left - 7, top - 7, W + 14, H + 14, 0xFF3F2A20, 0xFF7A5240);
        for (int i = left - 3; i < left + W + 2; i += 6) {
            g.fill(i, top - 4, i + 3, top - 3, 0xFFD9B98C);
            g.fill(i, top + H + 3, i + 3, top + H + 4, 0xFFD9B98C);
        }
        for (int p = 0; p < 2; p++) {
            int px = left + p * (PAGE + 16);
            Ui.box(g, px, top, PAGE, H, 0xFFD8C49C, 0xFFFFF6E2);
            for (int ly = top + 30; ly < top + H - 8; ly += 12) g.fill(px + 8, ly + 10, px + PAGE - 8, ly + 11, 0x22A08A60);
        }
        g.fill(left + PAGE, top + 2, left + PAGE + 16, top + H - 2, 0xFFE9DAB8);
        for (int ry = top + 12; ry < top + H - 10; ry += 18) {                     // the rings of the binding
            g.fill(left + PAGE - 4, ry, left + PAGE + 20, ry + 4, 0xFF8A7A62);
            g.fill(left + PAGE - 4, ry, left + PAGE + 20, ry + 1, 0xFFE8DCC0);
        }
        g.fill(left + W - 24, top - 7, left + W - 14, top + 14, 0xFFD9707E);
        g.fill(left + W - 24, top + 14, left + W - 21, top + 17, 0xFFD9707E);
        g.fill(left + W - 17, top + 14, left + W - 14, top + 17, 0xFFD9707E);

        Component tip = leftPage(g, left + 9, top + 9, t, grow, mx, my);
        Component tip2 = rightPage(g, left + PAGE + 16 + 9, top + 9, t, grow, mx, my);
        if (tip == null) tip = tip2;
        if (tip != null) g.renderTooltip(font, tip, mx, my);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mx, int my, float partial) {
        g.fill(0, 0, width, height, 0x99160F0C);
    }

    private Component leftPage(GuiGraphics g, int x, int y, float t, float grow, int mx, int my) {
        int w = PAGE - 18;
        Ui.centered(g, font, Component.translatable("gui.aestheticjobs.journal.title"), x + w / 2, y, Ui.INK);

        // the drink of the day with turning rays behind it
        int cy = y + 40, cx = x + 28;
        Ui.box(g, x, y + 14, w, 54, 0xFFE0B860, 0xFFFFEFC0);
        for (int i = 0; i < 12; i++) {
            double a = t * 0.7 + i * Math.PI / 6.0;
            for (int d = 12; d < 25; d += 2) {
                int rx = cx + (int) Math.round(Math.cos(a) * d), ry = cy + (int) Math.round(Math.sin(a) * d);
                g.fill(rx, ry, rx + 2, ry + 2, i % 2 == 0 ? 0xFFF8D880 : 0xFFFCE4A0);
            }
        }
        Drink daily = Drink.byIndex(data.daily());
        if (daily != null) {
            Ui.icon(g, daily.iconTexture(), cx - 16, cy - 16 + (int) Math.round(Math.sin(t * 2.5) * 1.5), 32);
            Ui.text(g, font, Component.translatable("gui.aestheticjobs.journal.daily"), x + 56, y + 23, 0xFF9A6A20);
            Ui.text(g, font, daily.displayName().copy(), x + 56, y + 36, Ui.INK);
            Ui.text(g, font, Component.translatable("gui.aestheticjobs.journal.daily.bonus", Career.DAILY_BONUS), x + 56, y + 50, Ui.GOOD_D);
        }

        Ui.text(g, font, Component.translatable("gui.aestheticjobs.journal.tasks"), x, y + 76, Ui.LABEL);
        List<JournalPayload.Task> tasks = data.tasks();
        Quest.Type[] types = Quest.Type.values();
        Component tip = null;
        for (int i = 0; i < tasks.size(); i++) {
            JournalPayload.Task task = tasks.get(i);
            if (task.type() < 0 || task.type() >= types.length) continue;
            int ty = y + 88 + i * 43;
            Ui.box(g, x, ty, w, 39, task.done() ? Ui.GOOD_D : Ui.KHAKI, task.done() ? 0xFFEEF6E4 : 0xFFFFFBEF);
            Drink d = Drink.byIndex(task.drink());
            Component name = d == null
                    ? Component.translatable("quest.aestheticjobs." + types[task.type()].id(), task.target())
                    : Component.translatable("quest.aestheticjobs.drink", task.target(), d.displayName());
            Ui.text(g, font, Component.literal(fit(font, name, w - 12)), x + 6, ty + 5, Ui.INK);
            if (Ui.in(mx, my, x, ty, w, 39)) tip = name;
            int barW = w - 64;
            Ui.bar(g, x + 7, ty + 19, barW, 5, grow * task.progress() / Math.max(1, task.target()), task.done() ? Ui.GOOD_D : Ui.WARN_D);
            Ui.text(g, font, Component.literal(task.progress() + "/" + task.target()), x + 13 + barW, ty + 18, Ui.LABEL);
            Ui.text(g, font, Component.translatable("gui.aestheticjobs.journal.reward", Money.format(task.reward())), x + 6, ty + 28, 0xFF9A6A20);
            if (task.done()) {                                                    // the stamp
                int sx = x + w - 17, sy = ty + 25;
                Ui.ring(g, sx, sy, 10, 2, 0xFFC0503C);
                Ui.line(g, sx - 5, sy, sx - 2, sy + 3, 2, 0xFFC0503C);
                Ui.line(g, sx - 2, sy + 3, sx + 4, sy - 4, 2, 0xFFC0503C);
            }
        }
        return tip;
    }

    private Component rightPage(GuiGraphics g, int x, int y, float t, float grow, int mx, int my) {
        int w = PAGE - 18;
        Ui.centered(g, font, Component.translatable("gui.aestheticjobs.journal.mastery"), x + w / 2, y, Ui.INK);
        Component tip = null;
        Drink[] all = Drink.values();
        for (int i = 0; i < all.length && i < data.cups().size(); i++) {
            int cups = data.cups().get(i), level = Career.masteryLevel(cups);
            int cx = x + (i % 4) * 40, cy = y + 13 + (i / 4) * 52;
            boolean hover = Ui.in(mx, my, cx, cy, 38, 49);
            Ui.box(g, cx, cy, 38, 49, MEDAL_DARK[level], hover ? 0xFFFFFFF4 : 0xFFFFFBEF);
            Ui.icon(g, all[i].iconTexture(), cx + 3, cy + 2, 32);
            int next = level >= 3 ? Career.MASTERY[2] : Career.MASTERY[level];
            int prev = level == 0 ? 0 : Career.MASTERY[level - 1];
            double p = level >= 3 ? 1.0 : (cups - prev) / (double) (next - prev);
            Ui.bar(g, cx + 4, cy + 38, 30, 4, p * grow, MEDAL_DARK[Math.max(1, level)]);
            Ui.disc(g, cx + 31, cy + 7, 5, MEDAL_DARK[level]);
            Ui.disc(g, cx + 31, cy + 7, 3, MEDAL[level]);
            if (level == 3 && (int) (t * 3 + i) % 5 == 0) g.fill(cx + 29, cy + 5, cx + 31, cy + 7, 0xFFFFFFFF);
            if (hover) {
                tip = level >= 3
                        ? Component.translatable("gui.aestheticjobs.journal.drink_max", all[i].displayName(), cups, Career.masteryBonus(cups))
                        : Component.translatable("gui.aestheticjobs.journal.drink", all[i].displayName(), cups, next, Career.masteryBonus(cups));
            }
        }

        // the streak
        int sy = y + 121;
        Ui.box(g, x, sy, w, 38, 0xFFE0A070, 0xFFFFEBD8);
        if (data.streak() > 0) CafeHud.flame(g, x + 16, sy + 29, t, Math.min(1.0F, data.streak() / 10.0F));
        else Ui.ring(g, x + 16, sy + 20, 6, 1, 0xFFCDBB98);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.journal.streak", data.streak()), x + 31, sy + 6, Ui.INK);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.journal.streak.bonus", Career.streakBonus(data.streak())), x + 31, sy + 17, Ui.GOOD_D);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.journal.best", data.best()), x + 31, sy + 27, Ui.LABEL);

        // numbers and how cosy the cafe is
        int ny = sy + 44;
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.journal.served", data.served()), x, ny, Ui.INK);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.journal.tips", Money.format(data.tips())), x, ny + 11, Ui.INK);
        String rating = data.rating() == 0 ? "-" : String.format(Locale.ROOT, "%.1f", data.rating() / 10.0);
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.journal.rating", rating), x, ny + 22, Ui.INK);
        int comfort = Career.comfortBonus(data.decor());
        Ui.text(g, font, Component.translatable("gui.aestheticjobs.journal.comfort", comfort), x, ny + 35, Ui.LABEL);
        Ui.bar(g, x + 1, ny + 46, w - 2, 5, grow * comfort / (double) Career.COMFORT_MAX, 0xFFE59AAB);
        if (Ui.in(mx, my, x, ny + 33, w, 20)) tip = Component.translatable("gui.aestheticjobs.journal.comfort.hint");
        return tip;
    }
}
