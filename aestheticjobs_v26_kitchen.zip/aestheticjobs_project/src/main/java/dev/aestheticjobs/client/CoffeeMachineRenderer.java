package dev.aestheticjobs.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.block.CoffeeMachineBlock;
import dev.aestheticjobs.block.CoffeeMachineBlockEntity;
import dev.aestheticjobs.cafe.Art;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.kitchen.Job;
import dev.aestheticjobs.cafe.kitchen.LatteArt;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * The live parts of the espresso machine on top of its static model: the gauge, the status lamp and, while there is a
 * drink, the cup that fills up under the stream and shows its latte art when it is ready. Coloured boxes on one white
 * texel, in block pixels (1/16) of the north-facing machine, turned to the facing of the block.
 */
public class CoffeeMachineRenderer implements BlockEntityRenderer<CoffeeMachineBlockEntity> {
    private static final ResourceLocation WHITE =
            ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "textures/block/fx_white.png");

    private static final int DARK = 0xFF4A3228, PORCELAIN = 0xFFF4EEE2, STREAM = 0xFF8A5A30, FOAM = 0xFFFCF0D6;

    // cup (outer box and wall) and its inside
    private static final double CUP_X0 = 6.6, CUP_X1 = 9.4, CUP_Z0 = 1.2, CUP_Z1 = 3.95, CUP_Y0 = 2.02, CUP_Y1 = 4.0, WALL = 0.3;
    private static final double IN_X0 = CUP_X0 + WALL, IN_X1 = CUP_X1 - WALL, IN_Z0 = CUP_Z0 + WALL, IN_Z1 = CUP_Z1 - WALL;
    private static final double IN_Y0 = CUP_Y0 + 0.3, IN_Y1 = CUP_Y1 - 0.15;

    /** The finished picture, built once per recipe and not every frame. */
    private int artKey = -1;
    private String art = "";

    public CoffeeMachineRenderer(BlockEntityRendererProvider.Context context) {}

    @Override
    public void render(CoffeeMachineBlockEntity be, float pt, PoseStack ps, MultiBufferSource buffers, int light, int overlay) {
        Level level = be.getLevel();
        if (level == null) return;
        BlockState state = be.getBlockState();
        Direction facing = state.hasProperty(CoffeeMachineBlock.FACING) ? state.getValue(CoffeeMachineBlock.FACING) : Direction.NORTH;
        Job job = be.job();
        long now = level.getGameTime();
        Job.State stage = job.state(now);
        Drink drink = Drink.byIndex(job.base());
        float progress = job.progress(now, pt);
        double clock = (now + pt) / 20.0;

        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(WHITE));

        ps.pushPose();
        ps.translate(0.5, 0.0, 0.5);
        ps.mulPose(Axis.YP.rotationDegrees(-yRot(facing)));
        ps.translate(-0.5, 0.0, -0.5);

        gauge(ps, vc, stage == Job.State.WORKING ? 0.66 + 0.035 * Math.sin(clock * 9.0) : 0.10, light, overlay);
        lamp(ps, vc, stage, clock, light, overlay);

        if (stage != Job.State.IDLE && drink != null) {
            cup(ps, vc, job, drink, stage, progress, light, overlay);
            if (stage == Job.State.WORKING && progress > 0.08F && progress < 0.96F) stream(ps, vc, drink, progress, clock, overlay);
        }
        ps.popPose();
    }

    @Override
    public int getViewDistance() {
        return 40;
    }

    private static int yRot(Direction facing) {
        return switch (facing) {
            case EAST -> 90;
            case SOUTH -> 180;
            case WEST -> 270;
            default -> 0;
        };
    }

    /** Pressure gauge on the front: rests low, trembles while the machine works. */
    private static void gauge(PoseStack ps, VertexConsumer vc, double value, int light, int overlay) {
        double angle = -115.0 + 230.0 * value;                              // clockwise from 12 o'clock, seen from the front
        box(ps, vc, 10.8, 7.4, 3.8, 13.2, 9.8, 4.0, DARK, light, overlay);          // rim
        box(ps, vc, 11.0, 7.6, 3.72, 13.0, 9.6, 3.8, 0xFFFFF6E2, light, overlay);   // face
        box(ps, vc, 11.2, 7.7, 3.69, 11.45, 8.0, 3.72, 0xFF7FA070, light, overlay);  // green zone marks
        box(ps, vc, 12.55, 7.7, 3.69, 12.8, 8.0, 3.72, 0xFFC98468, light, overlay);  // red zone mark
        ps.pushPose();
        ps.translate(12.0 / 16.0, 8.6 / 16.0, 0.0);   // dial centre
        ps.mulPose(Axis.ZP.rotationDegrees((float) angle));
        box(ps, vc, -0.09, -0.25, 3.62, 0.09, 0.8, 3.69, 0xFFC03A2A, light, overlay);   // needle (pivot at the origin)
        ps.popPose();
        box(ps, vc, 11.85, 8.45, 3.58, 12.15, 8.75, 3.69, DARK, light, overlay);     // hub
    }

    private static void lamp(PoseStack ps, VertexConsumer vc, Job.State stage, double clock, int light, int overlay) {
        int color;
        if (stage == Job.State.IDLE) {
            color = 0xFF3E6A44;
        } else if (stage == Job.State.READY) {
            color = 0xFF5CFF72;
            light = LightTexture.FULL_BRIGHT;
        } else {
            color = Ui.lerp(0xFFFF9A20, 0xFFFFD070, 0.5 + 0.5 * Math.sin(clock * 6.0));
            light = LightTexture.FULL_BRIGHT;
        }
        box(ps, vc, 3.2, 9.4, 3.82, 4.4, 10.3, 4.0, 0xFF2E2420, light, overlay);
        box(ps, vc, 3.35, 9.55, 3.78, 4.25, 10.15, 3.82, color, light, overlay);
    }

    private static double fill(float progress) {
        return Math.max(0.0, Math.min(1.0, (progress - 0.1) / 0.85));
    }

    private void cup(PoseStack ps, VertexConsumer vc, Job job, Drink drink, Job.State stage, float progress, int light, int overlay) {
        vessel(ps, vc, CUP_X0, CUP_Y0, CUP_Z0, CUP_X1, CUP_Y1, CUP_Z1, WALL, PORCELAIN, light, overlay);
        // a saucer under the cup
        box(ps, vc, CUP_X0 - 0.5, CUP_Y0, CUP_Z0 - 0.3, CUP_X1 + 0.5, CUP_Y0 + 0.12, CUP_Z1 - 0.1, 0xFFE6D9BA, light, overlay);

        double lv = stage == Job.State.READY ? 1.0 : fill(progress);
        if (lv <= 0.01) return;
        double top = IN_Y0 + (IN_Y1 - IN_Y0) * lv;
        int liquid = Ui.lerp(Ui.ESPRESSO, drink.baseColor(), lv);
        box(ps, vc, IN_X0, IN_Y0, IN_Z0, IN_X1, top - 0.02, IN_Z1, liquid, light, overlay);
        if (stage == Job.State.READY) {
            int key = (job.base() * 512 + job.mask()) * 8 + job.art() % LatteArt.STYLES.length;
            if (key != artKey) {
                artKey = key;
                art = LatteArt.picture(job.base(), job.mask(), job.art());
            }
            artTop(ps, vc, art, drink, top, light, overlay);
        } else {
            int surface = Ui.lerp(Ui.CREMA, LatteArt.paintable(job.base()) ? FOAM : Ui.CREMA, Math.max(0.0, lv * 2.0 - 1.0));
            quadUp(ps, vc, IN_X0, IN_Z0, IN_X1, IN_Z1, top, surface, light, overlay);
        }
    }

    /** Two thin streams from the spouts into the cup. */
    private static void stream(PoseStack ps, VertexConsumer vc, Drink drink, float progress, double clock, int overlay) {
        double bottom = IN_Y0 + (IN_Y1 - IN_Y0) * fill(progress);
        double half = 0.17 * (0.85 + 0.15 * Math.sin(clock * 31.0));
        int color = progress < 0.6F ? STREAM : Ui.lerp(STREAM, drink.baseColor(), (progress - 0.6) * 3.0);
        for (double x : new double[]{7.45, 8.55}) {
            box(ps, vc, x - half, bottom, 2.9 - half, x + half, 4.2, 2.9 + half, color, LightTexture.FULL_BRIGHT, overlay);
        }
    }

    private static void artTop(PoseStack ps, VertexConsumer vc, String art, Drink drink, double y, int light, int overlay) {
        double cw = (IN_X1 - IN_X0) / Drink.SIZE, cd = (IN_Z1 - IN_Z0) / Drink.SIZE;
        for (int row = 0; row < Drink.SIZE; row++) {
            for (int col = 0; col < Drink.SIZE; col++) {
                if (!Drink.inCup(col, row)) continue;
                int rgb = Art.rgb(art.charAt(row * Drink.SIZE + col), drink);
                double x1 = IN_X1 - col * cw, x0 = x1 - cw;
                double z1 = IN_Z1 - row * cd, z0 = z1 - cd;
                quadUp(ps, vc, x0, z0, x1, z1, y, rgb, light, overlay);
            }
        }
    }

    private static void vessel(PoseStack ps, VertexConsumer vc, double x0, double y0, double z0, double x1, double y1, double z1,
                               double wall, int color, int light, int overlay) {
        box(ps, vc, x0, y0, z0, x1, y0 + wall, z1, color, light, overlay);
        box(ps, vc, x0, y0 + wall, z0, x0 + wall, y1, z1, color, light, overlay);
        box(ps, vc, x1 - wall, y0 + wall, z0, x1, y1, z1, color, light, overlay);
        box(ps, vc, x0 + wall, y0 + wall, z0, x1 - wall, y1, z0 + wall, color, light, overlay);
        box(ps, vc, x0 + wall, y0 + wall, z1 - wall, x1 - wall, y1, z1, color, light, overlay);
    }


    private static void box(PoseStack ps, VertexConsumer vc, double ax, double ay, double az, double bx, double by, double bz,
                            int argb, int light, int overlay) {
        PoseStack.Pose p = ps.last();
        float x0 = (float) (ax / 16.0), y0 = (float) (ay / 16.0), z0 = (float) (az / 16.0);
        float x1 = (float) (bx / 16.0), y1 = (float) (by / 16.0), z1 = (float) (bz / 16.0);
        int r = argb >> 16 & 255, g = argb >> 8 & 255, b = argb & 255;
        // up
        v(vc, p, x0, y1, z0, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x0, y1, z1, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x1, y1, z1, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x1, y1, z0, r, g, b, light, overlay, 0, 1, 0);
        // down
        v(vc, p, x0, y0, z0, r, g, b, light, overlay, 0, -1, 0);
        v(vc, p, x1, y0, z0, r, g, b, light, overlay, 0, -1, 0);
        v(vc, p, x1, y0, z1, r, g, b, light, overlay, 0, -1, 0);
        v(vc, p, x0, y0, z1, r, g, b, light, overlay, 0, -1, 0);
        // north (-z)
        v(vc, p, x1, y1, z0, r, g, b, light, overlay, 0, 0, -1);
        v(vc, p, x1, y0, z0, r, g, b, light, overlay, 0, 0, -1);
        v(vc, p, x0, y0, z0, r, g, b, light, overlay, 0, 0, -1);
        v(vc, p, x0, y1, z0, r, g, b, light, overlay, 0, 0, -1);
        // south (+z)
        v(vc, p, x0, y1, z1, r, g, b, light, overlay, 0, 0, 1);
        v(vc, p, x0, y0, z1, r, g, b, light, overlay, 0, 0, 1);
        v(vc, p, x1, y0, z1, r, g, b, light, overlay, 0, 0, 1);
        v(vc, p, x1, y1, z1, r, g, b, light, overlay, 0, 0, 1);
        // west (-x)
        v(vc, p, x0, y1, z0, r, g, b, light, overlay, -1, 0, 0);
        v(vc, p, x0, y0, z0, r, g, b, light, overlay, -1, 0, 0);
        v(vc, p, x0, y0, z1, r, g, b, light, overlay, -1, 0, 0);
        v(vc, p, x0, y1, z1, r, g, b, light, overlay, -1, 0, 0);
        // east (+x)
        v(vc, p, x1, y1, z1, r, g, b, light, overlay, 1, 0, 0);
        v(vc, p, x1, y0, z1, r, g, b, light, overlay, 1, 0, 0);
        v(vc, p, x1, y0, z0, r, g, b, light, overlay, 1, 0, 0);
        v(vc, p, x1, y1, z0, r, g, b, light, overlay, 1, 0, 0);
    }

    /** Only the top face (the surface of a liquid). */
    private static void quadUp(PoseStack ps, VertexConsumer vc, double ax, double az, double bx, double bz, double y,
                               int argb, int light, int overlay) {
        PoseStack.Pose p = ps.last();
        float x0 = (float) (ax / 16.0), z0 = (float) (az / 16.0), x1 = (float) (bx / 16.0), z1 = (float) (bz / 16.0);
        float yy = (float) (y / 16.0);
        int r = argb >> 16 & 255, g = argb >> 8 & 255, b = argb & 255;
        v(vc, p, x0, yy, z0, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x0, yy, z1, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x1, yy, z1, r, g, b, light, overlay, 0, 1, 0);
        v(vc, p, x1, yy, z0, r, g, b, light, overlay, 0, 1, 0);
    }

    private static void v(VertexConsumer vc, PoseStack.Pose p, float x, float y, float z, int r, int g, int b,
                          int light, int overlay, float nx, float ny, float nz) {
        vc.addVertex(p, x, y, z).setColor(r, g, b, 255).setUv(0.5F, 0.5F).setOverlay(overlay).setLight(light).setNormal(p, nx, ny, nz);
    }
}
