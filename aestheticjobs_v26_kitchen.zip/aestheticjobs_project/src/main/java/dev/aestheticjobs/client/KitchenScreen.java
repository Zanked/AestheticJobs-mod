package dev.aestheticjobs.client;

import static dev.aestheticjobs.client.KitchenLayout.*;

import dev.aestheticjobs.AestheticJobs;
import dev.aestheticjobs.block.StationBlockEntity;
import dev.aestheticjobs.cafe.Drink;
import dev.aestheticjobs.cafe.career.Wish;
import dev.aestheticjobs.cafe.kitchen.Cooking;
import dev.aestheticjobs.cafe.kitchen.Extra;
import dev.aestheticjobs.cafe.kitchen.Flavor;
import dev.aestheticjobs.cafe.kitchen.Job;
import dev.aestheticjobs.cafe.kitchen.Knowledge;
import dev.aestheticjobs.cafe.kitchen.LatteArt;
import dev.aestheticjobs.cafe.kitchen.Menu;
import dev.aestheticjobs.cafe.kitchen.Signature;
import dev.aestheticjobs.item.Dessert;
import dev.aestheticjobs.network.CookPayload;
import dev.aestheticjobs.network.OpenKitchenPayload;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The kitchen of a station: pick a base on the left, up to three additions on the right, see the taste and (for known
 * combinations) the stars in the middle, and let the station cook. The book tab collects the signature recipes.
 * The screen only shows and asks; the server (block/StationBlockEntity) checks and cooks.
 */
public class KitchenScreen extends ScaledScreen {
    private static final ResourceLocation WIDGETS = gui("kitchen_widgets");
    private static final ResourceLocation BACK_DRINKS = gui("kitchen_drinks"), BACK_DESSERTS = gui("kitchen_desserts"),
            BACK_BOOK = gui("kitchen_book"), CARD = gui("kitchen_card");
    private static final ResourceLocation[] EXTRA_ICONS = new ResourceLocation[Extra.values().length];
    // places in kitchen_widgets.png (256 x 128)
    private static final int SLOT = 24, WIDE_W = 58, WIDE_H = 42, ADD = 36;
    private static final int INK = 0xFF4A342C, SOFT = 0xFF8C7466, LIGHT = 0xFFFFF6E2, GOOD = 0xFF4E8A4A, BAD = 0xFFB0483C;

    /** The last choice per kind of station, so that a second portion is one click. */
    private static final int[] lastBase = {0, Menu.DRINKS};
    private static final int[] lastMask = new int[2];
    private static int lastArt;

    static {
        for (Extra e : Extra.values()) EXTRA_ICONS[e.ordinal()] = gui("extra_" + e.id());
    }

    private static ResourceLocation gui(String name) {
        return ResourceLocation.fromNamespaceAndPath(AestheticJobs.MODID, "textures/gui/" + name + ".png");
    }

    private final BlockPos pos;
    private final Knowledge knowledge = new Knowledge();
    private final java.util.Map<String, ItemStack> items = new java.util.HashMap<>();
    private int wanted = -1, customer = -1;
    private Wish wish = Wish.NONE;
    private boolean drinks = true, book;
    private int base = -1, mask, art = lastArt;
    private int sentCooldown;
    private int ticks;
    private final List<Component> tooltip = new ArrayList<>();

    public KitchenScreen(OpenKitchenPayload payload) {
        super(Component.translatable("gui.aestheticjobs.kitchen.title"));
        this.pos = payload.pos();
        update(payload);
        if (net.minecraft.client.Minecraft.getInstance().level != null
                && net.minecraft.client.Minecraft.getInstance().level.getBlockEntity(pos) instanceof StationBlockEntity s) {
            drinks = s.cooksDrinks();
        }
        int kind = drinks ? 0 : 1;
        base = wanted >= 0 ? wanted : lastBase[kind];
        mask = base == lastBase[kind] ? lastMask[kind] : 0;
    }

    public BlockPos pos() {
        return pos;
    }

    public void update(OpenKitchenPayload payload) {
        int[] tried = new int[payload.tried().size()];
        for (int i = 0; i < tried.length; i++) tried[i] = payload.tried().get(i);
        knowledge.load(tried, payload.found());
        wanted = payload.wanted();
        customer = payload.customer();
        wish = Wish.byIndex(payload.wish());
    }

    @Override
    protected int vw() {
        return W;
    }

    @Override
    protected int vh() {
        return H;
    }

    private StationBlockEntity station() {
        return minecraft != null && minecraft.level != null
                && minecraft.level.getBlockEntity(pos) instanceof StationBlockEntity s ? s : null;
    }

    @Override
    public void tick() {
        ticks++;
        if (sentCooldown > 0) sentCooldown--;
        if (station() == null || minecraft.player == null || minecraft.player.distanceToSqr(Vec3.atCenterOf(pos)) > 60.0) onClose();
    }

    @Override
    public void onClose() {
        if (base >= 0) {
            int kind = drinks ? 0 : 1;
            lastBase[kind] = base;
            lastMask[kind] = mask;
            lastArt = art;
        }
        super.onClose();
    }

    // ------------------------------------------------------------------ the places that can be clicked

    private int firstBase() {
        return drinks ? 0 : Menu.DRINKS;
    }

    private int bases() {
        return drinks ? Menu.DRINKS : Menu.DESSERTS;
    }

    private int slotX(int i) {
        return drinks ? LIST_X + 5 + (i % 2) * 60 : LIST_X + 4 + (i % 5) * 24;
    }

    private int slotY(int i) {
        return drinks ? PANEL_Y + 4 + (i / 2) * 43 : PANEL_Y + 6 + (i / 5) * 24;
    }

    private static int addX(int i) {
        return ADD_X + 4 + (i % 3) * 40;
    }

    private static int addY(int i) {
        return PANEL_Y + 16 + (i / 3) * 38;
    }

    private static int artX(int i) {
        return VIEW_X + 4 + i * 16;
    }

    private static final int ART_Y = 205;

    // ------------------------------------------------------------------ drawing

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        tooltip.clear();
        super.render(g, mouseX, mouseY, partial);
        if (!tooltip.isEmpty()) g.renderComponentTooltip(font, tooltip, mouseX, mouseY);
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my, float partial) {
        StationBlockEntity station = station();
        if (station == null || base < 0) return;
        g.blit(book ? BACK_BOOK : drinks ? BACK_DRINKS : BACK_DESSERTS, 0, 0, 0, 0, W, H, W, H);
        text(g, Component.translatable(drinks ? "gui.aestheticjobs.kitchen.drinks" : "gui.aestheticjobs.kitchen.desserts"),
                14, 10, TAB_X - 20, LIGHT);
        tab(g, mx, my, TAB_X, Component.translatable("gui.aestheticjobs.kitchen.tab.cook"), !book);
        tab(g, mx, my, TAB_X + TAB_W + 4, Component.translatable("gui.aestheticjobs.kitchen.tab.book",
                found(), signatures()), book);
        drawWish(g, mx, my);

        long now = minecraft.level.getGameTime();
        Job.State stage = station.job().state(now);
        if (book) {
            drawBook(g, mx, my);
            return;
        }
        if (stage != Job.State.IDLE) {
            drawBusy(g, mx, my, station.job(), stage, station.job().progress(now, partial));
            return;
        }
        drawList(g, mx, my);
        drawPreview(g, mx, my);
        drawAdditions(g, mx, my);
    }

    private void tab(GuiGraphics g, int mx, int my, int x, Component label, boolean active) {
        boolean hover = Ui.in(mx, my, x, TAB_Y, TAB_W, TAB_H);
        g.blit(WIDGETS, x, TAB_Y, 180, active ? 24 : hover ? 40 : 56, TAB_W, TAB_H, 256, 128);
        centred(g, label, x + TAB_W / 2, TAB_Y + 4, TAB_W - 6, active ? INK : LIGHT);
    }

    private void drawWish(GuiGraphics g, int mx, int my) {
        Component line;
        int color = SOFT;
        if (wanted < 0) {
            line = Component.translatable("gui.aestheticjobs.kitchen.free");
        } else {
            Component name = customer < 0 ? Component.translatable("gui.aestheticjobs.kitchen.player")
                    : Component.translatable("customer.aestheticjobs." + customer);
            Component what = StationBlockEntity.recipeName(wanted, 0);
            if (drinks && wish != Wish.NONE) {
                boolean ok = base == wanted && wish.granted(base, mask);
                line = Component.translatable("gui.aestheticjobs.kitchen.order_wish", name, what,
                        Component.translatable("wish.aestheticjobs." + wish.id()));
                if (ok) line = Component.literal("✔ ").append(line);
                color = ok ? GOOD : BAD;
            } else {
                line = Component.translatable("gui.aestheticjobs.kitchen.order", name, what);
                color = INK;
            }
        }
        centred(g, line, W / 2, WISH_Y + 3, W - 28, color);
        if (font.width(line) > W - 28 && Ui.in(mx, my, 8, WISH_Y, W - 16, WISH_H)) tooltip.add(line);
    }

    private void drawList(GuiGraphics g, int mx, int my) {
        for (int i = 0; i < bases(); i++) {
            int b = firstBase() + i;
            int x = slotX(i), y = slotY(i), w = drinks ? WIDE_W : SLOT, h = drinks ? WIDE_H : SLOT;
            boolean hover = Ui.in(mx, my, x, y, w, h);
            int state = b == base ? 2 : hover ? 1 : 0;
            if (drinks) g.blit(WIDGETS, x, y, state * 60, 24, w, h, 256, 128);
            else g.blit(WIDGETS, x, y, state * 24, 0, w, h, 256, 128);
            Ui.icon(g, icon(b), x + (w - (drinks ? 32 : 20)) / 2, y + (h - (drinks ? 32 : 20)) / 2, drinks ? 32 : 20);
            if (b == wanted) g.blit(WIDGETS, x + w - 9, y, 222, 0, 9, 9, 256, 128);
            if (hover) {
                tooltip.add(StationBlockEntity.recipeName(b, 0));
                tooltip.add(Component.translatable("gui.aestheticjobs.kitchen.family." + Menu.get(b).kind().id())
                        .withStyle(ChatFormatting.GRAY));
            }
        }
    }

    private void drawPreview(GuiGraphics g, int mx, int my) {
        int cx = VIEW_X + VIEW_W / 2;
        float bob = (float) Math.sin(ticks * 0.12F) * 1.2F;
        g.pose().pushPose();
        g.pose().translate(0.0F, bob, 0.0F);
        Ui.icon(g, icon(base), cx - 24, PANEL_Y + 3, 48);
        g.pose().popPose();

        boolean known = knowledge.knows(base, mask);
        Signature signature = Signature.of(base, mask);
        Component name = StationBlockEntity.recipeName(base, signature != null && known ? mask : 0);
        List<String> lines = wrap(font, name, VIEW_W - 8);
        int y = PANEL_Y + (lines.size() > 1 ? 52 : 56);
        for (int i = 0; i < Math.min(2, lines.size()); i++) {
            Component line = fit(font, Component.literal(lines.get(i)), VIEW_W - 8);
            centred(g, line, cx, y + i * 9, VIEW_W - 4, signature != null && known ? 0xFFA0567E : INK);
        }

        int stars = known ? Cooking.stars(Cooking.quality(base, mask)) : 0;
        for (int i = 0; i < 5; i++) {
            g.blit(WIDGETS, cx - 30 + i * 12, PANEL_Y + 72, known ? i < stars ? 150 : 162 : 174, 0, 11, 11, 256, 128);
        }
        if (!known) centred(g, Component.translatable("gui.aestheticjobs.kitchen.new"), cx, PANEL_Y + 84, VIEW_W - 6, 0xFFA0567E);
        else if (signature != null) centred(g, Component.translatable("gui.aestheticjobs.kitchen.signature"), cx, PANEL_Y + 84, VIEW_W - 6, 0xFFA0567E);

        int row = PANEL_Y + 96;
        for (Flavor f : Flavor.values()) {
            int value = Cooking.taste(base, mask, f);
            text(g, Component.translatable("flavor.aestheticjobs." + f.id()), VIEW_X + 5, row, 52, SOFT);
            for (int i = 0; i < 6; i++) {
                int x = VIEW_X + 60 + i * 7;
                g.fill(x, row + 1, x + 5, row + 7, i < value ? f.color() : 0x338A6450);
                if (i < value) g.fill(x, row + 1, x + 5, row + 2, 0x55FFFFFF);
            }
            if (wish != Wish.NONE && wish.flavor() == f && base == wanted) {   // how far the wish wants this taste
                int x = VIEW_X + 60 + wish.need() * 7 - 2;
                g.fill(x, row - 1, x + 1, row + 9, INK);
            }
            row += 10;
        }

        if (LatteArt.paintable(base)) {
            centred(g, Component.translatable("gui.aestheticjobs.kitchen.art"), cx, ART_Y - 11, VIEW_W - 6, SOFT);
            Drink drink = Drink.byIndex(base);
            for (int i = 0; i < LatteArt.STYLES.length; i++) {
                int x = artX(i);
                boolean hover = Ui.in(mx, my, x, ART_Y, 16, 16);
                if (i == art || hover) g.fill(x - 1, ART_Y - 1, x + 17, ART_Y + 17, i == art ? 0xFFD9A02E : 0x66D9A02E);
                CupRenderer.draw(g, x, ART_Y, 1, LatteArt.picture(base, mask, i), drink);
                if (hover) tooltip.add(Component.translatable("art.aestheticjobs." + LatteArt.STYLES[i]));
            }
        }
    }

    private void drawAdditions(GuiGraphics g, int mx, int my) {
        centred(g, Component.translatable("gui.aestheticjobs.kitchen.additions", Integer.bitCount(mask), Cooking.MAX_EXTRAS),
                ADD_X + ADD_W / 2, PANEL_Y + 5, ADD_W - 8, INK);
        for (Extra e : Extra.values()) {
            int x = addX(e.ordinal()), y = addY(e.ordinal());
            boolean hover = Ui.in(mx, my, x, y, ADD, ADD);
            boolean chosen = e.in(mask);
            g.blit(WIDGETS, x, y, (chosen ? 2 : hover ? 1 : 0) * 38, 68, ADD, ADD, 256, 128);
            Ui.icon(g, EXTRA_ICONS[e.ordinal()], x + 6, y + 5, 24);
            boolean tried = knowledge.tried(base, e);
            int match = Cooking.match(base, e);
            int mark = !tried ? 3 : match > 0 ? 0 : match < 0 ? 1 : 2;
            g.blit(WIDGETS, x + ADD - 10, y + 1, 186 + mark * 9, 0, 9, 9, 256, 128);
            if (have(StationBlockEntity.item(e.item())) == 0) g.fill(x + 4, y + ADD - 6, x + ADD - 4, y + ADD - 4, BAD);
            if (hover) {
                tooltip.add(Component.translatable("extra.aestheticjobs." + e.id()));
                for (Flavor f : Flavor.values()) {
                    if (e.taste(f) > 0) {
                        tooltip.add(Component.literal("+" + e.taste(f) + " ").append(Component.translatable("flavor.aestheticjobs." + f.id()))
                                .withStyle(ChatFormatting.GRAY));
                    }
                }
                tooltip.add(Component.translatable("gui.aestheticjobs.kitchen.mark." + mark)
                        .withStyle(mark == 0 ? ChatFormatting.GREEN : mark == 1 ? ChatFormatting.RED : ChatFormatting.YELLOW));
                if (have(StationBlockEntity.item(e.item())) == 0) {
                    tooltip.add(Component.translatable("gui.aestheticjobs.kitchen.none").withStyle(ChatFormatting.RED));
                }
            }
        }

        // what it takes: one picture per item, framed red when it is missing
        List<String> shopping = Cooking.shopping(base, mask);
        List<String> kinds = new ArrayList<>(new java.util.LinkedHashSet<>(shopping));
        int step = Math.min(18, (ADD_W - 6) / Math.max(1, kinds.size()));
        int x = ADD_X + (ADD_W - step * kinds.size()) / 2;
        int y = PANEL_Y + 134;
        boolean all = true;
        for (String id : kinds) {
            Item item = StationBlockEntity.item(id);
            int need = (int) shopping.stream().filter(id::equals).count();
            boolean ok = have(item) >= need;
            all &= ok;
            if (!ok) g.fill(x, y, x + Math.min(16, step), y + 18, 0x66B0483C);
            g.pose().pushPose();
            g.pose().translate(x + (step - 14) / 2.0F, y + 1, 0.0F);
            g.pose().scale(0.875F, 0.875F, 1.0F);
            g.renderItem(items.computeIfAbsent(id, k -> new ItemStack(item)), 0, 0);
            g.pose().popPose();
            if (Ui.in(mx, my, x, y, step, 18)) {
                tooltip.add(item.getDescription().copy().append(need > 1 ? " ×" + need : ""));
                tooltip.add(Component.translatable(ok ? "gui.aestheticjobs.kitchen.have" : "gui.aestheticjobs.kitchen.none")
                        .withStyle(ok ? ChatFormatting.GREEN : ChatFormatting.RED));
            }
            x += step;
        }
        button(g, mx, my, COOK_X, COOK_Y, COOK_W, Component.translatable(!all ? "gui.aestheticjobs.kitchen.missing"
                : drinks ? "gui.aestheticjobs.kitchen.brew" : "gui.aestheticjobs.kitchen.bake"), all && sentCooldown == 0);
    }

    private void drawBusy(GuiGraphics g, int mx, int my, Job job, Job.State stage, float progress) {
        g.fill(5, PANEL_Y - 2, W - 5, H - 4, 0x88503028);          // the menu behind rests while the station works
        g.blit(CARD, CARD_X, CARD_Y, 0, 0, CARD_W, CARD_H, CARD_W, CARD_H);
        int cx = CARD_X + CARD_W / 2;
        float bob = stage == Job.State.READY ? (float) Math.sin(ticks * 0.2F) * 2.0F : 0.0F;
        g.pose().pushPose();
        g.pose().translate(0.0F, bob, 0.0F);
        Ui.icon(g, icon(job.base()), cx - 32, CARD_Y + 8, 64);
        g.pose().popPose();
        boolean mine = minecraft.player != null && job.owner().equals(minecraft.player.getUUID().toString());
        centred(g, StationBlockEntity.recipeName(job.base(), job.mask()), cx, CARD_Y + 78, CARD_W - 16, INK);
        if (stage == Job.State.WORKING) {
            int w = CARD_W - 40, x = CARD_X + 20, y = CARD_Y + 94;
            g.fill(x - 1, y - 1, x + w + 1, y + 9, 0xFF8A6450);
            g.fill(x, y, x + w, y + 8, 0xFFEFE1C2);
            int fill = Math.round(w * progress);
            g.fill(x, y, x + fill, y + 8, 0xFFE0A040);
            g.fill(x, y, x + fill, y + 2, 0x66FFFFFF);
            int left = Math.max(1, (int) Math.ceil((job.ready() - minecraft.level.getGameTime()) / 20.0));
            centred(g, Component.translatable("gui.aestheticjobs.kitchen.working", left), cx, y + 14, CARD_W - 16, SOFT);
            centred(g, Component.translatable("gui.aestheticjobs.kitchen.may_close"), cx, y + 26, CARD_W - 16, SOFT);
        } else {
            int stars = Cooking.stars(Cooking.quality(job.base(), job.mask()));
            for (int i = 0; i < 5; i++) {
                g.blit(WIDGETS, cx - 30 + i * 12, CARD_Y + 92, i < stars ? 150 : 162, 0, 11, 11, 256, 128);
            }
            centred(g, Component.translatable(mine ? "gui.aestheticjobs.kitchen.ready" : "gui.aestheticjobs.kitchen.not_yours"),
                    cx, CARD_Y + 110, CARD_W - 16, mine ? GOOD : BAD);
        }
        boolean collect = stage == Job.State.READY
                && job.mayCollect(minecraft.player.getUUID().toString(), minecraft.level.getGameTime());
        button(g, mx, my, cx - COOK_W / 2, CARD_Y + CARD_H - 26, COOK_W,
                Component.translatable(collect ? "gui.aestheticjobs.kitchen.collect" : "gui.aestheticjobs.kitchen.close"),
                sentCooldown == 0);
    }

    private void drawBook(GuiGraphics g, int mx, int my) {
        int i = 0;
        for (Signature s : Signature.values()) {
            if (s.isDrink() != drinks) continue;
            int x = 10 + (i % 2) * 184, y = PANEL_Y + 4 + (i / 2) * (drinks ? 43 : 25), h = drinks ? 40 : 23;
            i++;
            boolean known = knowledge.knows(s);
            boolean hover = Ui.in(mx, my, x, y, 180, h);
            g.fill(x, y, x + 180, y + h, hover ? 0xFFFFF0CC : known ? 0xFFFFF6E2 : 0xFFEBDDC0);
            g.fill(x, y + h - 1, x + 180, y + h, 0x558A6450);
            int size = drinks ? 32 : 20;
            Ui.icon(g, icon(s.base()), x + 3, y + (h - size) / 2, size);
            Component title = known ? Component.translatable("signature.aestheticjobs." + s.id())
                    : Component.translatable("gui.aestheticjobs.kitchen.secret");
            int tx = x + size + 8, tw = 180 - size - 8 - 44;
            if (drinks) {
                text(g, title, tx, y + 10, tw, known ? INK : SOFT);
                text(g, StationBlockEntity.recipeName(s.base(), 0), tx, y + 22, tw, SOFT);
            } else {
                text(g, title, tx, y + 8, tw, known ? INK : SOFT);
            }
            int ix = x + 180 - 41, iy = y + (h - 18) / 2;
            for (Extra e : Extra.values()) {
                if (!e.in(s.mask())) continue;
                int at = known || e == s.hint() ? ix : -1;
                if (at >= 0) Ui.icon(g, EXTRA_ICONS[e.ordinal()], ix, iy, 18);
                else g.blit(WIDGETS, ix + 4, iy + 4, 213, 0, 9, 9, 256, 128);
                ix += 20;
            }
            if (hover) {
                tooltip.add(title);
                tooltip.add(StationBlockEntity.recipeName(s.base(), 0).copy().withStyle(ChatFormatting.GRAY));
                for (Extra e : Extra.values()) {
                    if (e.in(s.mask())) {
                        tooltip.add(Component.literal("+ ").append(known || e == s.hint()
                                ? Component.translatable("extra.aestheticjobs." + e.id()) : Component.literal("?"))
                                .withStyle(ChatFormatting.GOLD));
                    }
                }
                tooltip.add(Component.translatable("gui.aestheticjobs.kitchen.book.open").withStyle(ChatFormatting.DARK_GRAY));
            }
        }
    }

    private void button(GuiGraphics g, int mx, int my, int x, int y, int w, Component label, boolean enabled) {
        boolean hover = enabled && Ui.in(mx, my, x, y, w, COOK_H);
        g.blit(WIDGETS, x, y, 120, !enabled ? 108 : hover ? 90 : 72, w, COOK_H, 256, 128);
        centred(g, label, x + w / 2, y + 5, w - 8, enabled ? LIGHT : 0xFFF0E6D4);
    }

    /** One line that always fits: shrunk a little when it is too wide, cut only when even that is not enough. */
    private void text(GuiGraphics g, Component c, int x, int y, int w, int color) {
        float k = Math.max(0.75F, Math.min(1.0F, w / (float) Math.max(1, font.width(c))));
        Component shown = fit(font, c, (int) (w / k));
        g.pose().pushPose();
        g.pose().translate(x, y + (1.0F - k) * 4.0F, 0.0F);
        g.pose().scale(k, k, 1.0F);
        g.drawString(font, shown, 0, 0, color, false);
        g.pose().popPose();
    }

    private void centred(GuiGraphics g, Component c, int cx, int y, int w, int color) {
        int width = Math.min(w, font.width(c));
        text(g, c, cx - width / 2, y, w, color);
    }

    private ResourceLocation icon(int b) {
        return b < Menu.DRINKS ? Drink.byIndex(b).iconTexture() : Dessert.byIndex(b - Menu.DRINKS).iconTexture();
    }

    private int have(Item item) {
        if (minecraft.player == null) return 0;
        return minecraft.player.getAbilities().instabuild ? 64 : StationBlockEntity.count(minecraft.player, item);
    }

    private int found() {
        int n = 0;
        for (Signature s : Signature.values()) if (s.isDrink() == drinks && knowledge.knows(s)) n++;
        return n;
    }

    private int signatures() {
        int n = 0;
        for (Signature s : Signature.values()) if (s.isDrink() == drinks) n++;
        return n;
    }

    // ------------------------------------------------------------------ clicks

    @Override
    protected boolean click(int mx, int my, int button) {
        StationBlockEntity station = station();
        if (station == null || button != 0 || minecraft.level == null || minecraft.player == null) return false;
        if (Ui.in(mx, my, TAB_X, TAB_Y, TAB_W, TAB_H)) return page(false);
        if (Ui.in(mx, my, TAB_X + TAB_W + 4, TAB_Y, TAB_W, TAB_H)) return page(true);
        if (book) {
            int i = 0;
            for (Signature s : Signature.values()) {
                if (s.isDrink() != drinks) continue;
                int x = 10 + (i % 2) * 184, y = PANEL_Y + 4 + (i / 2) * (drinks ? 43 : 25), h = drinks ? 40 : 23;
                i++;
                if (Ui.in(mx, my, x, y, 180, h)) {                       // cook it: take the base and what is known
                    base = s.base();
                    mask = knowledge.knows(s) ? s.mask() : s.hint().bit();
                    return page(false);
                }
            }
            return false;
        }
        long now = minecraft.level.getGameTime();
        Job job = station.job();
        if (job.state(now) != Job.State.IDLE) {
            if (sentCooldown == 0 && Ui.in(mx, my, CARD_X + (CARD_W - COOK_W) / 2, CARD_Y + CARD_H - 26, COOK_W, COOK_H)) {
                if (job.mayCollect(minecraft.player.getUUID().toString(), now)) send(CookPayload.COLLECT, 0);
                sound(1.0F);
                onClose();
                return true;
            }
            return false;
        }
        for (int i = 0; i < bases(); i++) {
            if (Ui.in(mx, my, slotX(i), slotY(i), drinks ? WIDE_W : SLOT, drinks ? WIDE_H : SLOT)) {
                if (base != firstBase() + i) mask = 0;
                base = firstBase() + i;
                sound(1.2F);
                return true;
            }
        }
        for (Extra e : Extra.values()) {
            if (Ui.in(mx, my, addX(e.ordinal()), addY(e.ordinal()), ADD, ADD)) {
                if (e.in(mask) || Integer.bitCount(mask) < Cooking.MAX_EXTRAS) {
                    mask ^= e.bit();
                    sound(e.in(mask) ? 1.5F : 0.9F);
                } else {
                    sound(0.5F);
                }
                return true;
            }
        }
        if (LatteArt.paintable(base)) {
            for (int i = 0; i < LatteArt.STYLES.length; i++) {
                if (Ui.in(mx, my, artX(i), ART_Y, 16, 16)) {
                    art = i;
                    sound(1.3F);
                    return true;
                }
            }
        }
        if (sentCooldown == 0 && Ui.in(mx, my, COOK_X, COOK_Y, COOK_W, COOK_H)) {
            List<String> shopping = Cooking.shopping(base, mask);
            for (String id : shopping) {
                if (have(StationBlockEntity.item(id)) < shopping.stream().filter(id::equals).count()) {
                    sound(0.5F);
                    return true;
                }
            }
            send(base, mask);
            sound(1.0F);
            return true;
        }
        return false;
    }

    private boolean page(boolean toBook) {
        book = toBook;
        sound(1.1F);
        return true;
    }

    private void send(int what, int additions) {
        sentCooldown = 20;
        PacketDistributor.sendToServer(new CookPayload(pos, what, additions, art));
    }

    private void sound(float pitch) {
        Ui.sound(SoundEvents.UI_BUTTON_CLICK.value(), pitch, 0.35F);
    }
}
