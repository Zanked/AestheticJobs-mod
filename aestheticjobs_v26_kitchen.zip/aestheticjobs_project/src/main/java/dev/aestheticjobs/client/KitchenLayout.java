package dev.aestheticjobs.client;

/**
 * Where everything is on the kitchen screen (canvas pixels). The background pictures of tools/gen_kitchen_art.py are
 * painted for exactly these places: keep both in step.
 */
public final class KitchenLayout {
    public static final int W = 384, H = 232;
    public static final int WISH_Y = 28, WISH_H = 14;
    public static final int PANEL_Y = 46, PANEL_H = 180;
    public static final int LIST_X = 8, LIST_W = 128;
    public static final int VIEW_X = 142, VIEW_W = 104;
    public static final int ADD_X = 252, ADD_W = 124;
    public static final int TAB_Y = 6, TAB_W = 70, TAB_H = 15, TAB_X = W - 8 - TAB_W * 2 - 4;
    public static final int COOK_X = ADD_X + 2, COOK_Y = 204, COOK_W = 120, COOK_H = 18;
    /** The card shown while the station is busy. */
    public static final int CARD_X = 92, CARD_Y = 54, CARD_W = 200, CARD_H = 164;

    private KitchenLayout() {}
}
