package dev.aestheticjobs.job.interview;

import dev.aestheticjobs.entity.JobManagerEntity;
import dev.aestheticjobs.job.Jobs;
import dev.aestheticjobs.job.Profession;
import dev.aestheticjobs.job.ProfessionManager;
import dev.aestheticjobs.job.Shift;
import dev.aestheticjobs.network.InterviewStatePayload;
import dev.aestheticjobs.registry.ModItems;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * The interview, all on the server (the window is only a picture of the state): the applicant gives the resume to the
 * manager of the job, answers four questions (every answer moves the manager's IMPRESSION), may be checked for lying
 * about his experience (a phone call to the "previous employer"), and gets an offer: a start rank he may try to haggle for.
 * Not enough impression: no job and a pause before the next try. The result is real: Jobs.hire, the badge, a start rank.
 */
public final class Interview {
    private static final long SESSION_MS = 10 * 60_000L;
    private static final long BLANK_COOLDOWN_MS = 20_000L;
    private static final Random RNG = new Random();

    // what the session is waiting for
    private static final int P_QUESTION = 0, P_CHECK = 1, P_CALL = 2, P_OFFER = 3, P_END = 4;
    // the answers of the check and of the offer
    private static final int C_CONFESS = 0, C_BLUFF = 1, C_EVADE = 2;
    private static final int O_ACCEPT = 0, O_HAGGLE = 1, O_THINK = 2;

    private record Opt(int code, String key) {}

    private static final class Session {
        final UUID player;
        final int managerId;
        final ManagerKind kind;
        final Resumes.Data resume;
        final List<InterviewScript.Q> questions;
        int step;
        int impression;
        int lastDelta;
        int exp;                    // the experience the applicant stands by (a confession or an evasion drops it to the truth)
        int gap;
        int rankOffer;
        boolean haggled;
        int phase = P_QUESTION;
        List<Opt> options = List.of();
        final long expires = System.currentTimeMillis() + SESSION_MS;

        Session(UUID player, int managerId, ManagerKind kind, Resumes.Data resume, List<InterviewScript.Q> questions) {
            this.player = player;
            this.managerId = managerId;
            this.kind = kind;
            this.resume = resume;
            this.questions = questions;
            this.exp = resume.exp();
        }
    }

    private static final Map<UUID, Session> SESSIONS = new HashMap<>();
    /** player|job -> until when (ms) the manager does not talk to him. */
    private static final Map<String, Long> BANS = new HashMap<>();
    private static final Map<UUID, Long> BLANKS = new HashMap<>();

    private Interview() {}

    // ------------------------------------------------------------------ start

    /** The player right-clicked a manager. */
    public static void begin(ServerPlayer sp, JobManagerEntity mgr) {
        MinecraftServer server = sp.server;
        ManagerKind kind = mgr.kind();
        Optional<Profession> prof = ProfessionManager.get(kind.profession);
        if (prof.isEmpty()) {
            say(sp, mgr, "interview.err.no_profession");
            return;
        }
        ItemStack held = heldResume(sp);
        if (held.isEmpty()) {
            if (hasResume(sp)) {
                say(sp, mgr, "interview.err.hold");
            } else {
                giveBlank(sp, mgr);
            }
            return;
        }
        if (!Resumes.isFilled(held)) {
            say(sp, mgr, "interview.err.blank");
            return;
        }
        Optional<Jobs.Status> cur = Jobs.status(server, sp.getUUID());
        if (cur.isPresent()) {
            say(sp, mgr, cur.get().profession().id().equals(kind.profession) ? "interview.err.here" : "interview.err.elsewhere");
            return;
        }
        long left = banLeft(sp.getUUID(), kind);
        if (left > 0) {
            say(sp, mgr, "interview.err.wait", Long.toString(Math.max(1L, (left + 59_999L) / 60_000L)));
            return;
        }
        for (Profession.Requirement r : prof.get().requirements()) {
            if (Jobs.bestRank(server, sp.getUUID(), r.profession()) < r.minRank()) {
                say(sp, mgr, "interview.err.requirements");
                return;
            }
        }

        Session s = new Session(sp.getUUID(), mgr.getId(), kind, Resumes.read(held), InterviewScript.pick(kind, RNG));
        s.impression = startImpression(s, server, prof.get());
        SESSIONS.put(sp.getUUID(), s);
        Resumes.Data d = s.resume;
        List<String> skills = new ArrayList<>();
        for (int i = 0; i < Resumes.SKILL_COUNT; i++) {
            if ((d.skills() >> i & 1) != 0) skills.add("resume.skill." + i);
        }
        List<String> args = List.of(sp.getGameProfile().getName(), "t:resume.exp." + d.exp(), "t:resume.trait." + d.trait(),
                skills.isEmpty() ? "t:resume.skill.none" : "T:" + String.join(",", skills));
        sendQuestion(sp, s, "interview.read." + kind.id, args, 0);
    }

    /** What the manager thinks of the paper alone: valued skills, the claimed experience, the character, the goal, real experience on this very job. */
    private static int startImpression(Session s, MinecraftServer server, Profession prof) {
        Resumes.Data d = s.resume;
        int imp = 50;
        int hits = 0;
        for (int skill : s.kind.valued) {
            if ((d.skills() >> skill & 1) != 0) hits++;
        }
        imp += hits * 4;
        imp += d.exp() * 3;
        if (d.trait() == s.kind.likedTrait) imp += 4;
        imp += d.goal() == 2 ? 2 : d.goal() == 0 ? (s.kind == ManagerKind.OFFICE ? 4 : 2) : 0;
        if (Jobs.bestRank(server, s.player, prof.id()) >= 0) imp += 8;
        return Resumes.clamp(imp, 0, 100);
    }

    // ------------------------------------------------------------------ the answers

    public static void answer(ServerPlayer sp, int choice) {
        Session s = SESSIONS.get(sp.getUUID());
        if (s == null) return;
        if (manager(sp, s) == null || System.currentTimeMillis() > s.expires) {
            close(sp);
            return;
        }
        if (choice < 0 || choice >= s.options.size()) return;
        int code = s.options.get(choice).code();
        switch (s.phase) {
            case P_QUESTION -> onQuestion(sp, s, code);
            case P_CHECK -> onCheck(sp, s, code);
            case P_CALL -> onCall(sp, s);
            case P_OFFER -> onOffer(sp, s, code);
            default -> SESSIONS.remove(sp.getUUID());
        }
    }

    /** The window was closed by the player. */
    public static void cancel(ServerPlayer sp) {
        SESSIONS.remove(sp.getUUID());
    }

    private static void onQuestion(ServerPlayer sp, Session s, int code) {
        InterviewScript.Q q = s.questions.get(s.step);
        int delta = q.deltas()[Math.max(0, Math.min(2, code))][s.kind.ordinal()];
        apply(s, delta);
        s.step++;
        String react = (delta >= 8 ? "interview.react.good." : delta <= -6 ? "interview.react.bad." : "interview.react.ok.") + (1 + RNG.nextInt(3));
        int mood = delta >= 8 ? 1 : delta <= -6 ? 2 : 0;
        if (s.impression <= 15) {                                              // he has had enough
            reject(sp, s, react, "interview.reject.walkout", 5 * 60_000L, 2);
            return;
        }
        if (s.step < s.questions.size()) {
            sendQuestion(sp, s, react, List.of(), mood);
        } else {
            afterQuestions(sp, s, react, mood);
        }
    }

    /** The manager checks the claimed experience against the records (a phone call) when it is bigger than the truth. */
    private static void afterQuestions(ServerPlayer sp, Session s, String react, int mood) {
        int truth = trueExp(sp.server, sp.getUUID());
        s.gap = Math.max(0, s.exp - truth);
        if (s.gap > 0) {
            s.phase = P_CHECK;
            s.options = List.of(new Opt(C_CONFESS, "interview.check.a0"), new Opt(C_BLUFF, "interview.check.a1"), new Opt(C_EVADE, "interview.check.a2"));
            send(sp, s, InterviewStatePayload.Q, react, List.of(), "interview.check", List.of(), s.options, 0);
            return;
        }
        if (s.exp >= 1) {                                                      // the records agree with the resume
            apply(s, 4);
            toVerdict(sp, s, "interview.verified", 1);
        } else {
            toVerdict(sp, s, react, mood);
        }
    }

    private static void onCheck(ServerPlayer sp, Session s, int code) {
        int truth = trueExp(sp.server, sp.getUUID());
        switch (code) {
            case C_CONFESS -> {
                apply(s, 3);
                s.exp = truth;
                toVerdict(sp, s, "interview.confess.react", 1);
            }
            case C_EVADE -> {
                apply(s, -10);
                s.exp = truth;
                toVerdict(sp, s, "interview.evade.react", 0);
            }
            default -> {                                                       // a bluff: the phone call decides
                s.phase = P_CALL;
                s.options = List.of(new Opt(0, ""));
                send(sp, s, InterviewStatePayload.CALL, "", List.of(), "interview.calling", List.of(), s.options, 0);
            }
        }
    }

    private static void onCall(ServerPlayer sp, Session s) {
        double caught = Math.min(0.9D, 0.3D + 0.25D * s.gap + (s.kind == ManagerKind.OFFICE ? 0.1D : 0.0D));
        if (RNG.nextDouble() < caught) {
            reject(sp, s, "", "interview.caught", 10 * 60_000L, 2);
        } else {
            apply(s, 6);
            toVerdict(sp, s, "interview.call.ok", 1);
        }
    }

    private static void toVerdict(ServerPlayer sp, Session s, String react, int mood) {
        int fin = Resumes.clamp(s.impression, 0, 100);
        if (fin < s.kind.threshold) {
            reject(sp, s, react, "interview.reject.low", 5 * 60_000L, fin < s.kind.threshold - 15 ? 2 : 0);
            return;
        }
        Optional<Profession> prof = ProfessionManager.get(s.kind.profession);
        if (prof.isEmpty()) {
            close(sp);
            return;
        }
        int maxRank = prof.get().ranks().size() - 1;
        s.rankOffer = fin >= 78 && s.exp >= 2 ? Math.min(1, maxRank) : 0;
        sendOffer(sp, s, prof.get(), react, mood);
    }

    private static void sendOffer(ServerPlayer sp, Session s, Profession prof, String react, int mood) {
        int fin = Resumes.clamp(s.impression, 0, 100);
        int maxRank = prof.ranks().size() - 1;
        List<Opt> opts = new ArrayList<>();
        opts.add(new Opt(O_ACCEPT, "interview.offer.a0"));
        if (!s.haggled && s.rankOffer + 1 <= maxRank && fin >= s.kind.threshold + 5) opts.add(new Opt(O_HAGGLE, "interview.offer.a1"));
        opts.add(new Opt(O_THINK, "interview.offer.a2"));
        s.phase = P_OFFER;
        s.options = opts;
        send(sp, s, InterviewStatePayload.OFFER, react, List.of(), "interview.offer",
                List.of("t:" + rankKey(prof, s.rankOffer), prof.wageText(s.rankOffer)), opts, mood);
    }

    private static void onOffer(ServerPlayer sp, Session s, int code) {
        Optional<Profession> prof = ProfessionManager.get(s.kind.profession);
        if (prof.isEmpty()) {
            close(sp);
            return;
        }
        switch (code) {
            case O_ACCEPT -> hire(sp, s, prof.get());
            case O_HAGGLE -> {
                s.haggled = true;
                double chance = Math.max(0.15D, Math.min(0.7D, 0.2D + (Resumes.clamp(s.impression, 0, 100) - 50) / 100.0D));
                if (RNG.nextDouble() < chance) {
                    s.rankOffer++;
                    sendOffer(sp, s, prof.get(), "interview.haggle.ok", 1);
                } else if (RNG.nextDouble() < 0.35D) {
                    reject(sp, s, "", "interview.haggle.withdrawn", 3 * 60_000L, 2);
                } else {
                    sendOffer(sp, s, prof.get(), "interview.haggle.no", 2);
                }
            }
            default -> close(sp);                                              // "I will think": nothing is lost
        }
    }

    // ------------------------------------------------------------------ the result

    private static void hire(ServerPlayer sp, Session s, Profession prof) {
        MinecraftServer server = sp.server;
        Jobs.Result r = Jobs.hire(server, sp.getUUID(), prof.id(), false);
        if (r != Jobs.Result.OK) {
            String why = switch (r) {
                case ALREADY_EMPLOYED -> "interview.err.elsewhere";
                case COOLDOWN -> "interview.err.cooldown";
                case REQUIREMENTS_NOT_MET -> "interview.err.requirements";
                default -> "interview.err.no_profession";
            };
            reject(sp, s, "", why, 0L, 0);
            return;
        }
        if (s.rankOffer > 0) {
            Jobs.addXp(server, sp.getUUID(), prof.ranks().get(s.rankOffer).xp());      // the start rank is real: the experience of that rank
        }
        Shift.giveBadgeIfMissing(sp);
        ItemStack held = heldResume(sp);
        if (!held.isEmpty()) held.shrink(1);                                     // the manager keeps the resume
        s.phase = P_END;
        s.options = List.of(new Opt(0, "interview.close"));
        send(sp, s, InterviewStatePayload.HIRED, "", List.of(), "interview.hired",
                List.of("t:" + rankKey(prof, s.rankOffer)), s.options, 1);
        sp.sendSystemMessage(Component.translatable("interview.hired.chat", prof.displayName(), prof.rankName(s.rankOffer)));
        ServerLevel level = sp.serverLevel();
        level.playSound(null, sp.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.6F, 1.3F);
        Entity mgr = level.getEntity(s.managerId);
        if (mgr != null) level.sendParticles(ParticleTypes.HAPPY_VILLAGER, mgr.getX(), mgr.getY() + 1.8D, mgr.getZ(), 12, 0.4D, 0.3D, 0.4D, 0.0D);
    }

    private static void reject(ServerPlayer sp, Session s, String react, String lineKey, long banMs, int mood) {
        if (banMs > 0) BANS.put(sp.getUUID() + "|" + s.kind.id, System.currentTimeMillis() + banMs);
        s.phase = P_END;
        s.options = List.of(new Opt(0, "interview.close"));
        List<String> args = lineKey.equals("interview.reject.low") ? List.of(Long.toString(Math.max(1L, banMs / 60_000L))) : List.of();
        send(sp, s, InterviewStatePayload.REJECTED, react, List.of(), lineKey, args, s.options, mood);
        sp.serverLevel().playSound(null, sp.blockPosition(), SoundEvents.VILLAGER_NO, SoundSource.NEUTRAL, 0.7F, 1.0F);
    }

    /** Ends the interview and tells the window to close. */
    private static void close(ServerPlayer sp) {
        Session s = SESSIONS.remove(sp.getUUID());
        if (s == null) return;
        PacketDistributor.sendToPlayer(sp, new InterviewStatePayload(s.managerId, InterviewStatePayload.CLOSE, "", List.of(), "", List.of(),
                List.of(), 0, 0, 0, 0, 0, 0));
    }

    // ------------------------------------------------------------------ sending

    private static void sendQuestion(ServerPlayer sp, Session s, String react, List<String> reactArgs, int mood) {
        InterviewScript.Q q = s.questions.get(s.step);
        List<Integer> order = new ArrayList<>(List.of(0, 1, 2));
        Collections.shuffle(order, RNG);                                        // the best answer is not always the first
        List<Opt> opts = new ArrayList<>();
        for (int orig : order) opts.add(new Opt(orig, "interview.a." + q.id() + "." + orig));
        s.phase = P_QUESTION;
        s.options = opts;
        send(sp, s, InterviewStatePayload.Q, react, reactArgs, "interview.q." + q.id(), List.of(), opts, mood);
    }

    private static void send(ServerPlayer sp, Session s, int phase, String react, List<String> reactArgs, String line,
                             List<String> lineArgs, List<Opt> opts, int mood) {
        Entity e = sp.serverLevel().getEntity(s.managerId);
        if (e instanceof JobManagerEntity m) m.setMood(mood);
        List<String> keys = new ArrayList<>();
        for (Opt o : opts) keys.add(o.key());
        PacketDistributor.sendToPlayer(sp, new InterviewStatePayload(s.managerId, phase, react, reactArgs, line, lineArgs, keys, mood,
                Resumes.clamp(s.impression, 0, 100), s.lastDelta, Math.min(s.step + 1, s.questions.size()), s.questions.size(), s.kind.threshold));
        s.lastDelta = 0;
    }

    private static void apply(Session s, int delta) {
        int before = s.impression;
        s.impression = Resumes.clamp(s.impression + delta, 0, 100);
        s.lastDelta += s.impression - before;
    }

    // ------------------------------------------------------------------ helpers

    private static String rankKey(Profession prof, int rank) {
        return "profession." + prof.id().getNamespace() + "." + prof.id().getPath() + ".rank." + prof.ranks().get(rank).id();
    }

    private static JobManagerEntity manager(ServerPlayer sp, Session s) {
        Entity e = sp.serverLevel().getEntity(s.managerId);
        return e instanceof JobManagerEntity m && m.isAlive() && m.distanceToSqr(sp) <= 64.0D ? m : null;
    }

    private static long banLeft(UUID player, ManagerKind kind) {
        Long until = BANS.get(player + "|" + kind.id);
        return until == null ? 0L : until - System.currentTimeMillis();
    }

    /** What the applicant really did: 0 nothing, 1 has worked somewhere, 2 reached the second rank, 3 the third. */
    private static int trueExp(MinecraftServer server, UUID player) {
        int best = -1;
        for (net.minecraft.resources.ResourceLocation id : ProfessionManager.ids()) {
            best = Math.max(best, Jobs.bestRank(server, player, id));
        }
        return best < 0 ? 0 : best >= 2 ? 3 : best == 1 ? 2 : 1;
    }

    private static ItemStack heldResume(ServerPlayer sp) {
        if (Resumes.isResume(sp.getMainHandItem())) return sp.getMainHandItem();
        if (Resumes.isResume(sp.getOffhandItem())) return sp.getOffhandItem();
        return ItemStack.EMPTY;
    }

    private static boolean hasResume(ServerPlayer sp) {
        for (ItemStack st : sp.getInventory().items) {
            if (Resumes.isResume(st)) return true;
        }
        return false;
    }

    private static void giveBlank(ServerPlayer sp, JobManagerEntity mgr) {
        long now = System.currentTimeMillis();
        Long last = BLANKS.get(sp.getUUID());
        if (last != null && now - last < BLANK_COOLDOWN_MS) {
            say(sp, mgr, "interview.err.hold");
            return;
        }
        BLANKS.put(sp.getUUID(), now);
        sp.getInventory().placeItemBackInInventory(new ItemStack(ModItems.RESUME.get()));
        say(sp, mgr, "interview.give_blank");
    }

    /** The manager says something in the chat (when there is no interview). */
    private static void say(ServerPlayer sp, JobManagerEntity mgr, String key, Object... args) {
        sp.sendSystemMessage(Component.translatable("cafe.customer.says", mgr.getDisplayName(), Component.translatable(key, args)));
    }
}
