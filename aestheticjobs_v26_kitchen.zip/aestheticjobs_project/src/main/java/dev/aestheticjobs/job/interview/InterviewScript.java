package dev.aestheticjobs.job.interview;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * The questions of the interview and what each answer is worth. Texts are in the lang files:
 * interview.q.[id] and interview.a.[id].[n]. deltas[n] = the change of the impression for the answer n, by the kind of
 * the manager (cafe, office, shop). The answer 0 is the best one; the order on the screen is shuffled by the server.
 */
public final class InterviewScript {
    public record Q(String id, int[][] deltas) {}

    private InterviewScript() {}

    private static int[] k(int cafe, int office, int shop) {
        return new int[]{cafe, office, shop};
    }

    private static int[] all(int v) {
        return new int[]{v, v, v};
    }

    private static Q q(String id, int[] a, int[] b, int[] c) {
        return new Q(id, new int[][]{a, b, c});
    }

    /** Asked by every manager (each manager weighs the answers in his own way). */
    public static final List<Q> GENERAL = List.of(
            q("g1", k(12, 6, 10), k(-2, 2, -2), all(-12)),
            q("g2", k(12, 12, 10), k(6, 4, 6), all(-10)),
            q("g3", k(12, 8, 12), k(2, 4, 2), all(-14)),
            q("g4", k(10, 6, 10), k(4, 8, 3), k(-8, -6, -8)),
            q("g5", k(8, 10, 6), k(-4, 0, -4), k(-6, -4, -6)),
            q("g6", k(10, 12, 10), all(2), all(-6)));

    /** About the work itself: one of these three is asked. */
    private static final Map<ManagerKind, List<Q>> SPECIAL = Map.of(
            ManagerKind.CAFE, List.of(q("c1", all(14), all(2), all(-10)), q("c2", all(14), all(-6), all(6)), q("c3", all(12), all(-6), all(-4))),
            ManagerKind.OFFICE, List.of(q("o1", all(14), all(-6), all(0)), q("o2", all(14), all(-4), all(-10)), q("o3", all(14), all(0), all(-10))),
            ManagerKind.SHOP, List.of(q("s1", all(14), all(-6), all(-4)), q("s2", all(14), all(-4), all(-12)), q("s3", all(12), all(-2), all(-10))));

    /** Four questions: three general ones and one about the work (always different from the last time by chance). */
    public static List<Q> pick(ManagerKind kind, Random rnd) {
        List<Q> general = new ArrayList<>(GENERAL);
        Collections.shuffle(general, rnd);
        List<Q> special = SPECIAL.get(kind);
        Q work = special.get(rnd.nextInt(special.size()));
        return new ArrayList<>(List.of(general.get(0), general.get(1), work, general.get(2)));
    }
}
