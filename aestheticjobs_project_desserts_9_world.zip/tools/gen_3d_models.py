#!/usr/bin/env python3
"""Generates the 3D item models (pastel, low-poly "voxel sweets") of the cafe: 8 drinks, 32 desserts, 7 supplies.

Every model is a handful of coloured boxes in Minecraft's item model format. All of them use ONE small palette
texture (textures/item/palette_3d.png, a 4x4 px swatch per colour), so there are no new pictures to paint: to change
a colour edit PALETTE below and run the script. The 2D icons (textures/item/<id>.png) are NOT touched: the GUI of the
mod keeps drawing them (the ticket, the thought bubbles, the menus).

    python3 tools/gen_3d_models.py            # writes models/item/*.json and the palette texture
    python3 tools/gen_3d_models.py --preview out.png   # also renders a contact sheet (a rough isometric view)
"""
import json
import math
import os
import random
import sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "aestheticjobs")

# ---------------------------------------------------------------------------------------------------- palette
PALETTE = {
    # ceramics, glass, milk
    "porcelain": "F4EEE8", "porcelain_d": "DCD2CC", "porcelain_dd": "C4B8B2", "glass": "E6ECEF", "glass_d": "C2CCD3",
    "milk": "FFF9EE", "foam": "FCF0D6", "foam_d": "EFDDB8", "cream": "FFF3DA", "cream_d": "F0DDB8",
    # coffee
    "espresso": "4A3028", "coffee": "6A4435", "coffee_l": "8A604A", "latte": "C9996B", "latte_l": "E3BE92",
    "caramel": "E2A857", "caramel_d": "C98B3E", "honey": "E8B55E", "honey_l": "F4D28A",
    # chocolate
    "choc": "6A4435", "choc_d": "4E2F26", "choc_l": "8A604A", "cocoa": "7A5240",
    # dough, pastry
    "dough": "EBC68C", "dough_l": "F4DDAE", "dough_d": "D8A45E", "golden": "E1A95E", "golden_d": "C48544", "golden_l": "F0C98A",
    "crust": "D79B58", "crust_d": "B57A3E", "ginger": "DEA56C", "ginger_d": "BD844B",
    # pastel colours
    "pink": "F3B3C4", "pink_d": "E48DA7", "pink_l": "FBD6E0", "rose": "E8A6B8", "red": "D9535E", "red_d": "B63A47",
    "mint": "AEDEC6", "mint_d": "86C4A8", "lemon": "F5E394", "lemon_d": "E4CC6A", "lilac": "BDAADB", "lilac_d": "9F8BC4",
    "blue": "6E73B5", "blue_d": "565B9E", "sky": "B4D3EE", "green": "9DC98F", "green_d": "7BAF70", "pistachio": "B3CC7E",
    "white": "FFFFFF", "straw": "D8B98A", "sack": "C9A878", "sack_d": "A98860", "sack_l": "DCC092", "silver": "C8CED6",
    "foil": "AEB9C9", "label": "FFF6E2", "vanilla": "F6E49D", "amber": "DC9A3C", "cork": "6A4A3A", "bean": "5A3A2E", "bean_l": "7A5240",
}

# ---------------------------------------------------------------------------------------------------- geometry
class Model:
    def __init__(self, name):
        self.name = name
        self.el = []                   # {"from","to","color","rot":(angle,cx,cz)}
        self.rng = random.Random(name)

    def box(self, x0, y0, z0, x1, y1, z1, color, rot=None):
        x0, x1 = min(x0, x1), max(x0, x1)
        y0, y1 = min(y0, y1), max(y0, y1)
        z0, z1 = min(z0, z1), max(z0, z1)
        if x1 - x0 < 0.05 or y1 - y0 < 0.05 or z1 - z0 < 0.05:
            return
        self.el.append({"from": [x0, y0, z0], "to": [x1, y1, z1], "color": color, "rot": rot})

    def rbox(self, cx, cz, w, d, y0, y1, angle, color):
        """A box centred at (cx, cz) turned by angle (22.5 / 45) about the vertical axis."""
        self.box(cx - w / 2, y0, cz - d / 2, cx + w / 2, y1, cz + d / 2, color, rot=(angle, cx, cz))

    # -- round things as stacks of rows (pixel circles)
    @staticmethod
    def _half(w):
        return round(w * 2) / 2.0

    def disc(self, cx, cz, r, y0, y1, color, hole=0.0):
        n = max(2, int(round(2 * r / 0.5)))
        rows = []
        for k in range(n):
            dz = -r + (k + 0.5) * 0.5
            wo = self._half(math.sqrt(max(0.0, r * r - dz * dz)))
            wi = self._half(math.sqrt(hole * hole - dz * dz)) if hole > 0 and abs(dz) < hole else 0.0
            rows.append((wo, wi))
        k = 0
        while k < n:
            j = k
            while j + 1 < n and rows[j + 1] == rows[k]:
                j += 1
            wo, wi = rows[k]
            z0, z1 = cz - r + k * 0.5, cz - r + (j + 1) * 0.5
            if wo > 0:
                if wi > 0:
                    self.box(cx - wo, y0, z0, cx - wi, y1, z1, color)
                    self.box(cx + wi, y0, z0, cx + wo, y1, z1, color)
                else:
                    self.box(cx - wo, y0, z0, cx + wo, y1, z1, color)
            k = j + 1

    def ring(self, cx, cz, ro, ri, y0, y1, color):
        self.disc(cx, cz, ro, y0, y1, color, hole=ri)

    def frustum(self, cx, cz, r0, r1, y0, y1, color, hole0=0.0, hole1=0.0, color_top=None):
        layers = max(1, int(round((y1 - y0) / 0.6)))
        h = (y1 - y0) / layers
        for i in range(layers):
            t = (i + 0.5) / layers
            self.disc(cx, cz, r0 + (r1 - r0) * t, y0 + i * h, y0 + (i + 1) * h,
                      color_top if (color_top and i == layers - 1) else color, hole=hole0 + (hole1 - hole0) * t)

    def sphere(self, cx, cy, cz, r, color, lower=True, upper=True, squash=1.0):
        steps = max(2, int(round(r / 0.6)))
        for i in range(-steps if lower else 0, steps if upper else 0):
            dy = (i + 0.5) / steps * r
            rr = math.sqrt(max(0.05, r * r - dy * dy))
            self.disc(cx, cz, max(0.7, rr), cy + i * r / steps * squash, cy + (i + 1) * r / steps * squash, color)

    def mask(self, rows, cell, cx, cz, y0, y1, color, hole_char=None, rot=None):
        h = len(rows) * cell
        for ri, row in enumerate(rows):
            x = 0
            while x < len(row):
                if row[x] == "X":
                    j = x
                    while j + 1 < len(row) and row[j + 1] == "X":
                        j += 1
                    w = len(row) * cell
                    self.box(cx - w / 2 + x * cell, y0, cz - h / 2 + ri * cell,
                             cx - w / 2 + (j + 1) * cell, y1, cz - h / 2 + (ri + 1) * cell, color,
                             rot=(rot, cx, cz) if rot else None)
                    x = j + 1
                else:
                    x += 1

    def scatter(self, n, cx, cz, r, y, size, colors, h=0.5, min_gap=0.0):
        pts = []
        tries = 0
        while len(pts) < n and tries < 400:
            tries += 1
            a, d = self.rng.random() * math.tau, math.sqrt(self.rng.random()) * r
            p = (cx + math.cos(a) * d, cz + math.sin(a) * d)
            if all((p[0] - q[0]) ** 2 + (p[1] - q[1]) ** 2 >= (size + min_gap) ** 2 for q in pts):
                pts.append(p)
        for i, (px, pz) in enumerate(pts):
            c = colors[i % len(colors)]
            self.box(px - size / 2, y, pz - size / 2, px + size / 2, y + h, pz + size / 2, c)

    def handle(self, x, y0, y1, color, depth=1.2, reach=1.6):
        """A C-shaped cup handle on the +x side."""
        self.box(x, y1 - 1.0, -depth / 2, x + reach, y1, depth / 2, color)
        self.box(x, y0, -depth / 2, x + reach, y0 + 1.0, depth / 2, color)
        self.box(x + reach - 1.0, y0, -depth / 2, x + reach, y1, depth / 2, color)


HEART = ["XX...XX", "XXX.XXX", "XXXXXXX", "XXXXXXX", ".XXXXX.", "..XXX..", "...X..."]
HEART_S = [".X.X.", "XXXXX", "XXXXX", ".XXX.", "..X.."]
HEART_BIG = [".XX...XX.", "XXXX.XXXX", "XXXXXXXXX", "XXXXXXXXX", ".XXXXXXX.", "..XXXXX..", "...XXX...", "....X...."]
MAN = ["...XXX...", "..XXXXX..", "..XXXXX..", "...XXX...", ".XXXXXXX.", "XXXXXXXXX", "XX.XXX.XX", "...XXX...", "..XX.XX..", "..XX.XX..", ".XXX.XXX."]


def triangle(width, rows):
    out = []
    for i in range(rows):
        w = 1 + int(round((width - 1) * i / (rows - 1))) if rows > 1 else width
        if w % 2 == 0:
            w += 1
        pad = (width - w) // 2
        out.append("." * pad + "X" * w + "." * (width - w - pad))
    return out


# ---------------------------------------------------------------------------------------------------- the items
MODELS = {}


def item(fn):
    MODELS[fn.__name__] = fn
    return fn


# ----- cups -----------------------------------------------------------------------------------------------
def china_cup(m, liquid, y0=0.0, r=4.2, h=4.6, handle=True, top=None):
    m.ring(0, 0, r, r - 0.9, y0 + h - 1.2, y0 + h, "porcelain")                       # the rim
    m.frustum(0, 0, r - 1.3, r, y0, y0 + h - 1.2, "porcelain", color_top="porcelain")
    m.disc(0, 0, r - 0.9, y0 + h - 1.5, y0 + h - 0.5, liquid)
    if top:
        top(m, y0 + h - 0.5)
    if handle:
        m.handle(r - 0.2, y0 + 1.0, y0 + h - 0.6, "porcelain_d")


def saucer(m):
    m.disc(0, 0, 6.4, 0, 0.5, "porcelain_d")
    m.disc(0, 0, 5.6, 0.5, 0.8, "porcelain")


def glass_mug(m, liquid, h=7.0, r=3.7, handle=True):
    m.disc(0, 0, r + 0.2, 0, 1.0, "glass_d")
    m.frustum(0, 0, r, r + 0.1, 1.0, h, liquid)
    m.ring(0, 0, r + 0.25, r - 0.6, h - 0.5, h, "glass")
    if handle:
        m.handle(r + 0.1, 1.4, h - 1.0, "glass_d", reach=1.7)


@item
def cup_espresso(m):
    saucer(m)
    china_cup(m, "espresso", y0=0.8, r=3.7, h=4.0)
    m.disc(0, 0, 2.4, 4.4, 4.7, "latte")                                                # crema


@item
def cup_americano(m):
    glass_mug(m, "espresso", h=7.2)
    m.disc(0, 0, 3.0, 7.0, 7.2, "coffee_l")


@item
def cup_latte(m):
    m.disc(0, 0, 3.4, 0, 1.0, "glass_d")
    for i, c in enumerate(("coffee", "latte", "latte_l", "foam")):                     # layered latte macchiato
        m.frustum(0, 0, 3.0 + i * 0.1, 3.1 + i * 0.1, 1.0 + i * 2.0, 3.0 + i * 2.0, c)
    m.ring(0, 0, 3.5, 2.5, 8.7, 9.2, "glass")
    m.disc(0, 0, 2.6, 8.6, 9.2, "milk")


@item
def cup_cappuccino(m):
    saucer(m)
    china_cup(m, "foam", y0=0.8, r=3.9, h=4.2)
    m.disc(0, 0, 2.9, 5.0, 5.5, "milk")
    m.scatter(7, 0, 0, 2.2, 5.5, 0.55, ["cocoa", "choc"], h=0.3)                       # cocoa dust


@item
def cup_flat_white(m):
    saucer(m)
    china_cup(m, "foam", y0=0.8, r=3.9, h=4.2)
    m.disc(0, 0, 3.0, 4.9, 5.3, "latte_l")
    m.mask(HEART_S, 0.55, 0, 0, 5.3, 5.6, "milk")                                        # a latte art heart
    m.mask(HEART, 0.45, 0, 0, 5.3, 5.5, "milk")


@item
def cup_raf(m):
    glass_mug(m, "latte_l", h=6.4, r=3.6)
    m.disc(0, 0, 3.0, 4.2, 6.4, "foam")
    for i, (r, c) in enumerate(((2.8, "milk"), (2.1, "white"), (1.4, "milk"), (0.8, "white"))):   # whipped cream
        m.disc(0, 0, r, 6.4 + i * 0.9, 7.3 + i * 0.9, c)
    m.box(-0.2, 7.3, 0.9, 0.9, 7.9, 2.3, "caramel")                                       # caramel drizzle
    m.box(-1.8, 6.5, 2.2, -0.4, 7.0, 2.8, "caramel")


@item
def cup_mocha(m):
    glass_mug(m, "choc", h=6.4, r=3.6)
    m.disc(0, 0, 3.0, 4.6, 6.4, "choc_l")
    for i, (r, c) in enumerate(((2.9, "white"), (2.2, "milk"), (1.5, "white"), (0.8, "milk"))):
        m.disc(0, 0, r, 6.4 + i * 0.9, 7.3 + i * 0.9, c)
    m.box(-2.0, 7.4, -0.3, 2.0, 7.8, 0.3, "choc", rot=(22.5, 0, 0))                       # chocolate stripes
    m.box(-1.4, 8.2, -1.4, -0.3, 9.2, -0.3, "choc_d")


@item
def cup_macchiato(m):
    m.disc(0, 0, 3.0, 0, 0.9, "glass_d")
    for i, c in enumerate(("milk", "latte_l", "latte", "coffee")):
        m.frustum(0, 0, 2.7, 2.8, 0.9 + i * 1.4, 2.3 + i * 1.4, c)
    m.disc(0, 0, 2.8, 6.4, 7.5, "foam")
    m.ring(0, 0, 3.0, 2.2, 7.0, 7.5, "glass")
    m.box(-0.6, 7.5, -0.6, 0.6, 8.0, 0.6, "caramel")


@item
def coffee_cup(m):                                                                       # the generic filled cup
    saucer(m)
    china_cup(m, "latte", y0=0.8, r=3.9, h=4.2)
    m.disc(0, 0, 2.9, 4.9, 5.3, "latte_l")


@item
def empty_cup(m):
    china_cup(m, "porcelain_d", r=4.4, h=5.6)
    m.disc(0, 0, 3.0, 1.3, 4.9, "porcelain_d")                                         # the inside is just a darker shade


# ----- pastries ---------------------------------------------------------------------------------------------
@item
def croissant(m):
    m.rbox(0, 0.2, 5.4, 4.6, 0, 3.8, 0, "golden")
    m.rbox(-4.0, 1.4, 4.0, 3.6, 0, 3.0, 22.5, "golden")
    m.rbox(4.0, 1.4, 4.0, 3.6, 0, 3.0, -22.5, "golden")
    m.rbox(-6.1, 3.5, 3.0, 2.6, 0, 2.2, 45, "golden_d")
    m.rbox(6.1, 3.5, 3.0, 2.6, 0, 2.2, -45, "golden_d")
    for x in (-2.0, 0.0, 2.0):                                                           # the folds on top
        m.box(x - 0.45, 3.8, -1.9, x + 0.45, 4.3, 2.3, "golden_l")
    m.rbox(-4.0, 1.4, 0.9, 3.0, 3.0, 3.4, 22.5, "golden_l")
    m.rbox(4.0, 1.4, 0.9, 3.0, 3.0, 3.4, -22.5, "golden_l")


def donut(m, glaze, sprinkles):
    m.ring(0, 0, 5.4, 1.7, 0, 1.6, "dough")
    m.ring(0, 0, 5.4, 1.7, 1.6, 2.6, "dough_d")
    m.ring(0, 0, 5.1, 1.9, 2.6, 3.4, glaze)
    m.scatter(9, 0, 0, 4.0, 3.4, 0.5, sprinkles, h=0.3, min_gap=0.35)


@item
def donut_pink(m):
    donut(m, "pink", ["white", "mint", "lemon"])


@item
def donut_choc(m):
    donut(m, "choc", ["cream", "dough_l"])


def wrapper(m, color, color_l, r0=3.0, r1=4.2, h=4.0):
    m.frustum(0, 0, r0, r1, 0, h, color)
    for a in range(0, 360, 45):                                                         # pleats
        x, z = math.cos(math.radians(a)) * (r1 - 0.1), math.sin(math.radians(a)) * (r1 - 0.1)
        m.box(x - 0.25, 0.8, z - 0.25, x + 0.25, h, z + 0.25, color_l)


@item
def cupcake_pink(m):
    wrapper(m, "rose", "pink_l")
    m.frustum(0, 0, 4.2, 4.4, 4.0, 5.2, "choc_l")
    for i, r in enumerate((4.0, 3.2, 2.4, 1.6, 0.9)):
        m.disc(0, 0, r, 5.2 + i * 1.0, 6.2 + i * 1.0, "pink" if i % 2 == 0 else "pink_l")
    m.sphere(0, 11.4, 0, 1.0, "red")


@item
def cupcake_choc(m):
    wrapper(m, "choc", "choc_l")
    m.frustum(0, 0, 4.2, 4.4, 4.0, 5.2, "choc_d")
    for i, r in enumerate((4.0, 3.2, 2.4, 1.6, 0.9)):
        m.disc(0, 0, r, 5.2 + i * 1.0, 6.2 + i * 1.0, "milk" if i % 2 == 0 else "white")
    m.box(-2.6, 6.2, -0.3, 2.6, 6.6, 0.3, "choc", rot=(22.5, 0, 0))
    m.box(-0.8, 10.2, -0.8, 0.8, 11.4, 0.8, "choc_d")


@item
def muffin_blueberry(m):
    wrapper(m, "lilac", "lilac_d", r0=2.9, r1=4.0, h=4.0)
    m.disc(0, 0, 4.6, 4.0, 5.0, "dough_d")
    m.disc(0, 0, 5.2, 5.0, 6.2, "golden")
    m.disc(0, 0, 4.4, 6.2, 7.2, "golden_l")
    m.disc(0, 0, 2.8, 7.2, 7.8, "golden_l")
    m.scatter(6, 0, 0, 3.4, 6.4, 1.1, ["blue", "blue_d"], h=1.0, min_gap=0.4)


@item
def cream_puff(m):
    m.disc(0, 0, 4.4, 0, 2.2, "golden")
    m.disc(0, 0, 4.1, 2.2, 3.3, "milk")
    m.disc(0, 0, 4.6, 3.3, 4.6, "golden")
    m.disc(0, 0, 4.0, 4.6, 5.6, "golden_l")
    m.disc(0, 0, 2.6, 5.6, 6.3, "golden_l")
    m.scatter(8, 0, 0, 3.0, 5.7, 0.7, ["white"], h=0.4)                                  # sugar dust


@item
def eclair(m):
    m.box(-5.6, 0, -2.0, 5.6, 2.3, 2.0, "golden")
    m.box(-5.1, 2.3, -1.9, 5.1, 3.0, 1.9, "milk")                                        # cream
    m.box(-5.6, 3.0, -2.1, 5.6, 4.6, 2.1, "golden_l")
    m.box(-5.3, 4.6, -1.8, 5.3, 5.5, 1.8, "choc")                                        # chocolate icing
    for x in (-3.6, -1.2, 1.2, 3.6):
        m.box(x - 0.4, 5.5, -1.3, x + 0.4, 5.8, 1.3, "cream")


@item
def cinnamon_roll(m):
    m.disc(0, 0, 5.2, 0, 3.8, "dough_d")
    m.disc(0, 0, 4.8, 3.8, 4.4, "dough")
    for ro, ri in ((3.7, 3.0), (2.2, 1.5)):                                                # the spiral
        m.ring(0, 0, ro, ri, 4.4, 4.8, "caramel_d")
    m.disc(0, 0, 0.8, 4.4, 4.8, "caramel_d")
    for (x, z, w, d) in ((-3.5, -1.5, 2.6, 0.8), (1.2, 2.6, 2.8, 0.8), (-0.5, -3.4, 3.2, 0.8), (2.6, -1.0, 0.8, 2.4), (-2.8, 1.8, 0.8, 2.2)):
        m.box(x - w / 2, 4.8, z - d / 2, x + w / 2, 5.3, z + d / 2, "milk")               # icing


@item
def cookie_choc(m):
    m.disc(0, 0, 5.4, 0, 1.0, "golden_d")
    m.disc(0, 0, 5.2, 1.0, 2.0, "golden")
    m.disc(0, 0, 4.4, 2.0, 2.4, "golden_l")
    m.scatter(7, 0, 0, 3.4, 2.2, 1.1, ["choc", "choc_d"], h=0.9, min_gap=0.5)


@item
def cookie_heart(m):
    m.mask(HEART_BIG, 1.35, 0, 0, 0, 1.6, "golden")
    m.mask(HEART_BIG, 1.35, 0, 0, 1.6, 2.2, "golden_l")
    inner = [".........", ".XX...XX.", ".XXX.XXX.", ".XXXXXXX.", "..XXXXX..", "...XXX...", "....X....", "........."]
    m.mask(inner, 1.35, 0, 0, 2.2, 2.7, "pink")
    m.box(-1.6, 2.7, -2.4, -0.6, 3.0, -1.4, "pink_l")


@item
def gingerbread_man(m):
    m.mask(MAN, 1.15, 0, 0, 0, 1.4, "ginger")
    m.mask(MAN, 1.15, 0, 0, 1.4, 1.9, "ginger_d")
    cell, h = 1.15, len(MAN) * 1.15
    z = lambda row: -h / 2 + row * cell
    m.box(-0.9, 1.9, z(1.2), -0.5, 2.3, z(1.2) + 0.4, "espresso")                          # the face
    m.box(0.5, 1.9, z(1.2), 0.9, 2.3, z(1.2) + 0.4, "espresso")
    m.box(-0.7, 1.9, z(2.1), 0.7, 2.2, z(2.1) + 0.35, "milk")
    for r in (4.4, 5.4, 6.4):                                                              # buttons and icing
        m.box(-0.3, 1.9, z(r), 0.3, 2.3, z(r) + 0.6, "pink" if r != 5.4 else "mint")
    m.box(-4.4, 1.9, z(4.6), -3.4, 2.2, z(4.6) + 0.5, "milk")
    m.box(3.4, 1.9, z(4.6), 4.4, 2.2, z(4.6) + 0.5, "milk")


def macaron(m, shell, shell_d, foot):
    m.disc(0, 0, 4.1, 0, 0.5, foot)
    m.disc(0, 0, 4.4, 0.5, 2.0, shell_d)
    m.disc(0, 0, 3.8, 2.0, 3.0, "milk")
    m.disc(0, 0, 4.4, 3.0, 4.6, shell)
    m.disc(0, 0, 3.6, 4.6, 5.2, shell)
    m.disc(0, 0, 4.3, 4.3, 4.6, foot)


@item
def macaron_pink(m):
    macaron(m, "pink", "pink_d", "pink_l")


@item
def macaron_mint(m):
    macaron(m, "mint", "mint_d", "white")


@item
def macaron_lemon(m):
    macaron(m, "lemon", "lemon_d", "cream")


@item
def cake_pop(m):
    m.box(-0.45, 0, -0.45, 0.45, 8.0, 0.45, "straw")
    m.sphere(0, 10.0, 0, 3.6, "pink")
    m.scatter(7, 0, 0, 2.6, 12.0, 0.6, ["white", "mint", "lemon"], h=0.3)
    m.box(-3.5, 9.4, -0.7, 3.5, 10.0, 0.7, "pink_l")                                        # glaze band


def slice_cake(m, layers, top_color, width=9, rows=7, cell=1.3):
    tri = triangle(width, rows)
    y = 0.0
    for h, c in layers:
        m.mask(tri, cell, 0, 0, y, y + h, c)
        y += h
    m.mask(tri, cell, 0, 0, y, y + 0.5, top_color)
    return y + 0.5


@item
def cheesecake(m):
    y = slice_cake(m, [(1.4, "crust"), (3.6, "cream")], "red", width=9, rows=7)
    m.mask(triangle(9, 7)[:3], 1.3, 0, 0, y - 0.5, y + 0.3, "red_d")
    m.sphere(-1.2, y + 0.8, -1.0, 0.9, "red")
    m.sphere(1.2, y + 0.8, -0.3, 0.8, "blue")


@item
def cake_strawberry(m):
    m.box(-4.6, 0, -3.2, 4.6, 1.8, 3.2, "dough_l")
    m.box(-4.6, 1.8, -3.2, 4.6, 2.8, 3.2, "milk")
    m.box(-4.6, 2.8, -3.2, 4.6, 4.2, 3.2, "dough_l")
    m.box(-4.6, 4.2, -3.2, 4.6, 5.0, 3.2, "milk")
    m.scatter(6, 0, 0, 3.0, 1.9, 0.7, ["pink_d"], h=0.8, min_gap=1.0)                       # strawberry bits in the cream
    m.disc(-0.5, 0.3, 2.0, 5.0, 6.0, "white")
    m.disc(-0.5, 0.3, 1.2, 6.0, 6.8, "milk")
    m.sphere(2.6, 6.2, -0.6, 1.6, "red", squash=1.1)
    m.box(2.1, 7.9, -1.0, 3.1, 8.4, 0.0, "green")


@item
def cake_choc(m):
    y = slice_cake(m, [(1.5, "choc_d"), (0.9, "cocoa"), (1.5, "choc_d"), (0.9, "cocoa"), (1.2, "choc")], "choc_d")
    m.sphere(0, y + 1.0, 1.0, 1.0, "red")
    m.box(-0.1, y + 1.8, 1.0, 0.3, y + 3.0, 1.4, "cork")


@item
def tiramisu(m):
    m.box(-5.4, 0, -3.8, 5.4, 1.3, 3.8, "dough_d")
    m.box(-5.4, 1.3, -3.8, 5.4, 2.7, 3.8, "foam")
    m.box(-5.4, 2.7, -3.8, 5.4, 4.0, 3.8, "latte")
    m.box(-5.4, 4.0, -3.8, 5.4, 5.2, 3.8, "foam")
    m.box(-5.4, 5.2, -3.8, 5.4, 6.0, 3.8, "cocoa")
    m.scatter(10, 0, 0, 4.0, 6.0, 0.6, ["choc_l", "choc"], h=0.2)


@item
def apple_pie(m):
    tri = triangle(9, 7)
    m.mask(tri, 1.35, 0, 0, 0, 1.0, "crust_d")
    m.mask(tri, 1.35, 0, 0, 1.0, 2.6, "honey")
    m.mask(tri, 1.35, 0, 0, 2.6, 3.4, "crust")
    cell, h = 1.35, 7 * 1.35
    for i in range(1, 9, 2):                                                                  # the lattice
        m.box(-4.0 + i * 0.9 - 0.3, 3.4, -h / 2, -4.0 + i * 0.9 + 0.3, 3.9, h / 2, "golden_l", rot=(22.5, 0, 0) if False else None)
    for j in range(1, 6, 2):
        m.box(-5.0, 3.4, -h / 2 + j * cell - 0.3, 5.0, 3.9, -h / 2 + j * cell + 0.3, "golden_l")


@item
def medovik(m):
    for i, c in enumerate(("honey", "foam", "honey", "foam", "honey", "foam", "honey")):
        m.box(-5.0, i * 0.9, -3.8, 5.0, (i + 1) * 0.9, 3.8, c)
    m.box(-5.0, 6.3, -3.8, 5.0, 6.9, 3.8, "honey_l")
    m.scatter(9, 0, 0, 3.8, 6.9, 0.8, ["honey", "caramel_d", "golden_l"], h=0.4)


@item
def brownie(m):
    m.box(-4.4, 0, -4.4, 4.4, 3.4, 4.4, "choc_d")
    m.box(-4.4, 3.4, -4.4, 4.4, 4.2, 4.4, "choc")
    for (x, z, w, d) in ((-2.0, -1.5, 3.0, 2.2), (1.8, 1.5, 2.8, 2.4), (1.5, -2.6, 2.0, 1.4)):
        m.box(x - w / 2, 4.2, z - d / 2, x + w / 2, 4.5, z + d / 2, "choc_l")
    m.box(-0.6, 4.2, 2.6, 0.8, 4.9, 3.6, "dough_d")                                          # a nut


@item
def waffle(m):
    m.box(-5.0, 0, -5.0, 5.0, 1.5, 5.0, "golden_d")
    for i in range(3):
        for j in range(3):
            x0, z0 = -4.5 + i * 3.1, -4.5 + j * 3.1
            m.box(x0, 1.5, z0, x0 + 2.6, 2.4, z0 + 2.6, "golden_l")
    m.box(-0.7, 2.4, -0.7, 0.7, 3.0, 0.7, "vanilla")                                         # butter


@item
def pancakes(m):
    for i in range(4):
        m.disc(0, 0, 5.2 - (i % 2) * 0.2, i * 1.3, (i + 1) * 1.3, "golden" if i % 2 == 0 else "golden_l")
    m.box(-1.3, 5.2, -1.3, 1.3, 6.2, 1.3, "vanilla")
    m.disc(0, 0, 3.6, 5.2, 5.5, "honey")                                                    # syrup
    for a in (20, 110, 200, 290):
        x, z = math.cos(math.radians(a)) * 4.9, math.sin(math.radians(a)) * 4.9
        m.box(x - 0.4, 1.4, z - 0.4, x + 0.4, 5.3, z + 0.4, "honey")


@item
def ice_cream_cone(m):
    m.frustum(0, 0, 0.7, 3.0, 0, 7.0, "golden")
    for i in range(1, 5):
        r = 0.7 + (3.0 - 0.7) * i / 5.0
        m.ring(0, 0, r + 0.05, r - 0.5, i * 1.4 - 0.2, i * 1.4 + 0.2, "golden_d")
    m.ring(0, 0, 3.2, 2.2, 6.4, 7.2, "pink_l")
    m.sphere(0, 9.6, 0, 3.3, "pink")
    m.sphere(0, 12.4, 0, 0.9, "red")


@item
def sundae(m):
    m.disc(0, 0, 3.0, 0, 0.8, "glass_d")
    m.box(-0.6, 0.8, -0.6, 0.6, 3.4, 0.6, "glass")
    m.frustum(0, 0, 1.6, 4.0, 3.4, 7.2, "glass", hole0=0.0, hole1=3.2)
    m.disc(0, 0, 3.3, 5.6, 6.6, "milk")
    m.sphere(-1.2, 8.2, 0.4, 2.3, "pink_l")
    m.sphere(1.5, 8.2, -0.5, 2.3, "milk")
    m.disc(0, 0, 1.8, 10.0, 11.0, "white")
    m.disc(0, 0, 1.1, 11.0, 11.8, "milk")
    m.box(-2.4, 9.0, -1.8, -1.4, 10.4, 1.6, "choc")
    m.box(2.0, 9.0, -1.6, 3.0, 10.2, 1.2, "choc")
    m.sphere(0, 12.6, 0, 0.9, "red")


@item
def creme_brulee(m):
    m.disc(0, 0, 5.4, 0, 0.9, "porcelain_d")
    m.ring(0, 0, 5.0, 3.9, 0.9, 3.1, "porcelain")
    m.disc(0, 0, 3.95, 0.9, 2.8, "cream_d")
    m.disc(0, 0, 3.9, 2.8, 3.2, "caramel")                                                   # the burnt sugar
    m.scatter(5, 0, 0, 2.8, 3.2, 1.0, ["caramel_d"], h=0.15, min_gap=0.3)


@item
def panna_cotta(m):
    m.disc(0, 0, 3.4, 0, 0.7, "glass_d")
    m.frustum(0, 0, 3.4, 3.8, 0.7, 6.0, "milk")
    m.ring(0, 0, 3.9, 3.3, 5.5, 6.0, "glass")
    m.disc(0, 0, 3.3, 5.7, 6.4, "red")
    for a in (30, 150, 270):                                                                  # berry sauce running down
        x, z = math.cos(math.radians(a)) * 3.7, math.sin(math.radians(a)) * 3.7
        m.box(x - 0.45, 3.4, z - 0.45, x + 0.45, 6.0, z + 0.45, "red")
    m.sphere(0.4, 7.6, 0, 1.4, "red_d", squash=1.1)
    m.box(-0.5, 8.9, -0.5, 0.5, 9.5, 0.5, "green")


@item
def flan(m):
    m.disc(0, 0, 6.0, 0, 0.7, "caramel_d")
    m.disc(0, 0, 5.4, 0.7, 1.2, "amber")
    m.frustum(0, 0, 4.4, 3.8, 1.2, 5.6, "vanilla")
    m.disc(0, 0, 3.7, 5.6, 6.2, "amber")
    for a in (0, 70, 150, 220, 300):
        x, z = math.cos(math.radians(a)) * 3.9, math.sin(math.radians(a)) * 3.9
        m.box(x - 0.4, 3.4, z - 0.4, x + 0.4, 5.7, z + 0.4, "amber")
    m.sphere(0, 6.8, 0, 1.0, "red")


@item
def fruit_tart(m):
    m.frustum(0, 0, 4.4, 5.2, 0, 3.0, "golden")
    for a in range(0, 360, 30):                                                                # the fluted edge
        x, z = math.cos(math.radians(a)) * 5.1, math.sin(math.radians(a)) * 5.1
        m.box(x - 0.35, 1.0, z - 0.35, x + 0.35, 3.1, z + 0.35, "golden_d")
    m.disc(0, 0, 4.4, 3.0, 3.7, "milk")
    for (x, z, c) in ((-2.4, -0.8, "red"), (0.0, -2.6, "blue"), (2.4, -0.6, "red"), (1.2, 1.9, "blue_d"), (-1.6, 1.8, "red_d"), (0.0, 0.0, "red")):
        m.sphere(x, 4.5, z, 1.0, c)
    m.box(-0.5, 4.6, 2.8, 1.5, 4.9, 3.8, "green")
    m.box(2.2, 4.6, 1.6, 3.2, 4.9, 3.2, "green")


@item
def baklava(m):
    for i, c in enumerate(("golden_l", "golden", "golden_l", "pistachio", "pistachio", "golden_l", "golden")):
        m.box(-5.0, i * 0.9, -5.0, 5.0, (i + 1) * 0.9, 5.0, c)
    m.box(-5.0, 6.3, -5.0, 5.0, 7.0, 5.0, "honey")
    m.box(-0.9, 7.0, -0.9, 0.9, 7.5, 0.9, "pistachio")
    m.scatter(6, 0, 0, 3.8, 7.0, 0.7, ["green", "pistachio"], h=0.25)


# ----- supplies ------------------------------------------------------------------------------------------------
@item
def coffee_beans(m):
    m.box(-4.6, 0, -3.6, 4.6, 7.0, 3.6, "sack")
    m.box(-4.6, 0, -3.6, -3.9, 7.0, 3.6, "sack_d")
    m.box(-4.0, 7.0, -3.0, 4.0, 8.4, 3.0, "sack_l")                                            # the rolled top
    m.box(-4.4, 4.4, -3.7, 4.4, 4.9, 3.7, "sack_d")                                            # the string
    m.box(-1.6, 2.0, -3.8, 1.6, 3.6, -3.6, "sack_d")                                           # a patch
    for (x, z) in ((-2.6, -1.0), (-0.8, 1.2), (1.0, -1.2), (2.4, 1.0), (0.2, -0.2), (-2.0, 1.6), (1.8, 2.0), (-1.2, -2.0), (2.8, -2.0)):
        m.box(x - 0.8, 8.4, z - 0.6, x + 0.8, 9.6, z + 0.6, "bean" if (x + z) > 0 else "bean_l")


def carton(m, body, accent, mark):
    m.box(-2.8, 0, -2.8, 2.8, 8.0, 2.8, body)
    m.box(-2.8, 3.2, -2.9, 2.8, 5.8, 2.9, accent)                                              # a band
    for (x0, z0, x1, z1) in ((-1.4, -3.0, 1.4, -2.9), (2.9, -1.4, 3.0, 1.4)):                  # the picture on two visible faces
        m.box(x0, 3.5, z0, x1, 5.5, z1, mark) if z0 != z1 else None
    m.box(-2.8, 8.0, -2.8, 2.8, 9.0, 2.8, body)
    m.box(-2.8, 9.0, -1.4, 2.8, 10.0, 1.4, body)
    m.box(-2.8, 10.0, -0.5, 2.8, 10.8, 0.5, accent)                                            # the folded roof


@item
def milk_carton(m):
    carton(m, "milk", "sky", "choc_d")
    m.box(-1.6, 3.4, -2.95, -0.2, 4.6, -2.8, "choc_d")                                         # cow spots
    m.box(0.4, 4.4, -2.95, 1.6, 5.6, -2.8, "choc_d")
    m.box(2.85, 3.4, -1.6, 3.0, 4.6, -0.2, "choc_d")
    m.box(2.85, 4.4, 0.4, 3.0, 5.6, 1.6, "choc_d")


@item
def cream_carton(m):
    carton(m, "cream", "caramel", "white")
    m.disc(0, -2.95, 0.1, 4.0, 4.4, "white")
    m.box(-1.2, 3.4, -3.0, 1.2, 3.8, -2.88, "white")
    m.box(-0.8, 3.8, -3.0, 0.8, 4.4, -2.88, "white")
    m.box(-0.4, 4.4, -3.0, 0.4, 5.0, -2.88, "white")
    m.box(2.88, 3.4, -1.2, 3.0, 3.8, 1.2, "white")
    m.box(2.88, 3.8, -0.8, 3.0, 4.4, 0.8, "white")
    m.box(2.88, 4.4, -0.4, 3.0, 5.0, 0.4, "white")


def bottle(m, liquid, liquid_d):
    m.disc(0, 0, 2.9, 0, 0.9, "glass_d")
    m.frustum(0, 0, 2.8, 2.7, 0.9, 6.0, liquid)
    m.frustum(0, 0, 2.7, 1.2, 6.0, 7.8, liquid_d)                                              # the shoulder
    m.ring(0, 0, 1.3, 0.8, 7.8, 9.4, "glass")
    m.disc(0, 0, 1.5, 9.4, 11.0, "cork")                                                       # the cap
    m.box(-2.0, 2.0, -2.95, 2.0, 5.0, -2.75, "label")                                          # label
    m.box(2.75, 2.0, -2.0, 2.95, 5.0, 2.0, "label")
    return


@item
def syrup_vanilla(m):
    bottle(m, "vanilla", "lemon_d")
    m.box(-0.8, 2.6, -3.0, 0.8, 4.2, -2.9, "lemon_d")
    m.box(2.9, 2.6, -0.8, 3.0, 4.2, 0.8, "lemon_d")
    m.box(-0.2, 3.2, -3.0, 0.2, 3.6, -2.95, "green_d")


@item
def syrup_caramel(m):
    bottle(m, "amber", "caramel_d")
    m.box(-0.8, 2.6, -3.0, 0.8, 4.2, -2.9, "caramel_d")
    m.box(2.9, 2.6, -0.8, 3.0, 4.2, 0.8, "caramel_d")


@item
def chocolate(m):
    m.box(-4.6, 0, -3.6, 4.6, 1.6, 3.6, "choc_d")
    for i in range(3):
        for j in range(2):
            m.box(-4.4 + i * 3.0, 1.6, -3.4 + j * 3.5, -1.7 + i * 3.0, 2.4, -0.6 + j * 3.5, "choc")
    m.box(1.6, 0.2, -3.9, 4.9, 1.9, 3.9, "foil")                                              # the foil wrapper at one end
    m.box(1.6, 1.9, -3.9, 4.9, 2.3, 3.9, "silver")



# ======================================================= v2: rounder, closer to the sprites
def dome(m, cx, cz, r, y0, h, color, steps=3, base=1.0):
    """A rounded bun: wide at the bottom, narrowing to the top."""
    for i in range(steps):
        t = (i + 0.5) / steps
        rr = r * math.sqrt(max(0.05, 1 - (t ** 2) * (1 - base * 0.0))) * (1.0 - 0.0)
        m.disc(cx, cz, max(0.8, rr * (1.0 - 0.12 * t)), y0 + h * i / steps, y0 + h * (i + 1) / steps, color)


def pill(m, cx, cz, r, y0, h, color, color_top=None):
    """Rounded puck: edge chamfered at the bottom and the top."""
    m.disc(cx, cz, r - 0.6, y0, y0 + 0.5, color)
    m.disc(cx, cz, r, y0 + 0.5, y0 + h - 0.5, color)
    m.disc(cx, cz, r - 0.7, y0 + h - 0.5, y0 + h, color_top or color)


def wedge(m, layers, length=10.0, back=8.0, tip=1.0, step=0.8, top=None, rot=None):
    """A cake slice: tip at -x, the wide cut face at +x (layers is a list of (height, colour))."""
    n = int(length / step)
    y = 0.0
    for h, c in layers + ([(0.5, top)] if top else []):
        for i in range(n):
            t = (i + 0.5) / n
            w = tip + (back - tip) * t
            w = round(w * 2) / 2
            x0 = -length / 2 + i * step
            m.box(x0, y, -w / 2, x0 + step, y + h, w / 2, c)
        y += h
    return y


@item
def croissant(m):
    segs = 9
    for i in range(segs):
        t = i / (segs - 1)
        a = math.radians(-70 + 140 * t)                      # a crescent: an arc opening towards -z
        x, z = math.sin(a) * 6.2, -math.cos(a) * 2.8 + 1.6
        th = 0.9 + 3.0 * math.sin(math.pi * t) ** 0.8          # thick in the middle, thin tips
        ang = round(-math.degrees(a) / 22.5) * 22.5
        m.rbox(x, z, 2.4 + 2.2 * math.sin(math.pi * t), 3.6 + 1.6 * math.sin(math.pi * t), 0, th, ang, "golden" if i % 2 == 0 else "golden_d")
        m.rbox(x, z, 1.4 + 1.2 * math.sin(math.pi * t), 2.2 + 1.2 * math.sin(math.pi * t), th, th + 0.6, ang, "golden_l")


def donut2(m, glaze, sprinkles):
    m.ring(0, 0, 5.0, 1.8, 0, 0.8, "dough_d")
    m.ring(0, 0, 5.6, 1.6, 0.8, 2.6, "dough")
    m.ring(0, 0, 5.2, 1.8, 2.6, 3.2, "dough_d")
    m.ring(0, 0, 5.0, 2.0, 3.2, 3.9, glaze)
    m.ring(0, 0, 5.6, 4.6, 2.9, 3.4, glaze)
    m.scatter(12, 0, 0, 3.9, 3.9, 0.5, sprinkles, h=0.3, min_gap=0.4)


@item
def donut_pink(m):
    donut2(m, "pink", ["white", "mint", "lemon", "lilac"])


@item
def donut_choc(m):
    donut2(m, "choc", ["cream", "dough_l", "caramel"])


def macaron2(m, shell, shell_d, foot):
    pill(m, 0, 0, 4.6, 0, 2.0, shell_d, shell)
    m.disc(0, 0, 4.7, 2.0, 2.2, foot)
    m.disc(0, 0, 4.0, 2.2, 3.4, "milk")
    m.disc(0, 0, 4.7, 3.4, 3.6, foot)
    pill(m, 0, 0, 4.6, 3.6, 2.2, shell, shell)
    m.disc(0, 0, 3.0, 5.8, 6.2, shell)


@item
def macaron_pink(m):
    macaron2(m, "pink", "pink_d", "pink_l")


@item
def macaron_mint(m):
    macaron2(m, "mint", "mint_d", "white")


@item
def macaron_lemon(m):
    macaron2(m, "lemon", "lemon_d", "cream")


@item
def cookie_choc(m):
    pill(m, 0, 0, 5.4, 0, 2.2, "golden", "golden_l")
    m.ring(0, 0, 5.4, 4.6, 0.5, 1.0, "golden_d")
    m.scatter(8, 0, 0, 3.6, 2.2, 1.1, ["choc", "choc_d"], h=0.8, min_gap=0.6)


@item
def cookie_heart(m):
    m.mask(HEART_BIG, 1.3, 0, 0, 0, 1.4, "golden_d", rot=135)
    m.mask(HEART_BIG, 1.3, 0, 0, 1.4, 2.1, "golden", rot=135)
    inner = [".........", "..XX.XX..", ".XXXXXXX.", ".XXXXXXX.", "..XXXXX..", "...XXX...", "....X....", "........."]
    m.mask(inner, 1.3, 0, 0, 2.1, 2.6, "pink", rot=135)
    inner2 = [".........", ".........", "..X...X..", "..XXXXX..", "...XXX...", "....X....", ".........", "........."]
    m.mask(inner2, 1.3, 0, 0, 2.6, 2.9, "pink_l", rot=135)


@item
def gingerbread_man(m):
    c = 1.15
    m.mask(MAN, c, 0, 0, 0, 1.4, "ginger_d", rot=135)
    m.mask(MAN, c, 0, 0, 1.4, 2.0, "ginger", rot=135)
    h = len(MAN) * c
    def dot(col, row, color, w=0.5):
        x, z = (col - 4.5) * c, -h / 2 + row * c
        r = math.radians(135)
        rx, rz = x * math.cos(r) + z * math.sin(r), -x * math.sin(r) + z * math.cos(r)
        m.box(rx - w / 2, 2.0, rz - w / 2, rx + w / 2, 2.4, rz + w / 2, color)
    dot(3.6, 1.4, "espresso"); dot(5.4, 1.4, "espresso")
    dot(4.5, 2.3, "pink_d", 0.9)
    for r_ in (4.3, 5.3, 6.3):
        dot(4.5, r_, "mint" if r_ == 5.3 else "pink", 0.7)
    for col, row in ((1.0, 5.2), (8.0, 5.2), (3.6, 10.4), (5.4, 10.4)):
        dot(col, row, "milk", 0.9)


@item
def cheesecake(m):
    y = wedge(m, [(1.4, "crust"), (3.8, "cream")], length=10, back=8.5, tip=1.0, top="cream_d")
    m.disc(-0.5, 0, 2.2, y, y + 0.5, "red_d")
    m.sphere(-0.5, y + 0.9, 0, 1.0, "red")
    m.sphere(1.5, y + 0.8, -1.4, 0.8, "red_d")
    m.sphere(1.8, y + 0.8, 1.3, 0.8, "blue")


@item
def cake_choc(m):
    y = wedge(m, [(1.4, "choc_d"), (0.8, "cocoa"), (1.4, "choc_d"), (0.8, "cocoa"), (1.4, "choc_d")], length=10, back=8.5, tip=1.0, top="choc")
    m.sphere(2.0, y + 0.9, 0, 1.0, "red")
    m.box(1.8, y + 1.8, -0.2, 2.2, y + 2.9, 0.2, "cork")


@item
def apple_pie(m):
    y = wedge(m, [(1.0, "crust_d"), (2.4, "honey")], length=10, back=8.5, tip=1.0, top="crust")
    for x in (-2.5, 0.0, 2.5, 4.2):
        w = (1.0 + 7.5 * (x + 5) / 10)
        m.box(x - 0.3, y, -w / 2 + 0.3, x + 0.3, y + 0.5, w / 2 - 0.3, "golden_l")
    for z in (-2.0, 0.0, 2.0):
        m.box(-2.0 + abs(z) * 0.2, y, z - 0.3, 5.0, y + 0.5, z + 0.3, "golden_l")


@item
def cream_puff(m):
    pill(m, 0, 0, 4.6, 0, 2.4, "golden", "golden")
    m.disc(0, 0, 4.1, 2.4, 3.4, "milk")
    pill(m, 0, 0, 4.8, 3.4, 2.4, "golden", "golden_l")
    m.disc(0, 0, 3.6, 5.8, 6.4, "golden_l")
    m.disc(0, 0, 2.2, 6.4, 6.8, "golden_l")
    m.scatter(10, 0, 0, 3.2, 6.0, 0.7, ["white"], h=0.4)


@item
def muffin_blueberry(m):
    wrapper(m, "lilac", "lilac_d", r0=2.9, r1=4.0, h=4.0)
    pill(m, 0, 0, 5.4, 4.0, 2.4, "golden", "golden")
    m.disc(0, 0, 4.6, 6.4, 7.4, "golden_l")
    m.disc(0, 0, 3.0, 7.4, 8.0, "golden_l")
    m.scatter(7, 0, 0, 3.6, 7.0, 1.2, ["blue", "blue_d"], h=1.0, min_gap=0.5)
    m.scatter(5, 0, 0, 2.2, 7.8, 0.6, ["white"], h=0.3)


@item
def cinnamon_roll(m):
    pill(m, 0, 0, 5.4, 0, 4.2, "dough_d", "dough")
    m.disc(0, 0, 5.0, 4.2, 4.6, "dough")
    for ro, ri in ((4.0, 3.2), (2.4, 1.6)):
        m.ring(0, 0, ro, ri, 4.6, 5.0, "caramel_d")
    m.disc(0, 0, 0.9, 4.6, 5.0, "caramel_d")
    for (x, z, w, d) in ((-3.8, -1.8, 2.6, 0.9), (1.4, 3.2, 3.0, 0.9), (-0.5, -3.9, 3.4, 0.9), (3.4, -1.0, 0.9, 2.6), (-3.2, 2.2, 0.9, 2.4), (0.5, 0.2, 0.9, 0.9)):
        m.box(x - w / 2, 5.0, z - d / 2, x + w / 2, 5.6, z + d / 2, "milk")
    for (x, z) in ((-4.6, 0.5), (4.5, 2.0), (2.0, -4.4)):
        m.box(x - 0.5, 3.0, z - 0.5, x + 0.5, 5.0, z + 0.5, "milk")


# ---------------------------------------------------------------------------------------------------- output
def corners(e):
    x0, y0, z0 = e["from"]
    x1, y1, z1 = e["to"]
    pts = [(x, y, z) for x in (x0, x1) for y in (y0, y1) for z in (z0, z1)]
    if e["rot"]:
        a, cx, cz = e["rot"]
        c, s = math.cos(math.radians(a)), math.sin(math.radians(a))
        pts = [(cx + (x - cx) * c + (z - cz) * s, y, cz - (x - cx) * s + (z - cz) * c) for x, y, z in pts]
    return pts


def bbox(elements):
    pts = [p for e in elements for p in corners(e)]
    return [min(p[i] for p in pts) for i in range(3)], [max(p[i] for p in pts) for i in range(3)]


def view(p, ang_x=30.0, ang_y=225.0):
    """The GUI view of a point (relative to the model centre): x right, y up, z towards the camera."""
    x, y, z = p
    a = math.radians(ang_x)
    y, z = y * math.cos(a) + z * math.sin(a), -y * math.sin(a) + z * math.cos(a)
    b = math.radians(ang_y)
    x, z = x * math.cos(b) + z * math.sin(b), -x * math.sin(b) + z * math.cos(b)
    return x, y, z


def finish(model, color_cells):
    lo, hi = bbox(model.el)
    # centre the model in the 16x16x16 space (resting evenly around the middle)
    off = [8 - (lo[i] + hi[i]) / 2 for i in range(3)]
    ext = [hi[i] - lo[i] for i in range(3)]
    elements = []
    for e in model.el:
        cell = color_cells[e["color"]]
        u, v = cell % 16, cell // 16
        uv = [u + 0.25, v + 0.25, u + 0.75, v + 0.75]
        face = {"uv": uv, "texture": "#p"}
        el = {"from": [round(e["from"][i] + off[i], 3) for i in range(3)],
              "to": [round(e["to"][i] + off[i], 3) for i in range(3)],
              "faces": {k: dict(face) for k in ("north", "east", "south", "west", "up", "down")}}
        if e["rot"]:
            a, cx, cz = e["rot"]
            el["rotation"] = {"angle": a, "axis": "y", "origin": [round(cx + off[0], 3), round(e["from"][1] + off[1], 3), round(cz + off[2], 3)]}
        elements.append(el)
    # GUI scale: the picture is about 13 px of the 16 px slot, whatever the model
    shifted = [{"from": [e["from"][i] - lo[i] - ext[i] / 2 for i in range(3)], "to": [e["to"][i] - lo[i] - ext[i] / 2 for i in range(3)], "rot": e["rot"] and (e["rot"][0], e["rot"][1] - lo[0] - ext[0] / 2, e["rot"][2] - lo[2] - ext[2] / 2)} for e in model.el]
    pts = [view(p) for e in shifted for p in corners(e)]
    w = max(p[0] for p in pts) - min(p[0] for p in pts)
    h = max(p[1] for p in pts) - min(p[1] for p in pts)
    s = max(0.55, min(1.15, 13.0 / max(w, h)))
    hand = round(0.5 * min(1.0, 11.0 / max(ext[0], ext[2], ext[1] * 0.8)) + 0.12, 3)
    display = {
        "gui": {"rotation": [30, 225, 0], "translation": [0, 0, 0], "scale": [round(s, 3)] * 3},
        "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.45, 0.45, 0.45]},
        "fixed": {"rotation": [25, 225, 0], "translation": [0, 0, 0], "scale": [0.6, 0.6, 0.6]},
        "thirdperson_righthand": {"rotation": [75, 45, 0], "translation": [0, 2.5, 0], "scale": [hand, hand, hand]},
        "thirdperson_lefthand": {"rotation": [75, 45, 0], "translation": [0, 2.5, 0], "scale": [hand, hand, hand]},
        "firstperson_righthand": {"rotation": [0, 45, 0], "translation": [0, 1.5, 0], "scale": [hand + 0.08] * 3},
        "firstperson_lefthand": {"rotation": [0, 225, 0], "translation": [0, 1.5, 0], "scale": [hand + 0.08] * 3},
        "head": {"rotation": [0, 0, 0], "translation": [0, 13, 0], "scale": [0.8, 0.8, 0.8]},
    }
    return {"textures": {"particle": "aestheticjobs:item/palette_3d", "p": "aestheticjobs:item/palette_3d"},
            "gui_light": "side", "elements": elements, "display": display}


def main():
    names = ["cup_espresso", "cup_americano", "cup_latte", "cup_cappuccino", "cup_flat_white", "cup_raf", "cup_mocha", "cup_macchiato",
             "croissant", "donut_pink", "donut_choc", "cupcake_pink", "cupcake_choc", "muffin_blueberry", "cream_puff", "eclair",
             "cinnamon_roll", "cookie_choc", "cookie_heart", "gingerbread_man", "macaron_pink", "macaron_mint", "macaron_lemon", "cake_pop",
             "cheesecake", "cake_strawberry", "cake_choc", "tiramisu", "apple_pie", "medovik", "brownie", "waffle",
             "pancakes", "ice_cream_cone", "sundae", "creme_brulee", "panna_cotta", "flan", "fruit_tart", "baklava",
             "empty_cup", "coffee_beans", "milk_carton", "cream_carton", "syrup_vanilla", "syrup_caramel", "chocolate"]
    cells = {name: i for i, name in enumerate(PALETTE)}
    assert len(cells) <= 256
    built = {}
    for n in names + ["coffee_cup"]:
        m = Model(n)
        MODELS[n](m)
        for e in m.el:
            assert e["color"] in cells, (n, e["color"])
        built[n] = (m, finish(m, cells))

    # the palette texture: 16x16 swatches of 4x4 px
    try:
        from PIL import Image
        img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
        for name, i in cells.items():
            rgb = tuple(int(PALETTE[name][k:k + 2], 16) for k in (0, 2, 4))
            for dx in range(4):
                for dy in range(4):
                    img.putpixel(((i % 16) * 4 + dx, (i // 16) * 4 + dy), rgb + (255,))
        img.save(os.path.join(ROOT, "textures", "item", "palette_3d.png"))
    except ImportError:
        print("Pillow is missing: the palette texture was not written")

    for n, (m, data) in built.items():
        if n == "coffee_cup":                                                               # keeps the overrides of the 8 drinks
            old = json.load(open(os.path.join(ROOT, "models", "item", "coffee_cup.json")))
            data["overrides"] = old.get("overrides", [])
        with open(os.path.join(ROOT, "models", "item", n + ".json"), "w") as f:
            json.dump(data, f, indent=1)
            f.write("\n")
    print("wrote", len(built), "models,", sum(len(b[0].el) for b in built.values()), "boxes")

    if "--preview" in sys.argv:
        preview(built, names, cells, sys.argv[sys.argv.index("--preview") + 1])


# ---------------------------------------------------------------------------------------------------- preview
def preview(built, names, cells, out):
    from PIL import Image, ImageDraw
    S, CELL = 8, 30                                         # supersample, cell size in px
    cols = 8
    sheet = Image.new("RGB", (cols * CELL * 4, ((len(names) + cols - 1) // cols) * CELL * 4), (240, 232, 222))
    for idx, n in enumerate(names):
        m = built[n][0]
        lo, hi = bbox(m.el)
        ctr = [(lo[i] + hi[i]) / 2 for i in range(3)]
        faces = []
        for e in m.el:
            x0, y0, z0 = e["from"]
            x1, y1, z1 = e["to"]
            quads = {"up": ([(x0, y1, z0), (x0, y1, z1), (x1, y1, z1), (x1, y1, z0)], (0, 1, 0), 1.0),
                     "north": ([(x1, y1, z0), (x1, y0, z0), (x0, y0, z0), (x0, y1, z0)], (0, 0, -1), 0.82),
                     "south": ([(x0, y1, z1), (x0, y0, z1), (x1, y0, z1), (x1, y1, z1)], (0, 0, 1), 0.82),
                     "west": ([(x0, y1, z0), (x0, y0, z0), (x0, y0, z1), (x0, y1, z1)], (-1, 0, 0), 0.66),
                     "east": ([(x1, y1, z1), (x1, y0, z1), (x1, y0, z0), (x1, y1, z0)], (1, 0, 0), 0.66)}
            rgb = tuple(int(PALETTE[e["color"]][k:k + 2], 16) for k in (0, 2, 4))
            for face, (pts, normal, shade) in quads.items():
                if e["rot"]:
                    a, cx, cz = e["rot"]
                    c, s = math.cos(math.radians(a)), math.sin(math.radians(a))
                    pts = [(cx + (x - cx) * c + (z - cz) * s, y, cz - (x - cx) * s + (z - cz) * c) for x, y, z in pts]
                    nx, ny, nz = normal
                    normal = (nx * c + nz * s, ny, -nx * s + nz * c)
                vp = [view((p[0] - ctr[0], p[1] - ctr[1], p[2] - ctr[2])) for p in pts]
                vn = view(normal)
                if vn[2] <= 0.01:
                    continue
                depth = sum(p[2] for p in vp) / 4
                col = tuple(int(c * shade) for c in rgb)
                faces.append((depth, vp, col))
        faces.sort(key=lambda f: f[0])
        size = CELL * 4
        im = Image.new("RGB", (size * S // 4, size * S // 4), (240, 232, 222))
        d = ImageDraw.Draw(im)
        k = size * S // 4 / 17.0
        for _, vp, col in faces:
            poly = [(im.width / 2 + p[0] * k * 0.95, im.height / 2 - p[1] * k * 0.95) for p in vp]
            d.polygon(poly, fill=col, outline=tuple(int(c * 0.78) for c in col))
        im = im.resize((size, size), Image.LANCZOS)
        sheet.paste(im, ((idx % cols) * size, (idx // cols) * size))
    sheet.save(out)
    print("preview", out, sheet.size)


if __name__ == "__main__":
    main()
