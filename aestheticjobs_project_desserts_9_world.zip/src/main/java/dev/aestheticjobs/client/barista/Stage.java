package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.cafe.Step;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** One mini-game of a recipe. The screen gives it a rectangle, calls update every frame and render after it. */
public abstract class Stage {
    protected final Brew brew;
    public final Step step;
    protected boolean done;
    protected int rx, ry, rw, rh;

    protected Stage(Brew brew, Step step) {
        this.brew = brew;
        this.step = step;
    }

    public final void layout(int x, int y, int w, int h) {
        rx = x;
        ry = y;
        rw = w;
        rh = h;
    }

    public boolean isDone() { return done; }

    /** 0..100, valid once the stage is done. */
    public abstract int score();

    public abstract void update(float dt, int mx, int my);

    public abstract void render(GuiGraphics g, Font font, int mx, int my);

    /** A line under the play area that changes with what is going on. */
    public Component status() { return step.hint(); }

    /** The main button of the stage (grind: "stop", steam: "done" ...). */
    public boolean canFinish() { return false; }

    public Component finishLabel() { return Component.translatable("gui.aestheticjobs.cafe.done"); }

    public void finish() { }

    public boolean click(double mx, double my, int button) { return false; }

    // ------------------------------------------------------------------ a stage that is played ON the real machine
    /** True when the camera should fly to the machine: no panel, the screen only carries render, update and click in gui coordinates. */
    public boolean worldMode() { return false; }

    /** Where the camera stands in world mode. */
    public CameraRig.Shot shot() { return CameraRig.GROUP; }

    /** The HUD of a world-mode stage, in gui coordinates (rx, ry, rw, rh = the whole screen). */
    public void renderWorld(GuiGraphics g, Font font, int mx, int my) { }

    public void scroll(double amount) { }

    // ------------------------------------------------------------------ a stage that goes on while the barista does the next one (the shot)
    /** True when the stage hands over to the background (the barista moves on to the next step, the stage keeps running). */
    public boolean wantsBackground() { return false; }

    /** Called every frame while the stage runs in the background. */
    public void updateBackground(float dt) { }

    /** The background job is over; score() is final now. */
    public boolean backgroundDone() { return true; }

    /** The little control strip of the background job (drawn at the bottom of the canvas). */
    public void renderStrip(GuiGraphics g, Font font, int x, int y, int w, int h, int mx, int my) { }

    public boolean clickStrip(double mx, double my, int x, int y, int w, int h) { return false; }

    /** Keyboard shortcut to stop the background job. */
    public void requestStop() { }
}
