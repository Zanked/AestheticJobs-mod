package dev.aestheticjobs.client.barista;

import net.minecraft.core.BlockPos;

/**
 * What the barista's own mini-game wants the REAL machine in the world to show (client only). The server-synced
 * phase of the machine runs on a fixed timer; while the barista plays, the machine shows the true state instead:
 * the stream that appears when the pump is held, the colour that tells the stage of the shot, the sputtering.
 * The renderer asks get(pos); null = nothing is played here, draw the default animation.
 */
public final class LiveMachine {
    public static final class Live {
        public boolean pumping;
        /** 0..1 of the shot (1 = the cup holds the full espresso). */
        public double level;
        public double jitter, channeling;
        public int stream = 0xFF8A5A30, liquid = 0xFF52332A, surface = 0xFFE0AA78;
    }

    private static final Live LIVE = new Live();
    private static BlockPos pos;

    private LiveMachine() {}

    public static Live claim(BlockPos p) {
        if (!p.equals(pos)) {
            pos = p;
            LIVE.pumping = false;
            LIVE.level = 0.0;
        }
        return LIVE;
    }

    public static Live get(BlockPos p) {
        return p.equals(pos) ? LIVE : null;
    }

    public static void clear() {
        pos = null;
    }
}
