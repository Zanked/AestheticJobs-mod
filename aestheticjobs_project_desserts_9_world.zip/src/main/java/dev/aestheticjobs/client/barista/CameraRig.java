package dev.aestheticjobs.client.barista;

import dev.aestheticjobs.block.CoffeeMachineBlock;
import com.mojang.blaze3d.platform.Window;
import com.mojang.math.Axis;
import javax.annotation.Nullable;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.client.event.RenderPlayerEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import org.joml.Vector3f;

/**
 * The camera of the "world mode": while a step is played ON the real machine the camera flies from the player's eyes
 * to a close-up of the machine and the screen shows only a thin HUD. The camera is a client-only dummy entity
 * (never added to the level), so no mixin is needed. Poses are given in the 16-pixel space of the NORTH-facing
 * machine (the same space the CoffeeMachineRenderer draws in) and turned to the facing of the block.
 *
 * Also answers "where on the screen is this point of the machine" (project), so the HUD can hang a button on the
 * real portafilter, and carries the small effects of the camera: shake, punch, steam puffs.
 */
public final class CameraRig {
    /** Switch for the whole world mode; false = every step stays on the flat panel (the old behaviour). */
    public static boolean ENABLED = true;

    /** Camera and target in machine pixels (x right, y up, z toward the barista is NEGATIVE), vertical fov in degrees. */
    public record Shot(double cx, double cy, double cz, double tx, double ty, double tz, double fov) {}

    /** The group head: the cup, the portafilter and the two streams, seen from above and a little to the right. */
    public static final Shot GROUP = new Shot(11.5, 12.5, -3.5, 8.0, 3.9, 2.5, 50.0);

    private static final double FOLLOW = 5.0;           // how fast the camera flies (1 / seconds)

    private static boolean active;
    private static ArmorStand rig;
    private static Entity savedCamera;
    private static CameraType savedType;
    // where the camera is (smoothed), and what the last drawn frame was drawn from (see update)
    private static double px, py, pz, fov;
    private static float yaw, pitch;
    private static double sx, sy, sz, sfov;
    private static float syaw, spitch;
    private static double rfov;
    private static float shake, punch;

    private CameraRig() {}

    public static boolean isActive() { return active; }

    // ------------------------------------------------------------------ events (registered in AestheticJobs)

    public static void onFov(ViewportEvent.ComputeFov event) {
        if (active) event.setFOV(rfov);
    }

    /** The barista does not stand in his own shot. */
    public static void onRenderPlayer(RenderPlayerEvent.Pre event) {
        if (active && event.getEntity() == Minecraft.getInstance().player) event.setCanceled(true);
    }

    // ------------------------------------------------------------------ effects

    /** A short shake of the camera (0..1); call it every frame to hold a rumble. */
    public static void shake(float amount) {
        shake = Math.max(shake, Math.min(1.0F, amount));
    }

    /** A zoom punch: 1 = in (a perfect result), -1 = out. */
    public static void kick(float strength) {
        punch = strength;
    }

    /** A small puff of steam at a point of the machine. */
    public static void steam(BlockPos pos, double lx, double ly, double lz) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Direction facing = facing(pos);
        if (facing == null) return;
        Vec3 p = local(pos, facing, lx, ly, lz);
        mc.level.addParticle(ParticleTypes.CLOUD, p.x + (Math.random() - 0.5) * 0.03, p.y, p.z + (Math.random() - 0.5) * 0.03,
                0.0, 0.012, 0.0);
    }

    // ------------------------------------------------------------------ the rig

    /** Call once per frame from the screen: shot = where the camera should be, null = give the camera back. */
    public static void update(float dt, BlockPos pos, @Nullable Shot shot) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) {
            active = false;
            rig = null;
            return;
        }
        Direction facing = facing(pos);
        if (shot == null || !ENABLED || facing == null) {
            if (active) release();
            return;
        }
        if (!active) start(mc);

        // what is on the screen right now was drawn from the pose of the previous call
        sx = px; sy = py; sz = pz; syaw = yaw; spitch = pitch; sfov = rfov;

        Vec3 cam = local(pos, facing, shot.cx(), shot.cy(), shot.cz());
        Vec3 tgt = local(pos, facing, shot.tx(), shot.ty(), shot.tz());
        double dx = tgt.x - cam.x, dy = tgt.y - cam.y, dz = tgt.z - cam.z;
        float wantYaw = (float) (Mth.atan2(-dx, dz) * 180.0 / Math.PI);
        float wantPitch = (float) (-(Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI));

        double k = 1.0 - Math.exp(-dt * FOLLOW);
        px += (cam.x - px) * k;
        py += (cam.y - py) * k;
        pz += (cam.z - pz) * k;
        yaw += Mth.wrapDegrees(wantYaw - yaw) * (float) k;
        pitch += (wantPitch - pitch) * (float) k;
        fov += (shot.fov() - fov) * k;
        punch *= (float) Math.exp(-dt * 6.0);
        shake *= (float) Math.exp(-dt * 8.0);
        apply();
    }

    private static void start(Minecraft mc) {
        savedCamera = mc.getCameraEntity();
        savedType = mc.options.getCameraType();
        mc.options.setCameraType(CameraType.FIRST_PERSON);
        rig = new ArmorStand(EntityType.ARMOR_STAND, mc.level);
        var cam = mc.gameRenderer.getMainCamera();
        Vec3 p = cam.getPosition();
        px = p.x; py = p.y; pz = p.z;
        yaw = cam.getYRot();
        pitch = cam.getXRot();
        fov = mc.options.fov().get();
        rfov = fov;
        sx = px; sy = py; sz = pz; syaw = yaw; spitch = pitch; sfov = fov;
        shake = 0.0F;
        punch = 0.0F;
        active = true;
        mc.setCameraEntity(rig);
        mc.gameRenderer.setRenderHand(false);
        apply();
    }

    /** Puts the dummy entity where the camera is (the camera of the game follows its eyes). */
    private static void apply() {
        if (rig == null) return;
        double ox = (Math.random() - 0.5) * 2.0 * shake * 0.004;
        double oy = (Math.random() - 0.5) * 2.0 * shake * 0.004;
        float oyaw = (float) ((Math.random() - 0.5) * 2.0 * shake * 0.5);
        float opitch = (float) ((Math.random() - 0.5) * 2.0 * shake * 0.5);
        rig.setPos(px + ox, py + oy - rig.getEyeHeight(), pz);
        rig.xo = rig.xOld = rig.getX();
        rig.yo = rig.yOld = rig.getY();
        rig.zo = rig.zOld = rig.getZ();
        float y = yaw + oyaw, p = pitch + opitch;
        rig.setYRot(y);
        rig.yRotO = y;
        rig.setYHeadRot(y);
        rig.yHeadRotO = y;
        rig.setXRot(p);
        rig.xRotO = p;
        rfov = fov - punch * 5.0;
    }

    /** Gives the camera back to the player. Safe to call at any time. */
    public static void release() {
        Minecraft mc = Minecraft.getInstance();
        if (active && mc.player != null) {
            mc.setCameraEntity(savedCamera != null ? savedCamera : mc.player);
            if (savedType != null) mc.options.setCameraType(savedType);
        }
        mc.gameRenderer.setRenderHand(true);
        active = false;
        rig = null;
        savedCamera = null;
        savedType = null;
        shake = 0.0F;
        punch = 0.0F;
    }

    // ------------------------------------------------------------------ machine space

    @Nullable
    private static Direction facing(BlockPos pos) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return null;
        BlockState st = mc.level.getBlockState(pos);
        return st.hasProperty(CoffeeMachineBlock.FACING) ? st.getValue(CoffeeMachineBlock.FACING) : null;
    }

    private static int yRot(Direction facing) {
        return switch (facing) {
            case EAST -> 90;
            case SOUTH -> 180;
            case WEST -> 270;
            default -> 0;
        };
    }

    /** A point in machine pixels of the north-facing machine -> the world (the same turn the renderer does). */
    private static Vec3 local(BlockPos pos, Direction facing, double lx, double ly, double lz) {
        Vector3f v = new Vector3f((float) (lx / 16.0 - 0.5), (float) (ly / 16.0), (float) (lz / 16.0 - 0.5));
        Axis.YP.rotationDegrees(-yRot(facing)).transform(v);
        return new Vec3(pos.getX() + 0.5 + v.x, pos.getY() + v.y, pos.getZ() + 0.5 + v.z);
    }

    /** Where a point of the machine is on the screen (gui coordinates), or null if it is behind the camera. */
    @Nullable
    public static float[] projectLocal(BlockPos pos, double lx, double ly, double lz) {
        if (!active) return null;
        Direction facing = facing(pos);
        if (facing == null) return null;
        Vec3 w = local(pos, facing, lx, ly, lz);
        double dx = w.x - sx, dy = w.y - sy, dz = w.z - sz;
        double yr = Math.toRadians(syaw), pr = Math.toRadians(spitch), cp = Math.cos(pr);
        double fx = -Math.sin(yr) * cp, fy = -Math.sin(pr), fz = Math.cos(yr) * cp;      // forward
        double rx = -Math.cos(yr), rz = -Math.sin(yr);                                     // right (y = 0)
        double ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy;                        // up = right x forward
        double zc = dx * fx + dy * fy + dz * fz;
        if (zc < 0.05) return null;
        double xc = dx * rx + dz * rz, yc = dx * ux + dy * uy + dz * uz;
        double th = Math.tan(Math.toRadians(sfov) / 2.0);
        Window win = Minecraft.getInstance().getWindow();
        double aspect = (double) win.getWidth() / (double) win.getHeight();
        double nx = xc / zc / (th * aspect), ny = yc / zc / th;
        return new float[]{(float) ((nx * 0.5 + 0.5) * win.getGuiScaledWidth()), (float) ((0.5 - ny * 0.5) * win.getGuiScaledHeight())};
    }
}
